import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function PricingComparison() {
  const [billingCycle, setBillingCycle] = useState('monthly');

  const calculateYearlyPrice = (monthlyPrice) => {
    const yearly = monthlyPrice * 12 * 0.84; // 16% discount
    return yearly.toFixed(2);
  };

  const plans = [
    {
      name: 'Starter',
      monthlyPrice: 29.99,
      popular: false,
      features: {
        brands: '1',
        platforms: '3',
        posts: 'Unlimited',
        aiCredits: '200',
        analytics: '30 days',
        teamMembers: '1',
        crm: false,
        automation: false,
        whiteLabel: false,
        prioritySupport: false,
        customAI: false,
        dedicatedManager: false
      }
    },
    {
      name: 'Entrepreneur',
      monthlyPrice: 59.99,
      popular: false,
      features: {
        brands: '2',
        platforms: '3',
        posts: 'Unlimited',
        aiCredits: '500',
        analytics: '60 days',
        teamMembers: '2',
        crm: true,
        automation: true,
        whiteLabel: false,
        prioritySupport: false,
        customAI: false,
        dedicatedManager: false
      }
    },
    {
      name: 'Pro',
      monthlyPrice: 99.99,
      popular: true,
      features: {
        brands: '3',
        platforms: '5',
        posts: 'Unlimited',
        aiCredits: '2,000',
        analytics: '90 days',
        teamMembers: '5',
        crm: true,
        automation: true,
        whiteLabel: false,
        prioritySupport: true,
        customAI: false,
        dedicatedManager: false
      }
    },
    {
      name: 'Agency',
      monthlyPrice: 199.99,
      popular: false,
      features: {
        brands: '6',
        platforms: '10',
        posts: 'Unlimited',
        aiCredits: '10,000',
        analytics: 'Unlimited',
        teamMembers: 'Unlimited',
        crm: true,
        automation: true,
        whiteLabel: true,
        prioritySupport: true,
        customAI: true,
        dedicatedManager: false
      }
    },
    {
      name: 'Enterprise',
      monthlyPrice: 399.99,
      startsAt: true,
      popular: false,
      features: {
        brands: 'Higher',
        platforms: 'Higher',
        posts: 'Unlimited',
        aiCredits: 'Unlimited',
        analytics: 'Unlimited',
        teamMembers: 'Unlimited',
        crm: true,
        automation: true,
        whiteLabel: true,
        prioritySupport: true,
        customAI: true,
        dedicatedManager: true
      }
    }
  ];

  const featureRows = [
    { key: 'brands', label: 'Brands/Accounts' },
    { key: 'platforms', label: 'Platforms' },
    { key: 'posts', label: 'Post Scheduling' },
    { key: 'aiCredits', label: 'AI Credits' },
    { key: 'analytics', label: 'Analytics Retention' },
    { key: 'teamMembers', label: 'Team Members' },
    { key: 'crm', label: 'CRM Integration' },
    { key: 'automation', label: 'Automation Rules' },
    { key: 'whiteLabel', label: 'White Label' },
    { key: 'prioritySupport', label: 'Priority Support' },
    { key: 'customAI', label: 'Custom AI Training' },
    { key: 'dedicatedManager', label: 'Dedicated Account Manager' }
  ];

  return (
    <div className="space-y-8">
      {/* Billing Toggle */}
      <div className="flex items-center justify-center gap-4">
        <span className={cn("text-sm font-medium", billingCycle === 'monthly' ? 'text-white' : 'text-slate-400')}>
          Monthly
        </span>
        <button
          onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
          className="relative w-14 h-7 bg-slate-700 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500"
        >
          <span
            className={cn(
              "absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform",
              billingCycle === 'yearly' && "translate-x-7"
            )}
          />
        </button>
        <span className={cn("text-sm font-medium", billingCycle === 'yearly' ? 'text-white' : 'text-slate-400')}>
          Yearly
        </span>
        {billingCycle === 'yearly' && (
          <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
            Save 16%
          </Badge>
        )}
      </div>

      {/* Comparison Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          {/* Header */}
          <thead>
            <tr>
              <th className="p-4 text-left text-white font-semibold bg-slate-900/50 border border-slate-800">
                Features
              </th>
              {plans.map((plan) => (
                <th
                  key={plan.name}
                  className={cn(
                    "p-4 text-center border border-slate-800 min-w-[180px]",
                    plan.popular ? "bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10" : "bg-slate-900/50"
                  )}
                >
                  {plan.popular && (
                    <Badge className="mb-2 bg-violet-600 text-white">Most Popular</Badge>
                  )}
                  <div className="text-white font-bold text-xl">{plan.name}</div>
                  <div className="mt-2">
                    <span className="text-3xl font-bold text-white">
                      {plan.startsAt && '+'}${billingCycle === 'monthly' 
                        ? plan.monthlyPrice 
                        : calculateYearlyPrice(plan.monthlyPrice)}
                    </span>
                    <span className="text-slate-400 ml-1">
                      /{billingCycle === 'monthly' ? 'mo' : 'yr'}
                    </span>
                  </div>
                  {billingCycle === 'yearly' && (
                    <div className="text-xs text-slate-400 mt-1">
                      ${plan.monthlyPrice}/mo billed annually
                    </div>
                  )}
                  <Button 
                    className={cn(
                      "mt-4 w-full",
                      plan.popular 
                        ? "bg-gradient-to-r from-violet-600 to-fuchsia-600" 
                        : "bg-slate-800 hover:bg-slate-700"
                    )}
                  >
                    Get Started
                  </Button>
                </th>
              ))}
            </tr>
          </thead>

          {/* Feature Rows */}
          <tbody>
            {featureRows.map((row, idx) => (
              <tr key={row.key} className={idx % 2 === 0 ? 'bg-slate-900/30' : 'bg-slate-900/50'}>
                <td className="p-4 text-slate-300 font-medium border border-slate-800">
                  {row.label}
                </td>
                {plans.map((plan) => (
                  <td key={plan.name} className="p-4 text-center border border-slate-800">
                    {typeof plan.features[row.key] === 'boolean' ? (
                      plan.features[row.key] ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto" />
                      ) : (
                        <X className="w-5 h-5 text-slate-600 mx-auto" />
                      )
                    ) : (
                      <span className="text-white font-medium">{plan.features[row.key]}</span>
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}