import React from 'react';
import { Facebook, Instagram, Youtube, Music, Pin, Linkedin, MessageCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const platformIcons = {
  facebook: { Icon: Facebook, color: 'text-blue-500' },
  instagram: { Icon: Instagram, color: 'text-pink-500' },
  youtube: { Icon: Youtube, color: 'text-red-500' },
  tiktok: { Icon: Music, color: 'text-slate-900 dark:text-white' },
  pinterest: { Icon: Pin, color: 'text-red-600' },
  linkedin: { Icon: Linkedin, color: 'text-blue-600' },
  threads: { Icon: MessageCircle, color: 'text-slate-900 dark:text-white' },
  whatsapp: { Icon: MessageCircle, color: 'text-green-500' },
};

const sizeClasses = {
  xs: 'w-3 h-3',
  sm: 'w-4 h-4',
  md: 'w-5 h-5',
  lg: 'w-6 h-6',
};

export default function PlatformIcon({ platform, size = 'md', className }) {
  const platformData = platformIcons[platform?.toLowerCase()];
  
  if (!platformData) return null;
  
  const { Icon, color } = platformData;
  
  return <Icon className={cn(sizeClasses[size], color, className)} />;
}