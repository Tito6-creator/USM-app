import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Upload, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function BrandKitEditor({ brandKit, onSave, onCancel, isSaving }) {
  const [formData, setFormData] = useState({
    name: brandKit?.name || '',
    tagline: brandKit?.tagline || '',
    logo_url: brandKit?.logo_url || '',
    logo_dark_url: brandKit?.logo_dark_url || '',
    colors: {
      primary: brandKit?.colors?.primary || '#8b5cf6',
      secondary: brandKit?.colors?.secondary || '#ec4899',
      accent: brandKit?.colors?.accent || '#06b6d4',
      background: brandKit?.colors?.background || '#ffffff',
      text: brandKit?.colors?.text || '#000000',
    },
    fonts: {
      heading: brandKit?.fonts?.heading || 'Inter',
      body: brandKit?.fonts?.body || 'Inter',
    },
    brand_voice: brandKit?.brand_voice || 'professional',
    hashtags: brandKit?.hashtags || [],
  });
  const [hashtagInput, setHashtagInput] = useState('');
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingLogoDark, setUploadingLogoDark] = useState(false);

  const handleLogoUpload = async (e, isDark = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (isDark) setUploadingLogoDark(true);
    else setUploadingLogo(true);

    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({
        ...prev,
        [isDark ? 'logo_dark_url' : 'logo_url']: file_url
      }));
      toast.success('Logo uploaded successfully');
    } catch (error) {
      toast.error('Failed to upload logo');
    } finally {
      if (isDark) setUploadingLogoDark(false);
      else setUploadingLogo(false);
    }
  };

  const addHashtag = () => {
    if (hashtagInput.trim()) {
      const tag = hashtagInput.trim().replace('#', '');
      if (!formData.hashtags.includes(tag)) {
        setFormData(prev => ({
          ...prev,
          hashtags: [...prev.hashtags, tag]
        }));
      }
      setHashtagInput('');
    }
  };

  const removeHashtag = (tag) => {
    setFormData(prev => ({
      ...prev,
      hashtags: prev.hashtags.filter(t => t !== tag)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      toast.error('Please enter a brand kit name');
      return;
    }
    onSave(formData);
  };

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label className="text-slate-300">Brand Kit Name *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="My Brand Kit"
              className="bg-slate-800/50 border-slate-700 mt-2"
            />
          </div>
          <div>
            <Label className="text-slate-300">Brand Voice</Label>
            <Select 
              value={formData.brand_voice}
              onValueChange={(value) => setFormData(prev => ({ ...prev, brand_voice: value }))}
            >
              <SelectTrigger className="bg-slate-800/50 border-slate-700 mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="casual">Casual</SelectItem>
                <SelectItem value="authoritative">Authoritative</SelectItem>
                <SelectItem value="playful">Playful</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label className="text-slate-300">Tagline</Label>
          <Input
            value={formData.tagline}
            onChange={(e) => setFormData(prev => ({ ...prev, tagline: e.target.value }))}
            placeholder="Your brand tagline"
            className="bg-slate-800/50 border-slate-700 mt-2"
          />
        </div>

        {/* Logos */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label className="text-slate-300">Logo (Light)</Label>
            <div className="mt-2 space-y-3">
              {formData.logo_url ? (
                <div className="relative">
                  <img 
                    src={formData.logo_url} 
                    alt="Logo" 
                    className="w-full h-32 object-contain bg-white rounded-lg border border-slate-700"
                  />
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, logo_url: '' }))}
                    className="absolute top-2 right-2 p-1 bg-slate-900 rounded-full text-slate-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center h-32 border-2 border-dashed border-slate-700 rounded-lg cursor-pointer hover:border-slate-600 transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleLogoUpload(e, false)}
                    className="hidden"
                    disabled={uploadingLogo}
                  />
                  {uploadingLogo ? (
                    <Loader2 className="w-6 h-6 text-slate-400 animate-spin" />
                  ) : (
                    <>
                      <Upload className="w-6 h-6 text-slate-400 mb-2" />
                      <span className="text-sm text-slate-400">Upload logo</span>
                    </>
                  )}
                </label>
              )}
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Logo (Dark)</Label>
            <div className="mt-2 space-y-3">
              {formData.logo_dark_url ? (
                <div className="relative">
                  <img 
                    src={formData.logo_dark_url} 
                    alt="Logo Dark" 
                    className="w-full h-32 object-contain bg-slate-950 rounded-lg border border-slate-700"
                  />
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, logo_dark_url: '' }))}
                    className="absolute top-2 right-2 p-1 bg-slate-900 rounded-full text-slate-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center h-32 border-2 border-dashed border-slate-700 rounded-lg cursor-pointer hover:border-slate-600 transition-colors">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleLogoUpload(e, true)}
                    className="hidden"
                    disabled={uploadingLogoDark}
                  />
                  {uploadingLogoDark ? (
                    <Loader2 className="w-6 h-6 text-slate-400 animate-spin" />
                  ) : (
                    <>
                      <Upload className="w-6 h-6 text-slate-400 mb-2" />
                      <span className="text-sm text-slate-400">Upload dark logo</span>
                    </>
                  )}
                </label>
              )}
            </div>
          </div>
        </div>

        {/* Colors */}
        <div>
          <Label className="text-slate-300 mb-3 block">Brand Colors</Label>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {Object.entries(formData.colors).map(([name, color]) => (
              <div key={name}>
                <Label className="text-slate-400 text-xs capitalize mb-2 block">{name}</Label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={color}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      colors: { ...prev.colors, [name]: e.target.value }
                    }))}
                    className="w-12 h-10 rounded cursor-pointer border border-slate-700"
                  />
                  <Input
                    value={color}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      colors: { ...prev.colors, [name]: e.target.value }
                    }))}
                    className="flex-1 bg-slate-800/50 border-slate-700 text-xs"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fonts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <Label className="text-slate-300">Heading Font</Label>
            <Input
              value={formData.fonts.heading}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                fonts: { ...prev.fonts, heading: e.target.value }
              }))}
              placeholder="Inter, Arial, etc."
              className="bg-slate-800/50 border-slate-700 mt-2"
            />
          </div>
          <div>
            <Label className="text-slate-300">Body Font</Label>
            <Input
              value={formData.fonts.body}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                fonts: { ...prev.fonts, body: e.target.value }
              }))}
              placeholder="Inter, Arial, etc."
              className="bg-slate-800/50 border-slate-700 mt-2"
            />
          </div>
        </div>

        {/* Hashtags */}
        <div>
          <Label className="text-slate-300">Brand Hashtags</Label>
          <div className="flex gap-2 mt-2">
            <Input
              value={hashtagInput}
              onChange={(e) => setHashtagInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addHashtag())}
              placeholder="Add hashtag"
              className="bg-slate-800/50 border-slate-700"
            />
            <Button type="button" onClick={addHashtag} variant="outline" className="border-slate-700">
              Add
            </Button>
          </div>
          {formData.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {formData.hashtags.map((tag) => (
                <Badge 
                  key={tag} 
                  variant="outline" 
                  className="border-slate-700 text-slate-300 pl-3 pr-1 py-1"
                >
                  #{tag}
                  <button
                    type="button"
                    onClick={() => removeHashtag(tag)}
                    className="ml-2 text-slate-500 hover:text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isSaving}
            className="border-slate-700"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            disabled={isSaving}
            className="bg-violet-600 hover:bg-violet-700"
          >
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Brand Kit'
            )}
          </Button>
        </div>
      </form>
    </Card>
  );
}