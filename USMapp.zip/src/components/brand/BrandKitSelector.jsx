import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Palette, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function BrandKitSelector({ onApply, selectedKitId }) {
  const { data: brandKits = [] } = useQuery({
    queryKey: ['brand-kits'],
    queryFn: () => base44.entities.BrandKit.list('-created_date'),
  });

  if (brandKits.length === 0) {
    return (
      <Card className="p-6 bg-slate-900/50 border-slate-800 text-center">
        <Palette className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <p className="text-sm text-slate-400">No brand kits available</p>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {brandKits.map((kit) => (
        <Card 
          key={kit.id}
          className={cn(
            "p-4 bg-slate-900/50 border-slate-800 cursor-pointer transition-all hover:border-slate-700",
            selectedKitId === kit.id && "border-violet-500/30 bg-violet-500/5"
          )}
          onClick={() => onApply(kit)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              {kit.logo_url && (
                <div className="w-12 h-12 rounded-lg bg-white flex items-center justify-center overflow-hidden">
                  <img src={kit.logo_url} alt={kit.name} className="w-full h-full object-contain p-1" />
                </div>
              )}
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-semibold text-white">{kit.name}</span>
                  {kit.is_active && (
                    <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                      Active
                    </Badge>
                  )}
                </div>
                {kit.colors && (
                  <div className="flex gap-1">
                    {Object.values(kit.colors).slice(0, 5).map((color, idx) => (
                      <div
                        key={idx}
                        className="w-5 h-5 rounded border border-slate-700"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
            {selectedKitId === kit.id && (
              <Check className="w-5 h-5 text-violet-400" />
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}