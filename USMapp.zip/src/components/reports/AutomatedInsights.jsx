import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { format, subDays, subMonths } from 'date-fns';
import {
  Sparkles,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Lightbulb,
  Target,
  Zap,
  RefreshCw,
  Loader2,
  CheckCircle,
  ArrowUpRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { toast } from 'sonner';

const insightTypes = {
  success: { icon: CheckCircle, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
  warning: { icon: AlertTriangle, color: 'text-amber-400', bg: 'bg-amber-500/10' },
  opportunity: { icon: Lightbulb, color: 'text-violet-400', bg: 'bg-violet-500/10' },
  improvement: { icon: Target, color: 'text-cyan-400', bg: 'bg-cyan-500/10' }
};

export default function AutomatedInsights({ period = 'week', data }) {
  const [insights, setInsights] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateInsights = async () => {
    setIsGenerating(true);

    const {
      posts = [],
      competitors = [],
      leads = [],
      chatbotConfigs = [],
      accounts = [],
      alerts = []
    } = data;

    const periodLabel = period === 'week' ? 'past 7 days' : 'past 30 days';
    const periodStart = period === 'week' ? subDays(new Date(), 7) : subMonths(new Date(), 1);

    // Calculate metrics
    const recentPosts = posts.filter(p => new Date(p.created_date) > periodStart);
    const publishedPosts = recentPosts.filter(p => p.status === 'published');
    const avgEngagement = publishedPosts.length > 0
      ? publishedPosts.reduce((a, p) => a + (p.engagement_rate || 0), 0) / publishedPosts.length
      : 0;

    const recentLeads = leads.filter(l => new Date(l.created_date) > periodStart);
    const qualifiedLeads = recentLeads.filter(l => l.status === 'qualified' || l.status === 'converted');

    const totalFollowers = accounts.reduce((a, acc) => a + (acc.followers_count || 0), 0);
    const totalReach = publishedPosts.reduce((a, p) => a + (p.reach || 0), 0);

    const prompt = `Analyze this social media marketing performance data for the ${periodLabel} and provide strategic insights:

CONTENT PERFORMANCE:
- Total posts: ${recentPosts.length}
- Published posts: ${publishedPosts.length}
- Average engagement rate: ${avgEngagement.toFixed(2)}%
- Total reach: ${totalReach.toLocaleString()}
- Platforms: ${[...new Set(publishedPosts.flatMap(p => p.platforms || []))].join(', ')}

AUDIENCE GROWTH:
- Total followers: ${totalFollowers.toLocaleString()}
- Connected accounts: ${accounts.length}

LEAD GENERATION:
- New leads: ${recentLeads.length}
- Qualified leads: ${qualifiedLeads.length}
- Conversion rate: ${recentLeads.length > 0 ? ((qualifiedLeads.length / recentLeads.length) * 100).toFixed(1) : 0}%

COMPETITOR INSIGHTS:
- Tracked competitors: ${competitors.length}
- Active trend alerts: ${alerts.length}

CHATBOT PERFORMANCE:
- Active chatbots: ${chatbotConfigs.filter(c => c.is_active).length}
- Total conversations: ${chatbotConfigs.reduce((a, c) => a + (c.total_conversations || 0), 0)}
- Leads captured: ${chatbotConfigs.reduce((a, c) => a + (c.leads_captured || 0), 0)}

Provide:
1. Overall performance summary (2-3 sentences)
2. 3-5 key successes with specific metrics
3. 3-5 areas for improvement with specific recommendations
4. 3-5 opportunities to leverage based on data
5. Performance score (0-100)
6. Top 3 priority actions for next ${period === 'week' ? 'week' : 'month'}

Be specific, data-driven, and actionable.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          performance_score: { type: 'number' },
          successes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                metric: { type: 'string' }
              }
            }
          },
          improvements: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                recommendation: { type: 'string' },
                priority: { type: 'string' }
              }
            }
          },
          opportunities: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                potential_impact: { type: 'string' }
              }
            }
          },
          priority_actions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                action: { type: 'string' },
                rationale: { type: 'string' },
                expected_outcome: { type: 'string' }
              }
            }
          }
        }
      }
    });

    setInsights(result);
    setIsGenerating(false);
    toast.success('Insights generated!');
  };

  if (!insights) {
    return (
      <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 p-8 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-2">AI Performance Analysis</h3>
        <p className="text-slate-400 mb-6">
          Generate comprehensive insights across all your marketing activities
        </p>
        <Button
          onClick={generateInsights}
          disabled={isGenerating}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing Performance...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Insights
            </>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Score */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold text-white mb-1">Performance Insights</h3>
          <p className="text-sm text-slate-400">AI-generated analysis for {period === 'week' ? 'this week' : 'this month'}</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-1">{insights.performance_score}</div>
            <div className="text-xs text-slate-400">Performance Score</div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={generateInsights}
            disabled={isGenerating}
            className="border-slate-700"
          >
            <RefreshCw className={cn("w-4 h-4", isGenerating && "animate-spin")} />
          </Button>
        </div>
      </div>

      {/* Summary */}
      <div className="p-5 rounded-xl bg-slate-800/50 border border-slate-700">
        <div className="flex items-start gap-3">
          <Zap className="w-5 h-5 text-violet-400 mt-1 flex-shrink-0" />
          <div>
            <h4 className="font-medium text-white mb-2">Executive Summary</h4>
            <p className="text-slate-300 leading-relaxed">{insights.summary}</p>
          </div>
        </div>
      </div>

      {/* Insights Accordion */}
      <Accordion type="multiple" defaultValue={['successes', 'priority']} className="space-y-4">
        {/* Successes */}
        <AccordionItem value="successes" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-emerald-400" />
              <span className="font-medium text-white">Key Successes ({insights.successes?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {insights.successes?.map((success, i) => (
                <div key={i} className="p-4 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-white">{success.title}</h5>
                    {success.metric && (
                      <Badge className="bg-emerald-500/10 text-emerald-400 text-xs">
                        {success.metric}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-300">{success.description}</p>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Priority Actions */}
        <AccordionItem value="priority" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 text-rose-400" />
              <span className="font-medium text-white">Priority Actions ({insights.priority_actions?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {insights.priority_actions?.map((action, i) => (
                <div key={i} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-8 h-8 rounded-lg bg-rose-500/10 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-bold text-rose-400">{i + 1}</span>
                    </div>
                    <div className="flex-1">
                      <h5 className="font-medium text-white mb-1">{action.action}</h5>
                      <p className="text-sm text-slate-400 mb-2">{action.rationale}</p>
                      <div className="flex items-center gap-2 text-xs text-emerald-400">
                        <ArrowUpRight className="w-3 h-3" />
                        {action.expected_outcome}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Improvements */}
        <AccordionItem value="improvements" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              <span className="font-medium text-white">Areas for Improvement ({insights.improvements?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {insights.improvements?.map((item, i) => (
                <div key={i} className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-white">{item.title}</h5>
                    {item.priority && (
                      <Badge className={cn(
                        "text-xs",
                        item.priority === 'high' ? "bg-rose-500/10 text-rose-400" :
                        item.priority === 'medium' ? "bg-amber-500/10 text-amber-400" :
                        "bg-slate-500/10 text-slate-400"
                      )}>
                        {item.priority}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-300 mb-2">{item.description}</p>
                  <div className="p-3 rounded bg-slate-900/50 border border-slate-700">
                    <p className="text-xs text-slate-400 mb-1">Recommendation:</p>
                    <p className="text-sm text-slate-200">{item.recommendation}</p>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Opportunities */}
        <AccordionItem value="opportunities" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Lightbulb className="w-5 h-5 text-violet-400" />
              <span className="font-medium text-white">Opportunities ({insights.opportunities?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {insights.opportunities?.map((opp, i) => (
                <div key={i} className="p-4 rounded-lg bg-violet-500/5 border border-violet-500/20">
                  <h5 className="font-medium text-white mb-2">{opp.title}</h5>
                  <p className="text-sm text-slate-300 mb-3">{opp.description}</p>
                  <div className="flex items-center gap-2 text-xs text-violet-400">
                    <TrendingUp className="w-3 h-3" />
                    Potential Impact: {opp.potential_impact}
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}