import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function MetricsSummary({ current, previous, label, icon: Icon, format = 'number' }) {
  const change = previous > 0 ? ((current - previous) / previous) * 100 : 0;
  const isPositive = change > 0;
  const isNeutral = change === 0;

  const formatValue = (value) => {
    if (format === 'percentage') return `${value.toFixed(1)}%`;
    if (format === 'currency') return `$${value.toLocaleString()}`;
    if (format === 'large') {
      if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
      if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
      return value.toLocaleString();
    }
    return value.toLocaleString();
  };

  return (
    <div className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/50">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-slate-800/50 flex items-center justify-center">
          <Icon className="w-5 h-5 text-violet-400" />
        </div>
        <span className="text-slate-400 text-sm">{label}</span>
      </div>
      
      <div className="flex items-end justify-between">
        <div>
          <p className="text-3xl font-bold text-white mb-1">
            {formatValue(current)}
          </p>
          {previous > 0 && (
            <div className="flex items-center gap-1 text-sm">
              {isNeutral ? (
                <Minus className="w-4 h-4 text-slate-400" />
              ) : isPositive ? (
                <TrendingUp className="w-4 h-4 text-emerald-400" />
              ) : (
                <TrendingDown className="w-4 h-4 text-rose-400" />
              )}
              <span className={cn(
                "font-medium",
                isNeutral ? "text-slate-400" :
                isPositive ? "text-emerald-400" : "text-rose-400"
              )}>
                {Math.abs(change).toFixed(1)}%
              </span>
              <span className="text-slate-500">vs previous</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}