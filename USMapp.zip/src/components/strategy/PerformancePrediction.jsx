import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import {
  TrendingUp,
  TrendingDown,
  Target,
  Sparkles,
  Loader2,
  BarChart3,
  Heart,
  MessageCircle,
  Eye,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function PerformancePrediction() {
  const [postContent, setPostContent] = useState('');
  const [platform, setPlatform] = useState('instagram');
  const [isPredicting, setIsPredicting] = useState(false);
  const [prediction, setPrediction] = useState(null);

  const { data: historicalPosts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 100),
  });

  const { data: account } = useQuery({
    queryKey: ['account', platform],
    queryFn: () => base44.entities.SocialAccount.filter({ platform }).then(acc => acc[0]),
  });

  const predictPerformance = async () => {
    if (!postContent.trim()) {
      toast.error('Enter content to analyze');
      return;
    }

    setIsPredicting(true);
    toast.info('🤖 AI is predicting performance...');

    const platformPosts = historicalPosts.filter(p => p.platforms?.includes(platform));
    
    const historicalData = platformPosts.length > 0 ? `
Historical Performance (${platformPosts.length} posts):
Average Likes: ${Math.round(platformPosts.reduce((sum, p) => sum + (p.likes || 0), 0) / platformPosts.length)}
Average Comments: ${Math.round(platformPosts.reduce((sum, p) => sum + (p.comments || 0), 0) / platformPosts.length)}
Average Engagement Rate: ${(platformPosts.reduce((sum, p) => sum + (p.engagement_rate || 0), 0) / platformPosts.length).toFixed(2)}%
Best performing post: ${Math.max(...platformPosts.map(p => p.likes || 0))} likes
    ` : 'No historical data available';

    const prompt = `Predict social media post performance and provide recommendations:

PLANNED POST:
Platform: ${platform}
Content: "${postContent}"

ACCOUNT CONTEXT:
Followers: ${account?.followers_count || 'Unknown'}
Platform: ${platform}

HISTORICAL PERFORMANCE:
${historicalData}

Analyze this planned content and predict:

1. PERFORMANCE PREDICTION - Expected likes, comments, shares, reach (provide specific numbers)
2. CONFIDENCE SCORE - How confident are you in this prediction (0-100)
3. VIRAL POTENTIAL - Likelihood of viral spread (0-100)
4. ENGAGEMENT FACTORS - What elements will drive engagement
5. OPTIMIZATION SUGGESTIONS - Specific improvements to maximize performance
6. BEST POSTING TIME - When to post for maximum reach
7. RISKS - Potential issues or things that could hurt performance
8. COMPARISON - How this compares to your typical posts

Be specific with numbers and actionable advice.`;

    try {
      const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          predicted_likes: { type: 'number' },
          predicted_comments: { type: 'number' },
          predicted_shares: { type: 'number' },
          predicted_reach: { type: 'number' },
          predicted_engagement_rate: { type: 'number' },
          confidence_score: { type: 'number' },
          viral_potential: { type: 'number' },
          performance_category: { type: 'string', enum: ['poor', 'average', 'good', 'excellent', 'viral'] },
          engagement_factors: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                factor: { type: 'string' },
                impact: { type: 'string' },
                score: { type: 'number' }
              }
            }
          },
          optimization_suggestions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                suggestion: { type: 'string' },
                expected_impact: { type: 'string' },
                priority: { type: 'string' }
              }
            }
          },
          best_posting_time: { type: 'string' },
          risks: { type: 'array', items: { type: 'string' } },
          comparison_to_average: { type: 'string' }
        }
      }
    });

      if (result) {
        setPrediction(result);
        toast.success('✅ Prediction complete!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Performance prediction error:', error);
      toast.error('❌ Failed to predict: ' + error.message);
    } finally {
      setIsPredicting(false);
    }
  };

  const performanceColors = {
    poor: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/20' },
    average: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' },
    good: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' },
    excellent: { bg: 'bg-violet-500/10', text: 'text-violet-400', border: 'border-violet-500/20' },
    viral: { bg: 'bg-fuchsia-500/10', text: 'text-fuchsia-400', border: 'border-fuchsia-500/20' }
  };

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Predict Post Performance</h3>
        
        <div className="space-y-4">
          <div>
            <Label className="text-slate-300 mb-2">Platform</Label>
            <Select value={platform} onValueChange={setPlatform}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                {['instagram', 'facebook', 'twitter', 'linkedin', 'tiktok'].map(p => (
                  <SelectItem key={p} value={p}>
                    <div className="flex items-center gap-2 capitalize">
                      <PlatformIcon platform={p} size="xs" />
                      {p}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-slate-300 mb-2">Post Content</Label>
            <Textarea
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder="Enter your planned post content..."
              className="bg-slate-800/50 border-slate-700 text-white min-h-[150px]"
            />
          </div>

          <Button
            onClick={predictPerformance}
            disabled={!postContent.trim() || isPredicting}
            className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            {isPredicting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Predict Performance
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Prediction Results */}
      {prediction && (
        <>
          {/* Performance Category */}
          <div className={cn(
            "rounded-2xl border p-6",
            performanceColors[prediction.performance_category].bg,
            performanceColors[prediction.performance_category].border
          )}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold text-white capitalize mb-1">
                  {prediction.performance_category} Performance Expected
                </h3>
                <p className={cn("text-sm", performanceColors[prediction.performance_category].text)}>
                  {prediction.comparison_to_average}
                </p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-bold text-white">{prediction.confidence_score}%</p>
                <p className="text-sm text-slate-400">Confidence</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="text-sm text-slate-400 mb-1">Viral Potential</p>
                <div className="flex items-center gap-2">
                  <Progress value={prediction.viral_potential} className="flex-1 h-2" />
                  <span className="text-sm text-white">{prediction.viral_potential}%</span>
                </div>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Engagement Rate</p>
                <div className="flex items-center gap-2">
                  <Progress value={prediction.predicted_engagement_rate * 10} className="flex-1 h-2" />
                  <span className="text-sm text-white">{prediction.predicted_engagement_rate}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Predicted Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
              <Heart className="w-5 h-5 text-rose-400 mb-2" />
              <p className="text-2xl font-bold text-white">{prediction.predicted_likes.toLocaleString()}</p>
              <p className="text-sm text-slate-500">Likes</p>
            </div>
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
              <MessageCircle className="w-5 h-5 text-blue-400 mb-2" />
              <p className="text-2xl font-bold text-white">{prediction.predicted_comments.toLocaleString()}</p>
              <p className="text-sm text-slate-500">Comments</p>
            </div>
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
              <TrendingUp className="w-5 h-5 text-emerald-400 mb-2" />
              <p className="text-2xl font-bold text-white">{prediction.predicted_shares.toLocaleString()}</p>
              <p className="text-sm text-slate-500">Shares</p>
            </div>
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
              <Eye className="w-5 h-5 text-violet-400 mb-2" />
              <p className="text-2xl font-bold text-white">{prediction.predicted_reach.toLocaleString()}</p>
              <p className="text-sm text-slate-500">Reach</p>
            </div>
          </div>

          {/* Engagement Factors */}
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h4 className="font-semibold text-white mb-4">Engagement Drivers</h4>
            <div className="space-y-3">
              {prediction.engagement_factors?.map((factor, idx) => (
                <div key={idx} className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-white">{factor.factor}</span>
                      <span className="text-sm text-slate-400">{factor.score}/10</span>
                    </div>
                    <Progress value={factor.score * 10} className="h-2" />
                  </div>
                  <p className="text-xs text-slate-400 w-1/3">{factor.impact}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Optimization Suggestions */}
          <div className="rounded-2xl bg-violet-500/10 border border-violet-500/20 p-6">
            <div className="flex items-center gap-2 mb-4">
              <Target className="w-5 h-5 text-violet-400" />
              <h4 className="font-semibold text-white">Optimization Suggestions</h4>
            </div>
            <div className="space-y-3">
              {prediction.optimization_suggestions?.map((sug, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-900/50 border border-slate-700">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-white">{sug.suggestion}</h5>
                    <Badge className={cn(
                      sug.priority === 'high' ? 'bg-rose-500/10 text-rose-400' :
                      sug.priority === 'medium' ? 'bg-amber-500/10 text-amber-400' :
                      'bg-emerald-500/10 text-emerald-400'
                    )}>
                      {sug.priority}
                    </Badge>
                  </div>
                  <p className="text-sm text-emerald-400">{sug.expected_impact}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Risks and Best Time */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <div className="flex items-center gap-2 mb-4">
                <AlertCircle className="w-5 h-5 text-amber-400" />
                <h4 className="font-semibold text-white">Potential Risks</h4>
              </div>
              <ul className="space-y-2">
                {prediction.risks?.map((risk, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-slate-300">
                    <span className="text-amber-400 mt-1">•</span>
                    <span>{risk}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl bg-emerald-500/10 border border-emerald-500/20 p-6">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="w-5 h-5 text-emerald-400" />
                <h4 className="font-semibold text-white">Best Posting Time</h4>
              </div>
              <p className="text-2xl font-bold text-white mb-2">{prediction.best_posting_time}</p>
              <p className="text-sm text-emerald-400">Optimal time for maximum engagement</p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}