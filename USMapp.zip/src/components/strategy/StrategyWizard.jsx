import React, { useState } from 'react';
import { 
  Target, Users, Megaphone, ShoppingCart, Heart, MousePointer, UserPlus,
  ChevronRight, ChevronLeft, Sparkles, Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';

const goals = [
  { id: 'brand_awareness', name: 'Brand Awareness', icon: Megaphone, description: 'Increase visibility and recognition' },
  { id: 'engagement', name: 'Engagement', icon: Heart, description: 'Boost likes, comments, and shares' },
  { id: 'lead_generation', name: 'Lead Generation', icon: MousePointer, description: 'Capture potential customers' },
  { id: 'sales', name: 'Sales', icon: ShoppingCart, description: 'Drive revenue and conversions' },
  { id: 'community_building', name: 'Community', icon: Users, description: 'Build a loyal community' },
  { id: 'followers_growth', name: 'Followers Growth', icon: UserPlus, description: 'Grow your audience' },
];

const brandVoices = [
  { id: 'professional', name: 'Professional', description: 'Formal, authoritative, trustworthy' },
  { id: 'casual', name: 'Casual', description: 'Friendly, approachable, conversational' },
  { id: 'humorous', name: 'Humorous', description: 'Fun, witty, entertaining' },
  { id: 'inspirational', name: 'Inspirational', description: 'Motivating, uplifting, empowering' },
  { id: 'educational', name: 'Educational', description: 'Informative, helpful, expert' },
  { id: 'bold', name: 'Bold', description: 'Daring, provocative, attention-grabbing' },
];

const platforms = ['instagram', 'facebook', 'tiktok', 'youtube', 'linkedin', 'pinterest', 'threads'];

export default function StrategyWizard({ onComplete, isGenerating }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    goal: '',
    target_audience: '',
    industry: '',
    brand_voice: 'professional',
    platforms: [],
    budget_range: 'medium',
    duration_weeks: 4,
    additional_context: ''
  });

  const updateForm = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const togglePlatform = (platform) => {
    setFormData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platform)
        ? prev.platforms.filter(p => p !== platform)
        : [...prev.platforms, platform]
    }));
  };

  const canProceed = () => {
    switch (step) {
      case 1: return formData.goal;
      case 2: return formData.target_audience && formData.industry;
      case 3: return formData.platforms.length > 0;
      case 4: return formData.title;
      default: return true;
    }
  };

  const handleSubmit = () => {
    onComplete(formData);
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Progress */}
      <div className="flex items-center justify-between mb-8">
        {[1, 2, 3, 4].map((s) => (
          <React.Fragment key={s}>
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all",
              s < step ? "bg-violet-600 text-white" :
              s === step ? "bg-violet-600 text-white ring-4 ring-violet-600/20" :
              "bg-slate-800 text-slate-500"
            )}>
              {s}
            </div>
            {s < 4 && (
              <div className={cn(
                "flex-1 h-1 mx-2 rounded-full transition-all",
                s < step ? "bg-violet-600" : "bg-slate-800"
              )} />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Step 1: Goal Selection */}
      {step === 1 && (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">What's your primary goal?</h2>
            <p className="text-slate-400">Select the main objective for your marketing strategy</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {goals.map((goal) => (
              <button
                key={goal.id}
                onClick={() => updateForm('goal', goal.id)}
                className={cn(
                  "p-6 rounded-2xl border text-left transition-all",
                  formData.goal === goal.id
                    ? "border-violet-500 bg-violet-500/10"
                    : "border-slate-700 hover:border-slate-600 bg-slate-800/30"
                )}
              >
                <goal.icon className={cn(
                  "w-8 h-8 mb-3",
                  formData.goal === goal.id ? "text-violet-400" : "text-slate-400"
                )} />
                <h3 className="font-semibold text-white mb-1">{goal.name}</h3>
                <p className="text-sm text-slate-500">{goal.description}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Step 2: Audience & Industry */}
      {step === 2 && (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Define your audience</h2>
            <p className="text-slate-400">Help the AI understand who you're targeting</p>
          </div>
          
          <div className="space-y-6">
            <div>
              <Label className="text-white mb-2 block">Target Audience</Label>
              <Textarea
                value={formData.target_audience}
                onChange={(e) => updateForm('target_audience', e.target.value)}
                placeholder="e.g., Young professionals aged 25-35 interested in fitness and wellness, health-conscious millennials..."
                className="bg-slate-800/50 border-slate-700 text-white min-h-[100px]"
              />
            </div>
            
            <div>
              <Label className="text-white mb-2 block">Industry / Niche</Label>
              <Input
                value={formData.industry}
                onChange={(e) => updateForm('industry', e.target.value)}
                placeholder="e.g., Fitness & Wellness, E-commerce, SaaS, Fashion..."
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>

            <div>
              <Label className="text-white mb-4 block">Brand Voice</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {brandVoices.map((voice) => (
                  <button
                    key={voice.id}
                    onClick={() => updateForm('brand_voice', voice.id)}
                    className={cn(
                      "p-4 rounded-xl border text-left transition-all",
                      formData.brand_voice === voice.id
                        ? "border-violet-500 bg-violet-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    )}
                  >
                    <h4 className="font-medium text-white mb-1">{voice.name}</h4>
                    <p className="text-xs text-slate-500">{voice.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Platforms & Budget */}
      {step === 3 && (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Choose your platforms</h2>
            <p className="text-slate-400">Select where you want to focus your efforts</p>
          </div>
          
          <div>
            <Label className="text-white mb-4 block">Platforms</Label>
            <div className="flex flex-wrap gap-3">
              {platforms.map((platform) => (
                <button
                  key={platform}
                  onClick={() => togglePlatform(platform)}
                  className={cn(
                    "flex items-center gap-3 px-5 py-3 rounded-xl border transition-all",
                    formData.platforms.includes(platform)
                      ? "border-violet-500 bg-violet-500/10"
                      : "border-slate-700 hover:border-slate-600"
                  )}
                >
                  <PlatformIcon platform={platform} size="sm" />
                  <span className="text-white capitalize">{platform}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 mt-8">
            <div>
              <Label className="text-white mb-2 block">Budget Range</Label>
              <Select value={formData.budget_range} onValueChange={(v) => updateForm('budget_range', v)}>
                <SelectTrigger className="bg-slate-800/50 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="low">Low (Organic focus)</SelectItem>
                  <SelectItem value="medium">Medium (Some paid ads)</SelectItem>
                  <SelectItem value="high">High (Aggressive growth)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="text-white mb-2 block">Campaign Duration: {formData.duration_weeks} weeks</Label>
              <Slider
                value={[formData.duration_weeks]}
                onValueChange={([v]) => updateForm('duration_weeks', v)}
                min={1}
                max={12}
                step={1}
                className="mt-4"
              />
            </div>
          </div>
        </div>
      )}

      {/* Step 4: Final Details */}
      {step === 4 && (
        <div className="space-y-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Final touches</h2>
            <p className="text-slate-400">Add any additional context for better AI recommendations</p>
          </div>
          
          <div>
            <Label className="text-white mb-2 block">Strategy Name</Label>
            <Input
              value={formData.title}
              onChange={(e) => updateForm('title', e.target.value)}
              placeholder="e.g., Q1 2024 Growth Campaign"
              className="bg-slate-800/50 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-white mb-2 block">Additional Context (Optional)</Label>
            <Textarea
              value={formData.additional_context}
              onChange={(e) => updateForm('additional_context', e.target.value)}
              placeholder="Any specific products to promote, upcoming events, brand guidelines, competitors to watch..."
              className="bg-slate-800/50 border-slate-700 text-white min-h-[120px]"
            />
          </div>

          {/* Summary */}
          <div className="rounded-xl bg-slate-800/50 p-6 mt-6">
            <h3 className="font-semibold text-white mb-4">Strategy Summary</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-500">Goal:</span>
                <span className="text-white ml-2 capitalize">{formData.goal?.replace('_', ' ')}</span>
              </div>
              <div>
                <span className="text-slate-500">Voice:</span>
                <span className="text-white ml-2 capitalize">{formData.brand_voice}</span>
              </div>
              <div>
                <span className="text-slate-500">Industry:</span>
                <span className="text-white ml-2">{formData.industry}</span>
              </div>
              <div>
                <span className="text-slate-500">Duration:</span>
                <span className="text-white ml-2">{formData.duration_weeks} weeks</span>
              </div>
              <div className="col-span-2">
                <span className="text-slate-500">Platforms:</span>
                <span className="text-white ml-2 capitalize">{formData.platforms.join(', ')}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <div className="flex justify-between mt-8">
        <Button
          variant="ghost"
          onClick={() => setStep(s => s - 1)}
          disabled={step === 1}
          className="text-slate-400"
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        
        {step < 4 ? (
          <Button
            onClick={() => setStep(s => s + 1)}
            disabled={!canProceed()}
            className="bg-violet-600 hover:bg-violet-700"
          >
            Continue
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            disabled={!canProceed() || isGenerating}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Strategy...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate AI Strategy
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}