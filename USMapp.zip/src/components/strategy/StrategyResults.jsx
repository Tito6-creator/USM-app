import React, { useState } from 'react';
import { format } from 'date-fns';
import {
  Clock,
  Hash,
  Lightbulb,
  MessageSquare,
  Target,
  TrendingUp,
  Calendar,
  Zap,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Sparkles,
  BarChart3,
  Users,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const dayColors = {
  Monday: 'from-blue-500 to-cyan-500',
  Tuesday: 'from-violet-500 to-purple-500',
  Wednesday: 'from-emerald-500 to-teal-500',
  Thursday: 'from-orange-500 to-amber-500',
  Friday: 'from-rose-500 to-pink-500',
  Saturday: 'from-indigo-500 to-blue-500',
  Sunday: 'from-fuchsia-500 to-pink-500',
};

export default function StrategyResults({ strategy, onCreateCampaign }) {
  const [copiedItem, setCopiedItem] = useState(null);

  const copyToClipboard = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedItem(id);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopiedItem(null), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">{strategy.title}</h1>
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20 capitalize">
                  {strategy.goal?.replace('_', ' ')}
                </Badge>
                <span>•</span>
                <span>{strategy.duration_weeks} weeks</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Zap className="w-3 h-3 text-amber-400" />
                  {strategy.ai_confidence_score}% confidence
                </span>
              </div>
            </div>
          </div>
        </div>
        <Button 
          onClick={() => onCreateCampaign(strategy)}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          <Target className="w-4 h-4 mr-2" />
          Create Campaign from Strategy
        </Button>
      </div>

      {/* KPI Targets */}
      {strategy.kpi_targets && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
            <Users className="w-5 h-5 text-violet-400 mb-2" />
            <p className="text-2xl font-bold text-white">+{strategy.kpi_targets.followers_growth}%</p>
            <p className="text-sm text-slate-500">Followers Growth</p>
          </div>
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
            <TrendingUp className="w-5 h-5 text-emerald-400 mb-2" />
            <p className="text-2xl font-bold text-white">{strategy.kpi_targets.engagement_rate}%</p>
            <p className="text-sm text-slate-500">Target Eng. Rate</p>
          </div>
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
            <Eye className="w-5 h-5 text-cyan-400 mb-2" />
            <p className="text-2xl font-bold text-white">+{strategy.kpi_targets.reach_increase}%</p>
            <p className="text-sm text-slate-500">Reach Increase</p>
          </div>
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-5">
            <BarChart3 className="w-5 h-5 text-rose-400 mb-2" />
            <p className="text-2xl font-bold text-white">{strategy.kpi_targets.conversions}</p>
            <p className="text-sm text-slate-500">Target Conversions</p>
          </div>
        </div>
      )}

      <Tabs defaultValue="schedule" className="space-y-6">
        <TabsList className="bg-slate-800/50 p-1">
          <TabsTrigger value="schedule" className="data-[state=active]:bg-violet-600">
            <Clock className="w-4 h-4 mr-2" />
            Optimal Times
          </TabsTrigger>
          <TabsTrigger value="themes" className="data-[state=active]:bg-violet-600">
            <Lightbulb className="w-4 h-4 mr-2" />
            Content Themes
          </TabsTrigger>
          <TabsTrigger value="captions" className="data-[state=active]:bg-violet-600">
            <MessageSquare className="w-4 h-4 mr-2" />
            Captions
          </TabsTrigger>
          <TabsTrigger value="hashtags" className="data-[state=active]:bg-violet-600">
            <Hash className="w-4 h-4 mr-2" />
            Hashtags
          </TabsTrigger>
          <TabsTrigger value="campaigns" className="data-[state=active]:bg-violet-600">
            <Target className="w-4 h-4 mr-2" />
            Campaign Ideas
          </TabsTrigger>
        </TabsList>

        {/* Optimal Posting Times */}
        <TabsContent value="schedule">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-6">Optimal Posting Schedule</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {strategy.optimal_posting_times?.map((slot, index) => (
                <div
                  key={index}
                  className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className={cn(
                      "px-3 py-1 rounded-lg text-xs font-medium text-white",
                      `bg-gradient-to-r ${dayColors[slot.day] || 'from-slate-600 to-slate-700'}`
                    )}>
                      {slot.day}
                    </div>
                    <PlatformIcon platform={slot.platform} size="sm" />
                  </div>
                  <p className="text-2xl font-bold text-white mb-1">{slot.time}</p>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-full"
                        style={{ width: `${slot.engagement_score}%` }}
                      />
                    </div>
                    <span className="text-xs text-slate-400">{slot.engagement_score}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Content Themes */}
        <TabsContent value="themes">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-6">Recommended Content Themes</h3>
            
            <div className="space-y-4">
              {strategy.content_themes?.map((theme, index) => (
                <div
                  key={index}
                  className="p-5 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold text-white text-lg mb-2">{theme.theme}</h4>
                      <p className="text-slate-400 mb-3">{theme.description}</p>
                      <div className="flex items-center gap-3 flex-wrap">
                        <Badge variant="outline" className="border-violet-500/30 text-violet-400">
                          {theme.frequency}
                        </Badge>
                        {theme.content_types?.map((type, i) => (
                          <Badge key={i} className="bg-slate-700 text-slate-300">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 flex items-center justify-center">
                      <Lightbulb className="w-6 h-6 text-violet-400" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Caption Templates */}
        <TabsContent value="captions">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-6">Caption Templates</h3>
            
            <div className="space-y-4">
              {strategy.caption_templates?.map((caption, index) => (
                <div
                  key={index}
                  className="p-5 rounded-xl bg-slate-800/50"
                >
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/20">
                      {caption.type}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(caption.template, `caption-${index}`)}
                      className="text-slate-400 hover:text-white"
                    >
                      {copiedItem === `caption-${index}` ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-white mb-2 whitespace-pre-wrap">{caption.template}</p>
                  <p className="text-sm text-slate-500">Use for: {caption.use_case}</p>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Hashtags */}
        <TabsContent value="hashtags">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-6">Recommended Hashtags</h3>
            
            <div className="space-y-6">
              {/* Group by category */}
              {Object.entries(
                (strategy.recommended_hashtags || []).reduce((acc, tag) => {
                  const cat = tag.category || 'General';
                  if (!acc[cat]) acc[cat] = [];
                  acc[cat].push(tag);
                  return acc;
                }, {})
              ).map(([category, tags]) => (
                <div key={category}>
                  <h4 className="text-sm font-medium text-slate-400 mb-3">{category}</h4>
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag, index) => (
                      <button
                        key={index}
                        onClick={() => copyToClipboard(`#${tag.hashtag}`, `tag-${tag.hashtag}`)}
                        className={cn(
                          "px-4 py-2 rounded-xl border transition-all group",
                          "border-slate-700 hover:border-violet-500 hover:bg-violet-500/10"
                        )}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-violet-400">#</span>
                          <span className="text-white">{tag.hashtag}</span>
                          {copiedItem === `tag-${tag.hashtag}` ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3 text-slate-500 opacity-0 group-hover:opacity-100" />
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
                          <span>{(tag.estimated_reach / 1000).toFixed(0)}K reach</span>
                          <span>•</span>
                          <span className={cn(
                            tag.competition === 'low' ? 'text-emerald-400' :
                            tag.competition === 'medium' ? 'text-amber-400' : 'text-rose-400'
                          )}>
                            {tag.competition} competition
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <Button
              variant="outline"
              className="w-full mt-6 border-slate-700"
              onClick={() => {
                const allTags = strategy.recommended_hashtags?.map(t => `#${t.hashtag}`).join(' ');
                copyToClipboard(allTags, 'all-tags');
              }}
            >
              {copiedItem === 'all-tags' ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy All Hashtags
                </>
              )}
            </Button>
          </div>
        </TabsContent>

        {/* Campaign Ideas */}
        <TabsContent value="campaigns">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-6">AI-Generated Campaign Ideas</h3>
            
            <Accordion type="single" collapsible className="space-y-4">
              {strategy.campaign_ideas?.map((campaign, index) => (
                <AccordionItem 
                  key={index} 
                  value={`campaign-${index}`}
                  className="border border-slate-800 rounded-xl overflow-hidden"
                >
                  <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
                    <div className="flex items-center gap-4 text-left">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center flex-shrink-0">
                        <Target className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white">{campaign.name}</h4>
                        <p className="text-sm text-slate-400">{campaign.objective}</p>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="px-5 pb-5">
                    <div className="space-y-4 pt-2">
                      <p className="text-slate-300">{campaign.description}</p>
                      
                      <div className="flex items-center gap-4">
                        <Badge variant="outline" className="border-slate-700">
                          <Calendar className="w-3 h-3 mr-1" />
                          {campaign.duration_days} days
                        </Badge>
                      </div>
                      
                      <div>
                        <h5 className="text-sm font-medium text-slate-400 mb-2">Content Plan</h5>
                        <ul className="space-y-2">
                          {campaign.content_plan?.map((item, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
                              <div className="w-5 h-5 rounded-full bg-violet-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                                <span className="text-xs text-violet-400">{i + 1}</span>
                              </div>
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                        <h5 className="text-sm font-medium text-emerald-400 mb-1">Expected Results</h5>
                        <p className="text-sm text-slate-300">{campaign.expected_results}</p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </TabsContent>
      </Tabs>

      {/* Trend Recommendations */}
      {strategy.trend_recommendations?.length > 0 && (
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="w-5 h-5 text-violet-400" />
            <h3 className="text-lg font-semibold text-white">Trending Opportunities</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {strategy.trend_recommendations.map((trend, index) => (
              <div
                key={index}
                className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span className="font-medium text-white">{trend.trend}</span>
                </div>
                <p className="text-sm text-slate-400 mb-2">{trend.relevance}</p>
                <p className="text-sm text-violet-300">{trend.how_to_leverage}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Competitor Insights */}
      {strategy.competitor_insights?.length > 0 && (
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center gap-2 mb-6">
            <Eye className="w-5 h-5 text-violet-400" />
            <h3 className="text-lg font-semibold text-white">Competitor Insights</h3>
          </div>
          
          <div className="space-y-3">
            {strategy.competitor_insights.map((insight, index) => (
              <div
                key={index}
                className="p-4 rounded-xl bg-slate-800/50 flex items-start gap-4"
              >
                <div className="w-8 h-8 rounded-lg bg-violet-500/20 flex items-center justify-center flex-shrink-0">
                  <Lightbulb className="w-4 h-4 text-violet-400" />
                </div>
                <div>
                  <p className="text-white mb-1">{insight.insight}</p>
                  <p className="text-sm text-emerald-400">Action: {insight.action}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}