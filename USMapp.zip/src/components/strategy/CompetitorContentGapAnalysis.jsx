import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import {
  TrendingUp,
  Target,
  AlertCircle,
  CheckCircle2,
  Loader2,
  Sparkles,
  BarChart3,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function CompetitorContentGapAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors'],
    queryFn: () => base44.entities.Competitor.list('-engagement_rate', 10),
  });

  const { data: ownPosts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 50),
  });

  const analyzeGaps = async () => {
    if (competitors.length === 0) {
      toast.error('Add competitors first to analyze gaps');
      return;
    }

    setIsAnalyzing(true);
    toast.info('🤖 AI is analyzing competitive gaps...');

    const competitorContext = competitors.map(c => `
Competitor: ${c.name} (@${c.username})
Platform: ${c.platform}
Followers: ${c.followers_count || 'N/A'}
Engagement Rate: ${c.engagement_rate || 'N/A'}%
Top Hashtags: ${c.top_hashtags?.join(', ') || 'None'}
Content Themes: ${c.content_themes?.join(', ') || 'None'}
    `).join('\n');

    const ownContext = ownPosts.length > 0 ? `
Your recent posts (${ownPosts.length} total):
Average Engagement: ${Math.round(ownPosts.reduce((sum, p) => sum + (p.likes || 0) + (p.comments || 0), 0) / ownPosts.length)}
Platforms used: ${[...new Set(ownPosts.map(p => p.platforms).flat())].join(', ')}
    ` : 'No published posts yet';

    const prompt = `Analyze competitive content gaps and opportunities:

COMPETITORS DATA:
${competitorContext}

YOUR CURRENT STRATEGY:
${ownContext}

Provide a comprehensive gap analysis with:

1. CONTENT GAPS - What successful content types/themes competitors use that you're missing
2. COMPETITIVE ADVANTAGES - Areas where you're stronger than competitors  
3. UNTAPPED OPPORTUNITIES - Content ideas/strategies competitors haven't explored
4. PERFORMANCE GAPS - Specific metrics where competitors outperform
5. STRATEGIC RECOMMENDATIONS - 5 actionable strategies to close gaps and capitalize on opportunities

Be specific with examples and data-driven insights.`;

    try {
      const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          overall_score: { type: 'number', description: '0-100 competitive score' },
          content_gaps: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                gap: { type: 'string' },
                competitor_example: { type: 'string' },
                impact: { type: 'string' },
                difficulty: { type: 'string' }
              }
            }
          },
          competitive_advantages: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                advantage: { type: 'string' },
                strength_score: { type: 'number' },
                how_to_leverage: { type: 'string' }
              }
            }
          },
          untapped_opportunities: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                opportunity: { type: 'string' },
                potential_impact: { type: 'string' },
                implementation_steps: { type: 'array', items: { type: 'string' } }
              }
            }
          },
          performance_gaps: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                metric: { type: 'string' },
                your_performance: { type: 'string' },
                competitor_performance: { type: 'string' },
                gap_size: { type: 'string' }
              }
            }
          },
          strategic_recommendations: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                recommendation: { type: 'string' },
                priority: { type: 'string' },
                expected_outcome: { type: 'string' },
                timeline: { type: 'string' }
              }
            }
          }
        }
      }
    });

      if (result) {
        setAnalysis(result);
        toast.success('✅ Analysis complete!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Gap analysis error:', error);
      toast.error('❌ Failed to analyze: ' + error.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (!analysis) {
    return (
      <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 p-8 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
          <Target className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-2">Competitor Content Gap Analysis</h3>
        <p className="text-slate-400 mb-6 max-w-md mx-auto">
          Identify what competitors are doing successfully and find opportunities to differentiate
        </p>
        <Button
          onClick={analyzeGaps}
          disabled={isAnalyzing || competitors.length === 0}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Analyze Gaps
            </>
          )}
        </Button>
        {competitors.length === 0 && (
          <p className="text-sm text-amber-400 mt-4">Add competitors first to enable analysis</p>
        )}
      </div>
    );
  }

  const difficultyColors = {
    easy: 'bg-emerald-500/10 text-emerald-400',
    medium: 'bg-amber-500/10 text-amber-400',
    hard: 'bg-rose-500/10 text-rose-400'
  };

  const priorityColors = {
    high: 'bg-rose-500/10 text-rose-400',
    medium: 'bg-amber-500/10 text-amber-400',
    low: 'bg-emerald-500/10 text-emerald-400'
  };

  return (
    <div className="space-y-6">
      {/* Overall Score */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-white mb-1">Competitive Position</h3>
            <p className="text-sm text-slate-400">Your overall competitive score</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={analyzeGaps}
            disabled={isAnalyzing}
            className="text-slate-400"
          >
            <Sparkles className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-end gap-4">
          <div className="text-6xl font-bold text-white">{analysis.overall_score}</div>
          <div className="flex-1 mb-4">
            <Progress value={analysis.overall_score} className="h-3" />
            <p className="text-sm text-slate-500 mt-2">
              {analysis.overall_score >= 75 ? 'Strong position' :
               analysis.overall_score >= 50 ? 'Room for improvement' :
               'Needs immediate attention'}
            </p>
          </div>
        </div>
      </div>

      {/* Content Gaps */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-6">
          <AlertCircle className="w-5 h-5 text-rose-400" />
          <h3 className="text-lg font-semibold text-white">Content Gaps</h3>
        </div>
        <div className="space-y-4">
          {analysis.content_gaps?.map((gap, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-medium text-white">{gap.gap}</h4>
                <Badge className={difficultyColors[gap.difficulty]}>
                  {gap.difficulty}
                </Badge>
              </div>
              <p className="text-sm text-slate-400 mb-2">{gap.competitor_example}</p>
              <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20">
                <p className="text-sm text-rose-300">Impact: {gap.impact}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Competitive Advantages */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-6">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <h3 className="text-lg font-semibold text-white">Your Competitive Advantages</h3>
        </div>
        <div className="space-y-4">
          {analysis.competitive_advantages?.map((adv, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium text-white">{adv.advantage}</h4>
                <div className="flex items-center gap-2">
                  <Progress value={adv.strength_score} className="w-20 h-2" />
                  <span className="text-sm text-emerald-400">{adv.strength_score}%</span>
                </div>
              </div>
              <p className="text-sm text-emerald-300">{adv.how_to_leverage}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Untapped Opportunities */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="w-5 h-5 text-violet-400" />
          <h3 className="text-lg font-semibold text-white">Untapped Opportunities</h3>
        </div>
        <div className="space-y-4">
          {analysis.untapped_opportunities?.map((opp, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
              <h4 className="font-medium text-white mb-2">{opp.opportunity}</h4>
              <p className="text-sm text-violet-300 mb-3">{opp.potential_impact}</p>
              <div className="space-y-2">
                <p className="text-xs text-slate-400">Implementation steps:</p>
                {opp.implementation_steps?.map((step, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm text-slate-300">
                    <span className="text-violet-400">{i + 1}.</span>
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Performance Gaps */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-6">
          <BarChart3 className="w-5 h-5 text-amber-400" />
          <h3 className="text-lg font-semibold text-white">Performance Gaps</h3>
        </div>
        <div className="space-y-3">
          {analysis.performance_gaps?.map((gap, idx) => (
            <div key={idx} className="p-4 rounded-xl bg-slate-800/50">
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-slate-500 mb-1">{gap.metric}</p>
                  <p className="text-white font-medium">Your: {gap.your_performance}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Competitors</p>
                  <p className="text-white font-medium">{gap.competitor_performance}</p>
                </div>
                <div>
                  <p className="text-slate-500 mb-1">Gap Size</p>
                  <Badge className={cn(
                    gap.gap_size === 'large' ? 'bg-rose-500/10 text-rose-400' :
                    gap.gap_size === 'medium' ? 'bg-amber-500/10 text-amber-400' :
                    'bg-emerald-500/10 text-emerald-400'
                  )}>
                    {gap.gap_size}
                  </Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Strategic Recommendations */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-6">
          <Eye className="w-5 h-5 text-fuchsia-400" />
          <h3 className="text-lg font-semibold text-white">Strategic Recommendations</h3>
        </div>
        <div className="space-y-4">
          {analysis.strategic_recommendations?.map((rec, idx) => (
            <div key={idx} className="p-5 rounded-xl bg-gradient-to-br from-slate-800/50 to-slate-800/30 border border-slate-700">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-fuchsia-500/20 flex items-center justify-center">
                    <span className="text-sm font-bold text-fuchsia-400">{idx + 1}</span>
                  </div>
                  <h4 className="font-medium text-white">{rec.recommendation}</h4>
                </div>
                <Badge className={priorityColors[rec.priority]}>
                  {rec.priority}
                </Badge>
              </div>
              <div className="ml-11 space-y-2">
                <p className="text-sm text-emerald-400">Expected: {rec.expected_outcome}</p>
                <p className="text-sm text-slate-400">Timeline: {rec.timeline}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}