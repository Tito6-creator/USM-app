import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Repeat, Copy, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function ContentRepurposingTool({ onContentCreated }) {
  const [selectedPostId, setSelectedPostId] = useState('');
  const [targetFormats, setTargetFormats] = useState([]);
  const [isRepurposing, setIsRepurposing] = useState(false);
  const [repurposedContent, setRepurposedContent] = useState([]);

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 50)
  });

  const formats = [
    { id: 'twitter_thread', name: 'Twitter Thread', icon: '🧵' },
    { id: 'linkedin_article', name: 'LinkedIn Article', icon: '📝' },
    { id: 'instagram_carousel', name: 'Instagram Carousel', icon: '📸' },
    { id: 'tiktok_script', name: 'TikTok Script', icon: '🎬' },
    { id: 'youtube_short', name: 'YouTube Short', icon: '▶️' },
    { id: 'facebook_story', name: 'Facebook Story', icon: '📱' },
    { id: 'blog_post', name: 'Blog Post', icon: '✍️' },
    { id: 'email_newsletter', name: 'Email Newsletter', icon: '📧' }
  ];

  const toggleFormat = (formatId) => {
    setTargetFormats(prev =>
      prev.includes(formatId) ? prev.filter(f => f !== formatId) : [...prev, formatId]
    );
  };

  const repurposeContent = async () => {
    if (!selectedPostId || targetFormats.length === 0) {
      toast.error('Select a post and at least one format');
      return;
    }

    setIsRepurposing(true);
    try {
      const post = posts.find(p => p.id === selectedPostId);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Repurpose this content into different formats:

Original Content:
${post.content}

Platforms: ${post.platforms?.join(', ')}
Hashtags: ${post.hashtags?.join(', ')}

Transform into these formats: ${targetFormats.map(f => formats.find(fmt => fmt.id === f)?.name).join(', ')}

For each format:
1. Adapt tone and style for the platform
2. Optimize length and structure
3. Suggest visual elements
4. Include relevant hashtags/keywords
5. Add platform-specific CTAs

Ensure each version maintains the core message but feels native to its platform.

Format as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            repurposed_content: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  format: { type: 'string' },
                  platform: { type: 'string' },
                  content: { type: 'string' },
                  visual_suggestions: { type: 'string' },
                  hashtags: { type: 'array', items: { type: 'string' } },
                  cta: { type: 'string' },
                  best_practices: { type: 'array', items: { type: 'string' } }
                }
              }
            }
          }
        }
      });

      setRepurposedContent(result.repurposed_content || []);
      toast.success(`Repurposed into ${result.repurposed_content?.length} formats!`);
    } catch (error) {
      toast.error('Failed to repurpose content');
      console.error(error);
    } finally {
      setIsRepurposing(false);
    }
  };

  const copyContent = async (content) => {
    await navigator.clipboard.writeText(content);
    toast.success('Copied to clipboard');
  };

  const createAsPost = async (repurposed) => {
    try {
      await base44.entities.Post.create({
        title: `${repurposed.format} - Repurposed`,
        content: repurposed.content,
        platforms: [repurposed.platform],
        hashtags: repurposed.hashtags,
        status: 'draft',
        ai_generated: true
      });
      toast.success('Created as draft post!');
      if (onContentCreated) onContentCreated();
    } catch (error) {
      toast.error('Failed to create post');
    }
  };

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center gap-2 mb-4">
        <Repeat className="w-5 h-5 text-emerald-400" />
        <h3 className="text-white font-semibold">Content Repurposing Tool</h3>
      </div>

      <div className="space-y-4 mb-4">
        <div>
          <label className="text-slate-300 text-sm mb-2 block">Select Post to Repurpose</label>
          <Select value={selectedPostId} onValueChange={setSelectedPostId}>
            <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
              <SelectValue placeholder="Choose a post..." />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              {posts.map(post => (
                <SelectItem key={post.id} value={post.id}>
                  {post.title || post.content?.substring(0, 50)}...
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-slate-300 text-sm mb-2 block">Target Formats</label>
          <div className="grid grid-cols-2 gap-2">
            {formats.map(format => (
              <div
                key={format.id}
                onClick={() => toggleFormat(format.id)}
                className={cn(
                  "p-3 rounded-lg border cursor-pointer transition-all",
                  targetFormats.includes(format.id)
                    ? "bg-emerald-500/10 border-emerald-500/30"
                    : "bg-slate-800/50 border-slate-700 hover:border-slate-600"
                )}
              >
                <span className="text-lg mr-2">{format.icon}</span>
                <span className="text-sm text-white">{format.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Button
        onClick={repurposeContent}
        disabled={isRepurposing || !selectedPostId || targetFormats.length === 0}
        className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 mb-4"
      >
        {isRepurposing ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Repeat className="w-4 h-4 mr-2" />
        )}
        Repurpose Content
      </Button>

      {repurposedContent.length > 0 && (
        <ScrollArea className="h-[500px]">
          <div className="space-y-4 pr-4">
            {repurposedContent.map((item, idx) => (
              <div key={idx} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      {item.format}
                    </Badge>
                    <Badge variant="outline" className="border-slate-600">
                      {item.platform}
                    </Badge>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyContent(item.content)}
                      className="h-7"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => createAsPost(item)}
                      className="text-green-400 hover:text-green-300 h-7"
                    >
                      <CheckCircle2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                <div className="p-3 bg-slate-900/50 rounded-lg mb-3">
                  <p className="text-sm text-slate-300 whitespace-pre-wrap">{item.content}</p>
                </div>

                <div className="space-y-2">
                  <div>
                    <p className="text-xs text-slate-400 mb-1">Visual Suggestions:</p>
                    <p className="text-xs text-slate-300">{item.visual_suggestions}</p>
                  </div>

                  {item.hashtags?.length > 0 && (
                    <div>
                      <p className="text-xs text-slate-400 mb-1">Hashtags:</p>
                      <div className="flex flex-wrap gap-1">
                        {item.hashtags.map((tag, tIdx) => (
                          <span key={tIdx} className="text-xs text-violet-400">#{tag}</span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <p className="text-xs text-slate-400 mb-1">CTA:</p>
                    <p className="text-xs text-slate-300">{item.cta}</p>
                  </div>

                  {item.best_practices?.length > 0 && (
                    <div>
                      <p className="text-xs text-slate-400 mb-1">Best Practices:</p>
                      <ul className="text-xs text-slate-500 space-y-0.5">
                        {item.best_practices.map((practice, pIdx) => (
                          <li key={pIdx}>• {practice}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </Card>
  );
}