import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Settings, 
  Plus, 
  Trash2, 
  RefreshCw, 
  CheckCircle2,
  ArrowLeftRight,
  ArrowRight,
  ArrowLeft,
  Zap
} from 'lucide-react';
import { toast } from 'sonner';

const leadFields = [
  { value: 'name', label: 'Name', type: 'string' },
  { value: 'email', label: 'Email', type: 'string' },
  { value: 'phone', label: 'Phone', type: 'string' },
  { value: 'status', label: 'Status', type: 'string' },
  { value: 'score', label: 'Lead Score', type: 'number' },
  { value: 'source', label: 'Source', type: 'string' },
  { value: 'platform', label: 'Platform', type: 'string' },
  { value: 'tags', label: 'Tags', type: 'array' },
  { value: 'interests', label: 'Interests', type: 'array' },
  { value: 'notes', label: 'Notes', type: 'string' },
];

const hubspotFields = [
  { value: 'firstname', label: 'First Name' },
  { value: 'lastname', label: 'Last Name' },
  { value: 'email', label: 'Email' },
  { value: 'phone', label: 'Phone' },
  { value: 'lifecyclestage', label: 'Lifecycle Stage' },
  { value: 'hs_lead_status', label: 'Lead Status' },
  { value: 'leadsource', label: 'Lead Source' },
  { value: 'industry', label: 'Industry' },
  { value: 'company', label: 'Company' },
  { value: 'jobtitle', label: 'Job Title' },
];

const salesforceFields = [
  { value: 'FirstName', label: 'First Name' },
  { value: 'LastName', label: 'Last Name' },
  { value: 'Email', label: 'Email' },
  { value: 'Phone', label: 'Phone' },
  { value: 'Status', label: 'Status' },
  { value: 'LeadSource', label: 'Lead Source' },
  { value: 'Rating', label: 'Rating' },
  { value: 'Industry', label: 'Industry' },
  { value: 'Company', label: 'Company' },
  { value: 'Title', label: 'Title' },
];

export default function CRMIntegrationSettings({ platform }) {
  const queryClient = useQueryClient();
  const [newMapping, setNewMapping] = useState({ app_field: '', crm_field: '' });
  const [newRule, setNewRule] = useState({ trigger: '', action: '' });

  const { data: mappings = [], isLoading } = useQuery({
    queryKey: ['crm-mappings', platform],
    queryFn: () => base44.entities.CRMFieldMapping.filter({ crm_platform: platform }),
  });

  const currentMapping = mappings[0] || {
    crm_platform: platform,
    field_mappings: [],
    automation_rules: [],
    sync_direction: 'bidirectional',
    sync_frequency: 'realtime',
    is_active: true
  };

  const saveMappingMutation = useMutation({
    mutationFn: (data) => {
      if (currentMapping.id) {
        return base44.entities.CRMFieldMapping.update(currentMapping.id, data);
      } else {
        return base44.entities.CRMFieldMapping.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['crm-mappings']);
      toast.success('CRM settings saved');
    },
  });

  const syncNowMutation = useMutation({
    mutationFn: () => base44.functions.invoke('syncCRMLeads', { platform }),
    onSuccess: () => {
      toast.success('Sync started successfully');
      queryClient.invalidateQueries(['crm-mappings']);
    },
    onError: (error) => {
      toast.error('Sync failed: ' + error.message);
    }
  });

  const addFieldMapping = () => {
    if (!newMapping.app_field || !newMapping.crm_field) {
      toast.error('Please select both fields');
      return;
    }

    const appField = leadFields.find(f => f.value === newMapping.app_field);
    const updatedMappings = [
      ...currentMapping.field_mappings,
      {
        app_field: newMapping.app_field,
        crm_field: newMapping.crm_field,
        field_type: appField?.type || 'string',
        is_required: false
      }
    ];

    saveMappingMutation.mutate({
      ...currentMapping,
      field_mappings: updatedMappings
    });

    setNewMapping({ app_field: '', crm_field: '' });
  };

  const removeFieldMapping = (index) => {
    const updatedMappings = currentMapping.field_mappings.filter((_, i) => i !== index);
    saveMappingMutation.mutate({
      ...currentMapping,
      field_mappings: updatedMappings
    });
  };

  const addAutomationRule = () => {
    if (!newRule.trigger || !newRule.action) {
      toast.error('Please fill in trigger and action');
      return;
    }

    const updatedRules = [
      ...currentMapping.automation_rules,
      {
        trigger: newRule.trigger,
        action: newRule.action,
        conditions: {},
        is_active: true
      }
    ];

    saveMappingMutation.mutate({
      ...currentMapping,
      automation_rules: updatedRules
    });

    setNewRule({ trigger: '', action: '' });
  };

  const removeAutomationRule = (index) => {
    const updatedRules = currentMapping.automation_rules.filter((_, i) => i !== index);
    saveMappingMutation.mutate({
      ...currentMapping,
      automation_rules: updatedRules
    });
  };

  const toggleRuleStatus = (index) => {
    const updatedRules = currentMapping.automation_rules.map((rule, i) => 
      i === index ? { ...rule, is_active: !rule.is_active } : rule
    );
    saveMappingMutation.mutate({
      ...currentMapping,
      automation_rules: updatedRules
    });
  };

  const updateSyncSettings = (key, value) => {
    saveMappingMutation.mutate({
      ...currentMapping,
      [key]: value
    });
  };

  const crmFields = platform === 'hubspot' ? hubspotFields : salesforceFields;
  const syncDirectionIcon = {
    bidirectional: <ArrowLeftRight className="w-4 h-4" />,
    to_crm: <ArrowRight className="w-4 h-4" />,
    from_crm: <ArrowLeft className="w-4 h-4" />
  };

  if (isLoading) {
    return <div className="text-slate-400">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Sync Status & Controls */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="w-5 h-5 text-violet-400" />
                {platform === 'hubspot' ? 'HubSpot' : 'Salesforce'} Integration
              </CardTitle>
              <CardDescription>
                Configure field mappings and automation rules
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Switch
                checked={currentMapping.is_active}
                onCheckedChange={(checked) => updateSyncSettings('is_active', checked)}
              />
              <Badge variant={currentMapping.is_active ? 'default' : 'secondary'}>
                {currentMapping.is_active ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Sync Direction</Label>
              <Select 
                value={currentMapping.sync_direction}
                onValueChange={(value) => updateSyncSettings('sync_direction', value)}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="bidirectional">
                    <span className="flex items-center gap-2">
                      <ArrowLeftRight className="w-4 h-4" />
                      Bidirectional
                    </span>
                  </SelectItem>
                  <SelectItem value="to_crm">
                    <span className="flex items-center gap-2">
                      <ArrowRight className="w-4 h-4" />
                      To CRM Only
                    </span>
                  </SelectItem>
                  <SelectItem value="from_crm">
                    <span className="flex items-center gap-2">
                      <ArrowLeft className="w-4 h-4" />
                      From CRM Only
                    </span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-slate-300">Sync Frequency</Label>
              <Select 
                value={currentMapping.sync_frequency}
                onValueChange={(value) => updateSyncSettings('sync_frequency', value)}
              >
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="realtime">Real-time</SelectItem>
                  <SelectItem value="hourly">Every Hour</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={() => syncNowMutation.mutate()}
            disabled={syncNowMutation.isPending || !currentMapping.is_active}
            className="w-full bg-violet-600 hover:bg-violet-700"
          >
            {syncNowMutation.isPending ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Syncing...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Sync Now
              </>
            )}
          </Button>

          {currentMapping.last_sync && (
            <p className="text-xs text-slate-400 text-center">
              Last synced: {new Date(currentMapping.last_sync).toLocaleString()}
            </p>
          )}
        </CardContent>
      </Card>

      {/* Field Mappings */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white">Field Mappings</CardTitle>
          <CardDescription>
            Map fields between your app and {platform === 'hubspot' ? 'HubSpot' : 'Salesforce'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Existing Mappings */}
          <div className="space-y-2">
            {currentMapping.field_mappings.map((mapping, index) => (
              <div key={index} className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg">
                <div className="flex-1 grid grid-cols-3 gap-3 items-center">
                  <Badge variant="outline" className="justify-center">
                    {leadFields.find(f => f.value === mapping.app_field)?.label || mapping.app_field}
                  </Badge>
                  <div className="flex justify-center">
                    {syncDirectionIcon[currentMapping.sync_direction]}
                  </div>
                  <Badge variant="outline" className="justify-center">
                    {crmFields.find(f => f.value === mapping.crm_field)?.label || mapping.crm_field}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeFieldMapping(index)}
                  className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          {/* Add New Mapping */}
          <div className="border-t border-slate-700 pt-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-slate-300 mb-2 block">App Field</Label>
                <Select value={newMapping.app_field} onValueChange={(value) => setNewMapping({...newMapping, app_field: value})}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue placeholder="Select field" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {leadFields.map(field => (
                      <SelectItem key={field.value} value={field.value}>
                        {field.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300 mb-2 block">CRM Field</Label>
                <Select value={newMapping.crm_field} onValueChange={(value) => setNewMapping({...newMapping, crm_field: value})}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue placeholder="Select field" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    {crmFields.map(field => (
                      <SelectItem key={field.value} value={field.value}>
                        {field.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button 
              onClick={addFieldMapping}
              className="w-full mt-3 bg-slate-700 hover:bg-slate-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Field Mapping
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Automation Rules */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-400" />
            Automation Rules
          </CardTitle>
          <CardDescription>
            Trigger CRM actions based on lead status changes
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Existing Rules */}
          <div className="space-y-2">
            {currentMapping.automation_rules.map((rule, index) => (
              <div key={index} className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg">
                <Switch
                  checked={rule.is_active}
                  onCheckedChange={() => toggleRuleStatus(index)}
                />
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-white font-medium">
                    When: <Badge variant="outline">{rule.trigger}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400 text-sm mt-1">
                    Then: <Badge variant="outline" className="bg-violet-600/10">{rule.action}</Badge>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeAutomationRule(index)}
                  className="text-red-400 hover:text-red-300 hover:bg-red-400/10"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          {/* Add New Rule */}
          <div className="border-t border-slate-700 pt-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-slate-300 mb-2 block">Trigger</Label>
                <Select value={newRule.trigger} onValueChange={(value) => setNewRule({...newRule, trigger: value})}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue placeholder="Select trigger" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="status_new">Status: New</SelectItem>
                    <SelectItem value="status_contacted">Status: Contacted</SelectItem>
                    <SelectItem value="status_qualified">Status: Qualified</SelectItem>
                    <SelectItem value="status_converted">Status: Converted</SelectItem>
                    <SelectItem value="status_lost">Status: Lost</SelectItem>
                    <SelectItem value="score_increase">Score Increased</SelectItem>
                    <SelectItem value="high_score">High Score (>80)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-slate-300 mb-2 block">CRM Action</Label>
                <Select value={newRule.action} onValueChange={(value) => setNewRule({...newRule, action: value})}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                    <SelectValue placeholder="Select action" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="create_contact">Create Contact</SelectItem>
                    <SelectItem value="update_status">Update Status</SelectItem>
                    <SelectItem value="assign_owner">Assign Owner</SelectItem>
                    <SelectItem value="add_to_list">Add to List</SelectItem>
                    <SelectItem value="send_email">Send Email</SelectItem>
                    <SelectItem value="create_deal">Create Deal</SelectItem>
                    <SelectItem value="add_note">Add Note</SelectItem>
                    <SelectItem value="update_properties">Update Properties</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button 
              onClick={addAutomationRule}
              className="w-full mt-3 bg-slate-700 hover:bg-slate-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Automation Rule
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}