import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Mail, 
  Phone, 
  Building2, 
  Calendar,
  DollarSign,
  CheckCircle2,
  Clock,
  MessageSquare
} from 'lucide-react';
import { toast } from 'sonner';

export default function ContactDetailModal({ contact, onClose }) {
  const queryClient = useQueryClient();
  const [newNote, setNewNote] = useState('');

  const { data: deals = [] } = useQuery({
    queryKey: ['deals', contact?.id],
    queryFn: () => base44.entities.Deal.filter({ contact_id: contact.id }),
    enabled: !!contact
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['crm-tasks', contact?.id],
    queryFn: () => base44.entities.CRMTask.filter({ contact_id: contact.id }),
    enabled: !!contact
  });

  const { data: notes = [] } = useQuery({
    queryKey: ['crm-notes', contact?.id],
    queryFn: () => base44.entities.CRMNote.filter({ contact_id: contact.id }, '-created_date'),
    enabled: !!contact
  });

  const addNoteMutation = useMutation({
    mutationFn: (data) => base44.entities.CRMNote.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries(['crm-notes']);
      setNewNote('');
      toast.success('Note added');
    },
  });

  const handleAddNote = () => {
    if (!newNote.trim()) return;
    
    addNoteMutation.mutate({
      contact_id: contact.id,
      contact_name: contact.name,
      note_type: 'note',
      content: newNote,
      author: 'You'
    });
  };

  if (!contact) return null;

  const statusColors = {
    lead: 'bg-blue-500/10 text-blue-400',
    demo: 'bg-purple-500/10 text-purple-400',
    trial: 'bg-amber-500/10 text-amber-400',
    client: 'bg-green-500/10 text-green-400',
    churn_risk: 'bg-red-500/10 text-red-400'
  };

  return (
    <Dialog open={!!contact} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={contact.avatar} />
                <AvatarFallback className="bg-violet-600 text-white text-xl">
                  {contact.name?.charAt(0) || '?'}
                </AvatarFallback>
              </Avatar>
              <div>
                <DialogTitle className="text-2xl">{contact.name}</DialogTitle>
                {contact.company && (
                  <p className="text-slate-400 flex items-center gap-2 mt-1">
                    <Building2 className="w-4 h-4" />
                    {contact.company}
                  </p>
                )}
              </div>
            </div>
            <Badge className={statusColors[contact.status]}>
              {contact.status.replace('_', ' ')}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Contact Info */}
          <div className="grid grid-cols-2 gap-4">
            {contact.email && (
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-4 h-4 text-slate-400" />
                <a href={`mailto:${contact.email}`} className="hover:text-violet-400">
                  {contact.email}
                </a>
              </div>
            )}
            {contact.phone && (
              <div className="flex items-center gap-2 text-slate-300">
                <Phone className="w-4 h-4 text-slate-400" />
                <a href={`tel:${contact.phone}`} className="hover:text-violet-400">
                  {contact.phone}
                </a>
              </div>
            )}
          </div>

          {contact.tags?.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {contact.tags.map((tag, idx) => (
                <Badge key={idx} variant="outline">{tag}</Badge>
              ))}
            </div>
          )}

          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList className="bg-slate-800/50">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="deals">Deals ({deals.length})</TabsTrigger>
              <TabsTrigger value="tasks">Tasks ({tasks.length})</TabsTrigger>
              <TabsTrigger value="notes">Notes ({notes.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              {contact.notes && (
                <Card className="bg-slate-800/50 border-slate-700 p-4">
                  <h4 className="text-white font-medium mb-2">Notes</h4>
                  <p className="text-slate-300">{contact.notes}</p>
                </Card>
              )}

              {contact.connected_accounts && (
                <Card className="bg-slate-800/50 border-slate-700 p-4">
                  <h4 className="text-white font-medium mb-3">Connected Social Accounts</h4>
                  <div className="space-y-2">
                    {contact.connected_accounts.facebook && (
                      <div className="text-slate-300">
                        <span className="text-slate-400">Facebook:</span> {contact.connected_accounts.facebook}
                      </div>
                    )}
                    {contact.connected_accounts.instagram && (
                      <div className="text-slate-300">
                        <span className="text-slate-400">Instagram:</span> {contact.connected_accounts.instagram}
                      </div>
                    )}
                    {contact.connected_accounts.tiktok && (
                      <div className="text-slate-300">
                        <span className="text-slate-400">TikTok:</span> {contact.connected_accounts.tiktok}
                      </div>
                    )}
                    {contact.connected_accounts.linkedin && (
                      <div className="text-slate-300">
                        <span className="text-slate-400">LinkedIn:</span> {contact.connected_accounts.linkedin}
                      </div>
                    )}
                  </div>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="deals" className="space-y-3">
              {deals.length === 0 ? (
                <p className="text-slate-400 text-center py-8">No deals yet</p>
              ) : (
                deals.map(deal => (
                  <Card key={deal.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{deal.title}</h4>
                      <div className="flex items-center gap-1 text-green-400 font-semibold">
                        <DollarSign className="w-4 h-4" />
                        {deal.value?.toLocaleString() || 0}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                      <Badge variant="outline">{deal.stage}</Badge>
                      {deal.next_action_date && (
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(deal.next_action_date).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </Card>
                ))
              )}
            </TabsContent>

            <TabsContent value="tasks" className="space-y-3">
              {tasks.length === 0 ? (
                <p className="text-slate-400 text-center py-8">No tasks yet</p>
              ) : (
                tasks.map(task => (
                  <Card key={task.id} className="bg-slate-800/50 border-slate-700 p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-white font-medium">{task.title}</h4>
                      <Badge className={task.status === 'completed' ? 'bg-green-500/10 text-green-400' : ''}>
                        {task.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                      <Badge variant="outline">{task.task_type}</Badge>
                      <Badge variant="outline">{task.priority}</Badge>
                      {task.due_date && (
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(task.due_date).toLocaleString()}
                        </span>
                      )}
                    </div>
                  </Card>
                ))
              )}
            </TabsContent>

            <TabsContent value="notes" className="space-y-4">
              <div className="flex gap-2">
                <Textarea
                  placeholder="Add a note..."
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white"
                />
                <Button 
                  onClick={handleAddNote}
                  disabled={!newNote.trim() || addNoteMutation.isPending}
                  className="bg-violet-600 hover:bg-violet-700"
                >
                  Add
                </Button>
              </div>

              {notes.length === 0 ? (
                <p className="text-slate-400 text-center py-8">No notes yet</p>
              ) : (
                <div className="space-y-3">
                  {notes.map(note => (
                    <Card key={note.id} className="bg-slate-800/50 border-slate-700 p-4">
                      <div className="flex items-start gap-3">
                        <MessageSquare className="w-4 h-4 text-slate-400 mt-1" />
                        <div className="flex-1">
                          <p className="text-white">{note.content}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-slate-400">
                            <span>{note.author || 'Unknown'}</span>
                            <span>•</span>
                            <span>{new Date(note.created_date).toLocaleString()}</span>
                            <Badge variant="outline" className="text-xs">{note.note_type}</Badge>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}