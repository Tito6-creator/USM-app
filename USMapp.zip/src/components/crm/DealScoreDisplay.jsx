import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, RefreshCw, Loader2 } from 'lucide-react';

export default function DealScoreDisplay({ deal, onScoreUpdate }) {
  const [loading, setLoading] = useState(false);
  const score = deal.lead_score || 0;

  const getScoreGrade = () => {
    if (score >= 80) return { grade: 'A', color: 'text-green-400', bg: 'bg-green-500/10' };
    if (score >= 60) return { grade: 'B', color: 'text-blue-400', bg: 'bg-blue-500/10' };
    if (score >= 40) return { grade: 'C', color: 'text-amber-400', bg: 'bg-amber-500/10' };
    return { grade: 'D', color: 'text-red-400', bg: 'bg-red-500/10' };
  };

  const gradeInfo = getScoreGrade();

  const recalculateScore = async () => {
    setLoading(true);
    try {
      await base44.functions.invoke('calculateLeadScore', {
        deal_id: deal.id
      });
      if (onScoreUpdate) onScoreUpdate();
    } catch (error) {
      console.error('Failed to recalculate score:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp className={`w-5 h-5 ${gradeInfo.color}`} />
          <span className="text-sm text-slate-400">Lead Score</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-2xl font-bold ${gradeInfo.color}`}>{score}</span>
          <Badge className={`${gradeInfo.bg} ${gradeInfo.color}`}>
            Grade {gradeInfo.grade}
          </Badge>
        </div>
      </div>

      <Progress value={score} className="h-2" />

      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400">Interactions</div>
          <div className="text-white font-medium">{deal.interaction_count || 0}</div>
        </div>
        
        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400">Demo Watched</div>
          <div className="text-white font-medium">{deal.demo_watched ? 'Yes' : 'No'}</div>
        </div>

        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400">Engagement</div>
          <div className="text-white font-medium">{deal.content_engagement || 0}%</div>
        </div>

        <div className="bg-slate-800/50 rounded p-2">
          <div className="text-slate-400">Probability</div>
          <div className="text-white font-medium">{deal.probability || 50}%</div>
        </div>
      </div>

      <Button 
        onClick={recalculateScore}
        disabled={loading}
        variant="outline"
        size="sm"
        className="w-full"
      >
        {loading ? (
          <>
            <Loader2 className="w-3 h-3 mr-2 animate-spin" />
            Calculating...
          </>
        ) : (
          <>
            <RefreshCw className="w-3 h-3 mr-2" />
            Recalculate Score
          </>
        )}
      </Button>
    </div>
  );
}