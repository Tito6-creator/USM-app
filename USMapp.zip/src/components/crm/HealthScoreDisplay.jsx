import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Activity, TrendingDown, TrendingUp, Minus, AlertTriangle } from 'lucide-react';

export default function HealthScoreDisplay({ contact, showDetails = false }) {
  const score = contact.health_score || 100;
  
  const getScoreColor = () => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-blue-400';
    if (score >= 40) return 'text-amber-400';
    return 'text-red-400';
  };

  const getScoreGrade = () => {
    if (score >= 80) return 'Healthy';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'At Risk';
    return 'Critical';
  };

  const getProgressColor = () => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const getTrendIcon = () => {
    if (!contact.engagement_trend) return <Minus className="w-4 h-4" />;
    if (contact.engagement_trend === 'improving') return <TrendingUp className="w-4 h-4 text-green-400" />;
    if (contact.engagement_trend === 'declining') return <TrendingDown className="w-4 h-4 text-red-400" />;
    return <Minus className="w-4 h-4 text-slate-400" />;
  };

  if (contact.status !== 'client') {
    return null;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Activity className={`w-5 h-5 ${getScoreColor()}`} />
          <span className="text-sm text-slate-400">Health Score</span>
          {score < 40 && <AlertTriangle className="w-4 h-4 text-red-400 animate-pulse" />}
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-2xl font-bold ${getScoreColor()}`}>{score}</span>
          <Badge className={score >= 60 ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}>
            {getScoreGrade()}
          </Badge>
        </div>
      </div>

      <div className="space-y-2">
        <Progress value={score} className="h-2" indicatorClassName={getProgressColor()} />
      </div>

      {showDetails && (
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-slate-800/50 rounded p-2">
            <div className="text-slate-400">Last Login</div>
            <div className="text-white font-medium">
              {contact.last_login 
                ? `${Math.floor((Date.now() - new Date(contact.last_login).getTime()) / (1000 * 60 * 60 * 24))} days ago`
                : 'Never'}
            </div>
          </div>
          
          <div className="bg-slate-800/50 rounded p-2">
            <div className="text-slate-400">Posting Frequency</div>
            <div className="text-white font-medium">
              {contact.posting_frequency || 0} posts/week
            </div>
          </div>

          <div className="bg-slate-800/50 rounded p-2">
            <div className="text-slate-400 flex items-center gap-1">
              Engagement {getTrendIcon()}
            </div>
            <div className="text-white font-medium capitalize">
              {contact.engagement_trend || 'stable'}
            </div>
          </div>

          <div className="bg-slate-800/50 rounded p-2">
            <div className="text-slate-400">Last Contact</div>
            <div className="text-white font-medium">
              {contact.last_contacted 
                ? `${Math.floor((Date.now() - new Date(contact.last_contacted).getTime()) / (1000 * 60 * 60 * 24))} days ago`
                : 'Never'}
            </div>
          </div>
        </div>
      )}

      {score < 40 && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span className="text-red-400 text-sm font-medium">Critical: Immediate attention required</span>
          </div>
        </div>
      )}
    </div>
  );
}