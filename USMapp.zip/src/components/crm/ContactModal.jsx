import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import { toast } from 'sonner';

const commonTags = ['Prospect', 'VIP', 'Hot Lead', 'Cold Lead', 'Referral', 'Partner'];

export default function ContactModal({ open, onClose, contact }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    status: 'lead',
    tags: [],
    notes: '',
    connected_accounts: {
      facebook: '',
      instagram: '',
      tiktok: '',
      linkedin: ''
    }
  });

  useEffect(() => {
    if (contact) {
      setFormData({
        name: contact.name || '',
        email: contact.email || '',
        phone: contact.phone || '',
        company: contact.company || '',
        status: contact.status || 'lead',
        tags: contact.tags || [],
        notes: contact.notes || '',
        connected_accounts: contact.connected_accounts || {
          facebook: '',
          instagram: '',
          tiktok: '',
          linkedin: ''
        }
      });
    } else {
      setFormData({
        name: '',
        email: '',
        phone: '',
        company: '',
        status: 'lead',
        tags: [],
        notes: '',
        connected_accounts: {
          facebook: '',
          instagram: '',
          tiktok: '',
          linkedin: ''
        }
      });
    }
  }, [contact, open]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      let result;
      if (contact?.id) {
        result = await base44.entities.Contact.update(contact.id, data);
        
        // Trigger automation if status changed
        if (contact.status !== data.status) {
          try {
            await base44.functions.invoke('handleContactStatusChange', {
              contact_id: contact.id,
              new_status: data.status,
              old_status: contact.status
            });
          } catch (error) {
            console.error('Automation trigger failed:', error);
          }
        }
      } else {
        result = await base44.entities.Contact.create(data);
      }
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['contacts']);
      queryClient.invalidateQueries(['crm-tasks']);
      toast.success(contact ? 'Contact updated' : 'Contact created');
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const addTag = (tag) => {
    if (!formData.tags.includes(tag)) {
      setFormData({ ...formData, tags: [...formData.tags, tag] });
    }
  };

  const removeTag = (tag) => {
    setFormData({ ...formData, tags: formData.tags.filter(t => t !== tag) });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{contact ? 'Edit Contact' : 'New Contact'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
                required
              />
            </div>

            <div>
              <Label className="text-slate-300">Email</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Phone</Label>
              <Input
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
              />
            </div>

            <div>
              <Label className="text-slate-300">Company</Label>
              <Input
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
              />
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Status</Label>
            <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                <SelectItem value="lead">Lead</SelectItem>
                <SelectItem value="demo">Demo</SelectItem>
                <SelectItem value="trial">Trial</SelectItem>
                <SelectItem value="client">Client</SelectItem>
                <SelectItem value="churn_risk">Churn Risk</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-slate-300 mb-2 block">Tags</Label>
            <div className="flex flex-wrap gap-2 mb-2">
              {formData.tags.map(tag => (
                <Badge key={tag} variant="secondary" className="flex items-center gap-1">
                  {tag}
                  <X className="w-3 h-3 cursor-pointer" onClick={() => removeTag(tag)} />
                </Badge>
              ))}
            </div>
            <div className="flex flex-wrap gap-2">
              {commonTags.filter(t => !formData.tags.includes(t)).map(tag => (
                <Badge 
                  key={tag} 
                  variant="outline" 
                  className="cursor-pointer hover:bg-violet-600/20"
                  onClick={() => addTag(tag)}
                >
                  + {tag}
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-slate-300 mb-2 block">Connected Social Accounts</Label>
            <div className="space-y-2">
              <Input
                placeholder="Facebook username"
                value={formData.connected_accounts.facebook}
                onChange={(e) => setFormData({
                  ...formData,
                  connected_accounts: { ...formData.connected_accounts, facebook: e.target.value }
                })}
                className="bg-slate-800 border-slate-700 text-white"
              />
              <Input
                placeholder="Instagram username"
                value={formData.connected_accounts.instagram}
                onChange={(e) => setFormData({
                  ...formData,
                  connected_accounts: { ...formData.connected_accounts, instagram: e.target.value }
                })}
                className="bg-slate-800 border-slate-700 text-white"
              />
              <Input
                placeholder="TikTok username"
                value={formData.connected_accounts.tiktok}
                onChange={(e) => setFormData({
                  ...formData,
                  connected_accounts: { ...formData.connected_accounts, tiktok: e.target.value }
                })}
                className="bg-slate-800 border-slate-700 text-white"
              />
              <Input
                placeholder="LinkedIn URL"
                value={formData.connected_accounts.linkedin}
                onChange={(e) => setFormData({
                  ...formData,
                  connected_accounts: { ...formData.connected_accounts, linkedin: e.target.value }
                })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white mt-1 min-h-[100px]"
            />
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-violet-600 hover:bg-violet-700" disabled={saveMutation.isPending}>
              {saveMutation.isPending ? 'Saving...' : 'Save Contact'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}