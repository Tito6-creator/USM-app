import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

export default function DealModal({ open, onClose, deal }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    title: '',
    contact_id: '',
    value: 0,
    stage: 'lead',
    next_action_date: '',
    next_action: '',
    expected_close_date: '',
    notes: ''
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list(),
    enabled: open
  });

  useEffect(() => {
    if (deal) {
      setFormData({
        title: deal.title || '',
        contact_id: deal.contact_id || '',
        value: deal.value || 0,
        stage: deal.stage || 'lead',
        next_action_date: deal.next_action_date || '',
        next_action: deal.next_action || '',
        expected_close_date: deal.expected_close_date || '',
        notes: deal.notes || ''
      });
    } else {
      setFormData({
        title: '',
        contact_id: '',
        value: 0,
        stage: 'lead',
        next_action_date: '',
        next_action: '',
        expected_close_date: '',
        notes: ''
      });
    }
  }, [deal, open]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const contact = contacts.find(c => c.id === data.contact_id);
      const dealData = {
        ...data,
        contact_name: contact?.name || ''
      };

      let result;
      if (deal?.id) {
        result = await base44.entities.Deal.update(deal.id, dealData);
        
        // Trigger automation if stage changed
        if (deal.stage !== data.stage) {
          try {
            await base44.functions.invoke('handleDealStageChange', {
              deal_id: deal.id,
              new_stage: data.stage,
              old_stage: deal.stage
            });
          } catch (error) {
            console.error('Automation trigger failed:', error);
          }
        }
      } else {
        result = await base44.entities.Deal.create(dealData);
      }
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['deals']);
      queryClient.invalidateQueries(['crm-tasks']);
      toast.success(deal ? 'Deal updated' : 'Deal created');
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-white max-w-xl">
        <DialogHeader>
          <DialogTitle>{deal ? 'Edit Deal' : 'New Deal'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-slate-300">Deal Title *</Label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white mt-1"
              required
            />
          </div>

          <div>
            <Label className="text-slate-300">Contact *</Label>
            <Select value={formData.contact_id} onValueChange={(value) => setFormData({ ...formData, contact_id: value })}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                <SelectValue placeholder="Select contact" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700">
                {contacts.map(contact => (
                  <SelectItem key={contact.id} value={contact.id}>
                    {contact.name} {contact.company && `(${contact.company})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Value ($)</Label>
              <Input
                type="number"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: parseFloat(e.target.value) || 0 })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
              />
            </div>

            <div>
              <Label className="text-slate-300">Stage</Label>
              <Select value={formData.stage} onValueChange={(value) => setFormData({ ...formData, stage: value })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700">
                  <SelectItem value="lead">Lead</SelectItem>
                  <SelectItem value="demo">Demo</SelectItem>
                  <SelectItem value="trial">Trial</SelectItem>
                  <SelectItem value="client">Client</SelectItem>
                  <SelectItem value="churn_risk">Churn Risk</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Next Action</Label>
            <Input
              value={formData.next_action}
              onChange={(e) => setFormData({ ...formData, next_action: e.target.value })}
              placeholder="e.g., Schedule demo call"
              className="bg-slate-800 border-slate-700 text-white mt-1"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-slate-300">Next Action Date</Label>
              <Input
                type="datetime-local"
                value={formData.next_action_date}
                onChange={(e) => setFormData({ ...formData, next_action_date: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
              />
            </div>

            <div>
              <Label className="text-slate-300">Expected Close Date</Label>
              <Input
                type="date"
                value={formData.expected_close_date}
                onChange={(e) => setFormData({ ...formData, expected_close_date: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-1"
              />
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white mt-1 min-h-[80px]"
            />
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-violet-600 hover:bg-violet-700" disabled={saveMutation.isPending}>
              {saveMutation.isPending ? 'Saving...' : 'Save Deal'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}