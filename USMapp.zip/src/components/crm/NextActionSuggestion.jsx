import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Loader2, AlertCircle, Clock } from 'lucide-react';

export default function NextActionSuggestion({ contact }) {
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState(null);
  const [error, setError] = useState(null);

  const getSuggestion = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data } = await base44.functions.invoke('getNextActionSuggestion', {
        contact_id: contact.id
      });
      
      setSuggestion(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border-violet-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-violet-400" />
          AI Next Action Suggestion
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!suggestion && !loading && (
          <Button 
            onClick={getSuggestion}
            className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:opacity-90"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Get AI Suggestion
          </Button>
        )}

        {loading && (
          <div className="text-center py-8">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-violet-400 mb-2" />
            <p className="text-slate-400">Analyzing contact history...</p>
          </div>
        )}

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-400 font-medium">Error</p>
                <p className="text-sm text-slate-400">{error}</p>
              </div>
            </div>
          </div>
        )}

        {suggestion && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              <span className="text-sm text-slate-400">
                {suggestion.days_since_contact} days since last contact
              </span>
              <Badge 
                className={
                  suggestion.urgency === 'high' ? 'bg-red-500/20 text-red-400' :
                  suggestion.urgency === 'medium' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-green-500/20 text-green-400'
                }
              >
                {suggestion.urgency} urgency
              </Badge>
            </div>

            <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4">
              <p className="text-white whitespace-pre-wrap">{suggestion.suggestion}</p>
            </div>

            <Button 
              onClick={getSuggestion}
              variant="outline"
              className="w-full"
            >
              Refresh Suggestion
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}