import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Sparkles,
  Loader2,
  Check,
  Calendar,
  Send,
  Clock,
  Zap,
  ChevronRight,
  Play
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';
import { format, addDays } from 'date-fns';

export default function AutomatedWorkflow() {
  const [step, setStep] = useState(1);
  const [selectedSource, setSelectedSource] = useState(null);
  const [sourceType, setSourceType] = useState(null);
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);
  const [generatedPosts, setGeneratedPosts] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [schedulingData, setSchedulingData] = useState(null);

  const queryClient = useQueryClient();

  const { data: strategies = [] } = useQuery({
    queryKey: ['strategies'],
    queryFn: () => base44.entities.MarketingStrategy.list('-created_date', 10),
  });

  const { data: trends = [] } = useQuery({
    queryKey: ['trends'],
    queryFn: () => base44.entities.TrendAlert.filter({ status: 'new' }, '-created_date', 10),
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const createPostsMutation = useMutation({
    mutationFn: (posts) => base44.entities.Post.bulkCreate(posts),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast.success('Posts created and scheduled!');
      setStep(1);
      setSelectedSource(null);
      setGeneratedPosts([]);
    },
  });

  const selectSource = (source, type) => {
    setSelectedSource(source);
    setSourceType(type);
    setStep(2);
  };

  const togglePlatform = (platform) => {
    setSelectedPlatforms(prev =>
      prev.includes(platform) ? prev.filter(p => p !== platform) : [...prev, platform]
    );
  };

  const generatePosts = async () => {
    if (selectedPlatforms.length === 0) {
      toast.error('Select at least one platform');
      return;
    }

    setIsGenerating(true);

    const sourceContext = sourceType === 'strategy'
      ? `Marketing Strategy: ${selectedSource.title}
Goal: ${selectedSource.goal}
Content Themes: ${selectedSource.content_themes?.map(t => t.theme).join(', ')}
Caption Templates: ${selectedSource.caption_templates?.map(t => t.type).join(', ')}
Recommended Hashtags: ${selectedSource.recommended_hashtags?.slice(0, 10).map(h => `#${h.hashtag}`).join(' ')}`
      : `Trend Alert: ${selectedSource.title}
Type: ${selectedSource.type}
Description: ${selectedSource.description}
Recommended Actions: ${selectedSource.recommended_actions?.join(', ')}`;

    const prompt = `Generate ready-to-publish social media posts based on this source:

${sourceContext}

TARGET PLATFORMS: ${selectedPlatforms.join(', ')}

For EACH platform, create 1 optimized post with:
1. Platform-specific content (respect character limits and best practices)
2. Engaging caption with hooks and CTAs
3. Relevant hashtags (5-10 per platform)
4. Suggested media type (image, video, carousel, etc.)
5. Best posting time recommendation with reasoning

Make content immediately publishable, on-brand, and optimized for engagement.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          posts: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                platform: { type: 'string' },
                content: { type: 'string' },
                hashtags: { type: 'array', items: { type: 'string' } },
                media_type: { type: 'string' },
                best_posting_time: { type: 'string' },
                posting_reasoning: { type: 'string' },
                expected_engagement: { type: 'string' }
              }
            }
          }
        }
      }
    });

    setGeneratedPosts(result.posts);
    setStep(3);
    setIsGenerating(false);

    // Generate smart scheduling
    await generateScheduling(result.posts);
  };

  const generateScheduling = async (posts) => {
    const prompt = `Create optimal posting schedule for ${posts.length} posts:

${posts.map((p, i) => `${i + 1}. ${p.platform} - Best time: ${p.best_posting_time}`).join('\n')}

Generate a 7-day schedule that:
1. Spreads posts to avoid platform overlap
2. Uses the recommended best times
3. Considers timezone (assume user timezone)
4. Maintains consistent posting rhythm

Return specific date-times for each post.`;

    const schedule = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          scheduled_posts: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                post_index: { type: 'number' },
                scheduled_datetime: { type: 'string' },
                day_of_week: { type: 'string' },
                reasoning: { type: 'string' }
              }
            }
          }
        }
      }
    });

    setSchedulingData(schedule);
  };

  const publishPosts = async (action) => {
    const postsToCreate = generatedPosts.map((post, idx) => {
      const scheduleInfo = schedulingData?.scheduled_posts.find(s => s.post_index === idx);
      
      return {
        title: `${sourceType === 'strategy' ? selectedSource.title : selectedSource.title} - ${post.platform}`,
        content: post.content,
        platforms: [post.platform],
        hashtags: post.hashtags,
        media_type: post.media_type,
        status: action === 'schedule' ? 'scheduled' : 'draft',
        scheduled_time: action === 'schedule' && scheduleInfo 
          ? new Date(scheduleInfo.scheduled_datetime).toISOString()
          : null,
        ai_generated: true
      };
    });

    createPostsMutation.mutate(postsToCreate);
  };

  // Step 1: Select Source
  if (step === 1) {
    return (
      <div className="space-y-6">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-white mb-2">Automated Content Workflow</h2>
          <p className="text-slate-400">Select a source to generate content from</p>
        </div>

        {/* Strategies */}
        {strategies.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">From Your Strategies</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {strategies.map(strategy => (
                <button
                  key={strategy.id}
                  onClick={() => selectSource(strategy, 'strategy')}
                  className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500 transition-all text-left"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-white">{strategy.title}</h4>
                    <Badge className="bg-violet-500/10 text-violet-400">
                      {strategy.content_themes?.length || 0} themes
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-400 capitalize">{strategy.goal?.replace('_', ' ')}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Trends */}
        {trends.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">From Trending Opportunities</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {trends.map(trend => (
                <button
                  key={trend.id}
                  onClick={() => selectSource(trend, 'trend')}
                  className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-fuchsia-500 transition-all text-left"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-white">{trend.title}</h4>
                    <Badge className="bg-fuchsia-500/10 text-fuchsia-400">
                      {trend.priority}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-400">{trend.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {strategies.length === 0 && trends.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            Generate a strategy or capture trends first to use this workflow
          </div>
        )}
      </div>
    );
  }

  // Step 2: Select Platforms
  if (step === 2) {
    const availablePlatforms = accounts.map(a => a.platform);
    const allPlatforms = ['instagram', 'facebook', 'twitter', 'linkedin', 'tiktok', 'youtube'];

    return (
      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={() => setStep(1)}
          className="text-slate-400 -ml-2"
        >
          <ChevronRight className="w-4 h-4 mr-1 rotate-180" />
          Back
        </Button>

        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-2">Select Platforms</h2>
          <p className="text-slate-400">Choose where to publish your content</p>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <h4 className="font-medium text-white mb-2">Source: {selectedSource.title}</h4>
          <p className="text-sm text-slate-400 mb-4">
            {sourceType === 'strategy' ? `Goal: ${selectedSource.goal}` : selectedSource.description}
          </p>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {allPlatforms.map(platform => {
              const isConnected = availablePlatforms.includes(platform);
              const isSelected = selectedPlatforms.includes(platform);

              return (
                <button
                  key={platform}
                  onClick={() => togglePlatform(platform)}
                  disabled={!isConnected}
                  className={cn(
                    "p-4 rounded-xl border transition-all",
                    isSelected
                      ? "border-violet-500 bg-violet-500/10"
                      : isConnected
                      ? "border-slate-700 hover:border-slate-600"
                      : "border-slate-800 opacity-50 cursor-not-allowed"
                  )}
                >
                  <PlatformIcon platform={platform} size="md" />
                  <p className="text-sm text-white capitalize mt-2">{platform}</p>
                  {!isConnected && (
                    <p className="text-xs text-slate-500 mt-1">Not connected</p>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <Button
          onClick={generatePosts}
          disabled={selectedPlatforms.length === 0 || isGenerating}
          className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating Posts...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate {selectedPlatforms.length} Post{selectedPlatforms.length !== 1 ? 's' : ''}
            </>
          )}
        </Button>
      </div>
    );
  }

  // Step 3: Review & Publish
  if (step === 3) {
    return (
      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={() => setStep(2)}
          className="text-slate-400 -ml-2"
        >
          <ChevronRight className="w-4 h-4 mr-1 rotate-180" />
          Back
        </Button>

        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-2">Review Generated Content</h2>
          <p className="text-slate-400">Edit if needed, then publish or schedule</p>
        </div>

        <div className="space-y-4">
          {generatedPosts.map((post, idx) => {
            const scheduleInfo = schedulingData?.scheduled_posts.find(s => s.post_index === idx);

            return (
              <div key={idx} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
                <div className="p-5 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <PlatformIcon platform={post.platform} size="md" />
                    <div>
                      <h4 className="font-semibold text-white capitalize">{post.platform}</h4>
                      <p className="text-xs text-slate-500">{post.media_type}</p>
                    </div>
                  </div>
                  {scheduleInfo && (
                    <Badge className="bg-emerald-500/10 text-emerald-400">
                      <Clock className="w-3 h-3 mr-1" />
                      {scheduleInfo.day_of_week}
                    </Badge>
                  )}
                </div>

                <div className="p-5 space-y-4">
                  <Textarea
                    value={post.content}
                    onChange={(e) => {
                      const updated = [...generatedPosts];
                      updated[idx].content = e.target.value;
                      setGeneratedPosts(updated);
                    }}
                    className="bg-slate-800/50 border-slate-700 text-white min-h-[100px]"
                  />

                  <div className="flex flex-wrap gap-2">
                    {post.hashtags?.map((tag, i) => (
                      <Badge key={i} variant="outline" className="border-violet-500/30 text-violet-400">
                        #{tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Best Posting Time</p>
                      <p className="text-sm text-white">{post.best_posting_time}</p>
                      <p className="text-xs text-slate-400 mt-1">{post.posting_reasoning}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Expected Performance</p>
                      <p className="text-sm text-emerald-400">{post.expected_engagement}</p>
                    </div>
                  </div>

                  {scheduleInfo && (
                    <div className="p-3 rounded-lg bg-violet-500/10 border border-violet-500/20">
                      <p className="text-sm text-violet-300">
                        <Zap className="w-4 h-4 inline mr-1" />
                        Scheduled: {format(new Date(scheduleInfo.scheduled_datetime), 'MMM d, yyyy @ h:mm a')}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">{scheduleInfo.reasoning}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex gap-3">
          <Button
            onClick={() => publishPosts('draft')}
            disabled={createPostsMutation.isPending}
            variant="outline"
            className="flex-1 border-slate-700"
          >
            Save as Drafts
          </Button>
          <Button
            onClick={() => publishPosts('schedule')}
            disabled={createPostsMutation.isPending}
            className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            {createPostsMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Calendar className="w-4 h-4 mr-2" />
                Schedule All
              </>
            )}
          </Button>
        </div>
      </div>
    );
  }
}