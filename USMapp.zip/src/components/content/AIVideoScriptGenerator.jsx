import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Video, Wand2, Download } from 'lucide-react';
import { toast } from 'sonner';

export default function AIVideoScriptGenerator({ productInfo, onScriptGenerated }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [script, setScript] = useState(null);

  const generateScript = async () => {
    if (!productInfo?.trim()) {
      toast.error('Please provide product information');
      return;
    }

    setIsGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a professional video script and storyboard for this product:

${productInfo}

Generate:
1. Hook (first 3 seconds) - attention-grabbing opener
2. Problem statement - pain point addressed
3. Solution presentation - how product solves it
4. Features showcase - key benefits
5. Social proof - trust elements
6. Call-to-action - clear next step

For each section, provide:
- Script text (what to say)
- Visual description (what to show)
- Duration (seconds)
- Shot type (close-up, wide, etc.)

Format as detailed JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            total_duration: { type: 'number' },
            target_platform: { type: 'string' },
            scenes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  duration: { type: 'number' },
                  script: { type: 'string' },
                  visual_description: { type: 'string' },
                  shot_type: { type: 'string' },
                  audio_notes: { type: 'string' }
                }
              }
            }
          }
        }
      });

      setScript(result);
      if (onScriptGenerated) onScriptGenerated(result);
      toast.success('Video script generated!');
    } catch (error) {
      toast.error('Failed to generate script');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const exportScript = () => {
    const text = `${script.title}\n\nTotal Duration: ${script.total_duration}s\nPlatform: ${script.target_platform}\n\n` +
      script.scenes.map((scene, idx) => 
        `Scene ${idx + 1}: ${scene.name} (${scene.duration}s)\n` +
        `Script: ${scene.script}\n` +
        `Visual: ${scene.visual_description}\n` +
        `Shot: ${scene.shot_type}\n` +
        `Audio: ${scene.audio_notes}\n\n`
      ).join('');
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'video-script.txt';
    a.click();
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Video className="w-5 h-5 text-violet-400" />
          <h3 className="text-white font-semibold">AI Video Script Generator</h3>
        </div>
        <Button
          onClick={generateScript}
          disabled={isGenerating || !productInfo}
          size="sm"
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          {isGenerating ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Wand2 className="w-4 h-4 mr-2" />
          )}
          Generate
        </Button>
      </div>

      {script && (
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
            <div>
              <h4 className="text-white font-semibold">{script.title}</h4>
              <p className="text-xs text-slate-400">
                {script.total_duration}s • {script.scenes.length} scenes • {script.target_platform}
              </p>
            </div>
            <Button size="sm" variant="outline" onClick={exportScript}>
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>

          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {script.scenes.map((scene, idx) => (
                <div key={idx} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div className="flex items-center justify-between mb-2">
                    <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                      Scene {idx + 1} • {scene.duration}s
                    </Badge>
                    <span className="text-xs text-slate-400">{scene.shot_type}</span>
                  </div>
                  <h5 className="text-white font-semibold mb-2">{scene.name}</h5>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-slate-400">Script: </span>
                      <span className="text-slate-300">{scene.script}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Visual: </span>
                      <span className="text-slate-300">{scene.visual_description}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Audio: </span>
                      <span className="text-slate-300">{scene.audio_notes}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}