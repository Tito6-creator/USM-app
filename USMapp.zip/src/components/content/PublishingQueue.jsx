import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import {
  Calendar,
  Clock,
  Send,
  Trash2,
  Edit,
  MoreVertical,
  Play,
  Pause,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

const statusConfig = {
  draft: { color: 'bg-slate-500/10 text-slate-400', icon: Edit },
  scheduled: { color: 'bg-violet-500/10 text-violet-400', icon: Calendar },
  pending_approval: { color: 'bg-amber-500/10 text-amber-400', icon: Clock },
  published: { color: 'bg-emerald-500/10 text-emerald-400', icon: CheckCircle2 },
  failed: { color: 'bg-rose-500/10 text-rose-400', icon: Trash2 }
};

export default function PublishingQueue() {
  const [activeTab, setActiveTab] = useState('scheduled');
  const queryClient = useQueryClient();

  const { data: scheduledPosts = [] } = useQuery({
    queryKey: ['posts', 'scheduled'],
    queryFn: () => base44.entities.Post.filter({ status: 'scheduled' }, 'scheduled_time', 50),
  });

  const { data: draftPosts = [] } = useQuery({
    queryKey: ['posts', 'draft'],
    queryFn: () => base44.entities.Post.filter({ status: 'draft' }, '-created_date', 50),
  });

  const { data: publishedPosts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 50),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Post.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast.success('Post updated');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Post.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast.success('Post deleted');
    },
  });

  const publishNow = (post) => {
    updateMutation.mutate({
      id: post.id,
      data: {
        status: 'published',
        published_time: new Date().toISOString()
      }
    });
  };

  const reschedule = (post) => {
    // In production, open a date picker dialog
    updateMutation.mutate({
      id: post.id,
      data: {
        scheduled_time: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      }
    });
  };

  const PostCard = ({ post }) => {
    const config = statusConfig[post.status] || statusConfig.draft;
    const StatusIcon = config.icon;

    return (
      <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-4 hover:border-slate-700 transition-colors">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="flex gap-1">
              {post.platforms?.map(platform => (
                <PlatformIcon key={platform} platform={platform} size="sm" />
              ))}
            </div>
            <div>
              <h4 className="font-medium text-white line-clamp-1">{post.title || 'Untitled'}</h4>
              <div className="flex items-center gap-2 mt-1">
                <Badge className={config.color}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {post.status}
                </Badge>
                {post.ai_generated && (
                  <Badge className="bg-fuchsia-500/10 text-fuchsia-400 text-xs">AI</Badge>
                )}
              </div>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-slate-400">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
              {post.status === 'scheduled' && (
                <>
                  <DropdownMenuItem onClick={() => publishNow(post)}>
                    <Send className="w-4 h-4 mr-2" />
                    Publish Now
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => reschedule(post)}>
                    <Calendar className="w-4 h-4 mr-2" />
                    Reschedule
                  </DropdownMenuItem>
                </>
              )}
              {post.status === 'draft' && (
                <DropdownMenuItem onClick={() => updateMutation.mutate({ 
                  id: post.id, 
                  data: { status: 'scheduled', scheduled_time: new Date(Date.now() + 60 * 60 * 1000).toISOString() }
                })}>
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule
                </DropdownMenuItem>
              )}
              <DropdownMenuItem 
                onClick={() => deleteMutation.mutate(post.id)}
                className="text-rose-400"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <p className="text-sm text-slate-400 line-clamp-2 mb-3">{post.content}</p>

        {post.scheduled_time && (
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Clock className="w-3 h-3" />
            {format(new Date(post.scheduled_time), 'MMM d, yyyy @ h:mm a')}
          </div>
        )}

        {post.published_time && (
          <div className="flex items-center gap-4 text-xs text-slate-500 mt-2">
            <span>{post.likes || 0} likes</span>
            <span>{post.comments || 0} comments</span>
            <span>{post.shares || 0} shares</span>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Publishing Queue</h2>
          <p className="text-slate-400 mt-1">Manage your content pipeline</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="scheduled" className="data-[state=active]:bg-violet-600">
            <Calendar className="w-4 h-4 mr-2" />
            Scheduled ({scheduledPosts.length})
          </TabsTrigger>
          <TabsTrigger value="drafts" className="data-[state=active]:bg-violet-600">
            <Edit className="w-4 h-4 mr-2" />
            Drafts ({draftPosts.length})
          </TabsTrigger>
          <TabsTrigger value="published" className="data-[state=active]:bg-violet-600">
            <CheckCircle2 className="w-4 h-4 mr-2" />
            Published ({publishedPosts.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="scheduled" className="mt-6">
          {scheduledPosts.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              No scheduled posts
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scheduledPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="drafts" className="mt-6">
          {draftPosts.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              No draft posts
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {draftPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="published" className="mt-6">
          {publishedPosts.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              No published posts
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {publishedPosts.map(post => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}