import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import PlatformIcon from '@/components/ui/PlatformIcon';

export default function PlatformVariations({ 
  selectedPlatforms, 
  variations, 
  onVariationChange,
  defaultContent,
  defaultHashtags 
}) {
  const handleContentChange = (platform, content) => {
    onVariationChange({
      ...variations,
      [platform]: {
        ...variations[platform],
        content
      }
    });
  };

  const handleHashtagAdd = (platform, hashtag) => {
    const currentHashtags = variations[platform]?.hashtags || [];
    if (hashtag && !currentHashtags.includes(hashtag.replace('#', ''))) {
      onVariationChange({
        ...variations,
        [platform]: {
          ...variations[platform],
          hashtags: [...currentHashtags, hashtag.replace('#', '')]
        }
      });
    }
  };

  const handleHashtagRemove = (platform, hashtag) => {
    const currentHashtags = variations[platform]?.hashtags || [];
    onVariationChange({
      ...variations,
      [platform]: {
        ...variations[platform],
        hashtags: currentHashtags.filter(h => h !== hashtag)
      }
    });
  };

  if (selectedPlatforms.length === 0) {
    return (
      <div className="text-center py-8 text-slate-500">
        <p>Select platforms to customize content</p>
      </div>
    );
  }

  return (
    <Tabs defaultValue={selectedPlatforms[0]} className="w-full">
      <TabsList className="bg-slate-800/50 flex-wrap h-auto">
        {selectedPlatforms.map((platform) => (
          <TabsTrigger 
            key={platform} 
            value={platform}
            className="data-[state=active]:bg-violet-600 flex items-center gap-2"
          >
            <PlatformIcon platform={platform} size="xs" />
            <span className="capitalize">{platform}</span>
          </TabsTrigger>
        ))}
      </TabsList>

      {selectedPlatforms.map((platform) => {
        const platformContent = variations[platform]?.content || defaultContent;
        const platformHashtags = variations[platform]?.hashtags || defaultHashtags || [];

        return (
          <TabsContent key={platform} value={platform} className="space-y-4">
            <div>
              <Label className="text-white mb-2 block">
                Content for {platform.charAt(0).toUpperCase() + platform.slice(1)}
              </Label>
              <Textarea
                value={platformContent}
                onChange={(e) => handleContentChange(platform, e.target.value)}
                placeholder={`Customize content for ${platform}...`}
                className="min-h-[120px] bg-slate-800/50 border-slate-700 text-white"
              />
              <p className="text-xs text-slate-500 mt-1">
                {platformContent?.length || 0} characters
                {platform === 'twitter' && ` (${280 - (platformContent?.length || 0)} remaining)`}
              </p>
            </div>

            <div>
              <Label className="text-white mb-2 block">Hashtags</Label>
              <Input
                placeholder="Add hashtag and press Enter..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleHashtagAdd(platform, e.target.value);
                    e.target.value = '';
                  }
                }}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
              <div className="flex flex-wrap gap-2 mt-2">
                {platformHashtags.map((tag) => (
                  <Badge
                    key={tag}
                    className="bg-violet-500/10 text-violet-400 border-violet-500/20 cursor-pointer hover:bg-violet-500/20"
                    onClick={() => handleHashtagRemove(platform, tag)}
                  >
                    #{tag}
                    <X className="w-3 h-3 ml-1" />
                  </Badge>
                ))}
              </div>
            </div>
          </TabsContent>
        );
      })}
    </Tabs>
  );
}