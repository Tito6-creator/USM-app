import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { 
  Sparkles, 
  Lightbulb, 
  Hash, 
  TrendingUp, 
  Wand2,
  Image as ImageIcon,
  Copy,
  CheckCircle2,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';

export default function AIContentAssistant({ 
  onContentSelect, 
  onHashtagsSelect,
  currentContent,
  selectedPlatforms,
  mediaUrls 
}) {
  const [activeTab, setActiveTab] = useState('ideas');
  const [isGenerating, setIsGenerating] = useState(false);
  const [niche, setNiche] = useState('');
  const [postIdeas, setPostIdeas] = useState([]);
  const [captions, setCaptions] = useState([]);
  const [hashtags, setHashtags] = useState([]);
  const [optimizedContent, setOptimizedContent] = useState('');
  const [imageDescriptions, setImageDescriptions] = useState([]);
  const [copiedIndex, setCopiedIndex] = useState(null);

  const generatePostIdeas = async () => {
    setIsGenerating(true);
    toast.info('🤖 AI is generating post ideas...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate 10 creative social media post ideas for ${niche || 'general audience'}.
        Consider trending topics, seasonal events, and engaging content formats.
        Make them diverse - include tips, questions, behind-the-scenes, educational, entertaining, and promotional ideas.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: 'object',
          properties: {
            ideas: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' },
                  content_type: { type: 'string' },
                  best_platforms: { type: 'array', items: { type: 'string' } }
                }
              }
            }
          }
        }
      });
      
      if (result && result.ideas) {
        setPostIdeas(result.ideas);
        toast.success(`✅ Generated ${result.ideas.length} post ideas!`);
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Post ideas generation error:', error);
      toast.error('❌ Failed to generate ideas: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateCaptions = async (ideaDescription = '') => {
    setIsGenerating(true);
    toast.info('🤖 AI is creating captions...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate 5 different caption variations for a social media post${ideaDescription ? ` about: ${ideaDescription}` : ''}.
        Platforms: ${selectedPlatforms.length > 0 ? selectedPlatforms.join(', ') : 'general social media'}
        Include:
        - Professional tone
        - Casual/friendly tone
        - Inspirational tone
        - Funny/witty tone
        - Question/engagement tone
        
        Each caption should be optimized for the platforms and include emojis where appropriate.`,
        response_json_schema: {
          type: 'object',
          properties: {
            captions: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  tone: { type: 'string' },
                  text: { type: 'string' },
                  character_count: { type: 'number' }
                }
              }
            }
          }
        }
      });
      
      if (result && result.captions) {
        setCaptions(result.captions);
        toast.success(`✅ Generated ${result.captions.length} captions!`);
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Caption generation error:', error);
      toast.error('❌ Failed to generate captions: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateHashtags = async () => {
    setIsGenerating(true);
    toast.info('🤖 AI is finding trending hashtags...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate trending and relevant hashtags for this content:
        "${currentContent || niche || 'social media post'}"
        
        Platforms: ${selectedPlatforms.length > 0 ? selectedPlatforms.join(', ') : 'general social media'}
        
        Provide:
        - 10 trending hashtags (high volume, competitive)
        - 10 niche-specific hashtags (lower volume, targeted)
        - 5 branded/unique hashtags
        
        Consider current trends and platform-specific best practices.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: 'object',
          properties: {
            trending: { type: 'array', items: { type: 'string' } },
            niche: { type: 'array', items: { type: 'string' } },
            branded: { type: 'array', items: { type: 'string' } }
          }
        }
      });
      
      if (result) {
        setHashtags(result);
        const total = (result.trending?.length || 0) + (result.niche?.length || 0) + (result.branded?.length || 0);
        toast.success(`✅ Generated ${total} hashtags!`);
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Hashtag generation error:', error);
      toast.error('❌ Failed to generate hashtags: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const optimizeContent = async () => {
    if (!currentContent) {
      toast.error('Please enter content to optimize');
      return;
    }
    
    setIsGenerating(true);
    toast.info('🤖 AI is optimizing your content...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Optimize this social media content for better engagement:
        
        Original content: "${currentContent}"
        Platforms: ${selectedPlatforms.length > 0 ? selectedPlatforms.join(', ') : 'general social media'}
        
        Improve:
        - Hook/opening line to grab attention
        - Clarity and readability
        - Call-to-action
        - Emoji usage
        - Length optimization for platforms
        - Engagement triggers (questions, polls, etc.)
        
        Provide the optimized version and explain what was improved.`,
        response_json_schema: {
          type: 'object',
          properties: {
            optimized_content: { type: 'string' },
            improvements: { type: 'array', items: { type: 'string' } },
            engagement_score_before: { type: 'number' },
            engagement_score_after: { type: 'number' }
          }
        }
      });
      
      if (result && result.optimized_content) {
        setOptimizedContent(result);
        toast.success('✅ Content optimized successfully!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Content optimization error:', error);
      toast.error('❌ Failed to optimize content: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateImageDescriptions = async () => {
    if (!mediaUrls || mediaUrls.length === 0) {
      toast.error('Please upload images first');
      return;
    }
    
    setIsGenerating(true);
    try {
      const descriptions = [];
      for (const url of mediaUrls.slice(0, 3)) {
        const result = await base44.integrations.Core.InvokeLLM({
          prompt: `Analyze this image and provide:
          1. A detailed alt text description for accessibility (describe what's in the image)
          2. A creative caption suggestion
          3. Relevant keywords/tags`,
          file_urls: [url],
          response_json_schema: {
            type: 'object',
            properties: {
              alt_text: { type: 'string' },
              caption_suggestion: { type: 'string' },
              keywords: { type: 'array', items: { type: 'string' } }
            }
          }
        });
        descriptions.push({ url, ...result });
      }
      setImageDescriptions(descriptions);
      toast.success('Image descriptions generated!');
    } catch (error) {
      toast.error('Failed to generate descriptions');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text, index) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast.success('Copied to clipboard');
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-semibold text-white">AI Content Assistant</h3>
          <p className="text-xs text-slate-400">Create better content with AI</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <div className="px-6 py-3 bg-slate-800/30">
          <TabsList className="bg-slate-800/50 w-full grid grid-cols-4">
            <TabsTrigger value="ideas" className="data-[state=active]:bg-violet-600 text-xs">
              <Lightbulb className="w-3 h-3 mr-1" />
              Ideas
            </TabsTrigger>
            <TabsTrigger value="captions" className="data-[state=active]:bg-violet-600 text-xs">
              <Wand2 className="w-3 h-3 mr-1" />
              Captions
            </TabsTrigger>
            <TabsTrigger value="hashtags" className="data-[state=active]:bg-violet-600 text-xs">
              <Hash className="w-3 h-3 mr-1" />
              Hashtags
            </TabsTrigger>
            <TabsTrigger value="optimize" className="data-[state=active]:bg-violet-600 text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              Optimize
            </TabsTrigger>
          </TabsList>
        </div>

        <ScrollArea className="h-[500px]">
          <div className="p-6">
            <TabsContent value="ideas" className="mt-0 space-y-4">
              <div>
                <Input
                  value={niche}
                  onChange={(e) => setNiche(e.target.value)}
                  placeholder="Enter your niche or topic..."
                  className="bg-slate-800/50 border-slate-700 text-white mb-3"
                />
                <Button 
                  onClick={generatePostIdeas} 
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
                >
                  {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Lightbulb className="w-4 h-4 mr-2" />}
                  Generate Post Ideas
                </Button>
              </div>

              <div className="space-y-3">
                {postIdeas.map((idea, idx) => (
                  <div key={idx} className="p-4 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors group">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <h4 className="text-white font-medium">{idea.title}</h4>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => generateCaptions(idea.description)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-xs"
                      >
                        Use
                      </Button>
                    </div>
                    <p className="text-sm text-slate-400 mb-2">{idea.description}</p>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20 text-xs">
                        {idea.content_type}
                      </Badge>
                      {idea.best_platforms?.map(platform => (
                        <Badge key={platform} variant="outline" className="text-xs border-slate-700 text-slate-400">
                          {platform}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="captions" className="mt-0 space-y-4">
              <Button 
                onClick={() => generateCaptions()} 
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Wand2 className="w-4 h-4 mr-2" />}
                Generate Captions
              </Button>

              <div className="space-y-3">
                {captions.map((caption, idx) => (
                  <div key={idx} className="p-4 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors group">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <Badge className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20 text-xs">
                        {caption.tone}
                      </Badge>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onContentSelect(caption.text)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity h-6 px-2 text-xs"
                        >
                          Use
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(caption.text, `caption-${idx}`)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity h-6 px-2"
                        >
                          {copiedIndex === `caption-${idx}` ? (
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-slate-300">{caption.text}</p>
                    <p className="text-xs text-slate-500 mt-2">{caption.character_count} characters</p>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="hashtags" className="mt-0 space-y-4">
              <Button 
                onClick={generateHashtags} 
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Hash className="w-4 h-4 mr-2" />}
                Generate Hashtags
              </Button>

              {hashtags.trending && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-white">Trending Hashtags</h4>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onHashtagsSelect(hashtags.trending)}
                      className="text-xs"
                    >
                      Use All
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {hashtags.trending?.map((tag, idx) => (
                      <Badge
                        key={idx}
                        className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 cursor-pointer hover:bg-emerald-500/20"
                        onClick={() => onHashtagsSelect([tag])}
                      >
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {hashtags.niche && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-white">Niche Hashtags</h4>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onHashtagsSelect(hashtags.niche)}
                      className="text-xs"
                    >
                      Use All
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {hashtags.niche?.map((tag, idx) => (
                      <Badge
                        key={idx}
                        className="bg-violet-500/10 text-violet-400 border-violet-500/20 cursor-pointer hover:bg-violet-500/20"
                        onClick={() => onHashtagsSelect([tag])}
                      >
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {hashtags.branded && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="text-sm font-medium text-white">Branded Hashtags</h4>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onHashtagsSelect(hashtags.branded)}
                      className="text-xs"
                    >
                      Use All
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {hashtags.branded?.map((tag, idx) => (
                      <Badge
                        key={idx}
                        className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20 cursor-pointer hover:bg-cyan-500/20"
                        onClick={() => onHashtagsSelect([tag])}
                      >
                        #{tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="optimize" className="mt-0 space-y-4">
              <Button 
                onClick={optimizeContent} 
                disabled={isGenerating || !currentContent}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <TrendingUp className="w-4 h-4 mr-2" />}
                Optimize Content
              </Button>

              {optimizedContent && (
                <>
                  <div className="p-4 rounded-lg bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-medium text-white">Optimized Version</h4>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onContentSelect(optimizedContent.optimized_content)}
                          className="h-6 px-2 text-xs"
                        >
                          Use
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(optimizedContent.optimized_content, 'optimized')}
                          className="h-6 px-2"
                        >
                          {copiedIndex === 'optimized' ? (
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-slate-300 whitespace-pre-wrap">{optimizedContent.optimized_content}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-slate-800/50">
                      <p className="text-xs text-slate-500 mb-1">Before</p>
                      <p className="text-2xl font-bold text-white">{optimizedContent.engagement_score_before}/100</p>
                    </div>
                    <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <p className="text-xs text-emerald-400 mb-1">After</p>
                      <p className="text-2xl font-bold text-emerald-400">{optimizedContent.engagement_score_after}/100</p>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-white mb-2">Improvements Made</h4>
                    <ul className="space-y-2">
                      {optimizedContent.improvements?.map((improvement, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-slate-400">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                          <span>{improvement}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </>
              )}

              {mediaUrls && mediaUrls.length > 0 && (
                <>
                  <div className="pt-4 border-t border-slate-800">
                    <Button 
                      onClick={generateImageDescriptions} 
                      disabled={isGenerating}
                      variant="outline"
                      className="w-full border-slate-700"
                    >
                      {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ImageIcon className="w-4 h-4 mr-2" />}
                      Generate Image Descriptions
                    </Button>
                  </div>

                  {imageDescriptions.map((desc, idx) => (
                    <div key={idx} className="p-4 rounded-lg bg-slate-800/50">
                      <img src={desc.url} alt="" className="w-full h-32 object-cover rounded-lg mb-3" />
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Alt Text (Accessibility)</p>
                          <p className="text-sm text-slate-300">{desc.alt_text}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Caption Suggestion</p>
                          <p className="text-sm text-slate-300">{desc.caption_suggestion}</p>
                        </div>
                        <div className="flex flex-wrap gap-1">
                          {desc.keywords?.map((keyword, kidx) => (
                            <Badge key={kidx} variant="outline" className="text-xs border-slate-700 text-slate-400">
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </TabsContent>
          </div>
        </ScrollArea>
      </Tabs>
    </div>
  );
}