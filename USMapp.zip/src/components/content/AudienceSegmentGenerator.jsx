import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Users, Copy, Check } from 'lucide-react';
import { toast } from 'sonner';

export default function AudienceSegmentGenerator({ baseContent, onVariationsGenerated }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [segments, setSegments] = useState([]);
  const [copiedIdx, setCopiedIdx] = useState(null);

  const generateSegmentedContent = async () => {
    if (!baseContent?.trim()) {
      toast.error('Please add content first');
      return;
    }

    setIsGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this content and create personalized variations for different audience segments:

Original content: ${baseContent}

Create 4 variations targeting:
1. Young Professionals (25-35, career-focused, tech-savvy)
2. Parents/Families (30-45, value-focused, practical)
3. Gen Z (18-24, trend-conscious, authentic voice)
4. Business Owners (35-55, ROI-focused, professional)

For each segment:
- Adapt tone and language
- Highlight relevant benefits
- Use appropriate references and examples
- Adjust call-to-action

Return JSON with segment variations.`,
        response_json_schema: {
          type: 'object',
          properties: {
            segments: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  age_range: { type: 'string' },
                  characteristics: { type: 'string' },
                  adapted_content: { type: 'string' },
                  tone: { type: 'string' },
                  key_changes: { type: 'array', items: { type: 'string' } }
                }
              }
            }
          }
        }
      });

      setSegments(result.segments || []);
      if (onVariationsGenerated) onVariationsGenerated(result.segments);
      toast.success('Generated content for 4 audience segments!');
    } catch (error) {
      toast.error('Failed to generate variations');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyContent = async (content, idx) => {
    await navigator.clipboard.writeText(content);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
    toast.success('Copied to clipboard');
  };

  const colors = ['bg-violet-500/10 text-violet-400 border-violet-500/20',
                  'bg-blue-500/10 text-blue-400 border-blue-500/20',
                  'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
                  'bg-amber-500/10 text-amber-400 border-amber-500/20'];

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-400" />
          <h3 className="text-white font-semibold">Audience Segment Generator</h3>
        </div>
        <Button
          onClick={generateSegmentedContent}
          disabled={isGenerating || !baseContent}
          size="sm"
          className="bg-gradient-to-r from-blue-600 to-cyan-600"
        >
          {isGenerating ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Users className="w-4 h-4 mr-2" />
          )}
          Generate
        </Button>
      </div>

      {segments.length > 0 && (
        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            {segments.map((segment, idx) => (
              <div key={idx} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-white font-semibold">{segment.name}</h4>
                    <p className="text-xs text-slate-400">{segment.age_range} • {segment.tone}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyContent(segment.adapted_content, idx)}
                  >
                    {copiedIdx === idx ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>

                <p className="text-xs text-slate-500 mb-3">{segment.characteristics}</p>

                <div className="p-3 bg-slate-900/50 rounded-lg mb-3">
                  <p className="text-sm text-slate-300 whitespace-pre-wrap">
                    {segment.adapted_content}
                  </p>
                </div>

                <div>
                  <p className="text-xs text-slate-400 mb-2">Key Adaptations:</p>
                  <div className="flex flex-wrap gap-2">
                    {segment.key_changes.map((change, cIdx) => (
                      <Badge key={cIdx} className={colors[idx % colors.length]}>
                        {change}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}