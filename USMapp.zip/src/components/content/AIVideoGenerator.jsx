import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Video, 
  Sparkles, 
  Loader2, 
  Upload,
  Wand2,
  AlertCircle,
  Clock,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function AIVideoGenerator({ onVideoGenerated }) {
  const [prompt, setPrompt] = useState('');
  const [duration, setDuration] = useState('15');
  const [style, setStyle] = useState('realistic');
  const [isGenerating, setIsGenerating] = useState(false);

  const videoStyles = [
    { value: 'realistic', label: 'Realistic', icon: '📹' },
    { value: 'animated', label: 'Animated', icon: '🎨' },
    { value: 'cinematic', label: 'Cinematic', icon: '🎬' },
    { value: 'minimalist', label: 'Minimalist', icon: '⚪' },
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a video description');
      return;
    }

    setIsGenerating(true);
    toast.info('🤖 AI is creating video storyboard...');

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a detailed video script and storyboard for: ${prompt}
        
Duration: ${duration} seconds
Style: ${style}

Provide:
1. Scene-by-scene breakdown
2. Visual descriptions for each scene
3. Suggested camera movements
4. Audio/music suggestions
5. Text overlays/captions

Make it production-ready and optimized for social media.`,
        response_json_schema: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            scenes: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  scene_number: { type: 'number' },
                  duration: { type: 'number' },
                  visual: { type: 'string' },
                  camera: { type: 'string' },
                  audio: { type: 'string' },
                  text_overlay: { type: 'string' }
                }
              }
            },
            overall_mood: { type: 'string' },
            music_suggestion: { type: 'string' }
          }
        }
      });

      if (result) {
        toast.success('✅ Video storyboard generated! Connect video API to render.');
        if (onVideoGenerated) {
          onVideoGenerated(result);
        }
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Video generation error:', error);
      toast.error('❌ Failed to generate video: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const examplePrompts = [
    'Product showcase with smooth camera movements',
    'Inspiring morning routine with upbeat music',
    'Tech product unboxing with cinematic lighting',
    'Food preparation in time-lapse style',
    'Nature scenery with aerial drone footage',
  ];

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
          <Video className="w-4 h-4 text-white" />
        </div>
        <div>
          <h3 className="font-semibold text-white">AI Video Generator</h3>
          <p className="text-xs text-slate-400">Create videos from text descriptions</p>
        </div>
      </div>

      <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20 mb-4">
        <div className="flex items-start gap-2">
          <Sparkles className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
          <div className="text-sm">
            <p className="text-emerald-300 font-medium">AI Video Generation Ready</p>
            <p className="text-emerald-400/80 text-xs mt-1">
              Generates video storyboards. Connect Runway/Synthesia API for full rendering.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <Label className="text-white mb-2 block">Video Description</Label>
          <Textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe the video you want to create..."
            className="min-h-[100px] bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-white mb-2 block">Duration</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="5">5 seconds</SelectItem>
                <SelectItem value="10">10 seconds</SelectItem>
                <SelectItem value="15">15 seconds</SelectItem>
                <SelectItem value="30">30 seconds</SelectItem>
                <SelectItem value="60">60 seconds</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-white mb-2 block">Style</Label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                {videoStyles.map(s => (
                  <SelectItem key={s.value} value={s.value}>
                    {s.icon} {s.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button
          onClick={handleGenerate}
          disabled={isGenerating || !prompt.trim()}
          className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating Video...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate Video
            </>
          )}
        </Button>

        {isGenerating && (
          <div className="p-4 rounded-lg bg-violet-500/10 border border-violet-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-violet-400" />
              <span className="text-sm text-violet-300 font-medium">
                Estimated time: ~{duration} seconds
              </span>
            </div>
            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 animate-pulse" style={{ width: '60%' }} />
            </div>
          </div>
        )}

        <div>
          <Label className="text-slate-400 mb-2 block text-xs">Example Prompts</Label>
          <div className="space-y-2">
            {examplePrompts.map((example, idx) => (
              <button
                key={idx}
                onClick={() => setPrompt(example)}
                className="w-full text-left p-2 rounded-lg bg-slate-800/30 border border-slate-700/50 hover:border-violet-500/30 hover:bg-slate-800/50 transition-all text-sm text-slate-400 hover:text-white"
              >
                <Wand2 className="w-3 h-3 inline mr-2 text-violet-400" />
                {example}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-slate-800">
          <div className="flex items-start gap-2 text-xs text-slate-500">
            <Zap className="w-3 h-3 mt-0.5 text-violet-400" />
            <p>
              Videos will be optimized for {style} style with {duration}s duration. 
              Generation typically takes 30-60 seconds per video.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}