import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  Sparkles,
  RefreshCw,
  Hash,
  Target,
  Copy,
  Check,
  Loader2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function AIContentRefinement({ 
  content, 
  onContentUpdate, 
  onHashtagsUpdate,
  currentHashtags = []
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isRefining, setIsRefining] = useState(false);
  const [activeTab, setActiveTab] = useState('rephrase');
  
  // Rephrase states
  const [rephraseVariations, setRephraseVariations] = useState([]);
  const [rephraseStyle, setRephraseStyle] = useState('professional');
  
  // Hashtag states
  const [hashtagSets, setHashtagSets] = useState([]);
  
  // CTA states
  const [ctaVariations, setCtaVariations] = useState([]);
  
  const [copiedIndex, setCopiedIndex] = useState(null);

  const rephraseStyles = [
    { id: 'professional', label: 'Professional', icon: '💼' },
    { id: 'casual', label: 'Casual', icon: '😊' },
    { id: 'engaging', label: 'Engaging', icon: '✨' },
    { id: 'concise', label: 'Concise', icon: '📝' },
    { id: 'expanded', label: 'Expanded', icon: '📖' }
  ];

  const generateRephrase = async () => {
    if (!content) {
      toast.error('Please add content first');
      return;
    }

    setIsRefining(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Rephrase the following social media post in a ${rephraseStyle} style. Generate 3 different variations.
        
Original post: ${content}

Requirements:
- Keep the core message
- Make it ${rephraseStyle}
- Maintain appropriate length for social media
- Include emojis where appropriate

Return JSON array with 3 variations.`,
        response_json_schema: {
          type: 'object',
          properties: {
            variations: {
              type: 'array',
              items: { type: 'string' }
            }
          }
        }
      });

      if (result && result.variations) {
        setRephraseVariations(result.variations);
        toast.success('✅ Generated rephrased versions!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Rephrase error:', error);
      toast.error('❌ Failed to generate variations: ' + error.message);
    } finally {
      setIsRefining(false);
    }
  };

  const generateHashtagSets = async () => {
    if (!content) {
      toast.error('Please add content first');
      return;
    }

    setIsRefining(true);
    toast.info('🤖 AI is generating hashtag sets...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this social media post and generate 3 different hashtag strategies:

Post content: ${content}

Generate:
1. Trending Set: High-volume trending hashtags (8-10 hashtags)
2. Niche Set: Specific niche/community hashtags (8-10 hashtags)
3. Balanced Set: Mix of popular and niche hashtags (8-10 hashtags)

Each set should include hashtags without the # symbol.`,
        response_json_schema: {
          type: 'object',
          properties: {
            trending: {
              type: 'object',
              properties: {
                hashtags: { type: 'array', items: { type: 'string' } },
                description: { type: 'string' }
              }
            },
            niche: {
              type: 'object',
              properties: {
                hashtags: { type: 'array', items: { type: 'string' } },
                description: { type: 'string' }
              }
            },
            balanced: {
              type: 'object',
              properties: {
                hashtags: { type: 'array', items: { type: 'string' } },
                description: { type: 'string' }
              }
            }
          }
        }
      });

      if (result && result.trending && result.niche && result.balanced) {
        setHashtagSets([
          { name: 'Trending', ...result.trending },
          { name: 'Niche', ...result.niche },
          { name: 'Balanced', ...result.balanced }
        ]);
        toast.success('✅ Generated hashtag sets!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Hashtag generation error:', error);
      toast.error('❌ Failed to generate hashtags: ' + error.message);
    } finally {
      setIsRefining(false);
    }
  };

  const generateCTAVariations = async () => {
    if (!content) {
      toast.error('Please add content first');
      return;
    }

    setIsRefining(true);
    toast.info('🤖 AI is creating CTA variations...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Based on this social media post, generate 5 different A/B testable call-to-action variations:

Post content: ${content}

Each CTA should:
- Be action-oriented
- Be compelling and clear
- Vary in tone (urgent, friendly, curious, direct, value-focused)
- Be suitable for A/B testing
- Be under 15 words

Return JSON with CTAs and their tone/strategy.`,
        response_json_schema: {
          type: 'object',
          properties: {
            ctas: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  text: { type: 'string' },
                  tone: { type: 'string' },
                  strategy: { type: 'string' }
                }
              }
            }
          }
        }
      });

      if (result && result.ctas) {
        setCtaVariations(result.ctas);
        toast.success('✅ Generated CTA variations!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('CTA generation error:', error);
      toast.error('❌ Failed to generate CTAs: ' + error.message);
    } finally {
      setIsRefining(false);
    }
  };

  const copyToClipboard = async (text, index) => {
    await navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast.success('Copied to clipboard');
  };

  const applyContent = (text) => {
    onContentUpdate(text);
    toast.success('Content applied');
  };

  const applyHashtags = (hashtags) => {
    onHashtagsUpdate(hashtags);
    toast.success('Hashtags applied');
  };

  const appendCTA = (cta) => {
    const newContent = `${content}\n\n${cta}`;
    onContentUpdate(newContent);
    toast.success('CTA added to content');
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full p-4 flex items-center justify-between hover:bg-slate-800/30 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div className="text-left">
            <h3 className="text-white font-semibold">AI Content Refinement</h3>
            <p className="text-xs text-slate-400">Rephrase, hashtags & CTA variations</p>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 text-slate-400" />
        ) : (
          <ChevronDown className="w-5 h-5 text-slate-400" />
        )}
      </button>

      {isExpanded && (
        <div className="p-4 border-t border-slate-800">
          {/* Tabs */}
          <div className="flex gap-2 mb-4">
            {[
              { id: 'rephrase', label: 'Rephrase', icon: RefreshCw },
              { id: 'hashtags', label: 'Hashtags', icon: Hash },
              { id: 'cta', label: 'CTA Tests', icon: Target }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                    activeTab === tab.id
                      ? "bg-violet-600 text-white"
                      : "bg-slate-800/50 text-slate-400 hover:text-slate-300"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          <Separator className="mb-4 bg-slate-800" />

          {/* Rephrase Tab */}
          {activeTab === 'rephrase' && (
            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-400 mb-2">Select style:</p>
                <div className="flex flex-wrap gap-2">
                  {rephraseStyles.map(style => (
                    <button
                      key={style.id}
                      onClick={() => setRephraseStyle(style.id)}
                      className={cn(
                        "px-3 py-1.5 rounded-lg text-sm transition-all",
                        rephraseStyle === style.id
                          ? "bg-violet-600 text-white"
                          : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                      )}
                    >
                      {style.icon} {style.label}
                    </button>
                  ))}
                </div>
              </div>

              <Button
                onClick={generateRephrase}
                disabled={isRefining || !content}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isRefining ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Generate Variations
              </Button>

              {rephraseVariations.length > 0 && (
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-3">
                    {rephraseVariations.map((variation, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-800/50 rounded-lg border border-slate-700"
                      >
                        <p className="text-sm text-slate-300 mb-3 whitespace-pre-wrap">{variation}</p>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => applyContent(variation)}
                            className="flex-1 border-slate-700"
                          >
                            Apply
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(variation, `rephrase-${idx}`)}
                          >
                            {copiedIndex === `rephrase-${idx}` ? (
                              <Check className="w-4 h-4 text-green-400" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          )}

          {/* Hashtags Tab */}
          {activeTab === 'hashtags' && (
            <div className="space-y-4">
              <Button
                onClick={generateHashtagSets}
                disabled={isRefining || !content}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isRefining ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Hash className="w-4 h-4 mr-2" />
                )}
                Generate Hashtag Sets
              </Button>

              {hashtagSets.length > 0 && (
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-3">
                    {hashtagSets.map((set, idx) => (
                      <div
                        key={idx}
                        className="p-4 bg-slate-800/50 rounded-lg border border-slate-700"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-white">{set.name}</h4>
                          <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                            {set.hashtags?.length || 0} tags
                          </Badge>
                        </div>
                        <p className="text-xs text-slate-400 mb-3">{set.description}</p>
                        <div className="flex flex-wrap gap-1.5 mb-3">
                          {set.hashtags?.map((tag, tagIdx) => (
                            <Badge
                              key={tagIdx}
                              variant="outline"
                              className="border-slate-600 text-slate-300 text-xs"
                            >
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => applyHashtags(set.hashtags)}
                            className="flex-1 border-slate-700"
                          >
                            Apply Set
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(set.hashtags.map(t => `#${t}`).join(' '), `hashtag-${idx}`)}
                          >
                            {copiedIndex === `hashtag-${idx}` ? (
                              <Check className="w-4 h-4 text-green-400" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          )}

          {/* CTA Tab */}
          {activeTab === 'cta' && (
            <div className="space-y-4">
              <Button
                onClick={generateCTAVariations}
                disabled={isRefining || !content}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isRefining ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Target className="w-4 h-4 mr-2" />
                )}
                Generate CTA Variations
              </Button>

              {ctaVariations.length > 0 && (
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-3">
                    {ctaVariations.map((cta, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-800/50 rounded-lg border border-slate-700"
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <Badge className="bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/20 text-xs mb-2">
                              {cta.tone}
                            </Badge>
                            <p className="text-sm text-white font-medium">{cta.text}</p>
                            <p className="text-xs text-slate-400 mt-1">{cta.strategy}</p>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => appendCTA(cta.text)}
                            className="flex-1 border-slate-700"
                          >
                            Add to Post
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(cta.text, `cta-${idx}`)}
                          >
                            {copiedIndex === `cta-${idx}` ? (
                              <Check className="w-4 h-4 text-green-400" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}