import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Repeat, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function RecurringSchedule({ 
  isRecurring, 
  onRecurringChange,
  recurrenceData,
  onRecurrenceChange 
}) {
  const toggleDay = (day) => {
    const currentDays = recurrenceData.recurrence_days || [];
    const newDays = currentDays.includes(day)
      ? currentDays.filter(d => d !== day)
      : [...currentDays, day];
    onRecurrenceChange({ ...recurrenceData, recurrence_days: newDays });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Repeat className="w-4 h-4 text-violet-400" />
          <Label className="text-white">Recurring Post</Label>
        </div>
        <Switch checked={isRecurring} onCheckedChange={onRecurringChange} />
      </div>

      {isRecurring && (
        <div className="space-y-4 p-4 rounded-lg bg-slate-800/30 border border-slate-700">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white mb-2 block">Repeat</Label>
              <Select 
                value={recurrenceData.recurrence_pattern || 'weekly'} 
                onValueChange={(value) => onRecurrenceChange({ ...recurrenceData, recurrence_pattern: value })}
              >
                <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white mb-2 block">Every</Label>
              <Input
                type="number"
                min="1"
                value={recurrenceData.recurrence_interval || 1}
                onChange={(e) => onRecurrenceChange({ 
                  ...recurrenceData, 
                  recurrence_interval: parseInt(e.target.value) 
                })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
          </div>

          {recurrenceData.recurrence_pattern === 'weekly' && (
            <div>
              <Label className="text-white mb-2 block">Repeat on</Label>
              <div className="flex flex-wrap gap-2">
                {DAYS_OF_WEEK.map((day) => (
                  <Badge
                    key={day}
                    variant="outline"
                    className={cn(
                      "cursor-pointer transition-colors",
                      (recurrenceData.recurrence_days || []).includes(day)
                        ? "bg-violet-500/20 text-violet-300 border-violet-500/30"
                        : "border-slate-700 text-slate-400 hover:border-violet-500/30"
                    )}
                    onClick={() => toggleDay(day)}
                  >
                    {day.substring(0, 3)}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div>
            <Label className="text-white mb-2 block">End Date (optional)</Label>
            <Input
              type="date"
              value={recurrenceData.recurrence_end_date?.split('T')[0] || ''}
              onChange={(e) => onRecurrenceChange({ 
                ...recurrenceData, 
                recurrence_end_date: e.target.value ? new Date(e.target.value).toISOString() : null 
              })}
              className="bg-slate-800/50 border-slate-700 text-white"
            />
          </div>

          <div className="flex items-start gap-2 p-3 rounded-lg bg-violet-500/10 border border-violet-500/20">
            <Calendar className="w-4 h-4 text-violet-400 mt-0.5" />
            <div className="text-sm text-violet-300">
              <p className="font-medium mb-1">Recurring Schedule Summary</p>
              <p className="text-violet-400/80">
                Posts every {recurrenceData.recurrence_interval || 1} {recurrenceData.recurrence_pattern || 'week'}
                {recurrenceData.recurrence_pattern === 'weekly' && recurrenceData.recurrence_days?.length > 0 
                  ? ` on ${recurrenceData.recurrence_days.join(', ')}`
                  : ''
                }
                {recurrenceData.recurrence_end_date 
                  ? ` until ${new Date(recurrenceData.recurrence_end_date).toLocaleDateString()}`
                  : ' indefinitely'
                }
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}