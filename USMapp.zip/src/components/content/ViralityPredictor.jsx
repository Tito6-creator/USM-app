import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Loader2, TrendingUp, AlertTriangle, CheckCircle2, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function ViralityPredictor({ content, mediaUrls, platforms, hashtags }) {
  const [isPredicting, setIsPredicting] = useState(false);
  const [prediction, setPrediction] = useState(null);

  const predictVirality = async () => {
    if (!content?.trim()) {
      toast.error('Please add content first');
      return;
    }

    setIsPredicting(true);
    try {
      // Get historical performance data
      const pastPosts = await base44.entities.Post.filter({ status: 'published' }, '-published_time', 50);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this content and predict its virality potential:

Content: ${content}
Platforms: ${platforms?.join(', ')}
Has media: ${mediaUrls?.length > 0}
Hashtags: ${hashtags?.join(', ')}

Historical performance context:
${pastPosts.slice(0, 10).map(p => 
  `Post: ${p.content?.substring(0, 50)}... | Engagement: ${(p.likes || 0) + (p.comments || 0) + (p.shares || 0)}`
).join('\n')}

Predict:
1. Virality score (0-100)
2. Engagement potential (low/medium/high/viral)
3. Strengths (what works well)
4. Weaknesses (what could be improved)
5. Specific recommendations to boost virality
6. Best platform for this content
7. Optimal posting time prediction
8. Risk factors (controversial, sensitive topics)

Format as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            virality_score: { type: 'number' },
            engagement_potential: { type: 'string' },
            predicted_reach: { type: 'number' },
            predicted_engagement: { type: 'number' },
            strengths: { type: 'array', items: { type: 'string' } },
            weaknesses: { type: 'array', items: { type: 'string' } },
            recommendations: { type: 'array', items: { type: 'string' } },
            best_platform: { type: 'string' },
            optimal_time: { type: 'string' },
            risk_factors: { type: 'array', items: { type: 'string' } }
          }
        }
      });

      setPrediction(result);
      toast.success('Virality prediction complete!');
    } catch (error) {
      toast.error('Failed to predict virality');
      console.error(error);
    } finally {
      setIsPredicting(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-emerald-400';
    if (score >= 60) return 'text-blue-400';
    if (score >= 40) return 'text-amber-400';
    return 'text-rose-400';
  };

  const getScoreBg = (score) => {
    if (score >= 80) return 'bg-emerald-500/10 border-emerald-500/20';
    if (score >= 60) return 'bg-blue-500/10 border-blue-500/20';
    if (score >= 40) return 'bg-amber-500/10 border-amber-500/20';
    return 'bg-rose-500/10 border-rose-500/20';
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <h3 className="text-white font-semibold">Virality Predictor</h3>
        </div>
        <Button
          onClick={predictVirality}
          disabled={isPredicting || !content}
          size="sm"
          className="bg-gradient-to-r from-emerald-600 to-teal-600"
        >
          {isPredicting ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4 mr-2" />
          )}
          Predict
        </Button>
      </div>

      {prediction && (
        <div className="space-y-4">
          {/* Score Card */}
          <div className={cn("p-6 rounded-lg border text-center", getScoreBg(prediction.virality_score))}>
            <p className="text-sm text-slate-400 mb-2">Virality Score</p>
            <p className={cn("text-5xl font-bold mb-2", getScoreColor(prediction.virality_score))}>
              {prediction.virality_score}
            </p>
            <Progress value={prediction.virality_score} className="h-2 mb-2" />
            <Badge className={cn("text-xs", getScoreBg(prediction.virality_score))}>
              {prediction.engagement_potential}
            </Badge>
          </div>

          {/* Predictions */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-800/50 rounded-lg">
              <p className="text-xs text-slate-400">Predicted Reach</p>
              <p className="text-lg font-semibold text-white">
                {prediction.predicted_reach?.toLocaleString()}
              </p>
            </div>
            <div className="p-3 bg-slate-800/50 rounded-lg">
              <p className="text-xs text-slate-400">Predicted Engagement</p>
              <p className="text-lg font-semibold text-white">
                {prediction.predicted_engagement?.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Best Platform & Time */}
          <div className="p-3 bg-violet-500/10 border border-violet-500/20 rounded-lg">
            <p className="text-xs text-violet-400 mb-1">Best Platform: {prediction.best_platform}</p>
            <p className="text-xs text-violet-400">Optimal Time: {prediction.optimal_time}</p>
          </div>

          {/* Strengths */}
          {prediction.strengths?.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Strengths
              </p>
              <div className="space-y-2">
                {prediction.strengths.map((strength, idx) => (
                  <div key={idx} className="p-2 bg-emerald-500/10 rounded-lg text-sm text-emerald-300">
                    {strength}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Weaknesses */}
          {prediction.weaknesses?.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Areas to Improve
              </p>
              <div className="space-y-2">
                {prediction.weaknesses.map((weakness, idx) => (
                  <div key={idx} className="p-2 bg-amber-500/10 rounded-lg text-sm text-amber-300">
                    {weakness}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recommendations */}
          {prediction.recommendations?.length > 0 && (
            <div>
              <p className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" />
                Recommendations
              </p>
              <div className="space-y-2">
                {prediction.recommendations.map((rec, idx) => (
                  <div key={idx} className="p-2 bg-slate-800/50 rounded-lg text-sm text-slate-300">
                    • {rec}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Risk Factors */}
          {prediction.risk_factors?.length > 0 && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg">
              <p className="text-sm font-semibold text-rose-400 mb-2">⚠️ Risk Factors</p>
              <ul className="space-y-1">
                {prediction.risk_factors.map((risk, idx) => (
                  <li key={idx} className="text-xs text-rose-300">• {risk}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}