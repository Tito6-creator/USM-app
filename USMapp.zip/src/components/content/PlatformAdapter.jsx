import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Loader2, Wand2, Check, Copy } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import PlatformIcon from '@/components/ui/PlatformIcon';

const platformSpecs = {
  instagram: {
    name: 'Instagram',
    charLimit: 2200,
    style: 'Visual-first, casual, emoji-rich, storytelling',
    hashtagCount: '8-15 hashtags',
    bestPractices: 'Use line breaks, emojis, call-to-action, location tags'
  },
  facebook: {
    name: 'Facebook',
    charLimit: 63206,
    style: 'Conversational, community-focused, longer narratives',
    hashtagCount: '1-3 hashtags',
    bestPractices: 'Ask questions, encourage engagement, use storytelling'
  },
  twitter: {
    name: 'Twitter',
    charLimit: 280,
    style: 'Concise, witty, timely, direct',
    hashtagCount: '1-2 hashtags',
    bestPractices: 'Keep it short, use threads for longer content, be conversational'
  },
  linkedin: {
    name: 'LinkedIn',
    charLimit: 3000,
    style: 'Professional, insightful, value-driven, thought leadership',
    hashtagCount: '3-5 hashtags',
    bestPractices: 'Share insights, provide value, professional tone, industry-relevant'
  },
  tiktok: {
    name: 'TikTok',
    charLimit: 2200,
    style: 'Fun, trendy, authentic, attention-grabbing',
    hashtagCount: '3-5 hashtags',
    bestPractices: 'Start with a hook, use trending sounds, be authentic'
  },
  youtube: {
    name: 'YouTube',
    charLimit: 5000,
    style: 'Descriptive, SEO-optimized, informative',
    hashtagCount: '3-5 hashtags',
    bestPractices: 'Front-load key info, use timestamps, include keywords'
  },
  pinterest: {
    name: 'Pinterest',
    charLimit: 500,
    style: 'Inspirational, descriptive, keyword-rich',
    hashtagCount: '5-10 hashtags',
    bestPractices: 'Use keywords, describe the visual, add value'
  }
};

export default function PlatformAdapter({ 
  baseContent, 
  selectedPlatforms = [],
  onVariationsGenerated
}) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [variations, setVariations] = useState({});
  const [copiedPlatform, setCopiedPlatform] = useState(null);

  const generateVariations = async () => {
    if (!baseContent || !baseContent.trim()) {
      toast.error('Please add content first');
      return;
    }

    if (selectedPlatforms.length === 0) {
      toast.error('Please select at least one platform');
      return;
    }

    setIsGenerating(true);
    toast.info('🤖 AI is adapting content for each platform...');
    
    try {
      const platformPrompts = selectedPlatforms.map(platform => {
        const spec = platformSpecs[platform];
        return `${platform}: 
- Character limit: ${spec.charLimit}
- Style: ${spec.style}
- Hashtags: ${spec.hashtagCount}
- Best practices: ${spec.bestPractices}`;
      }).join('\n\n');

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Adapt this social media post for multiple platforms. Keep the core message but optimize for each platform's unique style, character limits, and best practices.

Original content:
${baseContent}

Target platforms:
${platformPrompts}

For each platform, create an optimized version that:
1. Respects character limits
2. Matches the platform's style and tone
3. Uses appropriate hashtag count
4. Follows platform best practices
5. Maintains the core message and call-to-action

Return JSON with a key for each platform containing: content (string) and hashtags (array of strings without #).`,
        response_json_schema: {
          type: 'object',
          properties: selectedPlatforms.reduce((acc, platform) => {
            acc[platform] = {
              type: 'object',
              properties: {
                content: { type: 'string' },
                hashtags: { type: 'array', items: { type: 'string' } }
              }
            };
            return acc;
          }, {})
        }
      });

      if (result) {
        setVariations(result);
        if (onVariationsGenerated) {
          onVariationsGenerated(result);
        }
        toast.success(`✅ Generated ${selectedPlatforms.length} platform variations!`);
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Platform adapter error:', error);
      toast.error('❌ Failed to generate variations: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async (platform, text) => {
    await navigator.clipboard.writeText(text);
    setCopiedPlatform(platform);
    setTimeout(() => setCopiedPlatform(null), 2000);
    toast.success('Copied to clipboard');
  };

  const getCharCount = (text) => {
    return text?.length || 0;
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-white font-semibold flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-violet-400" />
            Platform Adapter
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Auto-adapt content for each platform's style
          </p>
        </div>
        <Button
          onClick={generateVariations}
          disabled={isGenerating || !baseContent || selectedPlatforms.length === 0}
          size="sm"
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          {isGenerating ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Wand2 className="w-4 h-4 mr-2" />
          )}
          Generate
        </Button>
      </div>

      {selectedPlatforms.length === 0 && (
        <div className="text-center py-8 text-slate-500 text-sm">
          Select platforms above to generate variations
        </div>
      )}

      {Object.keys(variations).length > 0 && (
        <>
          <Separator className="my-4 bg-slate-800" />
          <ScrollArea className="h-[500px] pr-4">
            <div className="space-y-4">
              {selectedPlatforms.map(platform => {
                const variation = variations[platform];
                if (!variation) return null;

                const spec = platformSpecs[platform];
                const charCount = getCharCount(variation.content);
                const isOverLimit = charCount > spec.charLimit;

                return (
                  <div
                    key={platform}
                    className="p-4 bg-slate-800/50 rounded-xl border border-slate-700"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <PlatformIcon platform={platform} size="sm" />
                        <span className="font-semibold text-white capitalize">
                          {spec.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge
                          className={cn(
                            "text-xs",
                            isOverLimit
                              ? "bg-red-500/20 text-red-400 border-red-500/30"
                              : "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                          )}
                        >
                          {charCount}/{spec.charLimit}
                        </Badge>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copyToClipboard(platform, 
                            `${variation.content}\n\n${variation.hashtags.map(h => `#${h}`).join(' ')}`
                          )}
                        >
                          {copiedPlatform === platform ? (
                            <Check className="w-4 h-4 text-green-400" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </div>

                    <div className="mb-3 p-3 bg-slate-900/50 rounded-lg">
                      <p className="text-sm text-slate-300 whitespace-pre-wrap">
                        {variation.content}
                      </p>
                    </div>

                    {variation.hashtags && variation.hashtags.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {variation.hashtags.map((tag, idx) => (
                          <Badge
                            key={idx}
                            variant="outline"
                            className="border-violet-500/30 text-violet-400 text-xs"
                          >
                            #{tag}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <div className="mt-3 pt-3 border-t border-slate-700">
                      <p className="text-xs text-slate-500">
                        <strong>Style:</strong> {spec.style}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </>
      )}
    </div>
  );
}