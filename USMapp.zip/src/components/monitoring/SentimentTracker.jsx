import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  ThumbsUp,
  ThumbsDown,
  Meh,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function SentimentTracker() {
  const [refreshKey, setRefreshKey] = useState(0);

  const { data: messages = [] } = useQuery({
    queryKey: ['messages', refreshKey],
    queryFn: () => base44.entities.Message.list('-created_date', 100),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', refreshKey],
    queryFn: () => base44.entities.Post.list('-published_time', 50),
  });

  const { data: mentions = [] } = useQuery({
    queryKey: ['brand-mentions', refreshKey],
    queryFn: () => base44.entities.BrandMention.list('-created_date', 100),
  });

  // Calculate sentiment breakdown
  const calculateSentiment = (items) => {
    const total = items.length;
    if (total === 0) return { positive: 0, neutral: 0, negative: 0 };

    const counts = items.reduce((acc, item) => {
      const sentiment = item.sentiment || 'neutral';
      acc[sentiment] = (acc[sentiment] || 0) + 1;
      return acc;
    }, {});

    return {
      positive: ((counts.positive || 0) / total) * 100,
      neutral: ((counts.neutral || 0) / total) * 100,
      negative: ((counts.negative || 0) / total) * 100,
    };
  };

  const messageSentiment = calculateSentiment(messages);
  const mentionSentiment = calculateSentiment(mentions);

  // Platform breakdown
  const platformSentiment = {};
  [...messages, ...mentions].forEach(item => {
    if (!item.platform) return;
    if (!platformSentiment[item.platform]) {
      platformSentiment[item.platform] = { positive: 0, neutral: 0, negative: 0, total: 0 };
    }
    const sentiment = item.sentiment || 'neutral';
    platformSentiment[item.platform][sentiment]++;
    platformSentiment[item.platform].total++;
  });

  // Recent negative items (potential issues)
  const recentNegative = [...messages, ...mentions]
    .filter(item => item.sentiment === 'negative')
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
    .slice(0, 5);

  const overallSentiment = calculateSentiment([...messages, ...mentions]);
  const sentimentTrend = overallSentiment.positive > overallSentiment.negative ? 'positive' : 
                        overallSentiment.positive < overallSentiment.negative ? 'negative' : 'neutral';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Real-Time Sentiment Tracking</h2>
          <p className="text-sm text-slate-400">Monitoring across all social channels</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setRefreshKey(k => k + 1)}
          className="border-slate-700"
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Overall Sentiment */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={cn(
          "p-6 rounded-2xl border",
          overallSentiment.positive > 60 ? "bg-emerald-500/10 border-emerald-500/30" :
          overallSentiment.negative > 30 ? "bg-rose-500/10 border-rose-500/30" :
          "bg-slate-800/50 border-slate-700"
        )}>
          <div className="flex items-center gap-3 mb-4">
            {sentimentTrend === 'positive' ? (
              <ThumbsUp className="w-8 h-8 text-emerald-400" />
            ) : sentimentTrend === 'negative' ? (
              <ThumbsDown className="w-8 h-8 text-rose-400" />
            ) : (
              <Meh className="w-8 h-8 text-slate-400" />
            )}
            <div>
              <p className="text-sm text-slate-400">Overall Sentiment</p>
              <p className="text-2xl font-bold text-white capitalize">{sentimentTrend}</p>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-emerald-400">Positive</span>
              <span className="text-white font-medium">{overallSentiment.positive.toFixed(1)}%</span>
            </div>
            <Progress value={overallSentiment.positive} className="h-2 bg-slate-700" />
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Neutral</span>
              <span className="text-white font-medium">{overallSentiment.neutral.toFixed(1)}%</span>
            </div>
            <Progress value={overallSentiment.neutral} className="h-2 bg-slate-700" />
            
            <div className="flex items-center justify-between text-sm">
              <span className="text-rose-400">Negative</span>
              <span className="text-white font-medium">{overallSentiment.negative.toFixed(1)}%</span>
            </div>
            <Progress value={overallSentiment.negative} className="h-2 bg-slate-700" />
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700">
          <p className="text-sm text-slate-400 mb-4">Messages & DMs</p>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-emerald-400">Positive</span>
              <span className="text-white font-bold">{messageSentiment.positive.toFixed(0)}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Neutral</span>
              <span className="text-white font-bold">{messageSentiment.neutral.toFixed(0)}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-rose-400">Negative</span>
              <span className="text-white font-bold">{messageSentiment.negative.toFixed(0)}%</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-700">
            <p className="text-xs text-slate-500">
              Based on {messages.length} recent messages
            </p>
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-slate-800/50 border border-slate-700">
          <p className="text-sm text-slate-400 mb-4">Brand Mentions</p>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-emerald-400">Positive</span>
              <span className="text-white font-bold">{mentionSentiment.positive.toFixed(0)}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">Neutral</span>
              <span className="text-white font-bold">{mentionSentiment.neutral.toFixed(0)}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-rose-400">Negative</span>
              <span className="text-white font-bold">{mentionSentiment.negative.toFixed(0)}%</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-slate-700">
            <p className="text-xs text-slate-500">
              Based on {mentions.length} mentions tracked
            </p>
          </div>
        </div>
      </div>

      {/* Platform Breakdown */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
        <div className="p-5 border-b border-slate-800">
          <h3 className="font-semibold text-white">Sentiment by Platform</h3>
        </div>
        <div className="p-5">
          <div className="space-y-4">
            {Object.entries(platformSentiment).map(([platform, data]) => {
              const positivePercent = (data.positive / data.total) * 100;
              const neutralPercent = (data.neutral / data.total) * 100;
              const negativePercent = (data.negative / data.total) * 100;

              return (
                <div key={platform} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <PlatformIcon platform={platform} size="sm" />
                      <span className="text-white capitalize">{platform}</span>
                    </div>
                    <span className="text-sm text-slate-400">{data.total} items</span>
                  </div>
                  <div className="flex h-2 rounded-full overflow-hidden bg-slate-800">
                    {positivePercent > 0 && (
                      <div
                        className="bg-emerald-500"
                        style={{ width: `${positivePercent}%` }}
                        title={`${positivePercent.toFixed(0)}% positive`}
                      />
                    )}
                    {neutralPercent > 0 && (
                      <div
                        className="bg-slate-500"
                        style={{ width: `${neutralPercent}%` }}
                        title={`${neutralPercent.toFixed(0)}% neutral`}
                      />
                    )}
                    {negativePercent > 0 && (
                      <div
                        className="bg-rose-500"
                        style={{ width: `${negativePercent}%` }}
                        title={`${negativePercent.toFixed(0)}% negative`}
                      />
                    )}
                  </div>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="text-emerald-400">{positivePercent.toFixed(0)}% positive</span>
                    <span className="text-slate-400">{neutralPercent.toFixed(0)}% neutral</span>
                    <span className="text-rose-400">{negativePercent.toFixed(0)}% negative</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent Negative Items */}
      {recentNegative.length > 0 && (
        <div className="rounded-2xl bg-rose-500/5 border border-rose-500/20 overflow-hidden">
          <div className="p-5 border-b border-rose-500/20">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-400" />
              <h3 className="font-semibold text-white">Recent Negative Feedback</h3>
              <Badge className="bg-rose-500/10 text-rose-400">{recentNegative.length}</Badge>
            </div>
          </div>
          <ScrollArea className="max-h-80">
            <div className="p-5 space-y-3">
              {recentNegative.map((item) => (
                <div key={item.id} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <PlatformIcon platform={item.platform} size="xs" />
                      <span className="text-sm text-slate-300">
                        {item.sender_name || item.author_name}
                      </span>
                    </div>
                    <span className="text-xs text-slate-500">
                      {new Date(item.created_date).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-white text-sm line-clamp-2">{item.content}</p>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}