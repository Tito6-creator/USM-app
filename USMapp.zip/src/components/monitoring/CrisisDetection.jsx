import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  AlertTriangle,
  Bell,
  TrendingDown,
  MessageCircle,
  Eye,
  CheckCircle2,
  Clock,
  Sparkles,
  Send,
  Copy,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const crisisTemplates = [
  {
    id: 'product_issue',
    name: 'Product/Service Issue',
    icon: AlertTriangle,
    severity: 'high',
    template: `We're aware of the issue with [PRODUCT/SERVICE] and sincerely apologize for any inconvenience. Our team is working on a resolution. We'll provide updates as soon as we have more information. Thank you for your patience.`
  },
  {
    id: 'negative_review',
    name: 'Negative Review Response',
    icon: MessageCircle,
    severity: 'medium',
    template: `Thank you for sharing your feedback. We're sorry to hear about your experience. We take all feedback seriously and would like to make this right. Please DM us so we can discuss this further and find a solution.`
  },
  {
    id: 'data_breach',
    name: 'Security/Privacy Issue',
    icon: AlertTriangle,
    severity: 'critical',
    template: `We take security seriously. We're investigating reports of [ISSUE] and are taking immediate action to protect our users. We'll provide a full update within [TIMEFRAME]. Your trust is our priority.`
  },
  {
    id: 'misinformation',
    name: 'Misinformation Clarification',
    icon: Eye,
    severity: 'medium',
    template: `We've seen some misinformation circulating about [TOPIC]. Here are the facts: [CLARIFICATION]. We're committed to transparency and will continue to provide accurate information.`
  },
  {
    id: 'apology',
    name: 'Public Apology',
    icon: MessageCircle,
    severity: 'high',
    template: `We sincerely apologize for [ISSUE]. This doesn't reflect our values or the experience we want to provide. We're taking the following steps to address this: [ACTIONS]. Thank you for holding us accountable.`
  },
  {
    id: 'outage',
    name: 'Service Outage',
    icon: TrendingDown,
    severity: 'high',
    template: `We're experiencing a service outage affecting [SERVICE]. Our team is working to restore service as quickly as possible. Current status: [STATUS]. ETA: [TIME]. We'll keep you updated.`
  }
];

export default function CrisisDetection() {
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [customResponse, setCustomResponse] = useState('');
  const [copiedId, setCopiedId] = useState(null);

  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery({
    queryKey: ['messages'],
    queryFn: () => base44.entities.Message.list('-created_date', 200),
    refetchInterval: 30000,
  });

  const { data: mentions = [] } = useQuery({
    queryKey: ['brand-mentions'],
    queryFn: () => base44.entities.BrandMention.list('-created_date', 200),
  });

  // Detect potential crisis situations
  const detectCrisis = () => {
    const alerts = [];
    const recentItems = [...messages, ...mentions].filter(item => {
      const itemDate = new Date(item.created_date);
      const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
      return itemDate > hourAgo;
    });

    // High volume of negative sentiment
    const negativeCount = recentItems.filter(item => item.sentiment === 'negative').length;
    if (negativeCount > 10) {
      alerts.push({
        id: 'negative_spike',
        type: 'sentiment_spike',
        severity: 'high',
        title: 'Negative Sentiment Spike',
        description: `${negativeCount} negative messages/mentions in the last hour`,
        count: negativeCount,
        items: recentItems.filter(item => item.sentiment === 'negative').slice(0, 5),
        timestamp: new Date().toISOString()
      });
    }

    // Unusual volume
    if (recentItems.length > 50) {
      alerts.push({
        id: 'volume_spike',
        type: 'volume_spike',
        severity: 'medium',
        title: 'Unusual Activity Volume',
        description: `${recentItems.length} messages in the last hour (above normal)`,
        count: recentItems.length,
        timestamp: new Date().toISOString()
      });
    }

    // Common complaint keywords
    const complaintKeywords = ['angry', 'disappointed', 'worst', 'terrible', 'scam', 'fraud', 'lawsuit', 'refund', 'broken'];
    const complaints = recentItems.filter(item => 
      complaintKeywords.some(keyword => item.content?.toLowerCase().includes(keyword))
    );
    
    if (complaints.length > 5) {
      alerts.push({
        id: 'complaints',
        type: 'complaints',
        severity: 'high',
        title: 'Multiple Complaints Detected',
        description: `${complaints.length} messages contain complaint-related keywords`,
        count: complaints.length,
        items: complaints.slice(0, 5),
        timestamp: new Date().toISOString()
      });
    }

    return alerts;
  };

  const alerts = detectCrisis();

  const severityConfig = {
    critical: { color: 'bg-rose-600/10 border-rose-600/30 text-rose-400', icon: AlertTriangle },
    high: { color: 'bg-orange-500/10 border-orange-500/30 text-orange-400', icon: AlertTriangle },
    medium: { color: 'bg-amber-500/10 border-amber-500/30 text-amber-400', icon: Bell },
    low: { color: 'bg-blue-500/10 border-blue-500/30 text-blue-400', icon: Eye }
  };

  const copyTemplate = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    toast.success('Template copied to clipboard');
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white">Crisis Detection System</h2>
          <p className="text-sm text-slate-400">Real-time monitoring and response templates</p>
        </div>
        <Button
          onClick={() => setIsTemplateDialogOpen(true)}
          className="bg-violet-600 hover:bg-violet-700"
        >
          <Eye className="w-4 h-4 mr-2" />
          Response Templates
        </Button>
      </div>

      {/* Active Alerts */}
      {alerts.length > 0 ? (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-rose-400" />
            <h3 className="font-semibold text-white">Active Alerts</h3>
            <Badge className="bg-rose-500/10 text-rose-400">{alerts.length}</Badge>
          </div>

          {alerts.map((alert) => {
            const config = severityConfig[alert.severity];
            const Icon = config.icon;

            return (
              <div
                key={alert.id}
                className={cn(
                  "p-6 rounded-2xl border cursor-pointer transition-all hover:shadow-lg",
                  config.color
                )}
                onClick={() => setSelectedAlert(alert)}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-slate-900/50 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-semibold text-white mb-1">{alert.title}</h4>
                        <p className="text-sm text-slate-300">{alert.description}</p>
                      </div>
                      <Badge className={cn("capitalize", config.color)}>
                        {alert.severity}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-4 mt-4 text-sm">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Clock className="w-4 h-4" />
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </div>
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setIsTemplateDialogOpen(true);
                        }}
                        className="bg-white/10 hover:bg-white/20 text-white"
                      >
                        View Response Templates
                      </Button>
                    </div>
                  </div>
                </div>

                {alert.items && alert.items.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-slate-700/50 space-y-2">
                    <p className="text-xs text-slate-400 mb-2">Recent Examples:</p>
                    {alert.items.map((item, idx) => (
                      <div key={idx} className="p-3 rounded-lg bg-slate-900/50 text-sm">
                        <p className="text-white line-clamp-2">{item.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="rounded-2xl bg-emerald-500/10 border border-emerald-500/20 p-12 text-center">
          <CheckCircle2 className="w-16 h-16 mx-auto text-emerald-400 mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">All Clear</h3>
          <p className="text-slate-400">No crisis situations detected. Sentiment and volume are normal.</p>
        </div>
      )}

      {/* Monitoring Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700">
          <p className="text-sm text-slate-400 mb-2">Messages Monitored</p>
          <p className="text-3xl font-bold text-white">{messages.length}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700">
          <p className="text-sm text-slate-400 mb-2">Mentions Tracked</p>
          <p className="text-3xl font-bold text-white">{mentions.length}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700">
          <p className="text-sm text-slate-400 mb-2">Active Alerts</p>
          <p className="text-3xl font-bold text-white">{alerts.length}</p>
        </div>
      </div>

      {/* Response Templates Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-white">Crisis Response Templates</DialogTitle>
          </DialogHeader>

          <ScrollArea className="flex-1 pr-4">
            <Accordion type="single" collapsible className="space-y-3">
              {crisisTemplates.map((template) => {
                const Icon = template.icon;
                const config = severityConfig[template.severity];

                return (
                  <AccordionItem
                    key={template.id}
                    value={template.id}
                    className={cn("border rounded-xl overflow-hidden", config.color)}
                  >
                    <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/30">
                      <div className="flex items-center gap-3 flex-1">
                        <Icon className="w-5 h-5" />
                        <span className="font-medium text-white text-left">{template.name}</span>
                        <Badge className={cn("ml-auto mr-3", config.color)}>
                          {template.severity}
                        </Badge>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-5 pb-5">
                      <div className="space-y-4">
                        <div className="p-4 rounded-lg bg-slate-800/50">
                          <p className="text-white whitespace-pre-wrap">{template.template}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => copyTemplate(template.template, template.id)}
                            className="flex-1 border-slate-700"
                          >
                            {copiedId === template.id ? (
                              <>
                                <Check className="w-4 h-4 mr-2" />
                                Copied!
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4 mr-2" />
                                Copy Template
                              </>
                            )}
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => {
                              setCustomResponse(template.template);
                              toast.success('Template loaded for customization');
                            }}
                            className="flex-1 bg-violet-600 hover:bg-violet-700"
                          >
                            <Sparkles className="w-4 h-4 mr-2" />
                            Customize with AI
                          </Button>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>

            {customResponse && (
              <div className="mt-6 p-5 rounded-2xl bg-violet-500/10 border border-violet-500/20">
                <h4 className="font-medium text-white mb-3">Customize Your Response</h4>
                <Textarea
                  value={customResponse}
                  onChange={(e) => setCustomResponse(e.target.value)}
                  className="min-h-[120px] bg-slate-800/50 border-slate-700 mb-3"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setCustomResponse('')}
                    className="border-slate-700"
                  >
                    Clear
                  </Button>
                  <Button
                    size="sm"
                    className="bg-violet-600 hover:bg-violet-700"
                    onClick={() => {
                      copyTemplate(customResponse, 'custom');
                      toast.success('Custom response copied');
                    }}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Response
                  </Button>
                </div>
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}