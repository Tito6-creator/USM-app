import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CheckCircle2, Clock, AlertCircle, Plus, User, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const priorityColors = {
  low: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  medium: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  high: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  urgent: 'bg-red-500/10 text-red-400 border-red-500/20'
};

const statusIcons = {
  todo: Clock,
  in_progress: AlertCircle,
  review: Clock,
  completed: CheckCircle2,
  cancelled: AlertCircle
};

export default function TaskManager() {
  const queryClient = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    type: 'general',
    priority: 'medium',
    assigned_to: '',
    due_date: ''
  });

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list('-created_date')
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['team'],
    queryFn: () => base44.entities.TeamMember.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Task.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['activity'] });
      toast.success('Task created');
      setShowCreate(false);
      setNewTask({ title: '', description: '', type: 'general', priority: 'medium', assigned_to: '', due_date: '' });
    }
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Task.update(id, { 
      status, 
      ...(status === 'completed' && { completed_date: new Date().toISOString() })
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['activity'] });
    }
  });

  const myTasks = tasks.filter(t => t.assigned_to === user?.email);
  const assignedByMe = tasks.filter(t => t.assigned_by === user?.email || t.created_by === user?.email);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-white">Tasks</h2>
        <Button onClick={() => setShowCreate(true)} className="bg-violet-600">
          <Plus className="w-4 h-4 mr-2" />
          New Task
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* My Tasks */}
        <Card className="p-4 bg-slate-900/50 border-slate-800">
          <h3 className="text-sm font-semibold text-white mb-4">My Tasks ({myTasks.length})</h3>
          <div className="space-y-2">
            {myTasks.map(task => {
              const StatusIcon = statusIcons[task.status];
              return (
                <div key={task.id} className="p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <p className="text-sm text-white font-medium">{task.title}</p>
                      <p className="text-xs text-slate-400 mt-1">{task.description}</p>
                    </div>
                    <Badge className={priorityColors[task.priority]}>
                      {task.priority}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Calendar className="w-3 h-3" />
                      {task.due_date && format(new Date(task.due_date), 'MMM d')}
                    </div>
                    <Select
                      value={task.status}
                      onValueChange={(status) => updateStatusMutation.mutate({ id: task.id, status })}
                    >
                      <SelectTrigger className="w-32 h-7 text-xs bg-slate-900 border-slate-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-900 border-slate-800">
                        <SelectItem value="todo">To Do</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="review">Review</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              );
            })}
            {myTasks.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-8">No tasks assigned</p>
            )}
          </div>
        </Card>

        {/* Tasks I Assigned */}
        <Card className="p-4 bg-slate-900/50 border-slate-800">
          <h3 className="text-sm font-semibold text-white mb-4">Tasks I Assigned ({assignedByMe.length})</h3>
          <div className="space-y-2">
            {assignedByMe.map(task => (
              <div key={task.id} className="p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <p className="text-sm text-white font-medium">{task.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <User className="w-3 h-3 text-slate-400" />
                      <p className="text-xs text-slate-400">{task.assigned_to}</p>
                    </div>
                  </div>
                  <Badge className={cn(
                    "text-xs",
                    task.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-700 text-slate-300'
                  )}>
                    {task.status}
                  </Badge>
                </div>
              </div>
            ))}
            {assignedByMe.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-8">No tasks created</p>
            )}
          </div>
        </Card>
      </div>

      {/* Create Task Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">Create New Task</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Task title"
              value={newTask.title}
              onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
            <Textarea
              placeholder="Description"
              value={newTask.description}
              onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
            <div className="grid grid-cols-2 gap-4">
              <Select value={newTask.type} onValueChange={(v) => setNewTask({ ...newTask, type: v })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="content_creation">Content Creation</SelectItem>
                  <SelectItem value="content_approval">Content Approval</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="research">Research</SelectItem>
                  <SelectItem value="scheduling">Scheduling</SelectItem>
                  <SelectItem value="analytics">Analytics</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
              <Select value={newTask.priority} onValueChange={(v) => setNewTask({ ...newTask, priority: v })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                  <SelectValue placeholder="Priority" />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Select value={newTask.assigned_to} onValueChange={(v) => setNewTask({ ...newTask, assigned_to: v })}>
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue placeholder="Assign to" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                {teamMembers.map(member => (
                  <SelectItem key={member.id} value={member.email}>{member.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="datetime-local"
              value={newTask.due_date}
              onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />
            <Button
              onClick={() => createMutation.mutate({ ...newTask, assigned_by: user?.email })}
              className="w-full bg-violet-600"
              disabled={!newTask.title || !newTask.assigned_to}
            >
              Create Task
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}