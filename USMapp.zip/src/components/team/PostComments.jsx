import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageSquare, ThumbsUp, ThumbsDown, Send, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

export default function PostComments({ postId, compact = false }) {
  const queryClient = useQueryClient();
  const [newComment, setNewComment] = useState('');
  const [commentType, setCommentType] = useState('comment');

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: comments = [] } = useQuery({
    queryKey: ['comments', postId],
    queryFn: () => base44.entities.Comment.filter({ post_id: postId }, '-created_date')
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Comment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['comments', postId] });
      queryClient.invalidateQueries({ queryKey: ['activity'] });
      setNewComment('');
      setCommentType('comment');
      toast.success('Comment added');
    }
  });

  const handleSubmit = () => {
    if (!newComment.trim()) return;

    createMutation.mutate({
      post_id: postId,
      author_email: user?.email,
      author_name: user?.full_name,
      content: newComment,
      comment_type: commentType
    });
  };

  const commentTypeColors = {
    comment: 'bg-slate-700 text-slate-300',
    approval: 'bg-emerald-500/20 text-emerald-400',
    rejection: 'bg-red-500/20 text-red-400',
    suggestion: 'bg-blue-500/20 text-blue-400'
  };

  if (compact) {
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-slate-400">
          <MessageSquare className="w-4 h-4" />
          <span>{comments.length} comments</span>
        </div>
        <div className="space-y-2">
          {comments.slice(0, 3).map(comment => (
            <div key={comment.id} className="text-xs text-slate-400">
              <span className="text-white font-medium">{comment.author_name}:</span> {comment.content}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <MessageSquare className="w-5 h-5 text-violet-400" />
        <h3 className="text-white font-semibold">Comments ({comments.length})</h3>
      </div>

      {/* Comment Input */}
      <div className="space-y-2">
        <Textarea
          placeholder="Add a comment, approval, or suggestion..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          className="bg-slate-800 border-slate-700 text-white"
        />
        <div className="flex items-center justify-between">
          <div className="flex gap-2">
            <Button
              size="sm"
              variant={commentType === 'comment' ? 'default' : 'outline'}
              onClick={() => setCommentType('comment')}
              className="text-xs"
            >
              Comment
            </Button>
            <Button
              size="sm"
              variant={commentType === 'approval' ? 'default' : 'outline'}
              onClick={() => setCommentType('approval')}
              className={cn("text-xs", commentType === 'approval' && "bg-emerald-600")}
            >
              <ThumbsUp className="w-3 h-3 mr-1" />
              Approve
            </Button>
            <Button
              size="sm"
              variant={commentType === 'rejection' ? 'default' : 'outline'}
              onClick={() => setCommentType('rejection')}
              className={cn("text-xs", commentType === 'rejection' && "bg-red-600")}
            >
              <ThumbsDown className="w-3 h-3 mr-1" />
              Reject
            </Button>
            <Button
              size="sm"
              variant={commentType === 'suggestion' ? 'default' : 'outline'}
              onClick={() => setCommentType('suggestion')}
              className={cn("text-xs", commentType === 'suggestion' && "bg-blue-600")}
            >
              Suggestion
            </Button>
          </div>
          <Button onClick={handleSubmit} disabled={!newComment.trim()} size="sm" className="bg-violet-600">
            <Send className="w-3 h-3 mr-1" />
            Send
          </Button>
        </div>
      </div>

      {/* Comments List */}
      <div className="space-y-3">
        {comments.map(comment => (
          <div key={comment.id} className="flex gap-3 p-3 bg-slate-800/50 rounded-lg border border-slate-700">
            <Avatar className="w-8 h-8">
              <AvatarFallback className="bg-violet-500 text-white text-xs">
                {comment.author_name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-white">{comment.author_name}</span>
                  <Badge className={cn("text-xs", commentTypeColors[comment.comment_type])}>
                    {comment.comment_type}
                  </Badge>
                </div>
                <span className="text-xs text-slate-500">
                  {format(new Date(comment.created_date), 'MMM d, h:mm a')}
                </span>
              </div>
              <p className="text-sm text-slate-300">{comment.content}</p>
            </div>
          </div>
        ))}
        {comments.length === 0 && (
          <p className="text-sm text-slate-500 text-center py-8">No comments yet</p>
        )}
      </div>
    </div>
  );
}