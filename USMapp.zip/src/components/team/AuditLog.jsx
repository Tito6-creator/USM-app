import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, User, FileText, Settings, Trash, CheckCircle, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

const actionIcons = {
  post_created: FileText,
  post_published: CheckCircle,
  post_approved: CheckCircle,
  post_rejected: AlertCircle,
  account_connected: User,
  account_disconnected: User,
  settings_changed: Settings,
  team_member_added: User,
  campaign_started: FileText,
  report_generated: FileText
};

const actionColors = {
  post_created: 'text-blue-400',
  post_published: 'text-emerald-400',
  post_approved: 'text-emerald-400',
  post_rejected: 'text-red-400',
  account_connected: 'text-violet-400',
  account_disconnected: 'text-orange-400',
  settings_changed: 'text-yellow-400',
  team_member_added: 'text-cyan-400',
  campaign_started: 'text-pink-400',
  report_generated: 'text-indigo-400'
};

export default function AuditLog() {
  const [filterUser, setFilterUser] = useState('all');
  const [filterAction, setFilterAction] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const { data: activities = [] } = useQuery({
    queryKey: ['activity'],
    queryFn: () => base44.entities.ActivityLog.list('-created_date', 200)
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['team'],
    queryFn: () => base44.entities.TeamMember.list()
  });

  const filteredActivities = activities.filter(activity => {
    if (filterUser !== 'all' && activity.user_email !== filterUser) return false;
    if (filterAction !== 'all' && activity.action !== filterAction) return false;
    if (searchQuery && !activity.description.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const uniqueActions = [...new Set(activities.map(a => a.action))];

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-white">Activity Log</h2>
          <p className="text-sm text-slate-400 mt-1">Complete audit trail of all team actions</p>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Input
          placeholder="Search activities..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-slate-800 border-slate-700 text-white"
        />
        <Select value={filterUser} onValueChange={setFilterUser}>
          <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
            <SelectValue placeholder="Filter by user" />
          </SelectTrigger>
          <SelectContent className="bg-slate-900 border-slate-800">
            <SelectItem value="all">All Users</SelectItem>
            {teamMembers.map(member => (
              <SelectItem key={member.id} value={member.email}>{member.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterAction} onValueChange={setFilterAction}>
          <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
            <SelectValue placeholder="Filter by action" />
          </SelectTrigger>
          <SelectContent className="bg-slate-900 border-slate-800">
            <SelectItem value="all">All Actions</SelectItem>
            {uniqueActions.map(action => (
              <SelectItem key={action} value={action}>{action.replace(/_/g, ' ')}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Activity List */}
      <ScrollArea className="h-[600px]">
        <div className="space-y-2">
          {filteredActivities.map(activity => {
            const Icon = actionIcons[activity.action] || FileText;
            const color = actionColors[activity.action] || 'text-slate-400';
            
            return (
              <div key={activity.id} className="flex gap-3 p-3 bg-slate-800/30 rounded-lg border border-slate-800 hover:border-slate-700 transition-colors">
                <div className={cn("w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0", color)}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <div>
                      <p className="text-sm text-white font-medium">{activity.description}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-slate-400">{activity.user_name || activity.user_email}</span>
                        <span className="text-xs text-slate-600">•</span>
                        <span className="text-xs text-slate-500">
                          {format(new Date(activity.created_date), 'MMM d, yyyy h:mm a')}
                        </span>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs border-slate-700">
                      {activity.action.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                  {activity.metadata && Object.keys(activity.metadata).length > 0 && (
                    <div className="mt-2 p-2 bg-slate-900/50 rounded text-xs text-slate-400">
                      {JSON.stringify(activity.metadata, null, 2)}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          {filteredActivities.length === 0 && (
            <p className="text-sm text-slate-500 text-center py-12">No activities found</p>
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}