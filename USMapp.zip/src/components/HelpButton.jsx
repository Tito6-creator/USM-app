import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { HelpCircle, X } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const pageHelp = {
  'Dashboard': {
    title: 'Dashboard Overview',
    content: 'Your main hub showing key metrics, upcoming posts, recent activity, and quick actions. View follower growth, engagement rates, and manage your social accounts from here.'
  },
  'CRMDashboard': {
    title: 'CRM Dashboard',
    content: 'Manage your contacts, leads, and deals. Track customer relationships, view pipeline status, and monitor sales metrics all in one place.'
  },
  'Contacts': {
    title: 'Contacts Management',
    content: 'Store and organize all your contacts with tags, notes, and interaction history. Track their status from lead to client and monitor engagement.'
  },
  'Pipeline': {
    title: 'Sales Pipeline',
    content: 'Visual pipeline showing deals at each stage (lead, demo, trial, client). Drag and drop to move deals through stages and track revenue opportunities.'
  },
  'CRMTasks': {
    title: 'CRM Tasks',
    content: 'Task management for your customer relationships. Create follow-ups, schedule calls, and track actions needed for each contact or deal.'
  },
  'Strategy': {
    title: 'AI Strategy',
    content: 'Let AI analyze your performance and create data-driven content strategies. Get recommendations on what to post, when, and how to improve engagement.'
  },
  'CampaignPlanner': {
    title: 'Campaign Planner',
    content: 'Create integrated marketing campaigns across multiple platforms. AI helps plan content calendars, email sequences, and landing pages for cohesive campaigns.'
  },
  'Calendar': {
    title: 'Content Calendar',
    content: 'Schedule and organize your posts across all platforms. Drag and drop to reschedule, see gaps in your calendar, and maintain consistent posting.'
  },
  'CreatePost': {
    title: 'Create Post',
    content: 'Create posts with AI assistance. Generate captions, images, and video scripts. Customize for each platform and schedule for optimal times.'
  },
  'Automation': {
    title: 'Automation Rules',
    content: 'Create rules that automatically perform actions when triggers happen. For example, send welcome messages to new followers or create leads when keywords are mentioned.'
  },
  'EmailCampaigns': {
    title: 'Email Campaigns',
    content: 'Create and send email campaigns to your audience. Design emails, manage subscriber lists, and track open rates and clicks.'
  },
  'Inbox': {
    title: 'Social Inbox',
    content: 'Unified inbox for all your social media messages and comments. AI suggests responses and helps you never miss important customer interactions.'
  },
  'BrandMonitor': {
    title: 'Brand Monitoring',
    content: 'Track mentions of your brand, products, or keywords across social media. Monitor sentiment and respond quickly to brand conversations.'
  },
  'Competitors': {
    title: 'Competitor Analysis',
    content: 'Track competitor social media performance, content strategies, and engagement. Learn from their successes and spot opportunities.'
  },
  'Analytics': {
    title: 'Analytics Dashboard',
    content: 'Deep dive into your social media performance with detailed analytics, engagement metrics, audience insights, and growth trends over time.'
  },
  'Hashtags': {
    title: 'Hashtag Manager',
    content: 'Research trending hashtags, save collections for different post types, and analyze hashtag performance to maximize reach.'
  },
  'MediaLibrary': {
    title: 'Media Library',
    content: 'Store and organize all your images, videos, and assets. AI can help find the right content and generate new media when needed.'
  },
  'Influencers': {
    title: 'Influencer Management',
    content: 'Find and track influencers in your niche. Manage partnerships, track campaign performance, and build relationships with creators.'
  },
  'Chatbot': {
    title: 'AI Chatbot',
    content: 'Configure AI chatbots for social media and website. Automatically respond to common questions and capture leads 24/7.'
  },
  'LinkInBio': {
    title: 'Link in Bio',
    content: 'Create custom landing pages for your social media bios. Add multiple links, track clicks, and update in real-time.'
  },
  'LandingPageBuilder': {
    title: 'Landing Page Builder',
    content: 'Create beautiful landing pages for campaigns without coding. AI helps generate content, optimize SEO, and track conversions.'
  },
  'Reports': {
    title: 'Reports',
    content: 'Generate comprehensive reports on your social media performance. Schedule automated reports and share insights with your team or clients.'
  },
  'Goals': {
    title: 'Goals & Targets',
    content: 'Set specific goals for followers, engagement, or revenue. Track progress and get AI recommendations to achieve your targets faster.'
  },
  'Team': {
    title: 'Team Management',
    content: 'Invite team members, assign roles, manage permissions, and collaborate on content. Review workflow and approval processes.'
  },
  'CustomerSupport': {
    title: 'Customer Support',
    content: 'Manage support tickets from your social media channels. Track issues, assign to team members, and ensure timely responses.'
  },
  'Features': {
    title: 'Platform Features',
    content: 'Explore all available features and capabilities. Learn about new updates and discover tools you might not be using yet.'
  },
  'AISettings': {
    title: 'AI Settings',
    content: 'Customize your AI assistant\'s personality, voice, and behavior. Adjust automation levels and train AI to understand your brand voice.'
  },
  'Settings': {
    title: 'Account Settings',
    content: 'Manage your account settings, connected social accounts, billing, team members, and preferences.'
  },
  'CreateVideo': {
    title: 'AI Video Generator',
    content: 'Create professional promotional videos with AI-generated scripts, royalty-free footage, and AI voiceovers. Perfect for social media campaigns.'
  },
  'Pricing': {
    title: 'Pricing Plans',
    content: 'View all available pricing tiers and features. Choose the plan that best fits your needs with flexible monthly or yearly billing.'
  },
  'ContentMonetization': {
    title: 'Content Monetization',
    content: 'Track revenue from your content including ad revenue, sponsorships, affiliates, and brand deals. Monitor CPM and earnings per platform.'
  },
  'AIAnalyticsDashboard': {
    title: 'Advanced AI Analytics',
    content: 'Deep AI-powered analytics with performance predictions, trend analysis, and data-driven recommendations for optimizing your strategy.'
  }
};

export default function HelpButton({ pageName, className }) {
  const [isOpen, setIsOpen] = useState(false);
  const help = pageHelp[pageName];

  if (!help) return null;

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsOpen(true)}
        className={`text-slate-400 hover:text-white h-8 w-8 ${className}`}
        title="Help"
      >
        <HelpCircle className="w-4 h-4" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-md">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center justify-between">
              {help.title}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="h-6 w-6 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </DialogTitle>
          </DialogHeader>
          <div className="text-slate-300 text-sm leading-relaxed">
            {help.content}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}