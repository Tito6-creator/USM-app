import React from 'react';
import { format } from 'date-fns';
import {
  AlertTriangle,
  Clock,
  MessageSquare,
  User,
  ChevronRight,
  ThumbsDown,
  HelpCircle,
  Phone
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';

const priorityConfig = {
  high: { color: 'bg-rose-500/10 text-rose-400 border-rose-500/20', icon: AlertTriangle },
  medium: { color: 'bg-amber-500/10 text-amber-400 border-amber-500/20', icon: HelpCircle },
  low: { color: 'bg-slate-500/10 text-slate-400 border-slate-500/20', icon: MessageSquare }
};

const sentimentColors = {
  positive: 'text-emerald-400',
  neutral: 'text-slate-400',
  negative: 'text-rose-400'
};

export default function HandoverQueue({ handovers = [], onAccept, onViewConversation }) {
  const getPriority = (handover) => {
    if (handover.sentiment === 'negative') return 'high';
    if (handover.reason?.toLowerCase().includes('urgent') || handover.reason?.toLowerCase().includes('complaint')) return 'high';
    if (handover.reason?.toLowerCase().includes('help') || handover.reason?.toLowerCase().includes('human')) return 'medium';
    return 'low';
  };

  const sortedHandovers = [...handovers].sort((a, b) => {
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    return priorityOrder[getPriority(a)] - priorityOrder[getPriority(b)];
  });

  if (handovers.length === 0) {
    return (
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-8 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-800/50 flex items-center justify-center mb-4">
          <Phone className="w-8 h-8 text-slate-600" />
        </div>
        <h3 className="font-medium text-white mb-2">No Pending Handovers</h3>
        <p className="text-sm text-slate-400">All conversations are being handled by AI</p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
            <Phone className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Handover Queue</h3>
            <p className="text-sm text-slate-400">{handovers.length} awaiting response</p>
          </div>
        </div>
        <Badge className="bg-amber-500/10 text-amber-400">
          {handovers.filter(h => getPriority(h) === 'high').length} urgent
        </Badge>
      </div>

      <ScrollArea className="h-[400px]">
        <div className="divide-y divide-slate-800">
          {sortedHandovers.map((handover, index) => {
            const priority = getPriority(handover);
            const config = priorityConfig[priority];
            const PriorityIcon = config.icon;
            
            return (
              <div 
                key={index}
                className="p-4 hover:bg-slate-800/30 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-slate-700 text-slate-300">
                      {handover.lead?.name?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-white">
                        {handover.lead?.name || 'Unknown User'}
                      </span>
                      <Badge className={cn("text-xs", config.color)}>
                        <PriorityIcon className="w-3 h-3 mr-1" />
                        {priority}
                      </Badge>
                      {handover.sentiment && (
                        <span className={cn("text-xs", sentimentColors[handover.sentiment])}>
                          • {handover.sentiment}
                        </span>
                      )}
                    </div>
                    
                    <p className="text-sm text-slate-400 line-clamp-2 mb-2">
                      {handover.reason || 'Customer requested human assistance'}
                    </p>
                    
                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" />
                        {handover.conversation?.length || 0} messages
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {handover.timestamp ? format(new Date(handover.timestamp), 'HH:mm') : 'Just now'}
                      </span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onViewConversation?.(handover)}
                      className="text-slate-400 hover:text-white"
                    >
                      View
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => onAccept?.(handover)}
                      className="bg-violet-600 hover:bg-violet-700"
                    >
                      Accept
                      <ChevronRight className="w-4 h-4 ml-1" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}