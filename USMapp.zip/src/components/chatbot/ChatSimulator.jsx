import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Send,
  Bot,
  User,
  Loader2,
  Globe,
  Sparkles,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const languages = [
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'pt', name: 'Portuguese', flag: '🇧🇷' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
];

export default function ChatSimulator({ config, onLeadCapture, onHandover }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [language, setLanguage] = useState('en');
  const [detectedIntent, setDetectedIntent] = useState(null);
  const [sentiment, setSentiment] = useState('neutral');
  const [leadData, setLeadData] = useState({});
  const scrollRef = useRef(null);

  useEffect(() => {
    if (config?.greeting_message) {
      setMessages([{
        role: 'assistant',
        content: config.greeting_message,
        timestamp: new Date().toISOString()
      }]);
    }
  }, [config?.greeting_message]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const processMessage = async (userMessage) => {
    const newMessages = [...messages, {
      role: 'user',
      content: userMessage,
      timestamp: new Date().toISOString(),
      language
    }];
    setMessages(newMessages);
    setInput('');
    setIsTyping(true);

    // Build conversation context
    const conversationHistory = newMessages.map(m => 
      `${m.role === 'user' ? 'Customer' : 'Assistant'}: ${m.content}`
    ).join('\n');

    const prompt = `You are an AI customer service chatbot with the following configuration:
    
Personality: ${config?.ai_personality || 'friendly'}
Business Context: ${config?.ai_context || 'General customer support'}

Current conversation (respond in ${languages.find(l => l.code === language)?.name || 'English'}):
${conversationHistory}

Analyze the customer's last message and respond naturally. Also detect:
1. Intent (greeting, inquiry, complaint, purchase_interest, support_request, pricing, human_request, other)
2. Sentiment (positive, neutral, negative)
3. Any lead information mentioned (name, email, phone, interests)
4. Whether this needs human handover (complex issue, explicit request, frustrated customer)

Provide a helpful, conversational response that matches the personality.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          response: { type: 'string' },
          detected_intent: { type: 'string' },
          sentiment: { type: 'string' },
          lead_info: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              email: { type: 'string' },
              phone: { type: 'string' },
              interests: { type: 'array', items: { type: 'string' } }
            }
          },
          needs_handover: { type: 'boolean' },
          handover_reason: { type: 'string' },
          confidence: { type: 'number' }
        }
      }
    });

    setIsTyping(false);
    setDetectedIntent(result.detected_intent);
    setSentiment(result.sentiment);

    // Update lead data
    if (result.lead_info) {
      const updatedLead = { ...leadData, ...result.lead_info };
      setLeadData(updatedLead);
      if (onLeadCapture && (result.lead_info.email || result.lead_info.name)) {
        onLeadCapture(updatedLead);
      }
    }

    // Check for handover
    if (result.needs_handover && onHandover) {
      onHandover({
        reason: result.handover_reason,
        conversation: [...newMessages, { role: 'assistant', content: result.response }],
        lead: leadData,
        sentiment: result.sentiment
      });
    }

    setMessages([...newMessages, {
      role: 'assistant',
      content: result.response,
      timestamp: new Date().toISOString(),
      intent: result.detected_intent,
      confidence: result.confidence
    }]);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    processMessage(input.trim());
  };

  const sentimentColors = {
    positive: 'bg-emerald-500/10 text-emerald-400',
    neutral: 'bg-slate-500/10 text-slate-400',
    negative: 'bg-rose-500/10 text-rose-400'
  };

  return (
    <div className="flex flex-col h-[600px] rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-medium text-white">{config?.name || 'AI Assistant'}</h3>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-400 rounded-full"></span>
              <span className="text-xs text-slate-400">Online</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {detectedIntent && (
            <Badge variant="outline" className="border-violet-500/30 text-violet-400 text-xs">
              <Sparkles className="w-3 h-3 mr-1" />
              {detectedIntent}
            </Badge>
          )}
          <Badge className={cn("text-xs", sentimentColors[sentiment])}>
            {sentiment}
          </Badge>
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-32 h-8 bg-slate-800/50 border-slate-700 text-xs">
              <Globe className="w-3 h-3 mr-1" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              {languages.map((lang) => (
                <SelectItem key={lang.code} value={lang.code}>
                  <span className="mr-2">{lang.flag}</span>
                  {lang.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={cn(
                "flex gap-3",
                message.role === 'user' ? "justify-end" : "justify-start"
              )}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              <div className={cn(
                "max-w-[75%] rounded-2xl px-4 py-2.5",
                message.role === 'user'
                  ? "bg-violet-600 text-white rounded-br-sm"
                  : "bg-slate-800 text-slate-100 rounded-bl-sm"
              )}>
                <p className="text-sm">{message.content}</p>
                <p className="text-[10px] mt-1 opacity-60">
                  {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                  <User className="w-4 h-4 text-slate-300" />
                </div>
              )}
            </div>
          ))}
          
          {isTyping && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-slate-800 rounded-2xl rounded-bl-sm px-4 py-3">
                <div className="flex gap-1">
                  <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Lead Info Banner */}
      {(leadData.name || leadData.email) && (
        <div className="px-4 py-2 bg-emerald-500/10 border-t border-emerald-500/20 flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-emerald-400" />
          <span className="text-xs text-emerald-400">
            Lead captured: {leadData.name} {leadData.email && `(${leadData.email})`}
          </span>
        </div>
      )}

      {/* Input */}
      <div className="p-4 border-t border-slate-800">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="bg-slate-800/50 border-slate-700 text-white"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="bg-violet-600 hover:bg-violet-700"
          >
            {isTyping ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}