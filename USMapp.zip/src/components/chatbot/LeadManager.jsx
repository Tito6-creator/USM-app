import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import {
  Users,
  Mail,
  Phone,
  Tag,
  Star,
  MessageSquare,
  ExternalLink,
  MoreVertical,
  Trash2,
  RefreshCw,
  Globe,
  TrendingUp,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

const statusColors = {
  new: 'bg-blue-500/10 text-blue-400',
  contacted: 'bg-amber-500/10 text-amber-400',
  qualified: 'bg-violet-500/10 text-violet-400',
  converted: 'bg-emerald-500/10 text-emerald-400',
  lost: 'bg-slate-500/10 text-slate-400'
};

const languageFlags = {
  en: '🇺🇸', es: '🇪🇸', fr: '🇫🇷', de: '🇩🇪', pt: '🇧🇷',
  zh: '🇨🇳', ja: '🇯🇵', ar: '🇸🇦', hi: '🇮🇳', ko: '🇰🇷'
};

export default function LeadManager({ leads = [], crmConfig, onLeadUpdate }) {
  const [selectedLead, setSelectedLead] = useState(null);
  const [enrichingId, setEnrichingId] = useState(null);
  const queryClient = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Lead.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      onLeadUpdate?.();
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Lead.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['leads'] })
  });

  const enrichLead = async (lead) => {
    setEnrichingId(lead.id);
    
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Based on the following lead information, provide enrichment data:
Name: ${lead.name}
Email: ${lead.email || 'Not provided'}
Interests: ${lead.interests?.join(', ') || 'Unknown'}
Conversation intents: ${lead.detected_intents?.join(', ') || 'Unknown'}

Provide:
1. A lead score (0-100) based on buying signals
2. Suggested tags for categorization
3. Key insights about this lead
4. Recommended follow-up actions`,
      response_json_schema: {
        type: 'object',
        properties: {
          score: { type: 'number' },
          tags: { type: 'array', items: { type: 'string' } },
          insights: { type: 'string' },
          recommended_actions: { type: 'array', items: { type: 'string' } }
        }
      }
    });

    await updateMutation.mutateAsync({
      id: lead.id,
      data: {
        score: result.score,
        tags: [...(lead.tags || []), ...result.tags],
        notes: `${lead.notes || ''}\n\nAI Insights: ${result.insights}\n\nRecommended Actions:\n${result.recommended_actions?.join('\n- ')}`
      }
    });

    setEnrichingId(null);
    toast.success('Lead enriched successfully!');
  };

  const syncToCRM = async (lead) => {
    // Simulate CRM sync
    await updateMutation.mutateAsync({
      id: lead.id,
      data: {
        crm_synced: true,
        crm_id: `CRM-${Date.now()}`
      }
    });
    toast.success('Lead synced to CRM!');
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-4 h-4 text-violet-400" />
            <span className="text-sm text-slate-400">Total Leads</span>
          </div>
          <p className="text-2xl font-bold text-white">{leads.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-4 h-4 text-amber-400" />
            <span className="text-sm text-slate-400">Avg Score</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {leads.length > 0 ? Math.round(leads.reduce((a, l) => a + (l.score || 0), 0) / leads.length) : 0}
          </p>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-sm text-slate-400">Qualified</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {leads.filter(l => l.status === 'qualified' || l.status === 'converted').length}
          </p>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <RefreshCw className="w-4 h-4 text-cyan-400" />
            <span className="text-sm text-slate-400">CRM Synced</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {leads.filter(l => l.crm_synced).length}
          </p>
        </div>
      </div>

      {/* Leads List */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-800">
          <h3 className="font-semibold text-white">Captured Leads</h3>
        </div>

        <ScrollArea className="h-[500px]">
          <div className="divide-y divide-slate-800">
            {leads.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                No leads captured yet
              </div>
            ) : (
              leads.map((lead) => (
                <div
                  key={lead.id}
                  className="p-4 hover:bg-slate-800/30 transition-colors cursor-pointer"
                  onClick={() => setSelectedLead(lead)}
                >
                  <div className="flex items-start gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white">
                        {lead.name?.charAt(0) || '?'}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-white">{lead.name}</span>
                        {lead.language && languageFlags[lead.language] && (
                          <span className="text-sm">{languageFlags[lead.language]}</span>
                        )}
                        <Badge className={cn("text-xs", statusColors[lead.status])}>
                          {lead.status}
                        </Badge>
                        {lead.crm_synced && (
                          <Badge variant="outline" className="text-xs border-emerald-500/30 text-emerald-400">
                            CRM
                          </Badge>
                        )}
                      </div>

                      <div className="flex items-center gap-4 text-sm text-slate-400 mb-2">
                        {lead.email && (
                          <span className="flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {lead.email}
                          </span>
                        )}
                        {lead.phone && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {lead.phone}
                          </span>
                        )}
                      </div>

                      {lead.score > 0 && (
                        <div className="flex items-center gap-2">
                          <Progress value={lead.score} className="h-1.5 w-24" />
                          <span className="text-xs text-slate-500">{lead.score}/100</span>
                        </div>
                      )}

                      {lead.tags?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {lead.tags.slice(0, 3).map((tag, i) => (
                            <Badge key={i} variant="outline" className="text-xs border-slate-700 text-slate-400">
                              {tag}
                            </Badge>
                          ))}
                          {lead.tags.length > 3 && (
                            <span className="text-xs text-slate-500">+{lead.tags.length - 3}</span>
                          )}
                        </div>
                      )}
                    </div>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="text-slate-400">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                        <DropdownMenuItem onClick={() => enrichLead(lead)} disabled={enrichingId === lead.id}>
                          {enrichingId === lead.id ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          ) : (
                            <Star className="w-4 h-4 mr-2" />
                          )}
                          Enrich with AI
                        </DropdownMenuItem>
                        {crmConfig?.enabled && !lead.crm_synced && (
                          <DropdownMenuItem onClick={() => syncToCRM(lead)}>
                            <ExternalLink className="w-4 h-4 mr-2" />
                            Sync to CRM
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem
                          onClick={() => deleteMutation.mutate(lead.id)}
                          className="text-rose-400"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Lead Detail Dialog */}
      <Dialog open={!!selectedLead} onOpenChange={() => setSelectedLead(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-3">
              <Avatar>
                <AvatarFallback className="bg-violet-600">
                  {selectedLead?.name?.charAt(0)}
                </AvatarFallback>
              </Avatar>
              {selectedLead?.name}
            </DialogTitle>
          </DialogHeader>

          {selectedLead && (
            <div className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <p className="text-xs text-slate-400 mb-1">Email</p>
                  <p className="text-white">{selectedLead.email || 'Not provided'}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <p className="text-xs text-slate-400 mb-1">Phone</p>
                  <p className="text-white">{selectedLead.phone || 'Not provided'}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <p className="text-xs text-slate-400 mb-1">Language</p>
                  <p className="text-white flex items-center gap-2">
                    {languageFlags[selectedLead.language]} {selectedLead.language?.toUpperCase()}
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <p className="text-xs text-slate-400 mb-1">Lead Score</p>
                  <div className="flex items-center gap-2">
                    <Progress value={selectedLead.score || 0} className="h-2 flex-1" />
                    <span className="text-white font-medium">{selectedLead.score || 0}</span>
                  </div>
                </div>
              </div>

              {selectedLead.interests?.length > 0 && (
                <div>
                  <p className="text-sm text-slate-400 mb-2">Interests</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedLead.interests.map((interest, i) => (
                      <Badge key={i} className="bg-violet-500/10 text-violet-400">
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedLead.detected_intents?.length > 0 && (
                <div>
                  <p className="text-sm text-slate-400 mb-2">Detected Intents</p>
                  <div className="flex flex-wrap gap-2">
                    {selectedLead.detected_intents.map((intent, i) => (
                      <Badge key={i} variant="outline" className="border-slate-700 text-slate-300">
                        {intent}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedLead.notes && (
                <div className="p-4 rounded-lg bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-2">Notes & Insights</p>
                  <p className="text-sm text-slate-300 whitespace-pre-wrap">{selectedLead.notes}</p>
                </div>
              )}

              {selectedLead.conversation_history?.length > 0 && (
                <div>
                  <p className="text-sm text-slate-400 mb-2">Conversation History</p>
                  <ScrollArea className="h-48 rounded-lg bg-slate-800/50 p-3">
                    <div className="space-y-2">
                      {selectedLead.conversation_history.map((msg, i) => (
                        <div key={i} className={cn(
                          "text-sm p-2 rounded",
                          msg.role === 'user' ? "bg-slate-700 ml-8" : "bg-violet-500/20 mr-8"
                        )}>
                          <p className="text-slate-300">{msg.content}</p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}