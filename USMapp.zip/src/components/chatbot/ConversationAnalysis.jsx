import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Sparkles,
  MessageSquare,
  AlertTriangle,
  Lightbulb,
  TrendingUp,
  RefreshCw,
  Loader2,
  ThumbsDown,
  Clock,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { toast } from 'sonner';

export default function ConversationAnalysis({ leads }) {
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeConversations = async () => {
    setIsAnalyzing(true);

    // Gather conversation data from leads
    const conversations = leads
      .filter(l => l.conversation_history && l.conversation_history.length > 0)
      .map(l => ({
        lead_id: l.id,
        intents: l.detected_intents || [],
        sentiment: l.sentiment,
        conversation: l.conversation_history,
        handover_requested: l.handover_requested,
        handover_reason: l.handover_reason
      }));

    if (conversations.length === 0) {
      toast.error('No conversation data available');
      setIsAnalyzing(false);
      return;
    }

    const prompt = `Analyze these chatbot conversations and provide insights:

CONVERSATION DATA:
Total Conversations: ${conversations.length}
Handover Requests: ${conversations.filter(c => c.handover_requested).length}

Sample Conversations:
${conversations.slice(0, 10).map((c, i) => `
Conversation ${i + 1}:
- Intents: ${c.intents.join(', ') || 'None detected'}
- Sentiment: ${c.sentiment}
- Handover: ${c.handover_requested ? `Yes (${c.handover_reason})` : 'No'}
- Messages: ${c.conversation.slice(0, 5).map(m => `${m.role}: ${m.content?.substring(0, 100)}`).join(' | ')}
`).join('\n')}

Provide:
1. Top 5 common user queries/topics
2. Areas where the chatbot struggles (based on handovers, negative sentiment, or unclear intents)
3. Specific improvements to responses and conversation flows
4. Key customer pain points and FAQs
5. Overall chatbot performance score (0-100)
6. Priority actions to improve the chatbot

Be specific and actionable.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          performance_score: { type: 'number' },
          common_queries: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                query: { type: 'string' },
                frequency: { type: 'string' },
                current_handling: { type: 'string' },
                satisfaction_level: { type: 'string' }
              }
            }
          },
          struggle_areas: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                area: { type: 'string' },
                description: { type: 'string' },
                impact: { type: 'string' },
                evidence: { type: 'string' }
              }
            }
          },
          improvements: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                improvement: { type: 'string' },
                rationale: { type: 'string' },
                implementation: { type: 'string' },
                expected_impact: { type: 'string' },
                priority: { type: 'string' }
              }
            }
          },
          pain_points: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                pain_point: { type: 'string' },
                frequency: { type: 'string' },
                current_response: { type: 'string' },
                suggested_solution: { type: 'string' }
              }
            }
          },
          faqs: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                question: { type: 'string' },
                suggested_answer: { type: 'string' }
              }
            }
          },
          priority_actions: {
            type: 'array',
            items: { type: 'string' }
          }
        }
      }
    });

    setAnalysis(result);
    setIsAnalyzing(false);
    toast.success('Analysis complete!');
  };

  if (!analysis) {
    return (
      <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 p-8 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
          <MessageSquare className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-2">AI Conversation Analysis</h3>
        <p className="text-slate-400 mb-6 max-w-md mx-auto">
          Analyze {leads.length} conversation{leads.length !== 1 ? 's' : ''} to identify improvements and optimize chatbot performance
        </p>
        <Button
          onClick={analyzeConversations}
          disabled={isAnalyzing || leads.length === 0}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing Conversations...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Analyze Conversations
            </>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Score */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold text-white mb-1">Conversation Analysis</h3>
          <p className="text-sm text-slate-400">AI insights from {leads.length} conversations</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-center">
            <div className={cn(
              "text-3xl font-bold mb-1",
              analysis.performance_score >= 80 ? "text-emerald-400" :
              analysis.performance_score >= 60 ? "text-amber-400" :
              "text-rose-400"
            )}>
              {analysis.performance_score}
            </div>
            <div className="text-xs text-slate-400">Performance</div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={analyzeConversations}
            disabled={isAnalyzing}
            className="border-slate-700"
          >
            <RefreshCw className={cn("w-4 h-4", isAnalyzing && "animate-spin")} />
          </Button>
        </div>
      </div>

      {/* Priority Actions */}
      {analysis.priority_actions?.length > 0 && (
        <div className="p-5 rounded-xl bg-rose-500/10 border border-rose-500/20">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-rose-400 mt-1 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="font-medium text-white mb-2">Priority Actions</h4>
              <ul className="space-y-2">
                {analysis.priority_actions.map((action, i) => (
                  <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                    <span className="text-rose-400 font-bold">{i + 1}.</span>
                    {action}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      <Accordion type="multiple" defaultValue={['queries', 'struggles']} className="space-y-4">
        {/* Common Queries */}
        <AccordionItem value="queries" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-5 h-5 text-cyan-400" />
              <span className="font-medium text-white">Common Queries ({analysis.common_queries?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {analysis.common_queries?.map((query, i) => (
                <div key={i} className="p-4 rounded-lg bg-slate-800/50">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-white">{query.query}</h5>
                    <Badge className="bg-cyan-500/10 text-cyan-400 text-xs">
                      {query.frequency}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Current Handling</p>
                      <p className="text-slate-300">{query.current_handling}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Satisfaction</p>
                      <Badge variant="outline" className={cn(
                        "border-slate-600",
                        query.satisfaction_level?.toLowerCase().includes('high') ? "text-emerald-400 border-emerald-500/30" :
                        query.satisfaction_level?.toLowerCase().includes('medium') ? "text-amber-400 border-amber-500/30" :
                        "text-rose-400 border-rose-500/30"
                      )}>
                        {query.satisfaction_level}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Struggle Areas */}
        <AccordionItem value="struggles" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <ThumbsDown className="w-5 h-5 text-rose-400" />
              <span className="font-medium text-white">Areas of Struggle ({analysis.struggle_areas?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {analysis.struggle_areas?.map((area, i) => (
                <div key={i} className="p-4 rounded-lg bg-rose-500/5 border border-rose-500/20">
                  <h5 className="font-medium text-white mb-2">{area.area}</h5>
                  <p className="text-sm text-slate-300 mb-3">{area.description}</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded bg-slate-900/50">
                      <p className="text-xs text-slate-400 mb-1">Impact</p>
                      <p className="text-sm text-white">{area.impact}</p>
                    </div>
                    <div className="p-3 rounded bg-slate-900/50">
                      <p className="text-xs text-slate-400 mb-1">Evidence</p>
                      <p className="text-sm text-slate-300">{area.evidence}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Improvements */}
        <AccordionItem value="improvements" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Lightbulb className="w-5 h-5 text-violet-400" />
              <span className="font-medium text-white">Suggested Improvements ({analysis.improvements?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {analysis.improvements?.map((improvement, i) => (
                <div key={i} className="p-4 rounded-lg bg-violet-500/5 border border-violet-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-white">{improvement.improvement}</h5>
                    <Badge className={cn(
                      "text-xs",
                      improvement.priority === 'high' ? "bg-rose-500/10 text-rose-400" :
                      improvement.priority === 'medium' ? "bg-amber-500/10 text-amber-400" :
                      "bg-slate-500/10 text-slate-400"
                    )}>
                      {improvement.priority} priority
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-300 mb-3">{improvement.rationale}</p>
                  <div className="p-3 rounded bg-slate-900/50 mb-3">
                    <p className="text-xs text-slate-400 mb-1">Implementation</p>
                    <p className="text-sm text-slate-200">{improvement.implementation}</p>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-emerald-400">
                    <TrendingUp className="w-3 h-3" />
                    Expected Impact: {improvement.expected_impact}
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Pain Points */}
        <AccordionItem value="pain-points" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-400" />
              <span className="font-medium text-white">Customer Pain Points ({analysis.pain_points?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {analysis.pain_points?.map((pain, i) => (
                <div key={i} className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-white">{pain.pain_point}</h5>
                    <Badge className="bg-amber-500/10 text-amber-400 text-xs">
                      {pain.frequency}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    <div className="p-3 rounded bg-slate-900/50">
                      <p className="text-xs text-slate-400 mb-1">Current Response</p>
                      <p className="text-sm text-slate-300">{pain.current_response}</p>
                    </div>
                    <div className="p-3 rounded bg-violet-500/10 border border-violet-500/20">
                      <p className="text-xs text-violet-400 mb-1">Suggested Solution</p>
                      <p className="text-sm text-white">{pain.suggested_solution}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* FAQs */}
        <AccordionItem value="faqs" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-5 h-5 text-emerald-400" />
              <span className="font-medium text-white">Suggested FAQs ({analysis.faqs?.length})</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {analysis.faqs?.map((faq, i) => (
                <div key={i} className="p-4 rounded-lg bg-slate-800/50">
                  <h5 className="font-medium text-white mb-2">{faq.question}</h5>
                  <p className="text-sm text-slate-300">{faq.suggested_answer}</p>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}