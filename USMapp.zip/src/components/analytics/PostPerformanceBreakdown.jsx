import React, { useState } from 'react';
import { format, parseISO } from 'date-fns';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MousePointerClick,
  TrendingUp,
  TrendingDown,
  Eye,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 rounded-lg p-3 shadow-xl">
        <p className="text-slate-400 text-sm mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm font-medium" style={{ color: entry.color }}>
            {entry.name}: {entry.value.toLocaleString()}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function PostPerformanceBreakdown({ posts }) {
  const [expandedPost, setExpandedPost] = useState(null);

  const getEngagementRate = (post) => {
    const total = (post.likes || 0) + (post.comments || 0) + (post.shares || 0) + (post.saves || 0);
    const reach = post.reach || post.impressions || 1;
    return ((total / reach) * 100).toFixed(2);
  };

  const getEngagementTrend = (post) => {
    const rate = parseFloat(getEngagementRate(post));
    if (rate > 5) return { icon: TrendingUp, color: 'text-emerald-400', label: 'High' };
    if (rate > 2) return { icon: TrendingUp, color: 'text-cyan-400', label: 'Good' };
    return { icon: TrendingDown, color: 'text-rose-400', label: 'Low' };
  };

  const getClickThroughRate = (post) => {
    if (!post.clicks || !post.reach) return '0.00';
    return ((post.clicks / post.reach) * 100).toFixed(2);
  };

  const generateHourlyData = (post) => {
    // Simulate hourly engagement data
    return Array.from({ length: 24 }, (_, i) => ({
      hour: `${i}:00`,
      engagement: Math.floor(Math.random() * (post.likes || 100) / 4)
    }));
  };

  return (
    <div className="space-y-4">
      {posts.map((post) => {
        const trend = getEngagementTrend(post);
        const TrendIcon = trend.icon;
        const isExpanded = expandedPost === post.id;
        const hourlyData = generateHourlyData(post);

        return (
          <div
            key={post.id}
            className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden"
          >
            {/* Post Header */}
            <div
              className="p-6 cursor-pointer hover:bg-slate-800/30 transition-colors"
              onClick={() => setExpandedPost(isExpanded ? null : post.id)}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex -space-x-1">
                      {post.platforms?.map((platform) => (
                        <PlatformIcon key={platform} platform={platform} size="xs" />
                      ))}
                    </div>
                    <span className="text-slate-500 text-sm">
                      {post.published_time && format(parseISO(post.published_time), 'MMM d, yyyy')}
                    </span>
                    <Badge className={cn(
                      "text-xs",
                      trend.color === 'text-emerald-400' && "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
                      trend.color === 'text-cyan-400' && "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
                      trend.color === 'text-rose-400' && "bg-rose-500/10 text-rose-400 border-rose-500/20"
                    )}>
                      <TrendIcon className="w-3 h-3 mr-1" />
                      {trend.label} Performance
                    </Badge>
                  </div>
                  <p className="text-white font-medium mb-1 line-clamp-2">{post.content}</p>
                  <div className="flex items-center gap-4 text-sm text-slate-400">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {(post.reach || post.impressions || 0).toLocaleString()} reach
                    </div>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-4 h-4" />
                      {getEngagementRate(post)}% engagement
                    </div>
                    {post.clicks && (
                      <div className="flex items-center gap-1">
                        <MousePointerClick className="w-4 h-4" />
                        {getClickThroughRate(post)}% CTR
                      </div>
                    )}
                  </div>
                </div>
                <button className="text-slate-400 hover:text-white transition-colors p-2">
                  {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                </button>
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mt-4">
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <div className="flex items-center gap-2 text-rose-400 mb-1">
                    <Heart className="w-4 h-4" />
                    <span className="text-xs">Likes</span>
                  </div>
                  <p className="text-lg font-semibold text-white">{(post.likes || 0).toLocaleString()}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <div className="flex items-center gap-2 text-cyan-400 mb-1">
                    <MessageCircle className="w-4 h-4" />
                    <span className="text-xs">Comments</span>
                  </div>
                  <p className="text-lg font-semibold text-white">{(post.comments || 0).toLocaleString()}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <div className="flex items-center gap-2 text-violet-400 mb-1">
                    <Share2 className="w-4 h-4" />
                    <span className="text-xs">Shares</span>
                  </div>
                  <p className="text-lg font-semibold text-white">{(post.shares || 0).toLocaleString()}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <div className="flex items-center gap-2 text-amber-400 mb-1">
                    <Bookmark className="w-4 h-4" />
                    <span className="text-xs">Saves</span>
                  </div>
                  <p className="text-lg font-semibold text-white">{(post.saves || 0).toLocaleString()}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50">
                  <div className="flex items-center gap-2 text-emerald-400 mb-1">
                    <MousePointerClick className="w-4 h-4" />
                    <span className="text-xs">Clicks</span>
                  </div>
                  <p className="text-lg font-semibold text-white">{(post.clicks || 0).toLocaleString()}</p>
                </div>
              </div>
            </div>

            {/* Expanded Details */}
            {isExpanded && (
              <div className="border-t border-slate-800 p-6 bg-slate-900/30 space-y-6">
                {/* Engagement Breakdown */}
                <div>
                  <h4 className="text-sm font-medium text-slate-400 mb-4">Engagement Breakdown</h4>
                  <div className="space-y-3">
                    {[
                      { label: 'Likes', value: post.likes || 0, color: 'bg-rose-500' },
                      { label: 'Comments', value: post.comments || 0, color: 'bg-cyan-500' },
                      { label: 'Shares', value: post.shares || 0, color: 'bg-violet-500' },
                      { label: 'Saves', value: post.saves || 0, color: 'bg-amber-500' },
                      { label: 'Clicks', value: post.clicks || 0, color: 'bg-emerald-500' },
                    ].map((item) => {
                      const total = (post.likes || 0) + (post.comments || 0) + (post.shares || 0) + (post.saves || 0) + (post.clicks || 0);
                      const percentage = total > 0 ? (item.value / total) * 100 : 0;
                      return (
                        <div key={item.label}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm text-slate-400">{item.label}</span>
                            <span className="text-sm text-white font-medium">
                              {item.value.toLocaleString()} ({percentage.toFixed(1)}%)
                            </span>
                          </div>
                          <Progress value={percentage} className="h-2" indicatorClassName={item.color} />
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Hourly Engagement Pattern */}
                <div>
                  <h4 className="text-sm font-medium text-slate-400 mb-4">24-Hour Engagement Pattern</h4>
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={hourlyData}>
                      <defs>
                        <linearGradient id={`gradient-${post.id}`} x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="hour" stroke="#64748B" fontSize={10} />
                      <YAxis stroke="#64748B" fontSize={10} />
                      <Tooltip content={<CustomTooltip />} />
                      <Area 
                        type="monotone" 
                        dataKey="engagement" 
                        stroke="#8B5CF6" 
                        fillOpacity={1} 
                        fill={`url(#gradient-${post.id})`} 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Media Performance */}
                {post.media_urls && post.media_urls.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-slate-400 mb-3">Media Assets</h4>
                    <div className="flex gap-2 flex-wrap">
                      {post.media_urls.slice(0, 4).map((url, idx) => (
                        <img 
                          key={idx}
                          src={url} 
                          alt="" 
                          className="w-20 h-20 rounded-lg object-cover"
                        />
                      ))}
                      {post.media_urls.length > 4 && (
                        <div className="w-20 h-20 rounded-lg bg-slate-800/50 flex items-center justify-center text-slate-400 text-sm">
                          +{post.media_urls.length - 4}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Hashtags */}
                {post.hashtags && post.hashtags.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium text-slate-400 mb-3">Hashtags Used</h4>
                    <div className="flex flex-wrap gap-2">
                      {post.hashtags.map((tag) => (
                        <Badge key={tag} variant="outline" className="border-slate-700 text-slate-400">
                          #{tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}