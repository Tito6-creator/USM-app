import React, { useState } from 'react';
import { format } from 'date-fns';
import {
  FlaskConical,
  Plus,
  Play,
  Pause,
  Trophy,
  TrendingUp,
  TrendingDown,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  MousePointer,
  Target,
  BarChart3,
  Loader2,
  Check,
  X,
  Trash2,
  MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

const testTypes = [
  { id: 'caption', label: 'Caption', description: 'Test different captions' },
  { id: 'hashtags', label: 'Hashtags', description: 'Compare hashtag sets' },
  { id: 'media', label: 'Media/Creative', description: 'Test images or videos' },
  { id: 'posting_time', label: 'Posting Time', description: 'Find optimal times' },
  { id: 'cta', label: 'Call-to-Action', description: 'Test different CTAs' },
  { id: 'ad_creative', label: 'Ad Creative', description: 'Compare ad variations' },
];

const statusColors = {
  draft: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  running: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  paused: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  completed: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
};

function MetricComparison({ label, valueA, valueB, icon: Icon, format: formatType = 'number' }) {
  const formatValue = (val) => {
    if (formatType === 'percent') return `${val}%`;
    if (formatType === 'number') return val?.toLocaleString() || 0;
    return val;
  };

  const winner = valueA > valueB ? 'a' : valueB > valueA ? 'b' : 'tie';
  const diff = valueA && valueB ? Math.round(((Math.max(valueA, valueB) - Math.min(valueA, valueB)) / Math.min(valueA, valueB)) * 100) : 0;

  return (
    <div className="p-4 rounded-xl bg-slate-800/30">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-4 h-4 text-slate-400" />
        <span className="text-sm text-slate-400">{label}</span>
      </div>
      <div className="grid grid-cols-3 gap-4 items-center">
        <div className={cn(
          "text-center p-3 rounded-lg",
          winner === 'a' ? "bg-emerald-500/10 ring-1 ring-emerald-500/30" : "bg-slate-800/50"
        )}>
          <p className="text-xl font-bold text-white">{formatValue(valueA)}</p>
          {winner === 'a' && <Trophy className="w-4 h-4 text-emerald-400 mx-auto mt-1" />}
        </div>
        <div className="text-center">
          {diff > 0 && (
            <Badge className={cn(
              "text-xs",
              winner === 'a' ? "bg-emerald-500/10 text-emerald-400" : "bg-violet-500/10 text-violet-400"
            )}>
              +{diff}%
            </Badge>
          )}
        </div>
        <div className={cn(
          "text-center p-3 rounded-lg",
          winner === 'b' ? "bg-violet-500/10 ring-1 ring-violet-500/30" : "bg-slate-800/50"
        )}>
          <p className="text-xl font-bold text-white">{formatValue(valueB)}</p>
          {winner === 'b' && <Trophy className="w-4 h-4 text-violet-400 mx-auto mt-1" />}
        </div>
      </div>
    </div>
  );
}

export default function ABTestingPanel({ tests = [], onCreate, onUpdate, onDelete }) {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedTest, setSelectedTest] = useState(null);
  const [newTest, setNewTest] = useState({
    name: '',
    description: '',
    test_type: 'caption',
    platform: 'instagram',
    primary_metric: 'engagement_rate',
    sample_size_target: 1000,
    variant_a: { name: 'Variant A', content: '' },
    variant_b: { name: 'Variant B', content: '' },
  });

  const handleCreate = () => {
    onCreate({
      ...newTest,
      status: 'draft',
    });
    setIsCreateOpen(false);
    setNewTest({
      name: '',
      description: '',
      test_type: 'caption',
      platform: 'instagram',
      primary_metric: 'engagement_rate',
      sample_size_target: 1000,
      variant_a: { name: 'Variant A', content: '' },
      variant_b: { name: 'Variant B', content: '' },
    });
  };

  const handleStatusChange = (test, newStatus) => {
    onUpdate(test.id, { status: newStatus });
  };

  const runningTests = tests.filter(t => t.status === 'running');
  const completedTests = tests.filter(t => t.status === 'completed');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">A/B Testing</h3>
          <p className="text-sm text-slate-400">
            {runningTests.length} active • {completedTests.length} completed
          </p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-violet-600 hover:bg-violet-700">
              <Plus className="w-4 h-4 mr-2" />
              New Test
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">Create A/B Test</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Test Name</Label>
                  <Input
                    value={newTest.name}
                    onChange={(e) => setNewTest({ ...newTest, name: e.target.value })}
                    placeholder="e.g., Caption Style Test"
                    className="mt-2 bg-slate-800/50 border-slate-700"
                  />
                </div>
                <div>
                  <Label className="text-white">Test Type</Label>
                  <Select 
                    value={newTest.test_type} 
                    onValueChange={(v) => setNewTest({ ...newTest, test_type: v })}
                  >
                    <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      {testTypes.map(type => (
                        <SelectItem key={type.id} value={type.id}>{type.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Platform</Label>
                  <Select 
                    value={newTest.platform} 
                    onValueChange={(v) => setNewTest({ ...newTest, platform: v })}
                  >
                    <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      <SelectItem value="instagram">Instagram</SelectItem>
                      <SelectItem value="facebook">Facebook</SelectItem>
                      <SelectItem value="tiktok">TikTok</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-white">Primary Metric</Label>
                  <Select 
                    value={newTest.primary_metric} 
                    onValueChange={(v) => setNewTest({ ...newTest, primary_metric: v })}
                  >
                    <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      <SelectItem value="engagement_rate">Engagement Rate</SelectItem>
                      <SelectItem value="clicks">Link Clicks</SelectItem>
                      <SelectItem value="conversions">Conversions</SelectItem>
                      <SelectItem value="reach">Reach</SelectItem>
                      <SelectItem value="ctr">Click-Through Rate</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label className="text-white">Sample Size Target</Label>
                <Input
                  type="number"
                  value={newTest.sample_size_target}
                  onChange={(e) => setNewTest({ ...newTest, sample_size_target: parseInt(e.target.value) })}
                  className="mt-2 bg-slate-800/50 border-slate-700"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center text-white text-xs font-bold">A</div>
                    <Input
                      value={newTest.variant_a.name}
                      onChange={(e) => setNewTest({ 
                        ...newTest, 
                        variant_a: { ...newTest.variant_a, name: e.target.value } 
                      })}
                      className="bg-transparent border-0 p-0 h-auto text-white font-medium focus-visible:ring-0"
                    />
                  </div>
                  <Textarea
                    value={newTest.variant_a.content}
                    onChange={(e) => setNewTest({ 
                      ...newTest, 
                      variant_a: { ...newTest.variant_a, content: e.target.value } 
                    })}
                    placeholder="Enter variant A content..."
                    className="bg-slate-800/50 border-slate-700 min-h-[100px]"
                  />
                </div>
                <div className="p-4 rounded-xl bg-violet-500/5 border border-violet-500/20">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-6 h-6 rounded-full bg-violet-500 flex items-center justify-center text-white text-xs font-bold">B</div>
                    <Input
                      value={newTest.variant_b.name}
                      onChange={(e) => setNewTest({ 
                        ...newTest, 
                        variant_b: { ...newTest.variant_b, name: e.target.value } 
                      })}
                      className="bg-transparent border-0 p-0 h-auto text-white font-medium focus-visible:ring-0"
                    />
                  </div>
                  <Textarea
                    value={newTest.variant_b.content}
                    onChange={(e) => setNewTest({ 
                      ...newTest, 
                      variant_b: { ...newTest.variant_b, content: e.target.value } 
                    })}
                    placeholder="Enter variant B content..."
                    className="bg-slate-800/50 border-slate-700 min-h-[100px]"
                  />
                </div>
              </div>

              <Button
                onClick={handleCreate}
                disabled={!newTest.name || !newTest.variant_a.content || !newTest.variant_b.content}
                className="w-full bg-violet-600 hover:bg-violet-700"
              >
                <FlaskConical className="w-4 h-4 mr-2" />
                Create Test
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tests List */}
      {tests.length === 0 ? (
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-12 text-center">
          <FlaskConical className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No A/B tests yet</h3>
          <p className="text-slate-400 mb-6">Create your first test to optimize your content</p>
          <Button onClick={() => setIsCreateOpen(true)} className="bg-violet-600 hover:bg-violet-700">
            <Plus className="w-4 h-4 mr-2" />
            Create Test
          </Button>
        </div>
      ) : (
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList className="bg-slate-800/50">
            <TabsTrigger value="all" className="data-[state=active]:bg-violet-600">All Tests</TabsTrigger>
            <TabsTrigger value="running" className="data-[state=active]:bg-violet-600">Running</TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-violet-600">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            {tests.map((test) => (
              <TestCard 
                key={test.id} 
                test={test} 
                onSelect={() => setSelectedTest(test)}
                onStatusChange={handleStatusChange}
                onDelete={onDelete}
              />
            ))}
          </TabsContent>

          <TabsContent value="running" className="space-y-4">
            {runningTests.map((test) => (
              <TestCard 
                key={test.id} 
                test={test} 
                onSelect={() => setSelectedTest(test)}
                onStatusChange={handleStatusChange}
                onDelete={onDelete}
              />
            ))}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {completedTests.map((test) => (
              <TestCard 
                key={test.id} 
                test={test} 
                onSelect={() => setSelectedTest(test)}
                onStatusChange={handleStatusChange}
                onDelete={onDelete}
              />
            ))}
          </TabsContent>
        </Tabs>
      )}

      {/* Test Detail Dialog */}
      <Dialog open={!!selectedTest} onOpenChange={() => setSelectedTest(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-3">
              <FlaskConical className="w-5 h-5 text-violet-400" />
              {selectedTest?.name}
            </DialogTitle>
          </DialogHeader>
          
          {selectedTest && (
            <div className="space-y-6 pt-4">
              {/* Status & Progress */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Badge className={statusColors[selectedTest.status]}>
                    {selectedTest.status}
                  </Badge>
                  <PlatformIcon platform={selectedTest.platform} size="sm" showLabel />
                </div>
                {selectedTest.confidence_level && (
                  <div className="text-sm text-slate-400">
                    Confidence: <span className="text-white font-medium">{selectedTest.confidence_level}%</span>
                  </div>
                )}
              </div>

              {/* Sample Progress */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-slate-400">Sample Progress</span>
                  <span className="text-sm text-white">
                    {((selectedTest.variant_a?.impressions || 0) + (selectedTest.variant_b?.impressions || 0)).toLocaleString()} / {selectedTest.sample_size_target?.toLocaleString()}
                  </span>
                </div>
                <Progress 
                  value={Math.min(
                    (((selectedTest.variant_a?.impressions || 0) + (selectedTest.variant_b?.impressions || 0)) / selectedTest.sample_size_target) * 100,
                    100
                  )} 
                  className="h-2"
                />
              </div>

              {/* Variants Comparison */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center text-white text-xs font-bold">A</div>
                    <span className="font-medium text-white">{selectedTest.variant_a?.name}</span>
                    {selectedTest.winner === 'variant_a' && (
                      <Badge className="bg-emerald-500/10 text-emerald-400">
                        <Trophy className="w-3 h-3 mr-1" />
                        Winner
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-400 line-clamp-3">{selectedTest.variant_a?.content}</p>
                </div>
                <div className="p-4 rounded-xl bg-violet-500/5 border border-violet-500/20">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-full bg-violet-500 flex items-center justify-center text-white text-xs font-bold">B</div>
                    <span className="font-medium text-white">{selectedTest.variant_b?.name}</span>
                    {selectedTest.winner === 'variant_b' && (
                      <Badge className="bg-violet-500/10 text-violet-400">
                        <Trophy className="w-3 h-3 mr-1" />
                        Winner
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-400 line-clamp-3">{selectedTest.variant_b?.content}</p>
                </div>
              </div>

              {/* Metrics Comparison */}
              <div className="space-y-3">
                <h4 className="font-medium text-white">Performance Comparison</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <MetricComparison
                    label="Engagement Rate"
                    valueA={selectedTest.variant_a?.engagement_rate}
                    valueB={selectedTest.variant_b?.engagement_rate}
                    icon={TrendingUp}
                    format="percent"
                  />
                  <MetricComparison
                    label="Impressions"
                    valueA={selectedTest.variant_a?.impressions}
                    valueB={selectedTest.variant_b?.impressions}
                    icon={Eye}
                  />
                  <MetricComparison
                    label="Likes"
                    valueA={selectedTest.variant_a?.likes}
                    valueB={selectedTest.variant_b?.likes}
                    icon={Heart}
                  />
                  <MetricComparison
                    label="Comments"
                    valueA={selectedTest.variant_a?.comments}
                    valueB={selectedTest.variant_b?.comments}
                    icon={MessageCircle}
                  />
                  <MetricComparison
                    label="Clicks"
                    valueA={selectedTest.variant_a?.clicks}
                    valueB={selectedTest.variant_b?.clicks}
                    icon={MousePointer}
                  />
                  <MetricComparison
                    label="CTR"
                    valueA={selectedTest.variant_a?.ctr}
                    valueB={selectedTest.variant_b?.ctr}
                    icon={Target}
                    format="percent"
                  />
                </div>
              </div>

              {/* Insights */}
              {selectedTest.insights && (
                <div className="p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
                  <h4 className="font-medium text-violet-300 mb-2">AI Insights</h4>
                  <p className="text-sm text-slate-300">{selectedTest.insights}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function TestCard({ test, onSelect, onStatusChange, onDelete }) {
  const progress = Math.min(
    (((test.variant_a?.impressions || 0) + (test.variant_b?.impressions || 0)) / test.sample_size_target) * 100,
    100
  );

  return (
    <div
      className="rounded-xl bg-slate-800/50 p-5 hover:bg-slate-800 transition-colors cursor-pointer"
      onClick={onSelect}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <FlaskConical className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="font-medium text-white">{test.name}</h4>
            <div className="flex items-center gap-2 text-sm">
              <Badge className={statusColors[test.status]}>{test.status}</Badge>
              <span className="text-slate-500">•</span>
              <PlatformIcon platform={test.platform} size="xs" />
              <span className="text-slate-500 capitalize">{test.test_type?.replace('_', ' ')}</span>
            </div>
          </div>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="icon" className="text-slate-400">
              <MoreVertical className="w-5 h-5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
            {test.status === 'draft' && (
              <DropdownMenuItem onClick={(e) => {
                e.stopPropagation();
                onStatusChange(test, 'running');
              }}>
                <Play className="w-4 h-4 mr-2" />
                Start Test
              </DropdownMenuItem>
            )}
            {test.status === 'running' && (
              <DropdownMenuItem onClick={(e) => {
                e.stopPropagation();
                onStatusChange(test, 'paused');
              }}>
                <Pause className="w-4 h-4 mr-2" />
                Pause Test
              </DropdownMenuItem>
            )}
            {test.status === 'paused' && (
              <DropdownMenuItem onClick={(e) => {
                e.stopPropagation();
                onStatusChange(test, 'running');
              }}>
                <Play className="w-4 h-4 mr-2" />
                Resume Test
              </DropdownMenuItem>
            )}
            <DropdownMenuItem 
              onClick={(e) => {
                e.stopPropagation();
                onDelete(test.id);
              }}
              className="text-rose-400"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-4 h-4 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[10px] font-bold">A</div>
            <span className="text-xs text-slate-400">{test.variant_a?.name}</span>
          </div>
          <p className="text-lg font-bold text-white">{test.variant_a?.engagement_rate || 0}%</p>
        </div>
        <div className="p-3 rounded-lg bg-violet-500/5 border border-violet-500/20">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-4 h-4 rounded-full bg-violet-500 flex items-center justify-center text-white text-[10px] font-bold">B</div>
            <span className="text-xs text-slate-400">{test.variant_b?.name}</span>
          </div>
          <p className="text-lg font-bold text-white">{test.variant_b?.engagement_rate || 0}%</p>
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-1 text-xs">
          <span className="text-slate-500">Progress</span>
          <span className="text-slate-400">{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-1.5" />
      </div>

      {test.winner && test.status === 'completed' && (
        <div className="mt-3 pt-3 border-t border-slate-700 flex items-center gap-2">
          <Trophy className={cn(
            "w-4 h-4",
            test.winner === 'variant_a' ? "text-emerald-400" : "text-violet-400"
          )} />
          <span className="text-sm text-slate-300">
            Winner: <span className="font-medium text-white">
              {test.winner === 'variant_a' ? test.variant_a?.name : test.variant_b?.name}
            </span>
          </span>
        </div>
      )}
    </div>
  );
}