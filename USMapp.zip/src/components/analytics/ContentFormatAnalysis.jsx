import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Image, Video, Play, LayoutGrid } from 'lucide-react';
import PlatformIcon from '@/components/ui/PlatformIcon';

const COLORS = ['#8b5cf6', '#ec4899', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

export default function ContentFormatAnalysis() {
  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 200),
  });

  // Analyze by media type
  const formatData = posts.reduce((acc, post) => {
    const type = post.media_type || 'text';
    if (!acc[type]) {
      acc[type] = {
        count: 0,
        totalLikes: 0,
        totalComments: 0,
        totalShares: 0,
        totalReach: 0,
        totalEngagement: 0
      };
    }
    acc[type].count++;
    acc[type].totalLikes += post.likes || 0;
    acc[type].totalComments += post.comments || 0;
    acc[type].totalShares += post.shares || 0;
    acc[type].totalReach += post.reach || 0;
    acc[type].totalEngagement += (post.likes || 0) + (post.comments || 0) + (post.shares || 0);
    return acc;
  }, {});

  const formatChartData = Object.entries(formatData).map(([type, data]) => ({
    type: type.charAt(0).toUpperCase() + type.slice(1),
    count: data.count,
    avgEngagement: Math.round(data.totalEngagement / data.count),
    avgReach: Math.round(data.totalReach / data.count),
    engagementRate: data.totalReach > 0 ? ((data.totalEngagement / data.totalReach) * 100).toFixed(2) : 0
  }));

  // Analyze by platform
  const platformData = posts.reduce((acc, post) => {
    post.platforms?.forEach(platform => {
      if (!acc[platform]) {
        acc[platform] = {
          count: 0,
          totalEngagement: 0,
          totalReach: 0
        };
      }
      acc[platform].count++;
      acc[platform].totalEngagement += (post.likes || 0) + (post.comments || 0) + (post.shares || 0);
      acc[platform].totalReach += post.reach || 0;
    });
    return acc;
  }, {});

  const platformChartData = Object.entries(platformData).map(([platform, data]) => ({
    platform: platform.charAt(0).toUpperCase() + platform.slice(1),
    count: data.count,
    avgEngagement: Math.round(data.totalEngagement / data.count),
    engagementRate: data.totalReach > 0 ? ((data.totalEngagement / data.totalReach) * 100).toFixed(2) : 0
  }));

  // Format distribution for pie chart
  const pieData = formatChartData.map(item => ({
    name: item.type,
    value: item.count
  }));

  const getFormatIcon = (type) => {
    switch(type.toLowerCase()) {
      case 'image': return Image;
      case 'video': return Video;
      case 'reel': case 'story': return Play;
      case 'carousel': return LayoutGrid;
      default: return Image;
    }
  };

  return (
    <div className="space-y-6">
      {/* Format Performance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {formatChartData.map((format, idx) => {
          const Icon = getFormatIcon(format.type);
          return (
            <Card key={format.type} className="p-6 bg-slate-900/50 border-slate-800">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
                  <Icon className="w-6 h-6 text-violet-400" />
                </div>
                <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                  {format.count} posts
                </Badge>
              </div>
              <h3 className="text-white font-semibold mb-1">{format.type}</h3>
              <p className="text-2xl font-bold text-white mb-1">{format.avgEngagement.toLocaleString()}</p>
              <p className="text-xs text-slate-400">Avg engagement</p>
              <div className="mt-3 pt-3 border-t border-slate-700">
                <p className="text-sm text-slate-400">
                  {format.engagementRate}% engagement rate
                </p>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Format Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-6">Content Format Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-6">Average Engagement by Format</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={formatChartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="type" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="avgEngagement" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Platform Performance */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-6">Performance by Platform</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {platformChartData.map((platform) => (
            <div key={platform.platform} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <PlatformIcon platform={platform.platform.toLowerCase()} size="sm" />
                  <span className="font-semibold text-white">{platform.platform}</span>
                </div>
                <Badge className="bg-slate-700 text-slate-300">
                  {platform.count} posts
                </Badge>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">Avg Engagement</span>
                  <span className="text-sm font-semibold text-white">{platform.avgEngagement.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">Engagement Rate</span>
                  <span className="text-sm font-semibold text-violet-400">{platform.engagementRate}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={platformChartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="platform" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px'
              }}
            />
            <Legend />
            <Bar dataKey="avgEngagement" fill="#ec4899" name="Avg Engagement" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}