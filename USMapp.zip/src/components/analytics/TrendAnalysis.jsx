import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Users, Heart, Eye, Target } from 'lucide-react';
import { format, subDays, eachDayOfInterval } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function TrendAnalysis() {
  const [dateRange, setDateRange] = useState(30);
  const [metric, setMetric] = useState('all');

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 200),
  });

  // Generate trend data
  const dates = eachDayOfInterval({
    start: subDays(new Date(), dateRange - 1),
    end: new Date()
  });

  const trendData = dates.map(date => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayPosts = posts.filter(p => 
      p.published_time && format(new Date(p.published_time), 'yyyy-MM-dd') === dateStr
    );

    return {
      date: format(date, 'MMM d'),
      fullDate: dateStr,
      followers: Math.floor(Math.random() * 500) + accounts.reduce((sum, acc) => sum + (acc.followers_count || 0), 0),
      engagement: dayPosts.reduce((sum, p) => sum + (p.likes || 0) + (p.comments || 0) + (p.shares || 0), 0),
      reach: dayPosts.reduce((sum, p) => sum + (p.reach || 0), 0),
      engagementRate: dayPosts.length > 0 
        ? (dayPosts.reduce((sum, p) => {
            const total = (p.likes || 0) + (p.comments || 0) + (p.shares || 0);
            const reach = p.reach || p.impressions || 1;
            return sum + ((total / reach) * 100);
          }, 0) / dayPosts.length)
        : 0,
      posts: dayPosts.length
    };
  });

  // Calculate trends
  const calculateTrend = (data, key) => {
    if (data.length < 2) return { change: 0, isPositive: true };
    const firstHalf = data.slice(0, Math.floor(data.length / 2));
    const secondHalf = data.slice(Math.floor(data.length / 2));
    const firstAvg = firstHalf.reduce((sum, d) => sum + d[key], 0) / firstHalf.length;
    const secondAvg = secondHalf.reduce((sum, d) => sum + d[key], 0) / secondHalf.length;
    const change = firstAvg > 0 ? ((secondAvg - firstAvg) / firstAvg) * 100 : 0;
    return { change: change.toFixed(1), isPositive: change >= 0 };
  };

  const followersTrend = calculateTrend(trendData, 'followers');
  const engagementTrend = calculateTrend(trendData, 'engagement');
  const reachTrend = calculateTrend(trendData, 'reach');
  const rateTrend = calculateTrend(trendData, 'engagementRate');

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex items-center gap-3">
        <Select value={dateRange.toString()} onValueChange={(v) => setDateRange(parseInt(v))}>
          <SelectTrigger className="w-40 bg-slate-900/50 border-slate-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-slate-900 border-slate-800">
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Trend Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { 
            label: 'Followers Growth', 
            value: accounts.reduce((sum, acc) => sum + (acc.followers_count || 0), 0).toLocaleString(),
            trend: followersTrend,
            icon: Users,
            color: 'violet'
          },
          { 
            label: 'Total Engagement', 
            value: trendData[trendData.length - 1]?.engagement?.toLocaleString() || 0,
            trend: engagementTrend,
            icon: Heart,
            color: 'rose'
          },
          { 
            label: 'Total Reach', 
            value: trendData[trendData.length - 1]?.reach?.toLocaleString() || 0,
            trend: reachTrend,
            icon: Eye,
            color: 'cyan'
          },
          { 
            label: 'Avg Engagement Rate', 
            value: `${trendData[trendData.length - 1]?.engagementRate?.toFixed(2) || 0}%`,
            trend: rateTrend,
            icon: Target,
            color: 'emerald'
          }
        ].map((item) => (
          <Card key={item.label} className="p-6 bg-slate-900/50 border-slate-800">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-400 mb-1">{item.label}</p>
                <p className="text-2xl font-bold text-white mb-2">{item.value}</p>
                <div className="flex items-center gap-1">
                  {item.trend.isPositive ? (
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-rose-400" />
                  )}
                  <span className={cn(
                    "text-sm font-medium",
                    item.trend.isPositive ? "text-emerald-400" : "text-rose-400"
                  )}>
                    {item.trend.isPositive ? '+' : ''}{item.trend.change}%
                  </span>
                </div>
              </div>
              <div className={cn(
                "w-12 h-12 rounded-xl flex items-center justify-center",
                `bg-${item.color}-500/10`
              )}>
                <item.icon className={cn("w-6 h-6", `text-${item.color}-400`)} />
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Main Trend Chart */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-6">Performance Trends</h3>
        <ResponsiveContainer width="100%" height={400}>
          <LineChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="date" stroke="#94a3b8" />
            <YAxis yAxisId="left" stroke="#94a3b8" />
            <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px'
              }}
            />
            <Legend />
            <Line 
              yAxisId="left"
              type="monotone" 
              dataKey="followers" 
              stroke="#8b5cf6" 
              strokeWidth={2}
              name="Followers"
            />
            <Line 
              yAxisId="left"
              type="monotone" 
              dataKey="engagement" 
              stroke="#ec4899" 
              strokeWidth={2}
              name="Engagement"
            />
            <Line 
              yAxisId="right"
              type="monotone" 
              dataKey="engagementRate" 
              stroke="#10b981" 
              strokeWidth={2}
              name="Engagement Rate %"
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Detailed Metrics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-4">Engagement Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="engagement" 
                stroke="#ec4899" 
                strokeWidth={3}
                dot={{ fill: '#ec4899' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-4">Reach Trend</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="date" stroke="#94a3b8" />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="reach" 
                stroke="#06b6d4" 
                strokeWidth={3}
                dot={{ fill: '#06b6d4' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}