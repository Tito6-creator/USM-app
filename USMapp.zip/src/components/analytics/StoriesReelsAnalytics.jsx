import React, { useState } from 'react';
import { format } from 'date-fns';
import {
  Play,
  Eye,
  Clock,
  TrendingUp,
  TrendingDown,
  MousePointer,
  ArrowUp,
  SkipForward,
  SkipBack,
  Share2,
  Bookmark,
  Heart,
  MessageCircle,
  UserPlus,
  X
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 rounded-lg p-3 shadow-xl">
        <p className="text-slate-400 text-sm mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm font-medium" style={{ color: entry.color }}>
            {entry.name}: {entry.value}%
          </p>
        ))}
      </div>
    );
  }
  return null;
};

function StatCard({ icon: Icon, label, value, change, color }) {
  const isPositive = change >= 0;
  return (
    <div className="p-4 rounded-xl bg-slate-800/50">
      <div className="flex items-center gap-3 mb-2">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center", color)}>
          <Icon className="w-4 h-4 text-white" />
        </div>
        <span className="text-sm text-slate-400">{label}</span>
      </div>
      <div className="flex items-end justify-between">
        <span className="text-2xl font-bold text-white">{value}</span>
        {change !== undefined && (
          <div className={cn(
            "flex items-center gap-1 text-xs",
            isPositive ? "text-emerald-400" : "text-rose-400"
          )}>
            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(change)}%
          </div>
        )}
      </div>
    </div>
  );
}

export default function StoriesReelsAnalytics({ data = [], contentType = 'all' }) {
  const [selectedItem, setSelectedItem] = useState(null);
  const [filter, setFilter] = useState(contentType);

  const filteredData = filter === 'all' 
    ? data 
    : data.filter(item => item.content_type === filter);

  // Calculate aggregated stats
  const totalViews = filteredData.reduce((sum, item) => sum + (item.views || 0), 0);
  const avgCompletionRate = filteredData.length > 0
    ? Math.round(filteredData.reduce((sum, item) => sum + (item.completion_rate || 0), 0) / filteredData.length)
    : 0;
  const totalSwipeUps = filteredData.reduce((sum, item) => sum + (item.swipe_ups || 0), 0);
  const avgWatchTime = filteredData.length > 0
    ? Math.round(filteredData.reduce((sum, item) => sum + (item.average_watch_time || 0), 0) / filteredData.length)
    : 0;

  // Generate retention chart data
  const generateRetentionData = (item) => {
    if (item?.audience_retention?.length) {
      return item.audience_retention;
    }
    // Mock data for demo
    return [
      { percentage_through: 0, viewers_remaining: 100 },
      { percentage_through: 25, viewers_remaining: 85 },
      { percentage_through: 50, viewers_remaining: 65 },
      { percentage_through: 75, viewers_remaining: 45 },
      { percentage_through: 100, viewers_remaining: 30 },
    ];
  };

  return (
    <div className="space-y-6">
      {/* Filter Tabs */}
      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="all" className="data-[state=active]:bg-violet-600">All</TabsTrigger>
          <TabsTrigger value="story" className="data-[state=active]:bg-violet-600">Stories</TabsTrigger>
          <TabsTrigger value="reel" className="data-[state=active]:bg-violet-600">Reels</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Eye}
          label="Total Views"
          value={totalViews.toLocaleString()}
          change={12}
          color="bg-violet-500"
        />
        <StatCard
          icon={Play}
          label="Avg. Completion Rate"
          value={`${avgCompletionRate}%`}
          change={5}
          color="bg-emerald-500"
        />
        <StatCard
          icon={ArrowUp}
          label="Swipe Ups"
          value={totalSwipeUps.toLocaleString()}
          change={-3}
          color="bg-cyan-500"
        />
        <StatCard
          icon={Clock}
          label="Avg. Watch Time"
          value={`${avgWatchTime}s`}
          change={8}
          color="bg-fuchsia-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Content List */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
          <div className="px-4 py-4 border-b border-slate-800">
            <h3 className="font-semibold text-white">Content Performance</h3>
          </div>
          <ScrollArea className="h-[500px]">
            <div className="p-4 space-y-3">
              {filteredData.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  No {filter === 'all' ? 'content' : filter + 's'} found
                </div>
              ) : (
                filteredData.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => setSelectedItem(item)}
                    className={cn(
                      "p-4 rounded-xl cursor-pointer transition-all",
                      selectedItem?.id === item.id
                        ? "bg-violet-500/10 border border-violet-500/30"
                        : "bg-slate-800/50 hover:bg-slate-800 border border-transparent"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-16 h-16 rounded-lg bg-slate-700 overflow-hidden flex-shrink-0">
                        {item.thumbnail_url ? (
                          <img src={item.thumbnail_url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Play className="w-6 h-6 text-slate-500" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={cn(
                            "text-xs",
                            item.content_type === 'reel' 
                              ? "bg-fuchsia-500/10 text-fuchsia-400" 
                              : "bg-cyan-500/10 text-cyan-400"
                          )}>
                            {item.content_type}
                          </Badge>
                          <PlatformIcon platform={item.platform} size="xs" />
                        </div>
                        <p className="text-sm text-white truncate">{item.title || 'Untitled'}</p>
                        <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3" />
                            {item.views?.toLocaleString() || 0}
                          </span>
                          <span className="flex items-center gap-1">
                            <Play className="w-3 h-3" />
                            {item.completion_rate || 0}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Detail View */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
          {selectedItem ? (
            <div className="p-6 space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-xl bg-slate-700 overflow-hidden">
                    {selectedItem.thumbnail_url ? (
                      <img src={selectedItem.thumbnail_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Play className="w-8 h-8 text-slate-500" />
                      </div>
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white">{selectedItem.title || 'Untitled'}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <PlatformIcon platform={selectedItem.platform} size="sm" showLabel />
                      <span className="text-sm text-slate-500">•</span>
                      <span className="text-sm text-slate-400">
                        {selectedItem.posted_at && format(new Date(selectedItem.posted_at), 'MMM d, yyyy')}
                      </span>
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSelectedItem(null)}
                  className="text-slate-400"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-4 gap-3">
                <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                  <Eye className="w-4 h-4 mx-auto text-violet-400 mb-1" />
                  <p className="text-lg font-bold text-white">{selectedItem.views?.toLocaleString() || 0}</p>
                  <p className="text-xs text-slate-500">Views</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                  <Play className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
                  <p className="text-lg font-bold text-white">{selectedItem.completion_rate || 0}%</p>
                  <p className="text-xs text-slate-500">Completion</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                  <ArrowUp className="w-4 h-4 mx-auto text-cyan-400 mb-1" />
                  <p className="text-lg font-bold text-white">{selectedItem.swipe_ups || 0}</p>
                  <p className="text-xs text-slate-500">Swipe Ups</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                  <Clock className="w-4 h-4 mx-auto text-fuchsia-400 mb-1" />
                  <p className="text-lg font-bold text-white">{selectedItem.average_watch_time || 0}s</p>
                  <p className="text-xs text-slate-500">Avg Watch</p>
                </div>
              </div>

              {/* Audience Retention Chart */}
              <div>
                <h4 className="font-medium text-white mb-4">Audience Retention</h4>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={generateRetentionData(selectedItem)}>
                    <defs>
                      <linearGradient id="colorRetention" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis 
                      dataKey="percentage_through" 
                      stroke="#64748B" 
                      fontSize={12}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <YAxis 
                      stroke="#64748B" 
                      fontSize={12}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Area 
                      type="monotone" 
                      dataKey="viewers_remaining" 
                      name="Viewers"
                      stroke="#8B5CF6" 
                      fillOpacity={1} 
                      fill="url(#colorRetention)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Engagement Metrics */}
              <div>
                <h4 className="font-medium text-white mb-4">Engagement</h4>
                <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <Heart className="w-4 h-4 mx-auto text-rose-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.likes || 0}</p>
                    <p className="text-xs text-slate-500">Likes</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <MessageCircle className="w-4 h-4 mx-auto text-blue-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.comments || 0}</p>
                    <p className="text-xs text-slate-500">Comments</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <Share2 className="w-4 h-4 mx-auto text-emerald-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.shares || 0}</p>
                    <p className="text-xs text-slate-500">Shares</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <Bookmark className="w-4 h-4 mx-auto text-amber-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.saves || 0}</p>
                    <p className="text-xs text-slate-500">Saves</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <UserPlus className="w-4 h-4 mx-auto text-violet-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.follows || 0}</p>
                    <p className="text-xs text-slate-500">Follows</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <MousePointer className="w-4 h-4 mx-auto text-cyan-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.link_clicks || 0}</p>
                    <p className="text-xs text-slate-500">Clicks</p>
                  </div>
                </div>
              </div>

              {/* Navigation Stats */}
              <div>
                <h4 className="font-medium text-white mb-4">Navigation</h4>
                <div className="grid grid-cols-4 gap-3">
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <SkipBack className="w-4 h-4 mx-auto text-slate-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.back_taps || 0}</p>
                    <p className="text-xs text-slate-500">Back Taps</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <SkipForward className="w-4 h-4 mx-auto text-slate-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.forward_taps || 0}</p>
                    <p className="text-xs text-slate-500">Forward Taps</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <X className="w-4 h-4 mx-auto text-rose-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.exited || 0}</p>
                    <p className="text-xs text-slate-500">Exited</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50 text-center">
                    <TrendingDown className="w-4 h-4 mx-auto text-amber-400 mb-1" />
                    <p className="text-sm font-medium text-white">{selectedItem.exit_rate || 0}%</p>
                    <p className="text-xs text-slate-500">Exit Rate</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-500 min-h-[500px]">
              <div className="text-center">
                <Play className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Select content to view detailed analytics</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}