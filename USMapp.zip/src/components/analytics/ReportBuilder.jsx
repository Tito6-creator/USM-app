import React, { useState } from 'react';
import {
  FileText,
  Calendar,
  Mail,
  Palette,
  Check,
  Upload,
  Clock,
  Plus,
  X,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';

const metricsOptions = [
  { id: 'followers', label: 'Followers', category: 'Audience' },
  { id: 'following', label: 'Following', category: 'Audience' },
  { id: 'reach', label: 'Reach', category: 'Reach' },
  { id: 'impressions', label: 'Impressions', category: 'Reach' },
  { id: 'engagement_rate', label: 'Engagement Rate', category: 'Engagement' },
  { id: 'likes', label: 'Likes', category: 'Engagement' },
  { id: 'comments', label: 'Comments', category: 'Engagement' },
  { id: 'shares', label: 'Shares', category: 'Engagement' },
  { id: 'saves', label: 'Saves', category: 'Engagement' },
  { id: 'clicks', label: 'Link Clicks', category: 'Conversions' },
  { id: 'conversions', label: 'Conversions', category: 'Conversions' },
  { id: 'profile_visits', label: 'Profile Visits', category: 'Conversions' },
  { id: 'story_views', label: 'Story Views', category: 'Stories & Reels' },
  { id: 'reel_plays', label: 'Reel Plays', category: 'Stories & Reels' },
  { id: 'completion_rate', label: 'Completion Rate', category: 'Stories & Reels' },
];

const sectionOptions = [
  { id: 'overview', label: 'Performance Overview', description: 'Summary of key metrics' },
  { id: 'engagement', label: 'Engagement Analysis', description: 'Detailed engagement breakdown' },
  { id: 'audience_growth', label: 'Audience Growth', description: 'Follower trends and demographics' },
  { id: 'top_posts', label: 'Top Performing Posts', description: 'Best content this period' },
  { id: 'stories_reels', label: 'Stories & Reels', description: 'Short-form content analytics' },
  { id: 'hashtag_performance', label: 'Hashtag Performance', description: 'Hashtag effectiveness' },
  { id: 'competitor_comparison', label: 'Competitor Comparison', description: 'Benchmark against competitors' },
  { id: 'recommendations', label: 'AI Recommendations', description: 'AI-powered suggestions' },
];

const platforms = ['instagram', 'facebook', 'tiktok', 'youtube', 'linkedin', 'twitter'];

export default function ReportBuilder({ onSave, initialData, isLoading }) {
  const [formData, setFormData] = useState(initialData || {
    name: '',
    description: '',
    report_type: 'performance',
    frequency: 'weekly',
    day_of_week: 'monday',
    time_of_day: '09:00',
    recipients: [''],
    platforms: [],
    metrics: ['followers', 'reach', 'engagement_rate', 'likes', 'comments'],
    date_range: 'last_7_days',
    include_sections: {
      overview: true,
      engagement: true,
      audience_growth: true,
      top_posts: true,
      stories_reels: false,
      hashtag_performance: false,
      competitor_comparison: false,
      recommendations: true,
    },
    white_label: {
      enabled: false,
      company_name: '',
      logo_url: '',
      primary_color: '#8B5CF6',
      secondary_color: '#EC4899',
      footer_text: '',
    },
    format: 'pdf',
    is_active: true,
  });

  const updateForm = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateWhiteLabel = (field, value) => {
    setFormData(prev => ({
      ...prev,
      white_label: { ...prev.white_label, [field]: value }
    }));
  };

  const updateSections = (field, value) => {
    setFormData(prev => ({
      ...prev,
      include_sections: { ...prev.include_sections, [field]: value }
    }));
  };

  const togglePlatform = (platform) => {
    setFormData(prev => ({
      ...prev,
      platforms: prev.platforms.includes(platform)
        ? prev.platforms.filter(p => p !== platform)
        : [...prev.platforms, platform]
    }));
  };

  const toggleMetric = (metric) => {
    setFormData(prev => ({
      ...prev,
      metrics: prev.metrics.includes(metric)
        ? prev.metrics.filter(m => m !== metric)
        : [...prev.metrics, metric]
    }));
  };

  const addRecipient = () => {
    setFormData(prev => ({
      ...prev,
      recipients: [...prev.recipients, '']
    }));
  };

  const updateRecipient = (index, value) => {
    setFormData(prev => ({
      ...prev,
      recipients: prev.recipients.map((r, i) => i === index ? value : r)
    }));
  };

  const removeRecipient = (index) => {
    setFormData(prev => ({
      ...prev,
      recipients: prev.recipients.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = () => {
    onSave(formData);
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="basics" className="space-y-6">
        <TabsList className="bg-slate-800/50 w-full grid grid-cols-4">
          <TabsTrigger value="basics" className="data-[state=active]:bg-violet-600">
            <FileText className="w-4 h-4 mr-2" />
            Basics
          </TabsTrigger>
          <TabsTrigger value="content" className="data-[state=active]:bg-violet-600">
            <Calendar className="w-4 h-4 mr-2" />
            Content
          </TabsTrigger>
          <TabsTrigger value="schedule" className="data-[state=active]:bg-violet-600">
            <Mail className="w-4 h-4 mr-2" />
            Delivery
          </TabsTrigger>
          <TabsTrigger value="branding" className="data-[state=active]:bg-violet-600">
            <Palette className="w-4 h-4 mr-2" />
            Branding
          </TabsTrigger>
        </TabsList>

        {/* Basics Tab */}
        <TabsContent value="basics" className="space-y-6">
          <div className="rounded-xl bg-slate-800/30 p-6 space-y-4">
            <div>
              <Label className="text-white">Report Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => updateForm('name', e.target.value)}
                placeholder="e.g., Weekly Performance Report"
                className="mt-2 bg-slate-800/50 border-slate-700"
              />
            </div>
            
            <div>
              <Label className="text-white">Description (Optional)</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => updateForm('description', e.target.value)}
                placeholder="Brief description of this report..."
                className="mt-2 bg-slate-800/50 border-slate-700 min-h-[80px]"
              />
            </div>

            <div>
              <Label className="text-white">Report Type</Label>
              <Select value={formData.report_type} onValueChange={(v) => updateForm('report_type', v)}>
                <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="performance">Performance Overview</SelectItem>
                  <SelectItem value="audience">Audience Insights</SelectItem>
                  <SelectItem value="content">Content Analysis</SelectItem>
                  <SelectItem value="competitor">Competitor Report</SelectItem>
                  <SelectItem value="campaign">Campaign Report</SelectItem>
                  <SelectItem value="custom">Custom Report</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white mb-3 block">Platforms</Label>
              <div className="flex flex-wrap gap-3">
                {platforms.map((platform) => (
                  <button
                    key={platform}
                    onClick={() => togglePlatform(platform)}
                    className={cn(
                      "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all",
                      formData.platforms.includes(platform)
                        ? "border-violet-500 bg-violet-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    )}
                  >
                    <PlatformIcon platform={platform} size="sm" />
                    <span className="text-sm text-white capitalize">{platform}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-white">Date Range</Label>
              <Select value={formData.date_range} onValueChange={(v) => updateForm('date_range', v)}>
                <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="last_7_days">Last 7 Days</SelectItem>
                  <SelectItem value="last_14_days">Last 14 Days</SelectItem>
                  <SelectItem value="last_30_days">Last 30 Days</SelectItem>
                  <SelectItem value="last_90_days">Last 90 Days</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white">Export Format</Label>
              <Select value={formData.format} onValueChange={(v) => updateForm('format', v)}>
                <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="pdf">PDF Document</SelectItem>
                  <SelectItem value="csv">CSV Spreadsheet</SelectItem>
                  <SelectItem value="excel">Excel Workbook</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </TabsContent>

        {/* Content Tab */}
        <TabsContent value="content" className="space-y-6">
          <div className="rounded-xl bg-slate-800/30 p-6">
            <Label className="text-white mb-4 block">Report Sections</Label>
            <div className="space-y-3">
              {sectionOptions.map((section) => (
                <div
                  key={section.id}
                  className={cn(
                    "flex items-center justify-between p-4 rounded-xl border transition-all",
                    formData.include_sections[section.id]
                      ? "border-violet-500/30 bg-violet-500/5"
                      : "border-slate-700 bg-slate-800/30"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <Checkbox
                      checked={formData.include_sections[section.id]}
                      onCheckedChange={(checked) => updateSections(section.id, checked)}
                    />
                    <div>
                      <p className="font-medium text-white">{section.label}</p>
                      <p className="text-sm text-slate-500">{section.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl bg-slate-800/30 p-6">
            <Label className="text-white mb-4 block">Metrics to Include</Label>
            <div className="space-y-4">
              {Object.entries(
                metricsOptions.reduce((acc, metric) => {
                  if (!acc[metric.category]) acc[metric.category] = [];
                  acc[metric.category].push(metric);
                  return acc;
                }, {})
              ).map(([category, metrics]) => (
                <div key={category}>
                  <p className="text-sm font-medium text-slate-400 mb-2">{category}</p>
                  <div className="flex flex-wrap gap-2">
                    {metrics.map((metric) => (
                      <button
                        key={metric.id}
                        onClick={() => toggleMetric(metric.id)}
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-sm transition-all",
                          formData.metrics.includes(metric.id)
                            ? "bg-violet-500/20 text-violet-300 border border-violet-500/30"
                            : "bg-slate-800 text-slate-400 border border-slate-700 hover:border-slate-600"
                        )}
                      >
                        {formData.metrics.includes(metric.id) && (
                          <Check className="w-3 h-3 inline mr-1" />
                        )}
                        {metric.label}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* Schedule Tab */}
        <TabsContent value="schedule" className="space-y-6">
          <div className="rounded-xl bg-slate-800/30 p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">Schedule Delivery</Label>
                <p className="text-sm text-slate-500 mt-1">Automatically send reports on schedule</p>
              </div>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => updateForm('is_active', checked)}
              />
            </div>

            {formData.is_active && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Frequency</Label>
                    <Select value={formData.frequency} onValueChange={(v) => updateForm('frequency', v)}>
                      <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-900 border-slate-800">
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="biweekly">Bi-weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {formData.frequency !== 'daily' && (
                    <div>
                      <Label className="text-white">Day</Label>
                      <Select value={formData.day_of_week} onValueChange={(v) => updateForm('day_of_week', v)}>
                        <SelectTrigger className="mt-2 bg-slate-800/50 border-slate-700">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-900 border-slate-800">
                          <SelectItem value="monday">Monday</SelectItem>
                          <SelectItem value="tuesday">Tuesday</SelectItem>
                          <SelectItem value="wednesday">Wednesday</SelectItem>
                          <SelectItem value="thursday">Thursday</SelectItem>
                          <SelectItem value="friday">Friday</SelectItem>
                          <SelectItem value="saturday">Saturday</SelectItem>
                          <SelectItem value="sunday">Sunday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-white">Time</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Clock className="w-4 h-4 text-slate-400" />
                    <Input
                      type="time"
                      value={formData.time_of_day}
                      onChange={(e) => updateForm('time_of_day', e.target.value)}
                      className="bg-slate-800/50 border-slate-700 w-32"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-white">Recipients</Label>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={addRecipient}
                  className="text-violet-400 hover:text-violet-300"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add
                </Button>
              </div>
              <div className="space-y-2">
                {formData.recipients.map((recipient, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <Input
                      type="email"
                      value={recipient}
                      onChange={(e) => updateRecipient(index, e.target.value)}
                      placeholder="email@example.com"
                      className="flex-1 bg-slate-800/50 border-slate-700"
                    />
                    {formData.recipients.length > 1 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeRecipient(index)}
                        className="text-slate-400 hover:text-rose-400"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Branding Tab */}
        <TabsContent value="branding" className="space-y-6">
          <div className="rounded-xl bg-slate-800/30 p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">White-Label Branding</Label>
                <p className="text-sm text-slate-500 mt-1">Customize reports with your branding</p>
              </div>
              <Switch
                checked={formData.white_label.enabled}
                onCheckedChange={(checked) => updateWhiteLabel('enabled', checked)}
              />
            </div>

            {formData.white_label.enabled && (
              <>
                <div>
                  <Label className="text-white">Company Name</Label>
                  <Input
                    value={formData.white_label.company_name}
                    onChange={(e) => updateWhiteLabel('company_name', e.target.value)}
                    placeholder="Your Company Name"
                    className="mt-2 bg-slate-800/50 border-slate-700"
                  />
                </div>

                <div>
                  <Label className="text-white">Logo URL</Label>
                  <Input
                    value={formData.white_label.logo_url}
                    onChange={(e) => updateWhiteLabel('logo_url', e.target.value)}
                    placeholder="https://..."
                    className="mt-2 bg-slate-800/50 border-slate-700"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Primary Color</Label>
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="color"
                        value={formData.white_label.primary_color}
                        onChange={(e) => updateWhiteLabel('primary_color', e.target.value)}
                        className="w-10 h-10 rounded border-0 cursor-pointer"
                      />
                      <Input
                        value={formData.white_label.primary_color}
                        onChange={(e) => updateWhiteLabel('primary_color', e.target.value)}
                        className="flex-1 bg-slate-800/50 border-slate-700"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-white">Secondary Color</Label>
                    <div className="flex items-center gap-2 mt-2">
                      <input
                        type="color"
                        value={formData.white_label.secondary_color}
                        onChange={(e) => updateWhiteLabel('secondary_color', e.target.value)}
                        className="w-10 h-10 rounded border-0 cursor-pointer"
                      />
                      <Input
                        value={formData.white_label.secondary_color}
                        onChange={(e) => updateWhiteLabel('secondary_color', e.target.value)}
                        className="flex-1 bg-slate-800/50 border-slate-700"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-white">Footer Text</Label>
                  <Input
                    value={formData.white_label.footer_text}
                    onChange={(e) => updateWhiteLabel('footer_text', e.target.value)}
                    placeholder="e.g., Confidential - For internal use only"
                    className="mt-2 bg-slate-800/50 border-slate-700"
                  />
                </div>

                {/* Preview */}
                <div className="mt-6 p-6 rounded-xl border border-slate-700 bg-white">
                  <div className="flex items-center justify-between mb-4">
                    {formData.white_label.logo_url ? (
                      <img src={formData.white_label.logo_url} alt="Logo" className="h-8" />
                    ) : (
                      <div className="text-lg font-bold" style={{ color: formData.white_label.primary_color }}>
                        {formData.white_label.company_name || 'Your Company'}
                      </div>
                    )}
                    <span className="text-sm text-gray-500">Report Preview</span>
                  </div>
                  <div 
                    className="h-2 rounded-full mb-4"
                    style={{ 
                      background: `linear-gradient(to right, ${formData.white_label.primary_color}, ${formData.white_label.secondary_color})` 
                    }}
                  />
                  <div className="text-gray-400 text-sm">Sample report content...</div>
                  {formData.white_label.footer_text && (
                    <div className="mt-4 pt-4 border-t text-xs text-gray-400">
                      {formData.white_label.footer_text}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-3">
        <Button
          onClick={handleSubmit}
          disabled={!formData.name || formData.recipients.every(r => !r) || isLoading}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Check className="w-4 h-4 mr-2" />
              Save Report
            </>
          )}
        </Button>
      </div>
    </div>
  );
}