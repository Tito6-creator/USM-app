import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend
} from 'recharts';
import { TrendingUp, Users, Heart, Target } from 'lucide-react';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';

export default function CompetitorComparison() {
  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors'],
    queryFn: () => base44.entities.Competitor.list('-followers_count'),
  });

  // Combine your accounts and competitors for comparison
  const myAvgFollowers = accounts.reduce((sum, acc) => sum + (acc.followers_count || 0), 0) / (accounts.length || 1);
  const myAvgEngagement = accounts.reduce((sum, acc) => sum + (acc.engagement_rate || 0), 0) / (accounts.length || 1);
  const myAvgPosts = accounts.reduce((sum, acc) => sum + (acc.posts_count || 0), 0) / (accounts.length || 1);

  const comparisonData = [
    {
      name: 'Your Account',
      followers: Math.round(myAvgFollowers),
      engagement: parseFloat(myAvgEngagement.toFixed(2)),
      posts: Math.round(myAvgPosts),
      isYou: true
    },
    ...competitors.slice(0, 5).map(comp => ({
      name: comp.name,
      followers: comp.followers_count || 0,
      engagement: comp.engagement_rate || 0,
      posts: comp.posts_count || 0,
      isYou: false
    }))
  ];

  // Radar chart data for multi-dimensional comparison
  const radarData = [
    {
      metric: 'Followers',
      'Your Account': myAvgFollowers / 1000,
      ...Object.fromEntries(
        competitors.slice(0, 3).map(c => [c.name, (c.followers_count || 0) / 1000])
      )
    },
    {
      metric: 'Engagement Rate',
      'Your Account': myAvgEngagement * 10,
      ...Object.fromEntries(
        competitors.slice(0, 3).map(c => [c.name, (c.engagement_rate || 0) * 10])
      )
    },
    {
      metric: 'Posts Count',
      'Your Account': myAvgPosts,
      ...Object.fromEntries(
        competitors.slice(0, 3).map(c => [c.name, c.posts_count || 0])
      )
    },
    {
      metric: 'Avg Likes',
      'Your Account': accounts.reduce((sum, acc) => sum + (acc.followers_count || 0), 0) * 0.05,
      ...Object.fromEntries(
        competitors.slice(0, 3).map(c => [c.name, c.avg_likes || 0])
      )
    },
  ];

  const getPositionBadge = (index) => {
    if (index === 0) return { text: '🏆 Leading', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20' };
    if (index === 1) return { text: '2nd Place', color: 'bg-slate-500/10 text-slate-400 border-slate-500/20' };
    if (index === 2) return { text: '3rd Place', color: 'bg-orange-500/10 text-orange-400 border-orange-500/20' };
    return { text: `#${index + 1}`, color: 'bg-slate-700 text-slate-400' };
  };

  return (
    <div className="space-y-6">
      {/* Comparison Table */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-6">Competitive Positioning</h3>
        <div className="space-y-3">
          {comparisonData.map((item, index) => {
            const badge = getPositionBadge(index);
            return (
              <div 
                key={item.name}
                className={cn(
                  "p-4 rounded-xl border transition-all",
                  item.isYou 
                    ? "bg-violet-500/10 border-violet-500/30" 
                    : "bg-slate-800/50 border-slate-700 hover:border-slate-600"
                )}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Badge className={badge.color}>{badge.text}</Badge>
                    <span className="font-semibold text-white">{item.name}</span>
                    {item.isYou && (
                      <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30">
                        You
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-violet-400" />
                    <div>
                      <p className="text-xs text-slate-400">Followers</p>
                      <p className="text-sm font-semibold text-white">{item.followers.toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-rose-400" />
                    <div>
                      <p className="text-xs text-slate-400">Engagement</p>
                      <p className="text-sm font-semibold text-white">{item.engagement}%</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-cyan-400" />
                    <div>
                      <p className="text-xs text-slate-400">Posts</p>
                      <p className="text-sm font-semibold text-white">{item.posts}</p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-6">Followers Comparison</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={comparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="followers" 
                fill="#8b5cf6"
                radius={[8, 8, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-6">Engagement Rate Comparison</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={comparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
              <XAxis dataKey="name" stroke="#94a3b8" angle={-45} textAnchor="end" height={100} />
              <YAxis stroke="#94a3b8" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1e293b', 
                  border: '1px solid #334155',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="engagement" 
                fill="#ec4899"
                radius={[8, 8, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Radar Comparison */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-6">Multi-Metric Comparison</h3>
        <ResponsiveContainer width="100%" height={400}>
          <RadarChart data={radarData}>
            <PolarGrid stroke="#334155" />
            <PolarAngleAxis dataKey="metric" stroke="#94a3b8" />
            <PolarRadiusAxis stroke="#94a3b8" />
            <Radar 
              name="Your Account" 
              dataKey="Your Account" 
              stroke="#8b5cf6" 
              fill="#8b5cf6" 
              fillOpacity={0.3}
            />
            {competitors.slice(0, 3).map((comp, idx) => (
              <Radar 
                key={comp.id}
                name={comp.name} 
                dataKey={comp.name} 
                stroke={['#ec4899', '#06b6d4', '#10b981'][idx]} 
                fill={['#ec4899', '#06b6d4', '#10b981'][idx]}
                fillOpacity={0.2}
              />
            ))}
            <Legend />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px'
              }}
            />
          </RadarChart>
        </ResponsiveContainer>
      </Card>

      {/* Growth Rate Comparison */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-6">Growth Rate Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { label: 'Your Account', rate: 12.5, isYou: true },
            ...competitors.slice(0, 2).map(c => ({
              label: c.name,
              rate: c.growth_rate || 0,
              isYou: false
            }))
          ].map((item) => (
            <div 
              key={item.label}
              className={cn(
                "p-6 rounded-xl border",
                item.isYou 
                  ? "bg-violet-500/10 border-violet-500/30" 
                  : "bg-slate-800/50 border-slate-700"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-slate-400">{item.label}</span>
                {item.isYou && (
                  <Badge className="bg-violet-500/20 text-violet-300">You</Badge>
                )}
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className={cn(
                  "w-6 h-6",
                  item.rate > 0 ? "text-emerald-400" : "text-rose-400"
                )} />
                <span className="text-3xl font-bold text-white">
                  {item.rate > 0 ? '+' : ''}{item.rate}%
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-2">Monthly growth rate</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}