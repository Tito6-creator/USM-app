import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { 
  Sparkles, 
  TrendingUp, 
  Clock, 
  Hash, 
  Image, 
  Target,
  Lightbulb,
  ArrowRight,
  Loader2,
  Copy,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function AIContentOptimizer({ posts }) {
  const [insights, setInsights] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);

  const generateInsights = async () => {
    setIsGenerating(true);
    
    try {
      // Analyze post performance data
      const topPosts = [...posts]
        .filter(p => p.status === 'published')
        .sort((a, b) => {
          const aEngagement = (a.likes || 0) + (a.comments || 0) + (a.shares || 0);
          const bEngagement = (b.likes || 0) + (b.comments || 0) + (b.shares || 0);
          return bEngagement - aEngagement;
        })
        .slice(0, 10);

      const lowPosts = [...posts]
        .filter(p => p.status === 'published')
        .sort((a, b) => {
          const aEngagement = (a.likes || 0) + (a.comments || 0) + (a.shares || 0);
          const bEngagement = (b.likes || 0) + (b.comments || 0) + (b.shares || 0);
          return aEngagement - bEngagement;
        })
        .slice(0, 5);

      // Get AI insights
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze these social media post performance metrics and provide actionable optimization insights:

TOP PERFORMING POSTS:
${topPosts.map(p => `
- Content: "${p.content?.substring(0, 100)}..."
- Engagement: ${(p.likes || 0) + (p.comments || 0) + (p.shares || 0)} (Likes: ${p.likes || 0}, Comments: ${p.comments || 0}, Shares: ${p.shares || 0})
- Reach: ${p.reach || p.impressions || 0}
- Hashtags: ${p.hashtags?.join(', ') || 'none'}
- Media Type: ${p.media_type || 'text'}
`).join('\n')}

UNDERPERFORMING POSTS:
${lowPosts.map(p => `
- Content: "${p.content?.substring(0, 100)}..."
- Engagement: ${(p.likes || 0) + (p.comments || 0) + (p.shares || 0)}
- Reach: ${p.reach || p.impressions || 0}
`).join('\n')}

TOTAL POSTS ANALYZED: ${posts.length}

Provide optimization insights in the following structure:
1. Key patterns that drive high engagement
2. Content type recommendations (what formats work best)
3. Optimal posting times based on engagement patterns
4. Hashtag strategy recommendations
5. Content topic suggestions that resonate with the audience
6. 3 specific actionable recommendations to improve future posts
7. Warning signs to avoid (what makes posts underperform)
8. 5 ready-to-use content ideas based on successful patterns`,
        response_json_schema: {
          type: 'object',
          properties: {
            key_patterns: {
              type: 'array',
              items: { type: 'string' }
            },
            content_type_recommendations: {
              type: 'object',
              properties: {
                best_format: { type: 'string' },
                engagement_boost: { type: 'string' },
                why: { type: 'string' }
              }
            },
            optimal_posting_times: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  time: { type: 'string' },
                  reason: { type: 'string' }
                }
              }
            },
            hashtag_strategy: {
              type: 'object',
              properties: {
                recommended_count: { type: 'string' },
                best_performing_tags: { type: 'array', items: { type: 'string' } },
                tips: { type: 'string' }
              }
            },
            content_topics: {
              type: 'array',
              items: { type: 'string' }
            },
            action_recommendations: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' },
                  expected_impact: { type: 'string' }
                }
              }
            },
            warning_signs: {
              type: 'array',
              items: { type: 'string' }
            },
            content_ideas: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' },
                  estimated_engagement: { type: 'string' }
                }
              }
            }
          }
        }
      });

      setInsights(result);
      toast.success('AI insights generated!');
    } catch (error) {
      toast.error('Failed to generate insights');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text, index) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast.success('Copied to clipboard');
  };

  if (!insights) {
    return (
      <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 p-12 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-2">AI Content Optimization</h3>
        <p className="text-slate-400 mb-6 max-w-md mx-auto">
          Let AI analyze your post performance and provide personalized recommendations to boost engagement
        </p>
        <Button
          onClick={generateInsights}
          disabled={isGenerating || posts.length === 0}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing {posts.length} posts...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate AI Insights
            </>
          )}
        </Button>
        {posts.length === 0 && (
          <p className="text-sm text-slate-500 mt-3">No posts to analyze yet</p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">AI-Powered Insights</h3>
            <p className="text-sm text-slate-400">Based on {posts.length} posts analyzed</p>
          </div>
        </div>
        <Button
          onClick={generateInsights}
          disabled={isGenerating}
          variant="outline"
          size="sm"
          className="border-slate-700"
        >
          {isGenerating ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-2" />}
          Refresh
        </Button>
      </div>

      {/* Key Patterns */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-emerald-400" />
          <h4 className="font-semibold text-white">Success Patterns</h4>
        </div>
        <div className="space-y-2">
          {insights.key_patterns?.map((pattern, idx) => (
            <div key={idx} className="flex items-start gap-3 p-3 rounded-lg bg-slate-800/50">
              <div className="w-6 h-6 rounded-full bg-emerald-500/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-sm text-slate-300">{pattern}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Content Type Recommendations */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Image className="w-5 h-5 text-violet-400" />
          <h4 className="font-semibold text-white">Content Format Insights</h4>
        </div>
        <div className="p-4 rounded-lg bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20">
          <div className="flex items-center gap-2 mb-2">
            <Badge className="bg-violet-500/20 text-violet-300">Best Format</Badge>
            <span className="text-white font-medium">{insights.content_type_recommendations?.best_format}</span>
          </div>
          <p className="text-sm text-slate-300 mb-2">{insights.content_type_recommendations?.why}</p>
          <div className="flex items-center gap-2 text-sm">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-400 font-medium">
              {insights.content_type_recommendations?.engagement_boost}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Optimal Posting Times */}
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-cyan-400" />
            <h4 className="font-semibold text-white">Best Posting Times</h4>
          </div>
          <div className="space-y-3">
            {insights.optimal_posting_times?.map((time, idx) => (
              <div key={idx} className="p-3 rounded-lg bg-slate-800/50">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-white font-medium">{time.time}</span>
                  <Badge className="bg-cyan-500/10 text-cyan-400 border-cyan-500/20 text-xs">
                    Recommended
                  </Badge>
                </div>
                <p className="text-sm text-slate-400">{time.reason}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Hashtag Strategy */}
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Hash className="w-5 h-5 text-fuchsia-400" />
            <h4 className="font-semibold text-white">Hashtag Strategy</h4>
          </div>
          <div className="mb-3">
            <span className="text-sm text-slate-400">Recommended Count: </span>
            <span className="text-white font-medium">{insights.hashtag_strategy?.recommended_count}</span>
          </div>
          <div className="mb-3">
            <p className="text-sm text-slate-400 mb-2">Top Performing Tags:</p>
            <div className="flex flex-wrap gap-2">
              {insights.hashtag_strategy?.best_performing_tags?.map((tag) => (
                <Badge key={tag} variant="outline" className="border-fuchsia-500/30 text-fuchsia-300">
                  #{tag}
                </Badge>
              ))}
            </div>
          </div>
          <p className="text-sm text-slate-400">{insights.hashtag_strategy?.tips}</p>
        </div>
      </div>

      {/* Action Recommendations */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Target className="w-5 h-5 text-amber-400" />
          <h4 className="font-semibold text-white">Action Plan</h4>
        </div>
        <div className="space-y-3">
          {insights.action_recommendations?.map((rec, idx) => (
            <div key={idx} className="p-4 rounded-lg bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20">
              <div className="flex items-start justify-between gap-3 mb-2">
                <h5 className="text-white font-medium">{rec.title}</h5>
                <Badge className="bg-amber-500/20 text-amber-300 border-amber-500/30 text-xs whitespace-nowrap">
                  {rec.expected_impact}
                </Badge>
              </div>
              <p className="text-sm text-slate-300">{rec.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Content Topics */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Lightbulb className="w-5 h-5 text-yellow-400" />
          <h4 className="font-semibold text-white">Trending Topics for Your Audience</h4>
        </div>
        <div className="flex flex-wrap gap-2">
          {insights.content_topics?.map((topic, idx) => (
            <Badge key={idx} className="bg-yellow-500/10 text-yellow-300 border-yellow-500/20">
              {topic}
            </Badge>
          ))}
        </div>
      </div>

      {/* Content Ideas */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-violet-400" />
          <h4 className="font-semibold text-white">Ready-to-Use Content Ideas</h4>
        </div>
        <div className="space-y-3">
          {insights.content_ideas?.map((idea, idx) => (
            <div key={idx} className="p-4 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors group">
              <div className="flex items-start justify-between gap-3 mb-2">
                <h5 className="text-white font-medium">{idea.title}</h5>
                <div className="flex items-center gap-2">
                  <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20 text-xs whitespace-nowrap">
                    {idea.estimated_engagement}
                  </Badge>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="opacity-0 group-hover:opacity-100 transition-opacity h-6 px-2"
                    onClick={() => copyToClipboard(idea.description, idx)}
                  >
                    {copiedIndex === idx ? (
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </Button>
                </div>
              </div>
              <p className="text-sm text-slate-300">{idea.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Warning Signs */}
      {insights.warning_signs && insights.warning_signs.length > 0 && (
        <div className="rounded-2xl bg-rose-500/10 border border-rose-500/20 p-6">
          <div className="flex items-center gap-2 mb-4">
            <ArrowRight className="w-5 h-5 text-rose-400" />
            <h4 className="font-semibold text-white">Avoid These Mistakes</h4>
          </div>
          <div className="space-y-2">
            {insights.warning_signs.map((warning, idx) => (
              <div key={idx} className="flex items-start gap-2 text-sm text-slate-300">
                <span className="text-rose-400 font-bold">⚠</span>
                <span>{warning}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}