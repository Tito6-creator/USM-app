import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle2, Instagram } from 'lucide-react';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const INSTAGRAM_APP_ID = '620987191101633'; // Same as Facebook

export default function InstagramConnect() {
  const [fbLoaded, setFbLoaded] = useState(false);
  const queryClient = useQueryClient();

  const { data: igAccounts = [], isLoading } = useQuery({
    queryKey: ['social-accounts', 'instagram'],
    queryFn: () => base44.entities.SocialAccount.filter({ platform: 'instagram' })
  });

  useEffect(() => {
    if (window.FB) {
      setFbLoaded(true);
      return;
    }

    window.fbAsyncInit = function() {
      window.FB.init({
        appId: INSTAGRAM_APP_ID,
        cookie: true,
        xfbml: false,
        version: 'v18.0'
      });
      setFbLoaded(true);
    };

    if (!document.getElementById('facebook-jssdk')) {
      const script = document.createElement('script');
      script.id = 'facebook-jssdk';
      script.src = 'https://connect.facebook.net/en_US/sdk.js';
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);
    }
  }, []);

  const connectMutation = useMutation({
    mutationFn: async () => {
      return new Promise((resolve, reject) => {
        window.FB.login((response) => {
          if (response.authResponse) {
            resolve(response.authResponse);
          } else {
            reject(new Error('Instagram login cancelled'));
          }
        }, { scope: 'instagram_basic,instagram_content_publish,pages_show_list' });
      });
    },
    onSuccess: async (authResponse) => {
      try {
        window.FB.api('/me/accounts', async (pagesResponse) => {
          if (pagesResponse.data && pagesResponse.data.length > 0) {
            for (const page of pagesResponse.data) {
              window.FB.api(`/${page.id}?fields=instagram_business_account`, async (igData) => {
                if (igData.instagram_business_account) {
                  const igId = igData.instagram_business_account.id;
                  window.FB.api(`/${igId}?fields=username,name,profile_picture_url,followers_count,media_count`, async (accountData) => {
                    await base44.entities.SocialAccount.create({
                      platform: 'instagram',
                      account_name: accountData.name,
                      username: accountData.username,
                      profile_image: accountData.profile_picture_url,
                      followers_count: accountData.followers_count || 0,
                      posts_count: accountData.media_count || 0,
                      is_connected: true,
                      access_token: page.access_token,
                      last_synced: new Date().toISOString()
                    });
                  });
                }
              });
            }
            
            queryClient.invalidateQueries({ queryKey: ['social-accounts'] });
            toast.success('Instagram accounts connected!');
          } else {
            toast.error('No Instagram business accounts found');
          }
        });
      } catch (error) {
        toast.error('Failed to connect Instagram');
        console.error(error);
      }
    },
    onError: (error) => {
      toast.error(error.message);
    }
  });

  const syncDataMutation = useMutation({
    mutationFn: async (account) => {
      return new Promise((resolve, reject) => {
        window.FB.api(`/${account.username}?fields=username,name,followers_count,media_count`, 
          { access_token: account.access_token },
          (response) => {
            if (response.error) {
              reject(new Error(response.error.message));
            } else {
              resolve(response);
            }
          }
        );
      });
    },
    onSuccess: async (data, account) => {
      await base44.entities.SocialAccount.update(account.id, {
        followers_count: data.followers_count || account.followers_count,
        posts_count: data.media_count || account.posts_count,
        last_synced: new Date().toISOString()
      });
      queryClient.invalidateQueries({ queryKey: ['social-accounts'] });
      toast.success('Instagram data synced!');
    },
    onError: () => {
      toast.error('Failed to sync Instagram data');
    }
  });

  const disconnectMutation = useMutation({
    mutationFn: (accountId) => base44.entities.SocialAccount.delete(accountId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-accounts'] });
      toast.success('Instagram account disconnected');
    }
  });

  if (isLoading) {
    return (
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <div className="flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-violet-400" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Instagram className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Instagram</h3>
            <p className="text-sm text-slate-400">Connect Instagram business accounts</p>
          </div>
        </div>
        <Button
          onClick={() => connectMutation.mutate()}
          disabled={!fbLoaded || connectMutation.isPending}
          className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
        >
          {connectMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Instagram className="w-4 h-4 mr-2" />
          )}
          Connect Account
        </Button>
      </div>

      {igAccounts.length === 0 ? (
        <div className="text-center py-8 text-slate-400">
          <p className="text-sm">No Instagram accounts connected yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          {igAccounts.map((account) => (
            <div key={account.id} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {account.profile_image && (
                  <img src={account.profile_image} alt={account.account_name} className="w-10 h-10 rounded-full" />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-medium">{account.account_name}</p>
                    {account.is_connected && (
                      <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Connected
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-400">@{account.username}</p>
                  <p className="text-xs text-slate-500 mt-1">
                    {account.followers_count?.toLocaleString()} followers • {account.posts_count} posts
                    {account.last_synced && ` • Last synced: ${new Date(account.last_synced).toLocaleDateString()}`}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => syncDataMutation.mutate(account)}
                  disabled={syncDataMutation.isPending}
                  className="border-slate-700 text-slate-300"
                >
                  {syncDataMutation.isPending ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    'Sync'
                  )}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => disconnectMutation.mutate(account.id)}
                  className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                >
                  Disconnect
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}