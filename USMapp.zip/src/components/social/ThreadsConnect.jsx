import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { Loader2, CheckCircle2, AtSign } from 'lucide-react';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function ThreadsConnect() {
  const queryClient = useQueryClient();

  const { data: threadsAccounts = [], isLoading } = useQuery({
    queryKey: ['social-accounts', 'threads'],
    queryFn: () => base44.entities.SocialAccount.filter({ platform: 'threads' })
  });

  const connectMutation = useMutation({
    mutationFn: async () => {
      // Threads uses Instagram Graph API
      toast.info('Threads connection uses Instagram - connect Instagram first');
    },
    onError: (error) => {
      toast.error('Failed to connect Threads');
    }
  });

  const disconnectMutation = useMutation({
    mutationFn: (accountId) => base44.entities.SocialAccount.delete(accountId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['social-accounts'] });
      toast.success('Threads account disconnected');
    }
  });

  if (isLoading) {
    return (
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <div className="flex items-center justify-center">
          <Loader2 className="w-6 h-6 animate-spin text-violet-400" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-black flex items-center justify-center">
            <AtSign className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white font-semibold">Threads</h3>
            <p className="text-sm text-slate-400">Connect your Threads account</p>
          </div>
        </div>
        <Button
          onClick={() => connectMutation.mutate()}
          disabled={connectMutation.isPending}
          className="bg-black hover:bg-gray-900"
        >
          {connectMutation.isPending ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <AtSign className="w-4 h-4 mr-2" />
          )}
          Connect Account
        </Button>
      </div>

      {threadsAccounts.length === 0 ? (
        <div className="text-center py-8 text-slate-400">
          <p className="text-sm">No Threads accounts connected yet</p>
          <p className="text-xs text-slate-500 mt-2">Connect your Instagram account to enable Threads</p>
        </div>
      ) : (
        <div className="space-y-3">
          {threadsAccounts.map((account) => (
            <div key={account.id} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700 flex items-center justify-between">
              <div className="flex items-center gap-3">
                {account.profile_image && (
                  <img src={account.profile_image} alt={account.account_name} className="w-10 h-10 rounded-full" />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-medium">{account.account_name}</p>
                    {account.is_connected && (
                      <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Connected
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-400">@{account.username}</p>
                </div>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => disconnectMutation.mutate(account.id)}
                className="border-red-500/20 text-red-400 hover:bg-red-500/10"
              >
                Disconnect
              </Button>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}