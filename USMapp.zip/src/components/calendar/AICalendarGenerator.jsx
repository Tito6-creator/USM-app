import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Calendar, Loader2, Sparkles, Plus, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

export default function AICalendarGenerator({ onPostsGenerated }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [config, setConfig] = useState({
    duration_days: 7,
    posts_per_day: 2,
    focus_areas: ''
  });
  const [generatedPosts, setGeneratedPosts] = useState([]);

  const generateCalendar = async () => {
    setIsGenerating(true);
    toast.info('🤖 AI is creating your calendar...');
    
    try {
      const [posts, trends] = await Promise.all([
        base44.entities.Post.filter({ status: 'published' }, '-published_time', 50),
        base44.integrations.Core.InvokeLLM({
          prompt: 'What are the top 5 social media trends right now? Provide brief list.',
          add_context_from_internet: true
        })
      ]);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate a ${config.duration_days}-day content calendar with ${config.posts_per_day} posts per day.

Focus Areas: ${config.focus_areas || 'General social media marketing'}

Recent Performance:
${posts.slice(0, 10).map(p => 
  `- ${p.content?.substring(0, 60)}... | Engagement: ${(p.likes || 0) + (p.comments || 0)}`
).join('\n')}

Current Trends:
${trends}

Generate posts that:
1. Align with successful past content patterns
2. Incorporate trending topics
3. Mix content types (educational, promotional, engagement-focused)
4. Include optimal posting times
5. Suggest platforms for each post

Provide complete post details including title, content preview, hashtags, media suggestions, and reasoning.

Format as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            calendar_summary: { type: 'string' },
            daily_schedule: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  date: { type: 'string' },
                  posts: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string' },
                        content_preview: { type: 'string' },
                        content_type: { type: 'string' },
                        platforms: { type: 'array', items: { type: 'string' } },
                        hashtags: { type: 'array', items: { type: 'string' } },
                        media_suggestion: { type: 'string' },
                        posting_time: { type: 'string' },
                        reasoning: { type: 'string' }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      });

      if (result && result.daily_schedule) {
        setGeneratedPosts(result.daily_schedule);
        toast.success('✅ Content calendar generated!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Calendar generation error:', error);
      toast.error('❌ Failed to generate calendar: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const createPost = async (post, date) => {
    toast.info('Creating post...');
    try {
      await base44.entities.Post.create({
        title: post.title,
        content: post.content_preview,
        platforms: post.platforms,
        hashtags: post.hashtags,
        media_type: post.content_type === 'video' ? 'video' : 'image',
        status: 'draft',
        ai_generated: true
      });
      toast.success('✅ Post created as draft!');
    } catch (error) {
      console.error('Post creation error:', error);
      toast.error('❌ Failed to create post: ' + error.message);
    }
  };

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-blue-400" />
        <h3 className="text-white font-semibold">AI Calendar Generator</h3>
      </div>

      <div className="space-y-4 mb-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-slate-300 text-xs">Duration (days)</Label>
            <Input
              type="number"
              value={config.duration_days}
              onChange={(e) => setConfig({ ...config, duration_days: parseInt(e.target.value) })}
              className="bg-slate-800 border-slate-700 text-white mt-1"
            />
          </div>
          <div>
            <Label className="text-slate-300 text-xs">Posts per day</Label>
            <Input
              type="number"
              value={config.posts_per_day}
              onChange={(e) => setConfig({ ...config, posts_per_day: parseInt(e.target.value) })}
              className="bg-slate-800 border-slate-700 text-white mt-1"
            />
          </div>
        </div>
        <div>
          <Label className="text-slate-300 text-xs">Focus Areas (optional)</Label>
          <Input
            value={config.focus_areas}
            onChange={(e) => setConfig({ ...config, focus_areas: e.target.value })}
            placeholder="e.g., product launches, tutorials, customer stories"
            className="bg-slate-800 border-slate-700 text-white mt-1"
          />
        </div>
      </div>

      <Button
        onClick={generateCalendar}
        disabled={isGenerating}
        className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 mb-4"
      >
        {isGenerating ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Sparkles className="w-4 h-4 mr-2" />
        )}
        Generate Calendar
      </Button>

      {generatedPosts.length > 0 && (
        <ScrollArea className="h-[500px]">
          <div className="space-y-4 pr-4">
            {generatedPosts.map((day, dayIdx) => (
              <div key={dayIdx} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                <h4 className="text-white font-semibold mb-3">{day.date}</h4>
                <div className="space-y-3">
                  {day.posts?.map((post, postIdx) => (
                    <div key={postIdx} className="p-3 bg-slate-900/50 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h5 className="text-white font-medium text-sm">{post.title}</h5>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => createPost(post, day.date)}
                          className="text-green-400 hover:text-green-300 h-7"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      <p className="text-xs text-slate-300 mb-2">{post.content_preview}</p>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {post.platforms?.map((platform, pIdx) => (
                          <Badge key={pIdx} variant="outline" className="text-xs border-slate-600">
                            {platform}
                          </Badge>
                        ))}
                        <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 text-xs">
                          {post.posting_time}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-1 mb-2">
                        {post.hashtags?.slice(0, 3).map((tag, tIdx) => (
                          <span key={tIdx} className="text-xs text-violet-400">#{tag}</span>
                        ))}
                      </div>
                      <p className="text-xs text-slate-500">{post.reasoning}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      )}
    </Card>
  );
}