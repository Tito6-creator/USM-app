import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Clock, Loader2, TrendingUp, Calendar as CalendarIcon, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function AIScheduleOptimizer({ platforms, onScheduleApply }) {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [schedule, setSchedule] = useState(null);

  const optimizeSchedule = async () => {
    setIsOptimizing(true);
    try {
      const posts = await base44.entities.Post.filter({ status: 'published' }, '-published_time', 100);

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze engagement patterns and suggest optimal posting schedule:

Historical Performance:
${posts.slice(0, 20).map(p => {
  const date = new Date(p.published_time);
  return `${date.toLocaleDateString()} ${date.getHours()}:00 - Engagement: ${(p.likes || 0) + (p.comments || 0) + (p.shares || 0)} - Platforms: ${p.platforms?.join(', ')}`;
}).join('\n')}

Analyze:
1. Best days of week for each platform
2. Optimal times (hour) for maximum engagement
3. Posting frequency recommendations
4. Platform-specific patterns

Provide weekly schedule with:
- Day-by-day posting times
- Platform recommendations per slot
- Expected engagement boost
- Content type suggestions

Format as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            weekly_schedule: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  day: { type: 'string' },
                  slots: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        time: { type: 'string' },
                        platforms: { type: 'array', items: { type: 'string' } },
                        content_type: { type: 'string' },
                        engagement_score: { type: 'number' },
                        reasoning: { type: 'string' }
                      }
                    }
                  }
                }
              }
            },
            frequency_recommendation: { type: 'string' },
            best_overall_times: { type: 'array', items: { type: 'string' } },
            expected_improvement: { type: 'string' }
          }
        }
      });

      setSchedule(result);
      toast.success('Optimal schedule generated!');
    } catch (error) {
      toast.error('Failed to optimize schedule');
      console.error(error);
    } finally {
      setIsOptimizing(false);
    }
  };

  const applySchedule = (slot) => {
    if (onScheduleApply) {
      onScheduleApply(slot);
    }
  };

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-violet-400" />
          <h3 className="text-white font-semibold">AI Schedule Optimizer</h3>
        </div>
        <Button
          onClick={optimizeSchedule}
          disabled={isOptimizing}
          size="sm"
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          {isOptimizing ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Sparkles className="w-4 h-4 mr-2" />
          )}
          Optimize
        </Button>
      </div>

      {schedule && (
        <div className="space-y-4">
          <div className="p-4 bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 rounded-lg">
            <p className="text-sm text-slate-300 mb-2">{schedule.summary}</p>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-400">{schedule.expected_improvement}</span>
            </div>
          </div>

          <div>
            <p className="text-xs text-slate-400 mb-2">Recommended Frequency</p>
            <p className="text-sm text-slate-300">{schedule.frequency_recommendation}</p>
          </div>

          <div>
            <p className="text-xs text-slate-400 mb-2">Best Overall Times</p>
            <div className="flex flex-wrap gap-2">
              {schedule.best_overall_times?.map((time, idx) => (
                <Badge key={idx} className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                  {time}
                </Badge>
              ))}
            </div>
          </div>

          <ScrollArea className="h-[400px]">
            <div className="space-y-3 pr-4">
              {schedule.weekly_schedule?.map((day, idx) => (
                <div key={idx} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <CalendarIcon className="w-4 h-4 text-violet-400" />
                    {day.day}
                  </h4>
                  <div className="space-y-2">
                    {day.slots?.map((slot, sIdx) => (
                      <div key={sIdx} className="p-3 bg-slate-900/50 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4 text-slate-400" />
                            <span className="text-white font-medium">{slot.time}</span>
                            <Badge className={cn(
                              "text-xs",
                              slot.engagement_score >= 80 ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" :
                              slot.engagement_score >= 60 ? "bg-blue-500/10 text-blue-400 border-blue-500/20" :
                              "bg-amber-500/10 text-amber-400 border-amber-500/20"
                            )}>
                              {slot.engagement_score} score
                            </Badge>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => applySchedule(slot)}
                            className="text-violet-400 hover:text-violet-300 h-7"
                          >
                            Apply
                          </Button>
                        </div>
                        <div className="flex flex-wrap gap-1 mb-2">
                          {slot.platforms?.map((platform, pIdx) => (
                            <Badge key={pIdx} variant="outline" className="text-xs border-slate-600">
                              {platform}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs text-slate-400 mb-1">
                          Content: {slot.content_type}
                        </p>
                        <p className="text-xs text-slate-500">{slot.reasoning}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}
    </Card>
  );
}