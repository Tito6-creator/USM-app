import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Calendar, Clock, Hash } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addDays } from 'date-fns';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';

const categoryColors = {
  promotional: 'bg-violet-500/20 border-violet-500/40 text-violet-300',
  educational: 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300',
  engagement: 'bg-fuchsia-500/20 border-fuchsia-500/40 text-fuchsia-300',
  announcement: 'bg-amber-500/20 border-amber-500/40 text-amber-300',
  seasonal: 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300',
  evergreen: 'bg-slate-500/20 border-slate-500/40 text-slate-300'
};

export default function DragDropCalendar({ posts, currentDate, onDateSelect, view = 'month' }) {
  const queryClient = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Post.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast.success('Post rescheduled!');
    },
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const postId = result.draggableId;
    const newDate = result.destination.droppableId;
    const post = posts.find(p => p.id === postId);

    if (post && newDate !== 'unscheduled') {
      const [year, month, day] = newDate.split('-');
      const scheduledDate = new Date(post.scheduled_time || new Date());
      scheduledDate.setFullYear(parseInt(year));
      scheduledDate.setMonth(parseInt(month) - 1);
      scheduledDate.setDate(parseInt(day));

      updateMutation.mutate({
        id: postId,
        data: { scheduled_time: scheduledDate.toISOString() }
      });
    }
  };

  const getDaysInMonth = () => {
    const start = startOfMonth(currentDate);
    const end = endOfMonth(currentDate);
    return eachDayOfInterval({ start, end });
  };

  const getPostsForDay = (day) => {
    return posts.filter(post => 
      post.scheduled_time && isSameDay(new Date(post.scheduled_time), day)
    );
  };

  const days = getDaysInMonth();

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="grid grid-cols-7 gap-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-sm font-semibold text-slate-400 pb-2">
            {day}
          </div>
        ))}
        
        {days.map((day, idx) => {
          const dayPosts = getPostsForDay(day);
          const dateKey = format(day, 'yyyy-MM-dd');
          const isToday = isSameDay(day, new Date());
          
          return (
            <Droppable key={dateKey} droppableId={dateKey}>
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                  onClick={() => onDateSelect(day)}
                  className={cn(
                    "min-h-[120px] p-2 rounded-xl border transition-all cursor-pointer",
                    snapshot.isDraggingOver 
                      ? "bg-violet-500/20 border-violet-500" 
                      : "bg-slate-900/50 border-slate-800 hover:border-slate-700",
                    isToday && "ring-2 ring-violet-500"
                  )}
                >
                  <div className="text-right mb-2">
                    <span className={cn(
                      "text-sm font-medium",
                      isToday ? "text-violet-400" : "text-slate-300"
                    )}>
                      {format(day, 'd')}
                    </span>
                  </div>
                  
                  <div className="space-y-1">
                    {dayPosts.slice(0, 3).map((post, postIdx) => (
                      <Draggable key={post.id} draggableId={post.id} index={postIdx}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={cn(
                              "p-2 rounded-lg border text-xs",
                              categoryColors[post.category] || categoryColors.evergreen,
                              snapshot.isDragging && "opacity-50 rotate-2"
                            )}
                          >
                            <div className="flex items-center gap-1 mb-1">
                              {post.platforms?.slice(0, 2).map(platform => (
                                <PlatformIcon key={platform} platform={platform} size="xs" />
                              ))}
                            </div>
                            <p className="line-clamp-1 text-white">{post.content}</p>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {dayPosts.length > 3 && (
                      <div className="text-xs text-slate-500 text-center">
                        +{dayPosts.length - 3} more
                      </div>
                    )}
                  </div>
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          );
        })}
      </div>
    </DragDropContext>
  );
}