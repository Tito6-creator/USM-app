import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Ticket,
  Clock,
  CheckCircle,
  AlertCircle,
  User,
  MessageSquare,
  Filter
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { toast } from 'sonner';

const statusColors = {
  open: 'bg-blue-500/10 text-blue-400',
  in_progress: 'bg-amber-500/10 text-amber-400',
  waiting: 'bg-violet-500/10 text-violet-400',
  resolved: 'bg-emerald-500/10 text-emerald-400',
  closed: 'bg-slate-500/10 text-slate-400'
};

const priorityColors = {
  low: 'bg-slate-500/10 text-slate-400',
  medium: 'bg-cyan-500/10 text-cyan-400',
  high: 'bg-amber-500/10 text-amber-400',
  urgent: 'bg-rose-500/10 text-rose-400'
};

export default function SupportTicketSystem() {
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const [replyText, setReplyText] = useState('');
  const queryClient = useQueryClient();

  const { data: tickets = [] } = useQuery({
    queryKey: ['supportTickets', filterStatus],
    queryFn: () => {
      if (filterStatus === 'all') {
        return base44.entities.SupportTicket.list('-created_date', 100);
      }
      return base44.entities.SupportTicket.filter({ status: filterStatus }, '-created_date', 100);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SupportTicket.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['supportTickets'] });
      toast.success('Ticket updated!');
    },
  });

  const handleReply = async () => {
    if (!selectedTicket || !replyText) return;

    const updatedHistory = [
      ...(selectedTicket.conversation_history || []),
      {
        timestamp: new Date().toISOString(),
        from: 'support',
        message: replyText
      }
    ];

    updateMutation.mutate({
      id: selectedTicket.id,
      data: {
        conversation_history: updatedHistory,
        status: 'in_progress'
      }
    });

    setReplyText('');
  };

  const stats = {
    open: tickets.filter(t => t.status === 'open').length,
    in_progress: tickets.filter(t => t.status === 'in_progress').length,
    resolved: tickets.filter(t => t.status === 'resolved').length,
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-xl bg-slate-900/50 border border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Open Tickets</p>
              <p className="text-2xl font-bold text-white mt-1">{stats.open}</p>
            </div>
            <AlertCircle className="w-8 h-8 text-blue-400" />
          </div>
        </div>

        <div className="rounded-xl bg-slate-900/50 border border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">In Progress</p>
              <p className="text-2xl font-bold text-white mt-1">{stats.in_progress}</p>
            </div>
            <Clock className="w-8 h-8 text-amber-400" />
          </div>
        </div>

        <div className="rounded-xl bg-slate-900/50 border border-slate-800 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Resolved</p>
              <p className="text-2xl font-bold text-white mt-1">{stats.resolved}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-emerald-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="flex gap-2 mb-4">
            {['all', 'open', 'in_progress', 'resolved'].map(status => (
              <Button
                key={status}
                size="sm"
                variant={filterStatus === status ? 'default' : 'outline'}
                onClick={() => setFilterStatus(status)}
                className={cn(
                  filterStatus === status && "bg-violet-600"
                )}
              >
                {status.replace('_', ' ')}
              </Button>
            ))}
          </div>

          <ScrollArea className="h-[600px]">
            <div className="space-y-2">
              {tickets.map(ticket => (
                <button
                  key={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className={cn(
                    "w-full p-4 rounded-xl border text-left transition-all",
                    selectedTicket?.id === ticket.id
                      ? "bg-violet-500/20 border-violet-500"
                      : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                  )}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xs text-slate-500">#{ticket.ticket_number || ticket.id.slice(0, 8)}</span>
                    <div className="flex gap-1">
                      <Badge className={statusColors[ticket.status]}>
                        {ticket.status}
                      </Badge>
                      <Badge className={priorityColors[ticket.priority]}>
                        {ticket.priority}
                      </Badge>
                    </div>
                  </div>
                  <h4 className="font-semibold text-white mb-1">{ticket.subject}</h4>
                  <p className="text-sm text-slate-400 line-clamp-2">{ticket.description}</p>
                  <div className="flex items-center gap-2 mt-2 text-xs text-slate-500">
                    <User className="w-3 h-3" />
                    {ticket.customer_name || ticket.customer_email}
                  </div>
                </button>
              ))}
            </div>
          </ScrollArea>
        </div>

        <div className="lg:col-span-2">
          {selectedTicket ? (
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800 overflow-hidden">
              <div className="p-6 border-b border-slate-800">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedTicket.subject}</h3>
                    <p className="text-sm text-slate-400 mt-1">
                      {selectedTicket.customer_name} • {selectedTicket.customer_email}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    {['open', 'in_progress', 'resolved', 'closed'].map(status => (
                      <Button
                        key={status}
                        size="sm"
                        variant="outline"
                        onClick={() => updateMutation.mutate({
                          id: selectedTicket.id,
                          data: { status }
                        })}
                        className={cn(
                          selectedTicket.status === status && "bg-violet-600"
                        )}
                      >
                        {status}
                      </Button>
                    ))}
                  </div>
                </div>
                <p className="text-slate-300">{selectedTicket.description}</p>
              </div>

              <ScrollArea className="h-[400px] p-6">
                <div className="space-y-4">
                  {selectedTicket.conversation_history?.map((msg, idx) => (
                    <div
                      key={idx}
                      className={cn(
                        "flex gap-3",
                        msg.from === 'support' ? "justify-end" : "justify-start"
                      )}
                    >
                      <div className={cn(
                        "max-w-[80%] rounded-2xl px-4 py-2",
                        msg.from === 'support'
                          ? "bg-violet-600 text-white"
                          : "bg-slate-800 text-slate-100"
                      )}>
                        <p className="text-sm">{msg.message}</p>
                        <p className="text-xs opacity-70 mt-1">
                          {format(new Date(msg.timestamp), 'MMM d, h:mm a')}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              <div className="p-6 border-t border-slate-800">
                <div className="flex gap-2">
                  <Textarea
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply..."
                    className="bg-slate-800 border-slate-700 text-white"
                  />
                  <Button
                    onClick={handleReply}
                    disabled={!replyText}
                    className="bg-violet-600 hover:bg-violet-700"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800 p-12 text-center">
              <Ticket className="w-12 h-12 mx-auto text-slate-600 mb-3" />
              <p className="text-slate-400">Select a ticket to view details</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}