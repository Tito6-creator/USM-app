import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, RefreshCw, ThumbsUp, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function AIResponseSuggestions({ message, onSelectSuggestion }) {
  const [suggestions, setSuggestions] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState(null);

  const generateSuggestions = async () => {
    setIsGenerating(true);

    const prompt = `Analyze this social media message and generate 3 response suggestions:

Message from: ${message.sender_name}
Platform: ${message.platform}
Message Type: ${message.message_type}
Sentiment: ${message.sentiment || 'neutral'}
Content: "${message.content}"

Generate 3 different response options:
1. Professional & Formal - for business inquiries
2. Friendly & Conversational - for casual engagement
3. Concise & Direct - for quick replies

Each response should:
- Address the message appropriately
- Match the tone described
- Be ready to send (no placeholders)
- Be under 280 characters
- Include emojis where appropriate

Also provide:
- Detected intent (question, complaint, praise, inquiry, general)
- Recommended action (reply, escalate, archive, follow_up)
- Priority level (low, medium, high)
- Key topics mentioned`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          intent: { type: 'string' },
          recommended_action: { type: 'string' },
          priority: { type: 'string' },
          key_topics: { type: 'array', items: { type: 'string' } },
          suggestions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                tone: { type: 'string' },
                response: { type: 'string' },
                reasoning: { type: 'string' }
              }
            }
          }
        }
      }
    });

    setSuggestions(result);
    setIsGenerating(false);
  };

  const copySuggestion = (text, index) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast.success('Response copied!');
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const priorityColors = {
    low: 'bg-slate-500/10 text-slate-400',
    medium: 'bg-amber-500/10 text-amber-400',
    high: 'bg-rose-500/10 text-rose-400'
  };

  if (!suggestions && !isGenerating) {
    return (
      <div className="p-4 rounded-xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="text-white font-medium">AI Response Suggestions</p>
              <p className="text-sm text-slate-400">Get smart reply recommendations</p>
            </div>
          </div>
          <Button
            onClick={generateSuggestions}
            size="sm"
            className="bg-violet-600 hover:bg-violet-700"
          >
            Generate
          </Button>
        </div>
      </div>
    );
  }

  if (isGenerating) {
    return (
      <div className="p-6 rounded-xl bg-slate-800/50 border border-slate-700">
        <div className="flex items-center justify-center gap-3 text-violet-400">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span>Analyzing message and generating responses...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Context Info */}
      <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
        <div className="flex items-center justify-between mb-3">
          <h4 className="font-medium text-white">Message Analysis</h4>
          <Button
            variant="ghost"
            size="sm"
            onClick={generateSuggestions}
            className="text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <span className="text-slate-400">Intent:</span>
            <p className="text-white capitalize">{suggestions.intent}</p>
          </div>
          <div>
            <span className="text-slate-400">Priority:</span>
            <Badge className={cn("mt-1", priorityColors[suggestions.priority])}>
              {suggestions.priority}
            </Badge>
          </div>
          <div>
            <span className="text-slate-400">Recommended Action:</span>
            <p className="text-white capitalize">{suggestions.recommended_action?.replace('_', ' ')}</p>
          </div>
          <div>
            <span className="text-slate-400">Topics:</span>
            <div className="flex flex-wrap gap-1 mt-1">
              {suggestions.key_topics?.map((topic, i) => (
                <Badge key={i} variant="outline" className="border-slate-600 text-slate-300 text-xs">
                  {topic}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Response Suggestions */}
      <div className="space-y-3">
        <h4 className="font-medium text-white">Suggested Responses</h4>
        {suggestions.suggestions?.map((suggestion, index) => (
          <div
            key={index}
            className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500/50 transition-colors"
          >
            <div className="flex items-start justify-between mb-2">
              <Badge className="bg-violet-500/10 text-violet-400 text-xs">
                {suggestion.tone}
              </Badge>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copySuggestion(suggestion.response, index)}
                  className="h-7 px-2 text-slate-400 hover:text-white"
                >
                  {copiedIndex === index ? (
                    <Check className="w-3 h-3" />
                  ) : (
                    <Copy className="w-3 h-3" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onSelectSuggestion(suggestion.response)}
                  className="h-7 px-2 text-violet-400 hover:text-violet-300"
                >
                  <ThumbsUp className="w-3 h-3 mr-1" />
                  Use
                </Button>
              </div>
            </div>
            <p className="text-white mb-2">{suggestion.response}</p>
            <p className="text-xs text-slate-400">{suggestion.reasoning}</p>
          </div>
        ))}
      </div>
    </div>
  );
}