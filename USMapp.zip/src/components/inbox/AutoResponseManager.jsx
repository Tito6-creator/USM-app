import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Zap, Plus, Edit, Trash2, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

export default function AutoResponseManager() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [currentLang, setCurrentLang] = useState('en');
  const queryClient = useQueryClient();

  const { data: templates = [] } = useQuery({
    queryKey: ['messageTemplates'],
    queryFn: () => base44.entities.MessageTemplate.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MessageTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messageTemplates'] });
      toast.success('Template created!');
      setIsOpen(false);
      setEditingTemplate(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.MessageTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messageTemplates'] });
      toast.success('Template updated!');
      setIsOpen(false);
      setEditingTemplate(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MessageTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messageTemplates'] });
      toast.success('Template deleted!');
    },
  });

  const handleSave = (formData) => {
    if (editingTemplate?.id) {
      updateMutation.mutate({ id: editingTemplate.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const languages = [
    { code: 'en', name: 'English' },
    { code: 'es', name: 'Spanish' },
    { code: 'fr', name: 'French' },
    { code: 'pt', name: 'Portuguese' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white">Auto-Response Templates</h3>
          <p className="text-sm text-slate-400 mt-1">Manage automated message responses</p>
        </div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-violet-600 hover:bg-violet-700">
              <Plus className="w-4 h-4 mr-2" />
              New Template
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">
                {editingTemplate ? 'Edit Template' : 'Create Template'}
              </DialogTitle>
            </DialogHeader>
            <TemplateForm
              template={editingTemplate}
              onSave={handleSave}
              languages={languages}
            />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {templates.map((template) => (
          <div key={template.id} className="rounded-xl bg-slate-900/50 border border-slate-800 p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-semibold text-white">{template.name}</h4>
                <Badge className="mt-1 bg-violet-500/10 text-violet-400 capitalize">
                  {template.category}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    setEditingTemplate(template);
                    setIsOpen(true);
                  }}
                  className="text-slate-400 hover:text-white"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => deleteMutation.mutate(template.id)}
                  className="text-rose-400 hover:text-rose-300"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <p className="text-sm text-slate-300 line-clamp-2">{template.template_text}</p>
            <div className="flex items-center gap-2 mt-3">
              <Globe className="w-3 h-3 text-slate-500" />
              <div className="flex gap-1">
                {Object.keys(template.languages || {}).map(lang => (
                  <Badge key={lang} variant="outline" className="text-xs border-slate-700">
                    {lang.toUpperCase()}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TemplateForm({ template, onSave, languages }) {
  const [formData, setFormData] = useState(template || {
    name: '',
    category: 'greeting',
    template_text: '',
    languages: {},
    is_active: true
  });
  const [currentLang, setCurrentLang] = useState('en');

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-white">Template Name</Label>
        <Input
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="bg-slate-800 border-slate-700 text-white mt-2"
        />
      </div>

      <Tabs value={currentLang} onValueChange={setCurrentLang}>
        <TabsList className="bg-slate-800">
          {languages.map(lang => (
            <TabsTrigger key={lang.code} value={lang.code}>
              {lang.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {languages.map(lang => (
          <TabsContent key={lang.code} value={lang.code} className="space-y-4">
            <Textarea
              value={formData.languages?.[lang.code] || ''}
              onChange={(e) => setFormData({
                ...formData,
                languages: {
                  ...formData.languages,
                  [lang.code]: e.target.value
                }
              })}
              placeholder={`Template in ${lang.name}...`}
              className="bg-slate-800 border-slate-700 text-white min-h-[100px]"
            />
          </TabsContent>
        ))}
      </Tabs>

      <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
        <Label className="text-white">Active</Label>
        <Switch
          checked={formData.is_active}
          onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
        />
      </div>

      <Button
        onClick={() => onSave(formData)}
        className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
      >
        Save Template
      </Button>
    </div>
  );
}