import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Clock, TrendingUp, Zap, Loader2, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function RealTimeScheduleSuggester({ platforms, onScheduleSelect }) {
  const [suggestions, setSuggestions] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [previousSuggestions, setPreviousSuggestions] = useState([]);
  const [lastRefresh, setLastRefresh] = useState(null);

  const { data: recentPosts = [] } = useQuery({
    queryKey: ['posts', 'engagement'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 100),
    refetchInterval: autoRefresh ? 300000 : false // Refresh every 5 minutes
  });

  const analyzeLiveSchedule = async () => {
    setIsAnalyzing(true);
    toast.info('🤖 AI is analyzing best posting times...');
    
    try {
      const now = new Date();
      const currentHour = now.getHours();
      const currentDay = now.toLocaleDateString('en-US', { weekday: 'long' });

      // Group posts by hour and day for pattern analysis
      const hourlyEngagement = {};
      const dayEngagement = {};
      
      recentPosts.forEach(post => {
        if (!post.published_time) return;
        
        const postDate = new Date(post.published_time);
        const hour = postDate.getHours();
        const day = postDate.toLocaleDateString('en-US', { weekday: 'long' });
        const engagement = (post.likes || 0) + (post.comments || 0) * 2 + (post.shares || 0) * 3;
        
        if (!hourlyEngagement[hour]) hourlyEngagement[hour] = { total: 0, count: 0 };
        hourlyEngagement[hour].total += engagement;
        hourlyEngagement[hour].count += 1;
        
        if (!dayEngagement[day]) dayEngagement[day] = { total: 0, count: 0 };
        dayEngagement[day].total += engagement;
        dayEngagement[day].count += 1;
      });

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze real-time posting opportunities for ${platforms.join(', ')}:

Current Time: ${now.toLocaleString()}
Day: ${currentDay}
Hour: ${currentHour}:00

Historical Performance by Hour:
${Object.keys(hourlyEngagement).map(h => 
  `${h}:00 - Avg Engagement: ${(hourlyEngagement[h].total / hourlyEngagement[h].count).toFixed(0)} (${hourlyEngagement[h].count} posts)`
).join('\n')}

Day Performance:
${Object.keys(dayEngagement).map(d => 
  `${d} - Avg Engagement: ${(dayEngagement[d].total / dayEngagement[d].count).toFixed(0)}`
).join('\n')}

IMPORTANT: Previously suggested times to AVOID repeating:
${previousSuggestions.length > 0 ? previousSuggestions.join(', ') : 'None yet'}

Provide FRESH suggestions:
1. Should they post NOW? (yes/no with confidence score)
2. If not now, next 3 DIFFERENT optimal times TODAY (avoid previous suggestions)
3. Platform-specific recommendations
4. Expected engagement multiplier vs posting now
5. Reasoning based on patterns

CRITICAL: Do NOT repeat these times: ${previousSuggestions.join(', ')}

Format as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            post_now: {
              type: 'object',
              properties: {
                recommended: { type: 'boolean' },
                confidence: { type: 'number' },
                reasoning: { type: 'string' }
              }
            },
            next_optimal_times: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  time: { type: 'string' },
                  platforms: { type: 'array', items: { type: 'string' } },
                  engagement_score: { type: 'number' },
                  multiplier: { type: 'string' },
                  reasoning: { type: 'string' }
                }
              }
            },
            platform_insights: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  platform: { type: 'string' },
                  best_time_today: { type: 'string' },
                  current_status: { type: 'string' }
                }
              }
            }
          }
        }
      });

      // Track suggested times to avoid repetition
      const newSuggestedTimes = result.next_optimal_times?.map(slot => slot.time) || [];
      setPreviousSuggestions(prev => [...new Set([...prev, ...newSuggestedTimes])]);
      
      if (result) {
        setSuggestions(result);
        setLastRefresh(new Date());
        toast.success('✅ Live schedule updated!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Schedule analysis error:', error);
      toast.error('❌ Failed to analyze schedule: ' + error.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    if (recentPosts.length > 0) {
      analyzeLiveSchedule();
    }
  }, [recentPosts]);

  const selectTime = (timeSlot) => {
    if (onScheduleSelect) {
      onScheduleSelect(timeSlot);
    }
  };

  if (!suggestions) {
    return (
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-violet-400" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="flex items-center justify-between mb-4">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-emerald-400" />
            <h3 className="text-white font-semibold">Real-Time Schedule</h3>
          </div>
          {lastRefresh && (
            <span className="text-xs text-slate-500">
              Updated {Math.floor((Date.now() - lastRefresh.getTime()) / 1000)}s ago
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setPreviousSuggestions([]);
              toast.success('Suggestion history cleared');
            }}
            className="text-xs text-slate-400"
          >
            Clear History
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={analyzeLiveSchedule}
            disabled={isAnalyzing}
          >
            <RefreshCw className={cn("w-4 h-4", isAnalyzing && "animate-spin")} />
          </Button>
        </div>
      </div>

      {/* Post Now Recommendation */}
      <div className={cn(
        "p-4 rounded-lg border mb-4",
        suggestions.post_now.recommended
          ? "bg-emerald-500/10 border-emerald-500/30"
          : "bg-amber-500/10 border-amber-500/30"
      )}>
        <div className="flex items-start justify-between mb-2">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Zap className={cn(
                "w-5 h-5",
                suggestions.post_now.recommended ? "text-emerald-400" : "text-amber-400"
              )} />
              <span className="text-white font-semibold">
                {suggestions.post_now.recommended ? 'Post Now - Good Time!' : 'Wait for Better Time'}
              </span>
            </div>
            <p className="text-sm text-slate-300">{suggestions.post_now.reasoning}</p>
          </div>
          <Badge className={cn(
            suggestions.post_now.recommended
              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
              : "bg-amber-500/20 text-amber-400 border-amber-500/30"
          )}>
            {suggestions.post_now.confidence}% confidence
          </Badge>
        </div>
        {suggestions.post_now.recommended && (
          <Button
            onClick={() => selectTime({ time: 'now', immediate: true })}
            className="w-full bg-emerald-600 hover:bg-emerald-700 mt-3"
          >
            <Zap className="w-4 h-4 mr-2" />
            Schedule for Now
          </Button>
        )}
      </div>

      {/* Optimal Times Today */}
      <div className="space-y-3">
        <h4 className="text-sm font-semibold text-slate-400">Optimal Times Today</h4>
        {suggestions.next_optimal_times?.map((slot, idx) => (
          <div
            key={idx}
            className="p-3 bg-slate-800/50 rounded-lg border border-slate-700 hover:border-violet-500/50 transition-all cursor-pointer"
            onClick={() => selectTime(slot)}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-violet-400" />
                <span className="text-white font-medium">{slot.time}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20 text-xs">
                  {slot.engagement_score}/100
                </Badge>
                <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                  {slot.multiplier}
                </Badge>
              </div>
            </div>
            <div className="flex flex-wrap gap-1 mb-2">
              {slot.platforms?.map((platform, pIdx) => (
                <Badge key={pIdx} variant="outline" className="text-xs border-slate-600">
                  {platform}
                </Badge>
              ))}
            </div>
            <p className="text-xs text-slate-400">{slot.reasoning}</p>
          </div>
        ))}
      </div>

      {/* Platform Insights */}
      {suggestions.platform_insights?.length > 0 && (
        <div className="mt-4 pt-4 border-t border-slate-800">
          <h4 className="text-sm font-semibold text-slate-400 mb-3">Platform Status</h4>
          <div className="grid grid-cols-2 gap-2">
            {suggestions.platform_insights.map((insight, idx) => (
              <div key={idx} className="p-2 bg-slate-800/50 rounded text-xs">
                <p className="text-white font-medium capitalize">{insight.platform}</p>
                <p className="text-slate-400">{insight.best_time_today}</p>
                <p className="text-emerald-400 text-[10px] mt-1">{insight.current_status}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Auto-refresh toggle */}
      <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
        <span className="text-xs text-slate-400">Auto-refresh every 5 min</span>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => setAutoRefresh(!autoRefresh)}
          className={cn(
            "text-xs",
            autoRefresh ? "text-emerald-400" : "text-slate-400"
          )}
        >
          {autoRefresh ? 'ON' : 'OFF'}
        </Button>
      </div>
    </Card>
  );
}