import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import {
  TrendingUp,
  Users,
  DollarSign,
  Target,
  Calendar,
  BarChart3
} from 'lucide-react';

export default function CampaignDetails({ campaign }) {
  const roiColor = campaign.roi > 100 ? 'text-emerald-400' : campaign.roi > 0 ? 'text-amber-400' : 'text-slate-400';
  const budgetUsed = campaign.spent || 0;
  const budgetPercentage = campaign.budget > 0 ? (budgetUsed / campaign.budget) * 100 : 0;

  return (
    <div className="space-y-6 pt-4">
      {/* Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-violet-400" />
            <p className="text-xs text-slate-400">Budget</p>
          </div>
          <p className="text-2xl font-bold text-white">${campaign.budget?.toLocaleString()}</p>
          <div className="mt-2">
            <Progress value={budgetPercentage} className="h-1" />
            <p className="text-xs text-slate-500 mt-1">${budgetUsed.toLocaleString()} spent</p>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <p className="text-xs text-slate-400">Revenue</p>
          </div>
          <p className="text-2xl font-bold text-white">${campaign.revenue?.toLocaleString() || 0}</p>
          <p className={cn("text-sm mt-1", roiColor)}>ROI: {campaign.roi || 0}%</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-4 h-4 text-cyan-400" />
            <p className="text-xs text-slate-400">Total Reach</p>
          </div>
          <p className="text-2xl font-bold text-white">{campaign.total_reach?.toLocaleString() || 0}</p>
          <p className="text-sm text-slate-400 mt-1">{campaign.total_engagement?.toLocaleString() || 0} engagements</p>
        </div>

        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <BarChart3 className="w-4 h-4 text-rose-400" />
            <p className="text-xs text-slate-400">Posts</p>
          </div>
          <p className="text-2xl font-bold text-white">{campaign.total_posts || 0}</p>
          <p className="text-sm text-slate-400 mt-1">{campaign.clicks || 0} clicks</p>
        </div>
      </div>

      {/* Description */}
      {campaign.description && (
        <div className="p-4 rounded-xl bg-slate-800/50">
          <h3 className="text-sm font-medium text-slate-400 mb-2">Description</h3>
          <p className="text-white">{campaign.description}</p>
        </div>
      )}

      {/* Details */}
      <div className="grid grid-cols-2 gap-4">
        {campaign.target_audience && (
          <div className="p-4 rounded-xl bg-slate-800/50">
            <h3 className="text-sm font-medium text-slate-400 mb-2 flex items-center gap-2">
              <Target className="w-4 h-4" />
              Target Audience
            </h3>
            <p className="text-sm text-white">{campaign.target_audience}</p>
          </div>
        )}

        {campaign.goals && (
          <div className="p-4 rounded-xl bg-slate-800/50">
            <h3 className="text-sm font-medium text-slate-400 mb-2">Goals</h3>
            <p className="text-sm text-white capitalize">{campaign.goals.replace(/_/g, ' ')}</p>
          </div>
        )}
      </div>

      {/* Platforms & Timeline */}
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-slate-800/50">
          <h3 className="text-sm font-medium text-slate-400 mb-3">Platforms</h3>
          <div className="flex flex-wrap gap-2">
            {campaign.platforms?.map((platform) => (
              <Badge key={platform} variant="outline" className="border-slate-600 text-slate-300 capitalize">
                {platform}
              </Badge>
            ))}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-800/50">
          <h3 className="text-sm font-medium text-slate-400 mb-2 flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Timeline
          </h3>
          {campaign.start_date && (
            <p className="text-sm text-white">
              {new Date(campaign.start_date).toLocaleDateString()} - {campaign.end_date ? new Date(campaign.end_date).toLocaleDateString() : 'Ongoing'}
            </p>
          )}
        </div>
      </div>

      {/* Performance Metrics */}
      <div className="p-4 rounded-xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20">
        <h3 className="text-sm font-medium text-white mb-4">Performance Summary</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-slate-400 mb-1">Conversion Rate</p>
            <p className="text-lg font-semibold text-white">
              {campaign.conversions && campaign.clicks ? ((campaign.conversions / campaign.clicks) * 100).toFixed(2) : 0}%
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-400 mb-1">Conversions</p>
            <p className="text-lg font-semibold text-white">{campaign.conversions || 0}</p>
          </div>
        </div>
      </div>
    </div>
  );
}