import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Target,
  Users,
  Sparkles,
  Calendar,
  FileText,
  ArrowRight,
  ArrowLeft,
  Loader2,
  CheckCircle,
  TrendingUp,
  Mail,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';

const campaignGoals = [
  { value: 'product_launch', label: 'Product Launch', icon: '🚀' },
  { value: 'lead_generation', label: 'Lead Generation', icon: '🎯' },
  { value: 'brand_awareness', label: 'Brand Awareness', icon: '📢' },
  { value: 'sales', label: 'Drive Sales', icon: '💰' },
  { value: 'engagement', label: 'Boost Engagement', icon: '❤️' },
  { value: 'traffic', label: 'Website Traffic', icon: '🌐' },
];

const platforms = ['facebook', 'instagram', 'youtube', 'tiktok', 'linkedin', 'twitter', 'email', 'landing_page'];

export default function CampaignWizard({ competitors, onComplete }) {
  const [step, setStep] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [campaignData, setCampaignData] = useState({
    name: '',
    goal: '',
    target_audience: '',
    budget: '',
    duration_weeks: 4,
    platforms: [],
    description: '',
  });
  const [aiPlan, setAiPlan] = useState(null);

  const handleInputChange = (field, value) => {
    setCampaignData({ ...campaignData, [field]: value });
  };

  const togglePlatform = (platform) => {
    setCampaignData({
      ...campaignData,
      platforms: campaignData.platforms.includes(platform)
        ? campaignData.platforms.filter(p => p !== platform)
        : [...campaignData.platforms, platform]
    });
  };

  const generateCampaignPlan = async () => {
    setIsGenerating(true);
    toast.info('🤖 AI is creating your campaign plan...');

    const competitorInsights = competitors.length > 0
      ? `Competitor Analysis:
${competitors.map(c => `- ${c.name} (@${c.username} on ${c.platform}): ${c.followers_count} followers, ${c.engagement_rate}% engagement, themes: ${c.content_themes?.join(', ') || 'N/A'}`).join('\n')}`
      : 'No competitor data available.';

    const prompt = `Create a comprehensive integrated marketing campaign plan:

CAMPAIGN BRIEF:
- Name: ${campaignData.name}
- Goal: ${campaignData.goal}
- Target Audience: ${campaignData.target_audience}
- Budget: $${campaignData.budget}
- Duration: ${campaignData.duration_weeks} weeks
- Platforms: ${campaignData.platforms.join(', ')}
- Description: ${campaignData.description}

${competitorInsights}

Generate:
1. Campaign Ideas (3-5 unique concepts)
2. Multi-platform Content Strategy with specific post types, themes, and timeline
3. Target Audience Segments for ad targeting
4. Campaign Assets:
   - 3 Ad copy variations
   - Email sequence (3 emails: announcement, nurture, conversion)
   - Landing page outline with sections and key messaging

Be specific, actionable, and data-driven.`;

    try {
      const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          campaign_ideas: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string' },
                description: { type: 'string' },
                unique_angle: { type: 'string' },
                expected_impact: { type: 'string' }
              }
            }
          },
          content_strategy: {
            type: 'object',
            properties: {
              themes: { type: 'array', items: { type: 'string' } },
              platforms: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    platform: { type: 'string' },
                    post_types: { type: 'array', items: { type: 'string' } },
                    frequency: { type: 'string' },
                    content_examples: { type: 'array', items: { type: 'string' } }
                  }
                }
              },
              timeline: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    week: { type: 'number' },
                    focus: { type: 'string' },
                    activities: { type: 'array', items: { type: 'string' } }
                  }
                }
              }
            }
          },
          audience_segments: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                segment_name: { type: 'string' },
                demographics: { type: 'string' },
                interests: { type: 'array', items: { type: 'string' } },
                behaviors: { type: 'array', items: { type: 'string' } },
                platform_focus: { type: 'array', items: { type: 'string' } }
              }
            }
          },
          campaign_assets: {
            type: 'object',
            properties: {
              ad_copy: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    variation: { type: 'string' },
                    headline: { type: 'string' },
                    body: { type: 'string' },
                    cta: { type: 'string' }
                  }
                }
              },
              email_sequence: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    email_number: { type: 'number' },
                    subject: { type: 'string' },
                    preview_text: { type: 'string' },
                    body: { type: 'string' },
                    cta: { type: 'string' }
                  }
                }
              },
              landing_page: {
                type: 'object',
                properties: {
                  hero_headline: { type: 'string' },
                  subheadline: { type: 'string' },
                  sections: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string' },
                        content: { type: 'string' }
                      }
                    }
                  },
                  cta_primary: { type: 'string' },
                  cta_secondary: { type: 'string' }
                }
              }
            }
          }
        }
      }
    });

      if (result) {
        setAiPlan(result);
        setStep(5);
        toast.success('✅ Campaign plan generated!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('Campaign generation error:', error);
      toast.error('❌ Failed to generate campaign: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const saveCampaign = async () => {
    try {
      await base44.entities.Campaign.create({
      name: campaignData.name,
      description: campaignData.description,
      status: 'draft',
      budget: parseFloat(campaignData.budget) || 0,
      platforms: campaignData.platforms,
      goals: campaignData.goal,
      target_audience: campaignData.target_audience,
      start_date: new Date().toISOString().split('T')[0],
    });

      toast.success('✅ Campaign saved!');
      onComplete();
    } catch (error) {
      console.error('Campaign save error:', error);
      toast.error('❌ Failed to save campaign: ' + error.message);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-white mb-3 block">Campaign Name</Label>
              <Input
                value={campaignData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="e.g., Summer Product Launch 2024"
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>

            <div>
              <Label className="text-white mb-3 block">Campaign Goal</Label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {campaignGoals.map((goal) => (
                  <button
                    key={goal.value}
                    onClick={() => handleInputChange('goal', goal.value)}
                    className={cn(
                      "p-4 rounded-xl border-2 transition-all text-left",
                      campaignData.goal === goal.value
                        ? "border-violet-500 bg-violet-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    )}
                  >
                    <div className="text-2xl mb-2">{goal.icon}</div>
                    <p className="text-sm font-medium text-white">{goal.label}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-white mb-3 block">Describe Your Campaign</Label>
              <Textarea
                value={campaignData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                placeholder="Describe what you want to achieve with this campaign..."
                className="bg-slate-800/50 border-slate-700 text-white min-h-[100px]"
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-white mb-3 block">Target Audience</Label>
              <Textarea
                value={campaignData.target_audience}
                onChange={(e) => handleInputChange('target_audience', e.target.value)}
                placeholder="Describe your target audience (demographics, interests, behaviors)..."
                className="bg-slate-800/50 border-slate-700 text-white min-h-[120px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white mb-3 block">Budget ($)</Label>
                <Input
                  type="number"
                  value={campaignData.budget}
                  onChange={(e) => handleInputChange('budget', e.target.value)}
                  placeholder="10000"
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
              <div>
                <Label className="text-white mb-3 block">Duration (weeks)</Label>
                <Input
                  type="number"
                  value={campaignData.duration_weeks}
                  onChange={(e) => handleInputChange('duration_weeks', e.target.value)}
                  placeholder="4"
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div>
              <Label className="text-white mb-3 block">Select Platforms</Label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {platforms.map((platform) => (
                  <button
                    key={platform}
                    onClick={() => togglePlatform(platform)}
                    className={cn(
                      "p-4 rounded-xl border-2 transition-all capitalize",
                      campaignData.platforms.includes(platform)
                        ? "border-violet-500 bg-violet-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    )}
                  >
                    <p className="text-sm font-medium text-white">{platform.replace('_', ' ')}</p>
                  </button>
                ))}
              </div>
            </div>

            {competitors.length > 0 && (
              <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                <p className="text-sm text-slate-400 mb-2">
                  📊 We'll analyze {competitors.length} competitor{competitors.length > 1 ? 's' : ''} to inform your strategy
                </p>
                <div className="flex flex-wrap gap-2">
                  {competitors.slice(0, 5).map((c) => (
                    <Badge key={c.id} variant="outline" className="border-slate-600 text-slate-300">
                      {c.name}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Ready to Generate</h3>
              <p className="text-slate-400 mb-6">
                AI will create a comprehensive campaign plan including content strategy, audience targeting, and campaign assets
              </p>

              <div className="bg-slate-800/50 rounded-xl p-6 text-left max-w-md mx-auto mb-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm text-slate-300">Campaign ideas & concepts</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm text-slate-300">Multi-platform content strategy</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm text-slate-300">Audience targeting segments</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm text-slate-300">Ad copy & email sequences</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400" />
                    <span className="text-sm text-slate-300">Landing page outline</span>
                  </div>
                </div>
              </div>

              <Button
                onClick={generateCampaignPlan}
                disabled={isGenerating}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Campaign Plan...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Campaign Plan
                  </>
                )}
              </Button>
            </div>
          </div>
        );

      case 5:
        return aiPlan ? (
          <ScrollArea className="h-[600px] pr-4">
            <div className="space-y-6">
              {/* Campaign Ideas */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-violet-400" />
                  Campaign Ideas
                </h3>
                <div className="space-y-3">
                  {aiPlan.campaign_ideas?.map((idea, i) => (
                    <div key={i} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <h4 className="font-medium text-white mb-2">{idea.title}</h4>
                      <p className="text-sm text-slate-300 mb-2">{idea.description}</p>
                      <div className="flex items-start gap-2 text-xs text-violet-400">
                        <TrendingUp className="w-3 h-3 mt-0.5 flex-shrink-0" />
                        <span>{idea.expected_impact}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Content Strategy */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Content Strategy</h3>
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <p className="text-sm text-slate-400 mb-2">Content Themes</p>
                    <div className="flex flex-wrap gap-2">
                      {aiPlan.content_strategy?.themes?.map((theme, i) => (
                        <Badge key={i} className="bg-violet-500/10 text-violet-400">
                          {theme}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {aiPlan.content_strategy?.platforms?.map((platform, i) => (
                    <div key={i} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium text-white capitalize">{platform.platform}</h4>
                        <Badge variant="outline" className="border-slate-600 text-slate-400">
                          {platform.frequency}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-400 mb-2">Post Types:</p>
                      <div className="flex flex-wrap gap-2">
                        {platform.post_types?.map((type, j) => (
                          <Badge key={j} variant="outline" className="border-slate-600 text-slate-300">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Timeline */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4">Campaign Timeline</h3>
                <div className="space-y-3">
                  {aiPlan.content_strategy?.timeline?.map((week, i) => (
                    <div key={i} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="w-4 h-4 text-violet-400" />
                        <span className="font-medium text-white">Week {week.week}: {week.focus}</span>
                      </div>
                      <ul className="space-y-1">
                        {week.activities?.map((activity, j) => (
                          <li key={j} className="text-sm text-slate-300 flex items-start gap-2">
                            <span className="text-violet-400">•</span>
                            {activity}
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>

              {/* Audience Segments */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-cyan-400" />
                  Target Audience Segments
                </h3>
                <div className="space-y-3">
                  {aiPlan.audience_segments?.map((segment, i) => (
                    <div key={i} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <h4 className="font-medium text-white mb-2">{segment.segment_name}</h4>
                      <p className="text-sm text-slate-400 mb-3">{segment.demographics}</p>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Interests</p>
                          <div className="flex flex-wrap gap-1">
                            {segment.interests?.slice(0, 3).map((int, j) => (
                              <Badge key={j} variant="outline" className="border-slate-600 text-slate-400 text-xs">
                                {int}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Platform Focus</p>
                          <div className="flex flex-wrap gap-1">
                            {segment.platform_focus?.map((plat, j) => (
                              <Badge key={j} variant="outline" className="border-slate-600 text-slate-400 text-xs capitalize">
                                {plat}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Campaign Assets */}
              <div>
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-fuchsia-400" />
                  Campaign Assets
                </h3>

                {/* Ad Copy */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-slate-400 mb-3">Ad Copy Variations</h4>
                  <div className="space-y-3">
                    {aiPlan.campaign_assets?.ad_copy?.map((ad, i) => (
                      <div key={i} className="p-4 rounded-xl bg-gradient-to-br from-slate-800/50 to-slate-800/30 border border-slate-700">
                        <Badge className="bg-violet-500/10 text-violet-400 mb-3">{ad.variation}</Badge>
                        <p className="font-medium text-white mb-2">{ad.headline}</p>
                        <p className="text-sm text-slate-300 mb-3">{ad.body}</p>
                        <Button size="sm" variant="outline" className="border-violet-500/30 text-violet-400">
                          {ad.cta}
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Email Sequence */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-slate-400 mb-3 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Sequence
                  </h4>
                  <div className="space-y-3">
                    {aiPlan.campaign_assets?.email_sequence?.map((email, i) => (
                      <div key={i} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                        <Badge variant="outline" className="border-slate-600 text-slate-400 mb-2">
                          Email {email.email_number}
                        </Badge>
                        <p className="font-medium text-white mb-1">{email.subject}</p>
                        <p className="text-xs text-slate-500 mb-2">{email.preview_text}</p>
                        <p className="text-sm text-slate-300 mb-2 line-clamp-3">{email.body}</p>
                        <p className="text-xs text-violet-400">CTA: {email.cta}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Landing Page */}
                <div>
                  <h4 className="text-sm font-medium text-slate-400 mb-3 flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    Landing Page Outline
                  </h4>
                  <div className="p-6 rounded-xl bg-gradient-to-br from-violet-500/5 to-fuchsia-500/5 border border-violet-500/20">
                    <h5 className="text-xl font-bold text-white mb-2">
                      {aiPlan.campaign_assets?.landing_page?.hero_headline}
                    </h5>
                    <p className="text-slate-300 mb-4">
                      {aiPlan.campaign_assets?.landing_page?.subheadline}
                    </p>
                    <div className="space-y-3">
                      {aiPlan.campaign_assets?.landing_page?.sections?.map((section, i) => (
                        <div key={i} className="p-3 rounded-lg bg-slate-800/50">
                          <p className="font-medium text-white text-sm mb-1">{section.title}</p>
                          <p className="text-xs text-slate-400">{section.content}</p>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-3 mt-4">
                      <Button size="sm" className="bg-violet-600">
                        {aiPlan.campaign_assets?.landing_page?.cta_primary}
                      </Button>
                      <Button size="sm" variant="outline" className="border-slate-600">
                        {aiPlan.campaign_assets?.landing_page?.cta_secondary}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </ScrollArea>
        ) : null;

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Progress */}
      {step < 5 && (
        <div className="flex items-center justify-center gap-2">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={cn(
                "w-12 h-1 rounded-full transition-all",
                s <= step ? "bg-violet-600" : "bg-slate-700"
              )}
            />
          ))}
        </div>
      )}

      {/* Content */}
      <div className="min-h-[400px]">
        {renderStep()}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-6 border-t border-slate-800">
        {step > 1 && step < 5 && (
          <Button
            variant="outline"
            onClick={() => setStep(step - 1)}
            className="border-slate-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        )}
        
        <div className="ml-auto flex items-center gap-3">
          {step < 4 && (
            <Button
              onClick={() => setStep(step + 1)}
              disabled={
                (step === 1 && (!campaignData.name || !campaignData.goal)) ||
                (step === 2 && !campaignData.target_audience) ||
                (step === 3 && campaignData.platforms.length === 0)
              }
              className="bg-violet-600 hover:bg-violet-700"
            >
              Continue
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
          
          {step === 5 && (
            <Button
              onClick={saveCampaign}
              className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Save Campaign
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}