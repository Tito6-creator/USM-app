import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Mic,
  MicOff,
  Camera,
  Save,
  Sparkles,
  Loader2,
  Volume2,
  VolumeX,
  MessageSquare,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';

export default function AIAssistant({ browserRef }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState([]);
  
  const recognitionRef = useRef(null);
  const synthRef = useRef(window.speechSynthesis);

  useEffect(() => {
    // Initialize speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('');
        setInput(transcript);
      };

      recognitionRef.current.onend = () => {
        if (isListening) {
          recognitionRef.current.start();
        }
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      synthRef.current.cancel();
    };
  }, [isListening]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not supported in this browser');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
      toast.success('Listening...');
    }
  };

  const speak = (text) => {
    if (!synthRef.current) return;

    synthRef.current.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    synthRef.current.speak(utterance);
  };

  const stopSpeaking = () => {
    synthRef.current.cancel();
    setIsSpeaking(false);
  };

  const captureScreenshot = async () => {
    if (!browserRef?.current) {
      toast.error('No browser window available');
      return null;
    }

    try {
      const canvas = await html2canvas(browserRef.current, {
        allowTaint: true,
        useCORS: true,
        logging: false,
      });
      
      return canvas.toDataURL('image/png');
    } catch (error) {
      console.error('Screenshot error:', error);
      toast.error('Could not capture screenshot');
      return null;
    }
  };

  const analyzeScreen = async () => {
    setIsProcessing(true);

    const screenshot = await captureScreenshot();
    if (!screenshot) {
      setIsProcessing(false);
      return;
    }

    // Upload screenshot
    const blob = await fetch(screenshot).then(r => r.blob());
    const file = new File([blob], 'screenshot.png', { type: 'image/png' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    const prompt = `Analyze this screenshot from a web browser and extract key information:

1. What is the main content/topic of this page?
2. Extract any important data, statistics, or insights
3. Identify any actionable marketing opportunities or trends
4. Summarize the key takeaways in bullet points

Provide structured information that can be saved for marketing strategy.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [file_url],
      response_json_schema: {
        type: 'object',
        properties: {
          main_topic: { type: 'string' },
          key_data: { type: 'array', items: { type: 'string' } },
          marketing_opportunities: { type: 'array', items: { type: 'string' } },
          summary: { type: 'string' },
          extracted_text: { type: 'string' }
        }
      }
    });

    const aiMessage = {
      role: 'assistant',
      content: result.summary,
      data: result,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, aiMessage]);
    speak(result.summary);
    setExtractedData(prev => [...prev, { ...result, screenshot: file_url, timestamp: new Date().toISOString() }]);
    setIsProcessing(false);
    toast.success('Screen analyzed!');
  };

  const sendMessage = async () => {
    if (!input.trim() && !isListening) return;

    const userMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    // Get recent context
    const recentData = extractedData.slice(-3);
    const context = recentData.length > 0 
      ? `Recent extracted data from browser:\n${recentData.map(d => d.summary).join('\n')}`
      : '';

    const prompt = `You are an AI marketing assistant helping with research and strategy.

${context}

User question: ${userMessage.content}

Provide a helpful, concise response. If relevant, reference the extracted data.`;

    const response = await base44.integrations.Core.InvokeLLM({ prompt });

    const aiMessage = {
      role: 'assistant',
      content: response,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, aiMessage]);
    speak(response);
    setIsProcessing(false);
  };

  const saveExtractedData = async () => {
    if (extractedData.length === 0) {
      toast.error('No data to save');
      return;
    }

    // Save to a TrendAlert or create a research note
    const latestData = extractedData[extractedData.length - 1];
    
    await base44.entities.TrendAlert.create({
      type: 'topic',
      title: latestData.main_topic || 'Research Finding',
      description: latestData.summary,
      trend_data: {
        keyword: latestData.main_topic,
        insights: latestData.key_data,
        opportunities: latestData.marketing_opportunities
      },
      priority: 'medium',
      status: 'new',
      platforms: ['research']
    });

    toast.success('Research saved to trends!');
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden flex flex-col h-[600px]">
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">AI Research Assistant</h3>
            <p className="text-xs text-slate-400">Voice & Vision Enabled</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-violet-500/10 text-violet-400">
            {extractedData.length} saved
          </Badge>
          <Button
            size="sm"
            variant="ghost"
            onClick={analyzeScreen}
            disabled={isProcessing}
            className="text-violet-400 hover:text-violet-300"
          >
            <Camera className="w-4 h-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={saveExtractedData}
            disabled={extractedData.length === 0}
            className="text-emerald-400 hover:text-emerald-300"
          >
            <Save className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-8">
              <Eye className="w-12 h-12 mx-auto text-slate-600 mb-3" />
              <p className="text-slate-400 text-sm">
                Click <Camera className="w-4 h-4 inline" /> to analyze browser content
                <br />or start a voice conversation
              </p>
            </div>
          )}
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={cn(
                "flex gap-3",
                msg.role === 'user' ? "justify-end" : "justify-start"
              )}
            >
              {msg.role === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
              )}
              <div className={cn(
                "max-w-[80%] rounded-2xl px-4 py-2",
                msg.role === 'user' 
                  ? "bg-violet-600 text-white" 
                  : "bg-slate-800 text-slate-100"
              )}>
                <p className="text-sm">{msg.content}</p>
                {msg.data && (
                  <div className="mt-2 pt-2 border-t border-slate-700 space-y-1">
                    {msg.data.key_data?.slice(0, 3).map((item, i) => (
                      <p key={i} className="text-xs text-slate-400">• {item}</p>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                <Loader2 className="w-4 h-4 text-white animate-spin" />
              </div>
              <div className="bg-slate-800 rounded-2xl px-4 py-2">
                <p className="text-sm text-slate-300">Analyzing...</p>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-slate-800">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder="Ask about the content or give instructions..."
            className="flex-1 min-h-[60px] max-h-[120px] bg-slate-800/50 border-slate-700 text-white resize-none"
          />
          <div className="flex flex-col gap-2">
            <Button
              onClick={toggleListening}
              className={cn(
                "flex-1",
                isListening 
                  ? "bg-rose-600 hover:bg-rose-700" 
                  : "bg-violet-600 hover:bg-violet-700"
              )}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </Button>
            <Button
              onClick={isSpeaking ? stopSpeaking : sendMessage}
              disabled={!input.trim() && !isListening || isProcessing}
              className="flex-1 bg-fuchsia-600 hover:bg-fuchsia-700"
            >
              {isSpeaking ? <VolumeX className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}