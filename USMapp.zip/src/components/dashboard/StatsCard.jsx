import React from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';

export default function StatsCard({ 
  title, 
  value, 
  change, 
  changeLabel,
  icon: Icon, 
  gradient = 'from-violet-500 to-purple-500',
  className 
}) {
  const isPositive = change >= 0;

  return (
    <div className={cn(
      "relative overflow-hidden rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6",
      "hover:border-slate-700/50 transition-all duration-300",
      className
    )}>
      <div className={cn(
        "absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-10 blur-2xl",
        `bg-gradient-to-br ${gradient}`
      )} />
      
      <div className="relative">
        <div className="flex items-start justify-between mb-4">
          <div className={cn(
            "w-12 h-12 rounded-xl flex items-center justify-center",
            `bg-gradient-to-br ${gradient}`
          )}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          {change !== undefined && (
            <div className={cn(
              "flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium",
              isPositive 
                ? "bg-emerald-500/10 text-emerald-400" 
                : "bg-rose-500/10 text-rose-400"
            )}>
              {isPositive ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {Math.abs(change)}%
            </div>
          )}
        </div>

        <p className="text-slate-400 text-sm mb-1">{title}</p>
        <p className="text-3xl font-bold text-white">{value}</p>
        {changeLabel && (
          <p className="text-xs text-slate-500 mt-1">{changeLabel}</p>
        )}
      </div>
    </div>
  );
}