import React from 'react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { Heart, MessageCircle, Share2, UserPlus, Eye, TrendingUp } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

const activityIcons = {
  like: { icon: Heart, color: 'text-rose-400 bg-rose-400/10' },
  comment: { icon: MessageCircle, color: 'text-blue-400 bg-blue-400/10' },
  share: { icon: Share2, color: 'text-emerald-400 bg-emerald-400/10' },
  follower: { icon: UserPlus, color: 'text-violet-400 bg-violet-400/10' },
  view: { icon: Eye, color: 'text-amber-400 bg-amber-400/10' },
  mention: { icon: TrendingUp, color: 'text-cyan-400 bg-cyan-400/10' },
};

export default function RecentActivity({ activities = [] }) {
  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-800">
        <h3 className="font-semibold text-white">Recent Activity</h3>
      </div>
      
      <ScrollArea className="h-[320px]">
        <div className="p-4 space-y-3">
          {activities.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              No recent activity
            </div>
          ) : (
            activities.map((activity, index) => {
              const activityType = activityIcons[activity.type] || activityIcons.view;
              const Icon = activityType.icon;
              
              return (
                <div
                  key={index}
                  className={cn(
                    "flex items-center gap-4 p-3 rounded-xl",
                    "bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                  )}
                >
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center",
                    activityType.color
                  )}>
                    <Icon className="w-5 h-5" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{activity.message}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <PlatformIcon platform={activity.platform} size="xs" />
                      <span className="text-xs text-slate-500">
                        {format(new Date(activity.created_date), 'MMM d, h:mm a')}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}