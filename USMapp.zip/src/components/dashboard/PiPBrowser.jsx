import React, { useState, useRef, useEffect } from 'react';
import { X, Minimize2, Maximize2, Globe, ArrowLeft, ArrowRight, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

export default function PiPBrowser({ onClose, onBrowserRef, initialUrl }) {
  const [url, setUrl] = useState(initialUrl || 'https://duckduckgo.com');
  const [currentUrl, setCurrentUrl] = useState(initialUrl || 'https://duckduckgo.com');
  const [isMinimized, setIsMinimized] = useState(false);
  const [position, setPosition] = useState({ x: window.innerWidth - 320, y: 80 });
  const [size, setSize] = useState({ width: 300, height: 400 });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  
  const containerRef = useRef(null);
  const iframeRef = useRef(null);

  useEffect(() => {
    if (onBrowserRef && containerRef.current) {
      onBrowserRef(containerRef);
    }
  }, [onBrowserRef]);

  useEffect(() => {
    const handleMouseMove = (e) => {
      if (isDragging) {
        setPosition({
          x: e.clientX - dragOffset.x,
          y: e.clientY - dragOffset.y,
        });
      } else if (isResizing) {
        const newWidth = Math.max(300, e.clientX - position.x);
        const newHeight = Math.max(200, e.clientY - position.y);
        setSize({ width: newWidth, height: newHeight });
      }
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setIsResizing(false);
    };

    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, isResizing, dragOffset, position]);

  const handleDragStart = (e) => {
    setIsDragging(true);
    setDragOffset({
      x: e.clientX - position.x,
      y: e.clientY - position.y,
    });
  };

  const handleResizeStart = (e) => {
    e.stopPropagation();
    setIsResizing(true);
  };

  const handleNavigate = () => {
    if (url && url.trim()) {
      let finalUrl = url.trim();
      if (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://')) {
        finalUrl = 'https://' + finalUrl;
      }
      setCurrentUrl(finalUrl);
    }
  };

  const handleRefresh = () => {
    if (iframeRef.current) {
      iframeRef.current.src = currentUrl;
    }
  };

  if (isMinimized) {
    return (
      <div
        className="fixed bottom-6 right-6 z-50"
        style={{ width: '200px' }}
      >
        <div className="bg-slate-900 border border-slate-700 rounded-lg p-3 shadow-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-violet-400" />
              <span className="text-sm text-white">Research Browser</span>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(false)}
                className="h-6 w-6 text-slate-400 hover:text-white"
              >
                <Maximize2 className="w-3 h-3" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="h-6 w-6 text-slate-400 hover:text-rose-400"
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="fixed z-50 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: `${size.width}px`,
        height: `${size.height}px`,
      }}
    >
      {/* Header */}
      <div
        className="bg-slate-800/50 border-b border-slate-700 px-3 py-2 cursor-move"
        onMouseDown={handleDragStart}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Globe className="w-4 h-4 text-violet-400" />
            <span className="text-sm font-medium text-white">Research Browser</span>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMinimized(true)}
              className="h-7 w-7 text-slate-400 hover:text-white"
            >
              <Minimize2 className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-7 w-7 text-slate-400 hover:text-rose-400"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="bg-slate-800/30 border-b border-slate-700 px-3 py-2">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => iframeRef.current?.contentWindow?.history.back()}
              className="h-7 w-7 text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => iframeRef.current?.contentWindow?.history.forward()}
              className="h-7 w-7 text-slate-400 hover:text-white"
            >
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRefresh}
              className="h-7 w-7 text-slate-400 hover:text-white"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
          <form onSubmit={(e) => { e.preventDefault(); handleNavigate(); }} className="flex-1">
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Enter URL or search..."
              className="h-7 bg-slate-800/50 border-slate-700 text-white text-sm"
            />
          </form>
        </div>
      </div>

      {/* Browser Content */}
      <div className="relative" style={{ height: `calc(100% - 88px)` }}>
        <iframe
          ref={iframeRef}
          src={currentUrl}
          className="w-full h-full bg-white"
          title="Research Browser"
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms allow-popups-to-escape-sandbox allow-top-navigation"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          onError={(e) => console.error('Iframe load error:', e)}
        />
        <div className="absolute top-2 left-2 right-2 text-xs text-slate-600 bg-amber-100/90 p-2 rounded pointer-events-none">
          ℹ️ Some sites (Google, Facebook) block iframe loading. Try DuckDuckGo, Wikipedia, or most other sites.
        </div>
      </div>

      {/* Resize Handle */}
      <div
        className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize"
        onMouseDown={handleResizeStart}
      >
        <div className="absolute bottom-1 right-1 w-3 h-3 border-r-2 border-b-2 border-slate-600" />
      </div>
    </div>
  );
}