import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';
import { Plus, Users, TrendingUp } from 'lucide-react';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

function formatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num?.toString() || '0';
}

export default function AccountsList({ accounts = [] }) {
  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <h3 className="font-semibold text-white">Connected Accounts</h3>
        <Link to={createPageUrl('Settings')}>
          <Button size="sm" variant="ghost" className="text-violet-400 hover:text-violet-300">
            <Plus className="w-4 h-4 mr-1" />
            Add
          </Button>
        </Link>
      </div>
      
      <ScrollArea className="h-[320px]">
        <div className="p-4 space-y-3">
          {accounts.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-800 flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-slate-500" />
              </div>
              <p className="text-slate-400 mb-4">No accounts connected</p>
              <Link to={createPageUrl('Settings')}>
                <Button size="sm" className="bg-violet-600 hover:bg-violet-700">
                  Connect Account
                </Button>
              </Link>
            </div>
          ) : (
            accounts.map((account) => (
              <div
                key={account.id}
                className={cn(
                  "flex items-center gap-4 p-3 rounded-xl",
                  "bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                )}
              >
                <PlatformIcon platform={account.platform} size="lg" />
                
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white truncate">{account.account_name}</p>
                  <p className="text-xs text-slate-500">@{account.username}</p>
                </div>
                
                <div className="text-right">
                  <div className="flex items-center gap-1 text-emerald-400">
                    <TrendingUp className="w-3 h-3" />
                    <span className="text-sm font-medium">{formatNumber(account.followers_count)}</span>
                  </div>
                  <p className="text-xs text-slate-500">followers</p>
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}