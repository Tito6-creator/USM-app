import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PenSquare, Calendar, BarChart3, Users, Hash, Bot } from 'lucide-react';
import { cn } from '@/lib/utils';

const actions = [
  { 
    name: 'Create Post', 
    icon: PenSquare, 
    page: 'CreatePost',
    gradient: 'from-violet-500 to-purple-500',
    description: 'AI-powered content'
  },
  { 
    name: 'Schedule', 
    icon: Calendar, 
    page: 'Calendar',
    gradient: 'from-cyan-500 to-blue-500',
    description: 'Plan your content'
  },
  { 
    name: 'Analytics', 
    icon: BarChart3, 
    page: 'Analytics',
    gradient: 'from-emerald-500 to-teal-500',
    description: 'View insights'
  },
  { 
    name: 'Hashtags', 
    icon: Hash, 
    page: 'Hashtags',
    gradient: 'from-orange-500 to-amber-500',
    description: 'Research tags'
  },
  { 
    name: 'Influencers', 
    icon: Users, 
    page: 'Influencers',
    gradient: 'from-pink-500 to-rose-500',
    description: 'Find partners'
  },
  { 
    name: 'Chatbot', 
    icon: Bot, 
    page: 'Chatbot',
    gradient: 'from-indigo-500 to-violet-500',
    description: 'Auto-reply setup'
  },
];

export default function QuickActions() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {actions.map((action) => (
        <Link
          key={action.name}
          to={createPageUrl(action.page)}
          className={cn(
            "group relative overflow-hidden rounded-2xl p-4 text-center",
            "bg-slate-900/50 border border-slate-800/50",
            "hover:border-slate-700/50 hover:scale-105 transition-all duration-300"
          )}
        >
          <div className={cn(
            "absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity",
            `bg-gradient-to-br ${action.gradient}`
          )} />
          
          <div className={cn(
            "w-12 h-12 mx-auto rounded-xl flex items-center justify-center mb-3",
            `bg-gradient-to-br ${action.gradient}`
          )}>
            <action.icon className="w-6 h-6 text-white" />
          </div>
          
          <p className="font-medium text-white text-sm">{action.name}</p>
          <p className="text-xs text-slate-500 mt-0.5">{action.description}</p>
        </Link>
      ))}
    </div>
  );
}