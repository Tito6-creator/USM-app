import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Calendar, Clock, Image, Video, FileText } from 'lucide-react';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

const mediaIcons = {
  image: Image,
  video: Video,
  carousel: Image,
  story: Image,
  reel: Video,
  text: FileText,
};

export default function UpcomingPosts({ posts = [] }) {
  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
        <h3 className="font-semibold text-white">Upcoming Posts</h3>
        <Link to={createPageUrl('Calendar')}>
          <Button size="sm" variant="ghost" className="text-violet-400 hover:text-violet-300">
            <Calendar className="w-4 h-4 mr-1" />
            View All
          </Button>
        </Link>
      </div>
      
      <ScrollArea className="h-[320px]">
        <div className="p-4 space-y-3">
          {posts.length === 0 ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-slate-800 flex items-center justify-center mb-4">
                <Calendar className="w-8 h-8 text-slate-500" />
              </div>
              <p className="text-slate-400 mb-4">No scheduled posts</p>
              <Link to={createPageUrl('CreatePost')}>
                <Button size="sm" className="bg-violet-600 hover:bg-violet-700">
                  Create Post
                </Button>
              </Link>
            </div>
          ) : (
            posts.map((post) => {
              const MediaIcon = mediaIcons[post.media_type] || FileText;
              
              return (
                <div
                  key={post.id}
                  className={cn(
                    "p-4 rounded-xl",
                    "bg-slate-800/30 hover:bg-slate-800/50 transition-colors"
                  )}
                >
                  <div className="flex items-start gap-3">
                    {post.media_urls?.[0] ? (
                      <div className="w-12 h-12 rounded-lg bg-slate-700 overflow-hidden flex-shrink-0">
                        <img 
                          src={post.media_urls[0]} 
                          alt="" 
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-slate-700 flex items-center justify-center flex-shrink-0">
                        <MediaIcon className="w-5 h-5 text-slate-400" />
                      </div>
                    )}
                    
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white line-clamp-2">{post.content}</p>
                      
                      <div className="flex items-center gap-2 mt-2">
                        <div className="flex -space-x-1">
                          {post.platforms?.slice(0, 3).map((platform) => (
                            <PlatformIcon key={platform} platform={platform} size="xs" />
                          ))}
                        </div>
                        
                        <div className="flex items-center gap-1 text-xs text-slate-500">
                          <Clock className="w-3 h-3" />
                          {post.scheduled_time && format(new Date(post.scheduled_time), 'MMM d, h:mm a')}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {post.status === 'pending_approval' && (
                    <Badge className="mt-2 bg-amber-500/10 text-amber-400 border-amber-500/20">
                      Pending Approval
                    </Badge>
                  )}
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>
    </div>
  );
}