import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Globe, CheckCircle, AlertCircle, Copy, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

export default function DomainManager({ page }) {
  const [customDomain, setCustomDomain] = useState(page.domain_settings?.custom_domain || '');
  const queryClient = useQueryClient();

  const verifyDomainMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('verifyDomain', {
        page_id: page.id,
        domain: customDomain
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Domain verified successfully!');
    },
    onError: (error) => {
      toast.error('Domain verification failed. Check DNS settings.');
    }
  });

  const saveDomainMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.LandingPage.update(page.id, {
        domain_settings: {
          ...page.domain_settings,
          custom_domain: customDomain,
          verification_token: `verify-${Date.now()}`
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Domain saved! Configure DNS records.');
    }
  });

  const domainVerified = page.domain_settings?.domain_verified;
  const verificationToken = page.domain_settings?.verification_token;

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Globe className="w-5 h-5" />
          Custom Domain
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label className="text-white">Your Domain</Label>
          <div className="flex gap-2 mt-2">
            <Input
              value={customDomain}
              onChange={(e) => setCustomDomain(e.target.value)}
              placeholder="www.yourdomain.com"
              className="bg-slate-800 border-slate-700 text-white"
            />
            <Button
              onClick={() => saveDomainMutation.mutate()}
              disabled={!customDomain || saveDomainMutation.isPending}
              className="bg-violet-600 hover:bg-violet-700"
            >
              Save
            </Button>
          </div>
        </div>

        {customDomain && page.domain_settings?.custom_domain && (
          <>
            <div className="flex items-center gap-2">
              <Badge className={domainVerified ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'}>
                {domainVerified ? (
                  <>
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Verified
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-3 h-3 mr-1" />
                    Pending Verification
                  </>
                )}
              </Badge>
              {page.domain_settings?.ssl_enabled && (
                <Badge className="bg-blue-500/10 text-blue-400">
                  SSL Enabled
                </Badge>
              )}
            </div>

            {!domainVerified && (
              <div className="space-y-3 p-4 bg-slate-800/50 rounded-lg">
                <h4 className="font-semibold text-white text-sm">DNS Configuration</h4>
                <p className="text-xs text-slate-400">
                  Add these DNS records to your domain provider:
                </p>

                <div className="space-y-2">
                  <div className="bg-slate-900 p-3 rounded text-xs font-mono">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400">Type: A</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard('185.199.108.153')}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="text-white">Value: 185.199.108.153</div>
                  </div>

                  <div className="bg-slate-900 p-3 rounded text-xs font-mono">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-slate-400">Type: TXT</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(verificationToken)}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="text-white break-all">Value: {verificationToken}</div>
                  </div>
                </div>

                <Button
                  onClick={() => verifyDomainMutation.mutate()}
                  disabled={verifyDomainMutation.isPending}
                  className="w-full bg-violet-600 hover:bg-violet-700 mt-3"
                >
                  {verifyDomainMutation.isPending ? 'Verifying...' : 'Verify Domain'}
                </Button>
              </div>
            )}

            {domainVerified && (
              <div className="flex items-center gap-2 p-3 bg-green-500/10 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <div>
                  <p className="text-sm font-medium text-green-400">Domain Active</p>
                  <a
                    href={`https://${customDomain}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
                  >
                    Visit your site <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}