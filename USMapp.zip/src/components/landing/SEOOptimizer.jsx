import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Search, CheckCircle, AlertCircle, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function SEOOptimizer({ page }) {
  const [seoData, setSeoData] = useState({
    title: page.seo?.title || '',
    description: page.seo?.description || '',
    keywords: page.seo?.keywords?.join(', ') || '',
    og_image: page.seo?.og_image || '',
    robots: page.seo?.robots || 'index, follow'
  });

  const queryClient = useQueryClient();

  const { data: seoAnalysis, refetch } = useQuery({
    queryKey: ['seoAnalysis', page.id],
    queryFn: async () => {
      const response = await base44.functions.invoke('analyzeSEO', {
        page_id: page.id,
        seo_data: seoData
      });
      return response.data;
    },
    enabled: false
  });

  const generateSEOMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate SEO-optimized metadata for a landing page:
        
Page content: ${page.content?.headline} - ${page.content?.subheadline}
${page.content?.body}

Generate:
1. SEO title (50-60 characters, compelling and keyword-rich)
2. Meta description (150-160 characters, action-oriented)
3. 5 relevant keywords
4. Robots meta tag recommendation

Return as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            description: { type: 'string' },
            keywords: { type: 'array', items: { type: 'string' } },
            robots: { type: 'string' }
          }
        }
      });
      return response;
    },
    onSuccess: (data) => {
      setSeoData({
        ...seoData,
        title: data.title,
        description: data.description,
        keywords: data.keywords.join(', '),
        robots: data.robots
      });
      toast.success('SEO suggestions generated!');
    }
  });

  const saveSEOMutation = useMutation({
    mutationFn: async () => {
      await base44.entities.LandingPage.update(page.id, {
        seo: {
          title: seoData.title,
          description: seoData.description,
          keywords: seoData.keywords.split(',').map(k => k.trim()).filter(Boolean),
          og_image: seoData.og_image,
          robots: seoData.robots
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('SEO settings saved!');
      refetch();
    }
  });

  const seoScore = seoAnalysis?.score || page.seo_score || 0;
  const recommendations = seoAnalysis?.recommendations || [];

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="flex items-center justify-between text-white">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            SEO Optimization
          </div>
          <Button
            size="sm"
            onClick={() => generateSEOMutation.mutate()}
            disabled={generateSEOMutation.isPending}
            className="bg-violet-600 hover:bg-violet-700"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            AI Generate
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {seoScore > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-slate-400">SEO Health Score</span>
              <Badge className={
                seoScore >= 80 ? 'bg-green-500/10 text-green-400' :
                seoScore >= 60 ? 'bg-yellow-500/10 text-yellow-400' :
                'bg-red-500/10 text-red-400'
              }>
                {seoScore}/100
              </Badge>
            </div>
            <Progress value={seoScore} className="h-2" />
          </div>
        )}

        <div>
          <Label className="text-white">SEO Title</Label>
          <Input
            value={seoData.title}
            onChange={(e) => setSeoData({ ...seoData, title: e.target.value })}
            placeholder="50-60 characters"
            className="bg-slate-800 border-slate-700 text-white mt-2"
            maxLength={60}
          />
          <p className="text-xs text-slate-400 mt-1">{seoData.title.length}/60 characters</p>
        </div>

        <div>
          <Label className="text-white">Meta Description</Label>
          <Textarea
            value={seoData.description}
            onChange={(e) => setSeoData({ ...seoData, description: e.target.value })}
            placeholder="150-160 characters"
            className="bg-slate-800 border-slate-700 text-white mt-2 min-h-[80px]"
            maxLength={160}
          />
          <p className="text-xs text-slate-400 mt-1">{seoData.description.length}/160 characters</p>
        </div>

        <div>
          <Label className="text-white">Keywords</Label>
          <Input
            value={seoData.keywords}
            onChange={(e) => setSeoData({ ...seoData, keywords: e.target.value })}
            placeholder="keyword1, keyword2, keyword3"
            className="bg-slate-800 border-slate-700 text-white mt-2"
          />
        </div>

        <div>
          <Label className="text-white">Open Graph Image URL</Label>
          <Input
            value={seoData.og_image}
            onChange={(e) => setSeoData({ ...seoData, og_image: e.target.value })}
            placeholder="https://..."
            className="bg-slate-800 border-slate-700 text-white mt-2"
          />
        </div>

        {recommendations.length > 0 && (
          <div className="space-y-2 p-4 bg-slate-800/50 rounded-lg">
            <h4 className="font-semibold text-white text-sm flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-yellow-400" />
              Recommendations
            </h4>
            <ul className="space-y-1">
              {recommendations.map((rec, index) => (
                <li key={index} className="text-xs text-slate-300 flex items-start gap-2">
                  <span className="text-yellow-400">•</span>
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            onClick={() => refetch()}
            variant="outline"
            className="flex-1 border-slate-700"
          >
            Analyze SEO
          </Button>
          <Button
            onClick={() => saveSEOMutation.mutate()}
            disabled={saveSEOMutation.isPending}
            className="flex-1 bg-violet-600 hover:bg-violet-700"
          >
            Save Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}