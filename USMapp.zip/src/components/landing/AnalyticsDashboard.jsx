import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Eye, MousePointer, TrendingUp, Users, Smartphone, Monitor, Tablet } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#8b5cf6', '#ec4899', '#06b6d4', '#10b981'];

export default function AnalyticsDashboard({ pageId }) {
  const [timeRange, setTimeRange] = useState('30');

  const { data: analytics, isLoading } = useQuery({
    queryKey: ['pageAnalytics', pageId, timeRange],
    queryFn: async () => {
      const response = await base44.functions.invoke('getPageAnalytics', {
        page_id: pageId,
        days: parseInt(timeRange)
      });
      return response.data;
    },
    enabled: !!pageId,
    refetchInterval: 60000,
  });

  if (isLoading || !analytics) {
    return (
      <div className="text-center py-12 text-slate-400">
        Loading analytics...
      </div>
    );
  }

  const { summary, chart_data, device_breakdown, top_referrers } = analytics;

  // Prepare chart data
  const chartData = Object.keys(chart_data.views_by_date).map(date => ({
    date,
    views: chart_data.views_by_date[date] || 0,
    conversions: chart_data.conversions_by_date[date] || 0
  })).sort((a, b) => new Date(a.date) - new Date(b.date));

  const deviceData = Object.entries(device_breakdown).map(([name, value]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    value
  }));

  const deviceIcons = {
    Mobile: Smartphone,
    Tablet: Tablet,
    Desktop: Monitor
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-white">Analytics Dashboard</h3>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-32 bg-slate-800 border-slate-700 text-white">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-slate-900 border-slate-800">
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Total Views</p>
                <p className="text-2xl font-bold text-white">{summary.total_views}</p>
              </div>
              <Eye className="w-8 h-8 text-violet-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Unique Visitors</p>
                <p className="text-2xl font-bold text-white">{summary.unique_visitors}</p>
              </div>
              <Users className="w-8 h-8 text-fuchsia-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Conversions</p>
                <p className="text-2xl font-bold text-white">{summary.conversions}</p>
              </div>
              <MousePointer className="w-8 h-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-400">Conversion Rate</p>
                <p className="text-2xl font-bold text-white">{summary.conversion_rate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Line Chart */}
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Traffic Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Line type="monotone" dataKey="views" stroke="#8b5cf6" strokeWidth={2} />
                <Line type="monotone" dataKey="conversions" stroke="#ec4899" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Device Breakdown */}
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Device Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <ResponsiveContainer width="50%" height={250}>
                <PieChart>
                  <Pie
                    data={deviceData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {deviceData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-3">
                {deviceData.map((device, index) => {
                  const Icon = deviceIcons[device.name];
                  return (
                    <div key={device.name} className="flex items-center gap-3">
                      {Icon && <Icon className="w-5 h-5" style={{ color: COLORS[index % COLORS.length] }} />}
                      <div>
                        <p className="text-sm text-white">{device.name}</p>
                        <p className="text-xs text-slate-400">{device.value} visits</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Referrers */}
      {top_referrers.length > 0 && (
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Top Referrers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {top_referrers.map((ref, index) => (
                <div key={index} className="flex items-center justify-between pb-3 border-b border-slate-800 last:border-0">
                  <p className="text-sm text-slate-300 truncate max-w-[70%]">{ref.referrer}</p>
                  <p className="text-sm font-semibold text-white">{ref.count} visits</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}