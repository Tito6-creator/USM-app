import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sparkles, Loader2, Copy, Check } from 'lucide-react';
import { toast } from 'sonner';

export default function AIContentGenerator({ onApply }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [businessInfo, setBusinessInfo] = useState({
    name: '',
    industry: '',
    target_audience: '',
    goal: 'leads',
    tone: 'professional'
  });
  const [generatedContent, setGeneratedContent] = useState(null);
  const [copiedField, setCopiedField] = useState(null);

  const handleGenerate = async () => {
    if (!businessInfo.name || !businessInfo.industry) {
      toast.error('Please fill in business name and industry');
      return;
    }

    setIsGenerating(true);
    try {
      const prompt = `Generate complete landing page content for a business with these details:
- Business Name: ${businessInfo.name}
- Industry: ${businessInfo.industry}
- Target Audience: ${businessInfo.target_audience || 'general'}
- Primary Goal: ${businessInfo.goal}
- Tone: ${businessInfo.tone}

Create compelling, conversion-focused content including:
1. Attention-grabbing headline (6-10 words)
2. Supporting subheadline (15-25 words)
3. Hero section body (2-3 sentences)
4. 3 key benefits/features with titles and descriptions
5. Social proof/testimonial quote
6. Strong call-to-action text
7. SEO-optimized meta title and description`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            headline: { type: 'string' },
            subheadline: { type: 'string' },
            hero_body: { type: 'string' },
            features: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  description: { type: 'string' }
                }
              }
            },
            testimonial: {
              type: 'object',
              properties: {
                quote: { type: 'string' },
                author: { type: 'string' },
                company: { type: 'string' }
              }
            },
            cta_text: { type: 'string' },
            cta_button: { type: 'string' },
            seo_title: { type: 'string' },
            seo_description: { type: 'string' }
          }
        }
      });

      setGeneratedContent(response);
      toast.success('Content generated successfully!');
    } catch (error) {
      toast.error('Failed to generate content: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text, field) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
    toast.success('Copied to clipboard!');
  };

  return (
    <div className="space-y-6">
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-violet-400" />
            AI Content Generator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Business Name</Label>
              <Input
                value={businessInfo.name}
                onChange={(e) => setBusinessInfo({ ...businessInfo, name: e.target.value })}
                placeholder="Acme Inc."
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
            <div>
              <Label className="text-white">Industry</Label>
              <Input
                value={businessInfo.industry}
                onChange={(e) => setBusinessInfo({ ...businessInfo, industry: e.target.value })}
                placeholder="SaaS, E-commerce, etc."
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
          </div>

          <div>
            <Label className="text-white">Target Audience</Label>
            <Input
              value={businessInfo.target_audience}
              onChange={(e) => setBusinessInfo({ ...businessInfo, target_audience: e.target.value })}
              placeholder="Small business owners, marketers, etc."
              className="bg-slate-800 border-slate-700 text-white mt-2"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Primary Goal</Label>
              <Select value={businessInfo.goal} onValueChange={(v) => setBusinessInfo({ ...businessInfo, goal: v })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="leads">Generate Leads</SelectItem>
                  <SelectItem value="sales">Drive Sales</SelectItem>
                  <SelectItem value="signups">Get Sign-ups</SelectItem>
                  <SelectItem value="awareness">Build Awareness</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-white">Tone</Label>
              <Select value={businessInfo.tone} onValueChange={(v) => setBusinessInfo({ ...businessInfo, tone: v })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="authoritative">Authoritative</SelectItem>
                  <SelectItem value="playful">Playful</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Content
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {generatedContent && (
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Generated Content</CardTitle>
              <Button
                onClick={() => onApply(generatedContent)}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                Apply to Page
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-white">Headline</Label>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(generatedContent.headline, 'headline')}
                >
                  {copiedField === 'headline' ? (
                    <Check className="w-4 h-4 text-green-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <p className="text-2xl font-bold text-white bg-slate-800 p-4 rounded-lg">
                {generatedContent.headline}
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-white">Subheadline</Label>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(generatedContent.subheadline, 'subheadline')}
                >
                  {copiedField === 'subheadline' ? (
                    <Check className="w-4 h-4 text-green-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <p className="text-slate-300 bg-slate-800 p-4 rounded-lg">
                {generatedContent.subheadline}
              </p>
            </div>

            <div>
              <Label className="text-white mb-2 block">Key Features</Label>
              <div className="grid gap-3">
                {generatedContent.features?.map((feature, i) => (
                  <div key={i} className="bg-slate-800 p-4 rounded-lg">
                    <h4 className="font-semibold text-white mb-1">{feature.title}</h4>
                    <p className="text-sm text-slate-400">{feature.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-white mb-2 block">Testimonial</Label>
              <div className="bg-slate-800 p-4 rounded-lg">
                <p className="text-white italic mb-2">"{generatedContent.testimonial?.quote}"</p>
                <p className="text-sm text-slate-400">
                  — {generatedContent.testimonial?.author}, {generatedContent.testimonial?.company}
                </p>
              </div>
            </div>

            <div>
              <Label className="text-white mb-2 block">Call to Action</Label>
              <div className="bg-slate-800 p-4 rounded-lg space-y-2">
                <p className="text-white">{generatedContent.cta_text}</p>
                <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
                  {generatedContent.cta_button}
                </Button>
              </div>
            </div>

            <div className="border-t border-slate-700 pt-4">
              <Label className="text-white mb-2 block">SEO</Label>
              <div className="space-y-2">
                <div>
                  <p className="text-xs text-slate-500">Meta Title</p>
                  <p className="text-sm text-slate-300">{generatedContent.seo_title}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Meta Description</p>
                  <p className="text-sm text-slate-300">{generatedContent.seo_description}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}