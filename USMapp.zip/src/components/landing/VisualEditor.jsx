import React, { useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { 
  Type, Image as ImageIcon, Video, Layout, 
  Plus, Trash2, GripVertical, Save, Eye 
} from 'lucide-react';
import { cn } from '@/lib/utils';

const blockTypes = [
  { id: 'hero', icon: Layout, label: 'Hero Section', defaultContent: { title: 'Welcome', subtitle: 'Your amazing headline here', image: '' } },
  { id: 'text', icon: Type, label: 'Text Block', defaultContent: { content: 'Add your content here...' } },
  { id: 'image', icon: ImageIcon, label: 'Image', defaultContent: { url: '', alt: 'Image' } },
  { id: 'cta', icon: Layout, label: 'Call to Action', defaultContent: { text: 'Get Started', url: '#', buttonText: 'Click Here' } },
  { id: 'features', icon: Layout, label: 'Features Grid', defaultContent: { items: [
    { title: 'Feature 1', description: 'Description' },
    { title: 'Feature 2', description: 'Description' },
    { title: 'Feature 3', description: 'Description' }
  ]}},
  { id: 'testimonial', icon: Type, label: 'Testimonial', defaultContent: { quote: 'Great product!', author: 'Customer Name', company: 'Company' } },
];

export default function VisualEditor({ page, onSave }) {
  const [blocks, setBlocks] = useState(page.blocks || []);
  const [selectedBlock, setSelectedBlock] = useState(null);
  const [previewMode, setPreviewMode] = useState(false);

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(blocks);
    const [reordered] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reordered);
    setBlocks(items);
  };

  const addBlock = (type) => {
    const blockType = blockTypes.find(b => b.id === type);
    const newBlock = {
      id: `block-${Date.now()}`,
      type,
      content: blockType.defaultContent
    };
    setBlocks([...blocks, newBlock]);
    setSelectedBlock(newBlock);
  };

  const updateBlock = (blockId, updates) => {
    setBlocks(blocks.map(b => b.id === blockId ? { ...b, content: { ...b.content, ...updates } } : b));
  };

  const deleteBlock = (blockId) => {
    setBlocks(blocks.filter(b => b.id !== blockId));
    setSelectedBlock(null);
  };

  const renderBlockPreview = (block) => {
    switch (block.type) {
      case 'hero':
        return (
          <div className="bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white p-12 text-center rounded-lg">
            <h1 className="text-4xl font-bold mb-4">{block.content.title}</h1>
            <p className="text-xl opacity-90">{block.content.subtitle}</p>
          </div>
        );
      case 'text':
        return <div className="prose prose-invert max-w-none">{block.content.content}</div>;
      case 'image':
        return block.content.url ? (
          <img src={block.content.url} alt={block.content.alt} className="w-full rounded-lg" />
        ) : (
          <div className="bg-slate-800 h-64 rounded-lg flex items-center justify-center">
            <ImageIcon className="w-12 h-12 text-slate-600" />
          </div>
        );
      case 'cta':
        return (
          <div className="bg-slate-800 p-8 rounded-lg text-center">
            <h3 className="text-2xl font-bold text-white mb-2">{block.content.text}</h3>
            <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600 mt-4">
              {block.content.buttonText}
            </Button>
          </div>
        );
      case 'features':
        return (
          <div className="grid grid-cols-3 gap-4">
            {block.content.items.map((item, i) => (
              <div key={i} className="bg-slate-800 p-6 rounded-lg">
                <h4 className="font-bold text-white mb-2">{item.title}</h4>
                <p className="text-slate-400 text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        );
      case 'testimonial':
        return (
          <div className="bg-slate-800 p-6 rounded-lg">
            <p className="text-white italic mb-4">"{block.content.quote}"</p>
            <p className="text-slate-400 text-sm">— {block.content.author}, {block.content.company}</p>
          </div>
        );
      default:
        return <div>Unknown block type</div>;
    }
  };

  const renderBlockEditor = (block) => {
    if (!block) return null;

    switch (block.type) {
      case 'hero':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">Title</Label>
              <Input
                value={block.content.title}
                onChange={(e) => updateBlock(block.id, { title: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
            <div>
              <Label className="text-white">Subtitle</Label>
              <Textarea
                value={block.content.subtitle}
                onChange={(e) => updateBlock(block.id, { subtitle: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
            <div>
              <Label className="text-white">Background Image URL</Label>
              <Input
                value={block.content.image}
                onChange={(e) => updateBlock(block.id, { image: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
          </div>
        );
      case 'text':
        return (
          <div>
            <Label className="text-white">Content</Label>
            <Textarea
              value={block.content.content}
              onChange={(e) => updateBlock(block.id, { content: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white mt-2 min-h-[200px]"
            />
          </div>
        );
      case 'image':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">Image URL</Label>
              <Input
                value={block.content.url}
                onChange={(e) => updateBlock(block.id, { url: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
            <div>
              <Label className="text-white">Alt Text</Label>
              <Input
                value={block.content.alt}
                onChange={(e) => updateBlock(block.id, { alt: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
          </div>
        );
      case 'cta':
        return (
          <div className="space-y-4">
            <div>
              <Label className="text-white">Heading</Label>
              <Input
                value={block.content.text}
                onChange={(e) => updateBlock(block.id, { text: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
            <div>
              <Label className="text-white">Button Text</Label>
              <Input
                value={block.content.buttonText}
                onChange={(e) => updateBlock(block.id, { buttonText: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
            <div>
              <Label className="text-white">Button URL</Label>
              <Input
                value={block.content.url}
                onChange={(e) => updateBlock(block.id, { url: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>
          </div>
        );
      default:
        return <div className="text-slate-400">Editor for {block.type} coming soon...</div>;
    }
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      {/* Blocks Sidebar */}
      <div className="w-64 bg-slate-900 rounded-lg border border-slate-800 p-4 space-y-2">
        <h3 className="text-white font-semibold mb-4">Add Blocks</h3>
        {blockTypes.map((type) => (
          <Button
            key={type.id}
            variant="outline"
            onClick={() => addBlock(type.id)}
            className="w-full justify-start border-slate-700 text-white"
          >
            <type.icon className="w-4 h-4 mr-2" />
            {type.label}
          </Button>
        ))}
      </div>

      {/* Canvas */}
      <div className="flex-1 bg-slate-900 rounded-lg border border-slate-800 overflow-auto">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-white font-semibold">Canvas</h3>
          <div className="flex gap-2">
            <Button
              variant={previewMode ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPreviewMode(!previewMode)}
              className="border-slate-700"
            >
              <Eye className="w-4 h-4 mr-2" />
              {previewMode ? 'Edit' : 'Preview'}
            </Button>
            <Button
              size="sm"
              onClick={() => onSave({ ...page, blocks })}
              className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
            >
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
          </div>
        </div>

        <div className="p-8">
          {blocks.length === 0 ? (
            <div className="text-center py-12 text-slate-500">
              <Layout className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Add blocks from the sidebar to start building</p>
            </div>
          ) : (
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="canvas">
                {(provided) => (
                  <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-4">
                    {blocks.map((block, index) => (
                      <Draggable key={block.id} draggableId={block.id} index={index}>
                        {(provided, snapshot) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            className={cn(
                              "bg-slate-800/50 rounded-lg border-2 transition-colors",
                              selectedBlock?.id === block.id ? 'border-violet-500' : 'border-slate-700',
                              snapshot.isDragging && 'shadow-2xl'
                            )}
                          >
                            <div className="flex items-center gap-2 p-2 border-b border-slate-700">
                              <div {...provided.dragHandleProps}>
                                <GripVertical className="w-4 h-4 text-slate-500 cursor-grab" />
                              </div>
                              <span className="text-xs text-slate-400 flex-1">
                                {blockTypes.find(t => t.id === block.type)?.label}
                              </span>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => setSelectedBlock(block)}
                                className="h-6 px-2 text-xs"
                              >
                                Edit
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => deleteBlock(block.id)}
                                className="h-6 px-2 text-rose-400"
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                            <div className="p-4">
                              {renderBlockPreview(block)}
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          )}
        </div>
      </div>

      {/* Properties Sidebar */}
      <div className="w-80 bg-slate-900 rounded-lg border border-slate-800 p-4">
        <h3 className="text-white font-semibold mb-4">Properties</h3>
        {selectedBlock ? (
          <div className="space-y-4">
            {renderBlockEditor(selectedBlock)}
            <Button
              variant="outline"
              onClick={() => deleteBlock(selectedBlock.id)}
              className="w-full border-rose-700 text-rose-400"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Block
            </Button>
          </div>
        ) : (
          <p className="text-slate-500 text-sm">Select a block to edit its properties</p>
        )}
      </div>
    </div>
  );
}