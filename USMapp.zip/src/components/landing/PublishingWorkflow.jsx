import React from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Rocket, Eye, Globe, Server, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import moment from 'moment';

export default function PublishingWorkflow({ page }) {
  const queryClient = useQueryClient();

  const deployToStagingMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('deployPage', {
        page_id: page.id,
        environment: 'staging'
      });
      return response.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Deployed to staging!');
    },
    onError: () => {
      toast.error('Staging deployment failed');
    }
  });

  const deployToProductionMutation = useMutation({
    mutationFn: async () => {
      const response = await base44.functions.invoke('deployPage', {
        page_id: page.id,
        environment: 'production'
      });
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Published to production!');
    },
    onError: () => {
      toast.error('Production deployment failed');
    }
  });

  const isPublished = page.is_published;
  const hasStaging = page.staging_active;
  const lastDeployed = page.deployment?.last_deployed;
  const stagingUrl = page.deployment?.staging_url || `https://staging-${page.slug}.pages.app`;
  const productionUrl = page.domain_settings?.custom_domain 
    ? `https://${page.domain_settings.custom_domain}`
    : page.deployment?.production_url || `https://${page.slug}.pages.app`;

  return (
    <Card className="bg-slate-900/50 border-slate-800">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <Rocket className="w-5 h-5" />
          Publishing Workflow
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Status */}
        <div className="flex items-center gap-3">
          <Badge className={isPublished ? 'bg-green-500/10 text-green-400' : 'bg-slate-500/10 text-slate-400'}>
            {isPublished ? 'Published' : 'Draft'}
          </Badge>
          {page.deployment?.cdn_enabled && (
            <Badge className="bg-blue-500/10 text-blue-400">
              <Server className="w-3 h-3 mr-1" />
              CDN Enabled
            </Badge>
          )}
          {lastDeployed && (
            <span className="text-xs text-slate-400">
              Last deployed {moment(lastDeployed).fromNow()}
            </span>
          )}
        </div>

        {/* Staging Environment */}
        <div className="p-4 bg-slate-800/50 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                <Eye className="w-4 h-4 text-yellow-400" />
                Staging Environment
              </h4>
              <p className="text-xs text-slate-400 mt-1">Preview changes before going live</p>
            </div>
            {hasStaging && (
              <Badge className="bg-yellow-500/10 text-yellow-400">Active</Badge>
            )}
          </div>

          {hasStaging && (
            <a
              href={stagingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs text-slate-300 hover:text-white"
            >
              {stagingUrl} <ExternalLink className="w-3 h-3" />
            </a>
          )}

          <Button
            onClick={() => deployToStagingMutation.mutate()}
            disabled={deployToStagingMutation.isPending}
            className="w-full bg-yellow-600 hover:bg-yellow-700"
          >
            {deployToStagingMutation.isPending ? 'Deploying...' : hasStaging ? 'Update Staging' : 'Deploy to Staging'}
          </Button>
        </div>

        {/* Production Environment */}
        <div className="p-4 bg-slate-800/50 rounded-lg space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                <Globe className="w-4 h-4 text-green-400" />
                Production
              </h4>
              <p className="text-xs text-slate-400 mt-1">Live site visible to visitors</p>
            </div>
            {isPublished && (
              <Badge className="bg-green-500/10 text-green-400">Live</Badge>
            )}
          </div>

          {isPublished && (
            <a
              href={productionUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs text-slate-300 hover:text-white"
            >
              {productionUrl} <ExternalLink className="w-3 h-3" />
            </a>
          )}

          <Button
            onClick={() => deployToProductionMutation.mutate()}
            disabled={deployToProductionMutation.isPending}
            className="w-full bg-green-600 hover:bg-green-700"
          >
            <Rocket className="w-4 h-4 mr-2" />
            {deployToProductionMutation.isPending ? 'Publishing...' : isPublished ? 'Update Production' : 'Publish to Production'}
          </Button>
        </div>

        {/* Deployment Info */}
        <div className="text-xs text-slate-400 space-y-1 pt-2 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <span>CDN Distribution</span>
            <Badge className="bg-blue-500/10 text-blue-400">Global</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span>SSL Certificate</span>
            <Badge className="bg-green-500/10 text-green-400">Auto-provisioned</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span>Cache TTL</span>
            <span className="text-slate-300">24 hours</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}