import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Zap,
  Calendar,
  MessageSquare,
  TrendingUp,
  Target,
  Clock,
  Sparkles,
  CheckCircle2,
  Play,
  Pause,
  Settings,
  Mic,
  MicOff,
  Wand2,
  Square,
  Volume2,
  MessageCircle,
  HelpCircle,
  User,
  Sliders
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

const autopilotFeatures = [
  {
    id: 'auto_content',
    name: 'Auto Content Generation',
    description: 'Automatically create and schedule posts based on your strategy',
    helpText: 'AI generates content ideas, captions, and images based on your past performance and current trends. Posts are created automatically when your calendar has gaps.',
    icon: Sparkles,
    color: 'text-violet-400',
    bgColor: 'bg-violet-500/10'
  },
  {
    id: 'smart_scheduling',
    name: 'Smart Scheduling',
    description: 'Post at optimal times based on audience engagement patterns',
    helpText: 'Analyzes your audience engagement history to determine the best times to post. Automatically schedules content when your followers are most active.',
    icon: Clock,
    color: 'text-blue-400',
    bgColor: 'bg-blue-500/10'
  },
  {
    id: 'auto_responses',
    name: 'Auto Responses',
    description: 'Automatically reply to messages and comments intelligently',
    helpText: 'AI reads incoming messages and comments, then generates contextual responses based on your brand voice. You can review and edit before they are sent.',
    icon: MessageSquare,
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-500/10'
  },
  {
    id: 'performance_optimization',
    name: 'Performance Optimization',
    description: 'Analyze results and adjust content strategy automatically',
    helpText: 'Continuously monitors post performance and adjusts content strategy. Identifies what works and automatically creates similar high-performing content.',
    icon: TrendingUp,
    color: 'text-orange-400',
    bgColor: 'bg-orange-500/10'
  },
  {
    id: 'calendar_filling',
    name: 'Calendar Auto-Fill',
    description: 'Keep your content calendar filled with relevant posts',
    helpText: 'Ensures your calendar always has scheduled content. When gaps are detected, AI generates posts to maintain consistent publishing schedule.',
    icon: Calendar,
    color: 'text-pink-400',
    bgColor: 'bg-pink-500/10'
  },
  {
    id: 'goal_tracking',
    name: 'Goal Achievement',
    description: 'Work towards your goals with automated actions',
    helpText: 'Tracks your goals (followers, engagement, conversions) and takes automated actions to help achieve them, like boosting underperforming content or creating goal-specific posts.',
    icon: Target,
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-500/10'
  }
];

const navigationMap = {
  'dashboard': 'Dashboard',
  'calendar': 'Calendar',
  'create post': 'CreatePost',
  'analytics': 'Analytics',
  'inbox': 'Inbox',
  'settings': 'Settings',
  'competitors': 'Competitors',
  'hashtags': 'Hashtags',
  'media library': 'MediaLibrary',
  'reports': 'Reports',
  'team': 'Team',
  'campaigns': 'CampaignPlanner',
  'chatbot': 'Chatbot',
  'goals': 'Goals',
  'automation': 'Automation',
  'strategy': 'Strategy',
  'link in bio': 'LinkInBio',
  'influencers': 'Influencers',
  'brand monitor': 'BrandMonitor'
};

export default function FloatingAutopilot({ externalOpen, onExternalOpenChange }) {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  
  // Sync with external control
  React.useEffect(() => {
    if (externalOpen !== undefined) {
      setIsOpen(externalOpen);
    }
  }, [externalOpen]);
  
  const handleOpenChange = (open) => {
    setIsOpen(open);
    if (onExternalOpenChange) {
      onExternalOpenChange(open);
    }
    
    // Auto-close after 10 seconds when opened
    if (open) {
      setTimeout(() => {
        setIsOpen(false);
        if (onExternalOpenChange) {
          onExternalOpenChange(false);
        }
      }, 10000);
    }
  };
  const [autopilotActive, setAutopilotActive] = useState(false);
  const [enabledFeatures, setEnabledFeatures] = useState({
    auto_content: true,
    smart_scheduling: true,
    auto_responses: true,
    performance_optimization: true,
    calendar_filling: true,
    goal_tracking: true
  });
  const [aggressiveness, setAggressiveness] = useState([50]);
  const [isListening, setIsListening] = useState(false);
  const [isRecordingPrompt, setIsRecordingPrompt] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [recordedPrompt, setRecordedPrompt] = useState('');
  const [conversationMode, setConversationMode] = useState(false);
  const [conversation, setConversation] = useState([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [onboardingProgress, setOnboardingProgress] = useState({
    accounts_connected: false,
    first_post_created: false,
    calendar_viewed: false,
    autopilot_explained: false
  });
  const [aiSettings, setAiSettings] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const recognitionRef = useRef(null);
  const promptRecognitionRef = useRef(null);
  const conversationRecognitionRef = useRef(null);
  const isRecognitionRunning = useRef(false);
  const isConversationRunning = useRef(false);

  const activeCount = Object.values(enabledFeatures).filter(Boolean).length;

  // Load AI settings
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const settings = await base44.entities.AISettings.list();
        if (settings.length > 0) {
          setAiSettings(settings[0]);
        } else {
          // Create default settings
          const newSettings = await base44.entities.AISettings.create({
            assistant_name: 'Assistant',
            voice_gender: 'female',
            personality: 'friendly',
            character_style: 'helper',
            voice_tone: 'warm',
            voice_pitch: 1.0,
            voice_speed: 1.1
          });
          setAiSettings(newSettings);
        }
      } catch (error) {
        console.error('Failed to load AI settings:', error);
      }
    };
    loadSettings();
  }, []);

  const saveAiSettings = async (updates) => {
    if (!aiSettings) return;
    try {
      const updated = await base44.entities.AISettings.update(aiSettings.id, updates);
      setAiSettings(updated);
      toast.success('Settings saved');
    } catch (error) {
      console.error('Failed to save settings:', error);
      toast.error('Failed to save settings');
    }
  };

  const toggleFeature = (featureId) => {
    setEnabledFeatures(prev => ({
      ...prev,
      [featureId]: !prev[featureId]
    }));
  };

  // Text-to-speech function
  const speak = (text) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      
      setTimeout(() => {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = aiSettings?.voice_speed || 1.1;
        utterance.pitch = aiSettings?.voice_pitch || 1.0;
        utterance.volume = 1.0;
        utterance.lang = 'en-US';
        
        // Select voice based on gender preference
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0 && aiSettings?.voice_gender) {
          const gender = aiSettings.voice_gender;
          let selectedVoice;
          
          if (gender === 'female') {
            selectedVoice = voices.find(v => v.name.includes('Female') || v.name.includes('Woman') || v.name.includes('Samantha') || v.name.includes('Victoria'));
          } else if (gender === 'male') {
            selectedVoice = voices.find(v => v.name.includes('Male') || v.name.includes('Man') || v.name.includes('Daniel') || v.name.includes('Alex'));
          }
          
          if (selectedVoice) {
            utterance.voice = selectedVoice;
          }
        }
        
        utterance.onstart = () => {
          setIsSpeaking(true);
          console.log('Speaking:', text);
        };
        utterance.onend = () => {
          setIsSpeaking(false);
          console.log('Finished speaking');
        };
        utterance.onerror = (e) => {
          setIsSpeaking(false);
          console.error('Speech error:', e);
        };
        
        window.speechSynthesis.speak(utterance);
      }, 100);
    }
  };

  // Process navigation voice commands
  const processNavigationCommand = (transcript) => {
    const lowerTranscript = transcript.toLowerCase();
    
    for (const [keyword, page] of Object.entries(navigationMap)) {
      if (lowerTranscript.includes(keyword) || 
          lowerTranscript.includes(`go to ${keyword}`) ||
          lowerTranscript.includes(`open ${keyword}`) ||
          lowerTranscript.includes(`show ${keyword}`)) {
        navigate(createPageUrl(page));
        speak(`Opening ${keyword}`);
        toast.success(`📍 Opening ${keyword}`);
        return true;
      }
    }
    return false;
  };

  // Onboarding handler
  const startOnboarding = async () => {
    setIsOnboarding(true);
    setOnboardingProgress({
      accounts_connected: false,
      first_post_created: false,
      calendar_viewed: false,
      autopilot_explained: false
    });
    setConversation([]);
    
    const name = aiSettings?.assistant_name || 'Assistant';
    const welcomeMsg = `Hi! I'm ${name}. I'm here to help you get started with Ultimate Social Media. Think of me as your personal guide - feel free to ask me anything! To begin, would you like me to walk you through connecting your social media accounts?`;
    setConversation([{ role: 'assistant', text: welcomeMsg, timestamp: Date.now() }]);
    speak(welcomeMsg);
  };

  const handleOnboardingConversation = async (transcript) => {
    try {
      // Build context about what's been done
      const progressSummary = `
Onboarding Progress:
- Social accounts connected: ${onboardingProgress.accounts_connected ? 'Yes' : 'No - NEXT STEP'}
- First post created: ${onboardingProgress.first_post_created ? 'Yes' : onboardingProgress.accounts_connected ? 'No - NEXT STEP' : 'Not yet (need accounts first)'}
- Calendar viewed: ${onboardingProgress.calendar_viewed ? 'Yes' : onboardingProgress.first_post_created ? 'No - NEXT STEP' : 'Not yet'}
- Autopilot explained: ${onboardingProgress.autopilot_explained ? 'Yes' : 'Not yet'}
${!onboardingProgress.accounts_connected && !onboardingProgress.first_post_created && !onboardingProgress.calendar_viewed && !onboardingProgress.autopilot_explained ? 'STATUS: Just starting onboarding' : ''}
`;

      const conversationHistory = conversation.slice(-4).map(msg => `${msg.role}: ${msg.text}`).join('\n');

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are ${aiSettings?.assistant_name || 'an AI assistant'} helping a user get started with Ultimate Social Media platform. Be conversational, helpful, and natural like ChatGPT.

${progressSummary}

Available pages you can navigate to: Settings (to connect accounts), CreatePost (to create first post), Calendar (to see schedule), and many others.

Previous conversation:
${conversationHistory}

User just said: "${transcript}"

Based on their response and progress:
1. Interpret what they mean naturally (yes/sure/ok/let's do it = agreement, skip/later/not now = skip, what/how/tell me more = question)
2. If they agree to next step, navigate them there
3. If they ask questions, answer helpfully
4. If they want to skip, that's okay - suggest next step
5. Track what they've completed

Respond conversationally in under 40 words. If you need to navigate, clearly state where you're taking them.`,
        response_json_schema: {
          type: 'object',
          properties: {
            response_text: { type: 'string' },
            action: { 
              type: 'string',
              enum: ['navigate', 'explain', 'continue', 'complete']
            },
            navigate_to: { type: 'string' },
            update_progress: {
              type: 'object',
              properties: {
                accounts_connected: { type: 'boolean' },
                first_post_created: { type: 'boolean' },
                calendar_viewed: { type: 'boolean' },
                autopilot_explained: { type: 'boolean' }
              }
            }
          }
        }
      });

      console.log('Onboarding AI response:', response);

      // Add AI response to conversation
      setConversation(prev => [...prev, { role: 'assistant', text: response.response_text, timestamp: Date.now() }]);
      speak(response.response_text);

      // Handle actions
      if (response.action === 'navigate' && response.navigate_to) {
        const pageMap = {
          'settings': 'Settings',
          'createpost': 'CreatePost',
          'calendar': 'Calendar',
          'dashboard': 'App'
        };
        const page = pageMap[response.navigate_to.toLowerCase()] || response.navigate_to;
        setTimeout(() => navigate(createPageUrl(page)), 1000);
      }

      // Update progress
      if (response.update_progress) {
        setOnboardingProgress(prev => ({
          ...prev,
          ...response.update_progress
        }));
      }

      // Check if complete
      if (response.action === 'complete' || 
          (onboardingProgress.accounts_connected && 
           onboardingProgress.first_post_created && 
           onboardingProgress.calendar_viewed && 
           onboardingProgress.autopilot_explained)) {
        setTimeout(() => {
          setIsOnboarding(false);
          toast.success('🎉 Onboarding complete!');
        }, 2000);
      }

    } catch (error) {
      console.error('Onboarding error:', error);
      const errorMsg = "Sorry, I had trouble understanding that. Could you rephrase?";
      setConversation(prev => [...prev, { role: 'assistant', text: errorMsg, timestamp: Date.now() }]);
      speak(errorMsg);
    }
  };

  // Conversation mode handler
  const handleConversation = async (transcript) => {
    console.log('Handling conversation:', transcript);
    
    setConversation(prev => [...prev, { role: 'user', text: transcript, timestamp: Date.now() }]);
    
    // Check if in onboarding mode
    if (isOnboarding) {
      handleOnboardingConversation(transcript);
      return;
    }
    
    try {
      const conversationHistory = conversation.slice(-5).map(msg => `${msg.role}: ${msg.text}`).join('\n');
      
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are ${aiSettings?.assistant_name || 'an AI assistant'}, a ${aiSettings?.personality || 'friendly'} ${aiSettings?.character_style || 'helper'} for Ultimate Social Media platform. 

Personality: ${aiSettings?.personality || 'friendly'}, ${aiSettings?.voice_tone || 'warm'} tone. Sound natural, conversational, and human-like.

Available pages: ${Object.keys(navigationMap).join(', ')}.

Previous conversation:
${conversationHistory}

User said: "${transcript}"

Respond naturally and conversationally. If navigation is needed, confirm warmly. If asking about features, explain briefly. Keep under 30 words but sound human, not robotic.`,
        add_context_from_internet: false
      });

      console.log('AI response:', response);
      setConversation(prev => [...prev, { role: 'assistant', text: response, timestamp: Date.now() }]);
      
      // Speak after a short delay to ensure state is updated
      setTimeout(() => speak(response), 200);
    } catch (error) {
      console.error('Conversation error:', error);
      const errorMsg = "Sorry, I had trouble processing that. Could you repeat?";
      setConversation(prev => [...prev, { role: 'assistant', text: errorMsg, timestamp: Date.now() }]);
      setTimeout(() => speak(errorMsg), 200);
    }
  };

  const toggleVoiceControl = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      setIsListening(false);
      toast.info('Voice control disabled');
    } else {
      // Make sure conversation mode is off
      if (conversationMode) {
        toast.error('Please disable conversation mode first');
        return;
      }
      
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
        } catch (e) {
          console.log('Already running');
        }
      }
      setIsListening(true);
      toast.success('🎤 Listening for commands');
    }
  };

  const toggleConversationMode = () => {
    const newMode = !conversationMode;
    
    // Stop main voice control if active
    if (newMode && isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      setIsListening(false);
    }
    
    setConversationMode(newMode);
    
    if (newMode) {
      const name = aiSettings?.assistant_name || 'Assistant';
      speak(`${name} here. Conversation mode activated. How can I help you today?`);
      toast.success('🎤 Voice conversation active');
    } else {
      // Clean up conversation mode
      if (conversationRecognitionRef.current) {
        conversationRecognitionRef.current.stop();
        conversationRecognitionRef.current = null;
      }
      window.speechSynthesis.cancel();
      setConversation([]);
      toast.success('Voice conversation ended');
    }
  };

  const startPromptRecording = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error('Voice recognition not supported');
      return;
    }

    promptRecognitionRef.current = new SpeechRecognition();
    promptRecognitionRef.current.continuous = true;
    promptRecognitionRef.current.interimResults = true;

    promptRecognitionRef.current.onresult = (event) => {
      let transcript = '';
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setRecordedPrompt(transcript);
    };

    promptRecognitionRef.current.start();
    setIsRecordingPrompt(true);
    speak('Listening... describe your campaign or product');
    toast.success('🎤 Recording your campaign description...');
  };

  const stopPromptRecording = () => {
    promptRecognitionRef.current?.stop();
    setIsRecordingPrompt(false);
    if (recordedPrompt.trim()) {
      generateAndPost();
    } else {
      toast.error('No prompt recorded');
    }
  };

  const generateAndPost = async () => {
    if (!recordedPrompt.trim()) {
      toast.error('Please record a prompt first');
      return;
    }

    setIsGenerating(true);
    try {
      const user = await base44.auth.me();
      speak('Creating your campaign. This will take a moment.');
      
      toast.info('🚀 Creating full campaign with multiple posts...');
      
      // Extract image references from prompt
      const lowerPrompt = recordedPrompt.toLowerCase();
      let imageDescriptions = [];
      if (lowerPrompt.includes('picture') || lowerPrompt.includes('photo') || lowerPrompt.includes('image')) {
        // Extract description of images mentioned
        imageDescriptions = [recordedPrompt];
      }
      
      // Call the comprehensive campaign creation function
      const campaignResult = await base44.functions.invoke('createCampaignFromVoice', {
        productDescription: recordedPrompt,
        imageDescriptions
      });

      if (campaignResult.data.success) {
        toast.info('📧 Sending campaign for approval...');
        
        // Send approval email with all posts and strategy
        await base44.functions.invoke('sendCampaignApprovalEmail', {
          campaignId: campaignResult.data.campaign.id,
          posts: campaignResult.data.posts,
          strategy: campaignResult.data.strategy,
          userEmail: user.email
        });

        speak('Campaign created successfully with multiple posts, video scripts, and a master strategy. Check your email to approve and I will handle the rest.');
        toast.success('✅ Full campaign generated! Check your email to approve.');
        setRecordedPrompt('');
        
        // Optionally open the campaign planner
        setTimeout(() => {
          navigate(createPageUrl('CampaignPlanner'));
        }, 2000);
      } else {
        throw new Error('Campaign creation failed');
      }
    } catch (error) {
      speak('Sorry, I encountered an error creating the campaign. Please try again.');
      toast.error('Failed to generate campaign: ' + error.message);
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  // Main voice recognition for autopilot toggle and navigation
  useEffect(() => {
    // Don't run if conversation mode is active
    if (conversationMode) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      return;
    }

    if (!isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error('Speech recognition not supported');
      return;
    }

    if (!recognitionRef.current) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = false;
      
      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        const lowerTranscript = transcript.toLowerCase();
        const currentActiveCount = Object.values(enabledFeatures).filter(Boolean).length;
        
        if (lowerTranscript.includes('autopilot on') || lowerTranscript.includes('activate autopilot') || lowerTranscript.includes('start autopilot')) {
          if (currentActiveCount > 0) {
            setAutopilotActive(true);
            speak('Autopilot activated');
            toast.success('🚀 Autopilot activated');
          } else {
            speak('Please enable at least one feature first');
            toast.error('Enable at least one feature first');
          }
        } else if (lowerTranscript.includes('autopilot off') || lowerTranscript.includes('deactivate autopilot') || lowerTranscript.includes('stop autopilot')) {
          setAutopilotActive(false);
          speak('Autopilot deactivated');
          toast.success('✋ Autopilot deactivated');
        } else {
          processNavigationCommand(transcript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        isRecognitionRunning.current = false;
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
          console.error('Speech recognition error:', event.error);
        }
      };

      recognitionRef.current.onstart = () => {
        isRecognitionRunning.current = true;
      };

      recognitionRef.current.onend = () => {
        isRecognitionRunning.current = false;
      };

      try {
        recognitionRef.current.start();
        isRecognitionRunning.current = true;
      } catch (e) {
        console.error('Failed to start recognition:', e);
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
        recognitionRef.current = null;
      }
    };
  }, [isListening, conversationMode, enabledFeatures]);

  // Conversation mode recognition
  useEffect(() => {
    if (!conversationMode) {
      if (conversationRecognitionRef.current) {
        conversationRecognitionRef.current.stop();
        conversationRecognitionRef.current = null;
      }
      window.speechSynthesis.cancel();
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error('Speech recognition not supported in your browser');
      return;
    }

    // Only create if doesn't exist
    if (!conversationRecognitionRef.current) {
      conversationRecognitionRef.current = new SpeechRecognition();
      conversationRecognitionRef.current.continuous = true;
      conversationRecognitionRef.current.interimResults = false;
      conversationRecognitionRef.current.lang = 'en-US';
      
      conversationRecognitionRef.current.onresult = (event) => {
        const transcript = event.results[event.results.length - 1][0].transcript;
        console.log('Voice input:', transcript);
        
        // Check for navigation first
        if (!processNavigationCommand(transcript)) {
          // If not navigation, handle as conversation
          handleConversation(transcript);
        }
      };

      conversationRecognitionRef.current.onerror = (event) => {
        isConversationRunning.current = false;
        console.error('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          toast.error('Microphone access denied');
        } else if (event.error !== 'no-speech' && event.error !== 'aborted') {
          toast.error('Voice recognition error');
        }
      };

      conversationRecognitionRef.current.onstart = () => {
        isConversationRunning.current = true;
      };

      conversationRecognitionRef.current.onend = () => {
        isConversationRunning.current = false;
      };

      try {
        conversationRecognitionRef.current.start();
        isConversationRunning.current = true;
        console.log('Conversation mode started');
      } catch (e) {
        console.error('Failed to start recognition:', e);
      }
    }

    return () => {
      if (conversationRecognitionRef.current) {
        conversationRecognitionRef.current.stop();
        conversationRecognitionRef.current = null;
      }
      window.speechSynthesis.cancel();
    };
  }, [conversationMode]);

  return (
    <>
      <Sheet open={isOpen} onOpenChange={handleOpenChange}>
        <SheetTrigger asChild>
          <Button
            size="lg"
            className={cn(
              "fixed bottom-6 right-6 z-50 h-14 px-6 rounded-full shadow-2xl transition-all duration-300",
              autopilotActive
                ? "bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 animate-pulse"
                : "bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600"
            )}
          >
            <Zap className="w-5 h-5 mr-2" />
            Autopilot
            {(activeCount > 0 || conversationMode) && (
              <Badge className="ml-2 bg-white/20 text-white border-0">
                {activeCount}{conversationMode && ' 🎤'}
              </Badge>
            )}
          </Button>
        </SheetTrigger>

        <SheetContent className="w-full sm:max-w-xl bg-slate-950 border-slate-800">
          <SheetHeader>
            <SheetTitle className="text-2xl text-white flex items-center gap-2">
              <Zap className="w-6 h-6 text-violet-400" />
              {aiSettings?.assistant_name || 'AI Autopilot'}
            </SheetTitle>
            <SheetDescription className="text-slate-400">
              Voice-controlled AI assistant for your social media
            </SheetDescription>
            
            {/* Voice Control Buttons */}
            <div className="flex gap-3 pt-4">
              <Button
                onClick={toggleConversationMode}
                className={cn(
                  "flex-1",
                  conversationMode 
                    ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-300 hover:bg-emerald-500/30" 
                    : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700"
                )}
                variant="outline"
              >
                {conversationMode ? (
                  <>
                    <MessageCircle className="w-4 h-4 mr-2 animate-pulse" />
                    Conversation Mode ON
                  </>
                ) : (
                  <>
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Conversation Mode OFF
                  </>
                )}
              </Button>
              <Button
                onClick={toggleVoiceControl}
                className={cn(
                  "flex-1",
                  isListening 
                    ? "bg-red-500/20 border-red-500/50 text-red-300 hover:bg-red-500/30" 
                    : "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700"
                )}
                variant="outline"
              >
                {isListening ? (
                  <>
                    <Mic className="w-4 h-4 mr-2 animate-pulse" />
                    Voice Commands ON
                  </>
                ) : (
                  <>
                    <MicOff className="w-4 h-4 mr-2" />
                    Voice Commands OFF
                  </>
                )}
              </Button>
            </div>
          </SheetHeader>

          <ScrollArea className="h-[calc(100vh-140px)] mt-6 pr-4">
            <Tabs defaultValue="autopilot" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
                <TabsTrigger value="autopilot">
                  <Zap className="w-4 h-4 mr-2" />
                  Autopilot
                </TabsTrigger>
                <TabsTrigger value="conversation">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Talk
                </TabsTrigger>
                <TabsTrigger value="settings">
                  <Sliders className="w-4 h-4 mr-2" />
                  Settings
                </TabsTrigger>
              </TabsList>

              <TabsContent value="autopilot" className="mt-6">
            {/* Onboarding */}
            <div className="mb-6 p-4 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-xl">
              <h4 className="text-sm font-semibold text-white mb-2 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-400" />
                New User?
              </h4>
              <p className="text-xs text-slate-400 mb-3">
                Have a natural conversation with AI while it guides you through setup
              </p>
              <Button
                onClick={() => {
                  startOnboarding();
                  setConversationMode(true);
                }}
                disabled={isOnboarding}
                className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600"
                size="sm"
              >
                {isOnboarding ? 'Onboarding in Progress...' : 'Chat with AI to Get Started'}
              </Button>
            </div>

            {/* Voice Conversation */}
            {conversationMode && (
              <div className="mb-6 p-4 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                    <MessageCircle className="w-4 h-4 text-emerald-400" />
                    {isOnboarding ? '🎓 Getting Started' : 'Voice Conversation'}
                  </h4>
                  {isSpeaking && (
                    <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />
                  )}
                </div>
                {isOnboarding && (
                  <div className="mb-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <div className="flex items-center gap-2 text-xs text-blue-300">
                      <Sparkles className="w-3 h-3" />
                      <span>Onboarding active - Ask me anything!</span>
                    </div>
                  </div>
                )}
                <ScrollArea className="h-64 mb-3 p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                  {conversation.length === 0 ? (
                    <p className="text-xs text-slate-500 text-center py-8">
                      {isOnboarding 
                        ? "I'm listening... speak naturally or ask questions" 
                        : "Start talking... Say things like 'Go to dashboard' or ask questions"}
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {conversation.map((msg, idx) => (
                        <div
                          key={idx}
                          className={cn(
                            "p-3 rounded-lg text-xs",
                            msg.role === 'user'
                              ? 'bg-violet-500/20 text-violet-100 ml-6'
                              : 'bg-emerald-500/20 text-emerald-100 mr-6'
                          )}
                        >
                          <div className="font-semibold mb-1 text-[10px] opacity-70">
                            {msg.role === 'user' ? 'You' : aiSettings?.assistant_name || 'AI'}
                          </div>
                          {msg.text}
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setConversation([]);
                      toast.success('Conversation cleared');
                    }}
                    className="flex-1 text-xs border-slate-700"
                  >
                    Clear
                  </Button>
                  {isOnboarding && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setIsOnboarding(false);
                        setConversation([]);
                        toast.info('Onboarding ended');
                      }}
                      className="flex-1 text-xs border-amber-500/30 text-amber-400"
                    >
                      End Onboarding
                    </Button>
                  )}
                </div>
              </div>
            )}

            {/* Master Switch */}
            <div className="bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 rounded-xl p-4 mb-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {autopilotActive ? (
                    <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
                      <Play className="w-5 h-5 text-emerald-400" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center">
                      <Pause className="w-5 h-5 text-slate-400" />
                    </div>
                  )}
                  <div>
                    <h3 className="font-semibold text-white">
                      Autopilot {autopilotActive ? 'Active' : 'Inactive'}
                    </h3>
                    <p className="text-sm text-slate-400">
                      {autopilotActive ? 'AI is managing your accounts' : 'Enable to start automation'}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={autopilotActive}
                  onCheckedChange={setAutopilotActive}
                  disabled={activeCount === 0}
                />
              </div>
              {activeCount === 0 && (
                <p className="text-xs text-amber-400 mt-3">
                  ⚠️ Enable at least one feature below to activate autopilot
                </p>
              )}
            </div>

            {/* Aggressiveness Slider */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <label className="text-sm font-medium text-white">
                  Automation Level
                </label>
                <span className="text-xs text-slate-400">
                  {aggressiveness[0] < 33 ? 'Conservative' : aggressiveness[0] < 66 ? 'Balanced' : 'Aggressive'}
                </span>
              </div>
              <Slider
                value={aggressiveness}
                onValueChange={setAggressiveness}
                max={100}
                step={1}
                className="mb-2"
              />
              <p className="text-xs text-slate-500">
                Controls how actively AI makes decisions and takes actions
              </p>
            </div>

            <Separator className="mb-6 bg-slate-800" />

            {/* Features */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Automation Features
              </h3>
              {autopilotFeatures.map((feature) => {
                const Icon = feature.icon;
                const isEnabled = enabledFeatures[feature.id];
                const [showHelp, setShowHelp] = useState(false);

                return (
                  <div
                    key={feature.id}
                    className={cn(
                      "p-4 rounded-xl border transition-all",
                      isEnabled
                        ? "bg-slate-800/50 border-violet-500/30"
                        : "bg-slate-900/30 border-slate-800 hover:border-slate-700"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0", feature.bgColor)}>
                        <Icon className={cn("w-5 h-5", feature.color)} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium text-white">{feature.name}</h4>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setShowHelp(!showHelp);
                              }}
                              className="text-slate-400 hover:text-white transition-colors"
                            >
                              <HelpCircle className="w-4 h-4" />
                            </button>
                          </div>
                          <Switch
                            checked={isEnabled}
                            onCheckedChange={() => toggleFeature(feature.id)}
                          />
                        </div>
                        <p className="text-sm text-slate-400">{feature.description}</p>
                        {showHelp && (
                          <div className="mt-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                            <p className="text-xs text-blue-300">{feature.helpText}</p>
                          </div>
                        )}
                        {isEnabled && (
                          <div className="flex items-center gap-1 mt-2">
                            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            <span className="text-xs text-emerald-400">Enabled</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Voice Campaign Generator */}
            <div className="mt-6 p-4 bg-gradient-to-r from-fuchsia-500/10 to-violet-500/10 border border-fuchsia-500/20 rounded-xl">
              <h4 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                <Wand2 className="w-4 h-4 text-fuchsia-400" />
                Voice Campaign Generator
              </h4>
              <p className="text-xs text-slate-400 mb-4">
                Describe your product/campaign and AI will create multiple posts, video scripts, research, and a master strategy
              </p>
              
              {recordedPrompt && (
                <div className="mb-3 p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-xs text-slate-300">{recordedPrompt}</p>
                </div>
              )}

              <div className="flex gap-2">
                {!isRecordingPrompt && !isGenerating && (
                  <Button
                    onClick={startPromptRecording}
                    className="flex-1 bg-gradient-to-r from-fuchsia-500 to-violet-500 hover:from-fuchsia-600 hover:to-violet-600"
                  >
                    <Mic className="w-4 h-4 mr-2" />
                    Start Campaign
                  </Button>
                )}

                {isRecordingPrompt && (
                  <Button
                    onClick={stopPromptRecording}
                    className="flex-1 bg-rose-500 hover:bg-rose-600 animate-pulse"
                  >
                    <Square className="w-4 h-4 mr-2" />
                    Stop & Create Campaign
                  </Button>
                )}

                {isGenerating && (
                  <Button disabled className="flex-1">
                    <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                    Creating Campaign...
                  </Button>
                )}
              </div>
              
              {!isGenerating && (
                <div className="mt-3 text-xs text-slate-500">
                  <p>✨ AI will automatically:</p>
                  <ul className="ml-4 mt-1 space-y-1">
                    <li>• Find relevant images from your library</li>
                    <li>• Research your product online</li>
                    <li>• Create 4 unique posts with captions</li>
                    <li>• Generate video scripts</li>
                    <li>• Build a master strategy</li>
                    <li>• Email you for approval</li>
                  </ul>
                </div>
              )}
            </div>

            {/* Voice Commands Guide */}
            <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
              <h4 className="text-sm font-semibold text-blue-400 mb-2">🎤 Voice Commands</h4>
              <ul className="text-xs text-slate-400 space-y-1">
                <li>• "Go to [page name]" - Navigate anywhere</li>
                <li>• "Autopilot on/off" - Toggle automation</li>
                <li>• "Make me a campaign about..." - Full campaign generation</li>
                <li>• Enable conversation mode for dialog</li>
                <li>• All major features can be triggered by voice</li>
              </ul>
            </div>
              </TabsContent>

              <TabsContent value="conversation" className="mt-6">
                <div className="space-y-4">
                  <Button
                    onClick={toggleConversationMode}
                    className={cn(
                      "w-full",
                      conversationMode 
                        ? "bg-red-500 hover:bg-red-600" 
                        : "bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600"
                    )}
                    size="lg"
                  >
                    {conversationMode ? (
                      <>
                        <Square className="w-5 h-5 mr-2" />
                        End Conversation
                      </>
                    ) : (
                      <>
                        <MessageCircle className="w-5 h-5 mr-2" />
                        Start Voice Conversation
                      </>
                    )}
                  </Button>

                  {conversationMode && (
                    <div className="p-4 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-xl">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                          <MessageCircle className="w-4 h-4 text-emerald-400" />
                          Active Conversation
                        </h4>
                        {isSpeaking && (
                          <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />
                        )}
                      </div>
                      <ScrollArea className="h-96 mb-3 p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                        {conversation.length === 0 ? (
                          <p className="text-xs text-slate-500 text-center py-8">
                            Start talking... Say things like "Go to dashboard" or ask questions
                          </p>
                        ) : (
                          <div className="space-y-3">
                            {conversation.map((msg, idx) => (
                              <div
                                key={idx}
                                className={cn(
                                  "p-3 rounded-lg text-xs",
                                  msg.role === 'user'
                                    ? 'bg-violet-500/20 text-violet-100 ml-6'
                                    : 'bg-emerald-500/20 text-emerald-100 mr-6'
                                )}
                              >
                                <div className="font-semibold mb-1 text-[10px] opacity-70">
                                  {msg.role === 'user' ? 'You' : aiSettings?.assistant_name || 'AI Assistant'}
                                </div>
                                {msg.text}
                              </div>
                            ))}
                          </div>
                        )}
                      </ScrollArea>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setConversation([]);
                          toast.success('Conversation cleared');
                        }}
                        className="w-full text-xs border-slate-700"
                      >
                        Clear Conversation
                      </Button>
                    </div>
                  )}

                  {!conversationMode && (
                    <div className="p-4 bg-slate-800/30 border border-slate-700 rounded-xl">
                      <p className="text-sm text-slate-400 text-center">
                        Click "Start Voice Conversation" to chat with {aiSettings?.assistant_name || 'your AI assistant'}
                      </p>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="settings" className="mt-6">
                {aiSettings && (
                  <div className="space-y-4">
                    <div className="p-4 bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 rounded-xl">
                      <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
                        <User className="w-4 h-4 text-violet-400" />
                        Assistant Identity
                      </h4>
                      
                      <div className="space-y-4">
                        <div>
                          <Label className="text-slate-400 text-xs">Assistant Name</Label>
                          <Input
                            value={aiSettings.assistant_name || ''}
                            onChange={(e) => saveAiSettings({ assistant_name: e.target.value })}
                            placeholder="e.g., Max, Luna, etc."
                            className="mt-1 bg-slate-800/50 border-slate-700 text-white"
                          />
                        </div>

                        <div>
                          <Label className="text-slate-400 text-xs">Voice Gender</Label>
                          <Select 
                            value={aiSettings.voice_gender} 
                            onValueChange={(value) => saveAiSettings({ voice_gender: value })}
                          >
                            <SelectTrigger className="mt-1 bg-slate-800/50 border-slate-700 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-900 border-slate-700">
                              <SelectItem value="female">Female</SelectItem>
                              <SelectItem value="male">Male</SelectItem>
                              <SelectItem value="neutral">Neutral</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-slate-400 text-xs">Personality</Label>
                          <Select 
                            value={aiSettings.personality} 
                            onValueChange={(value) => saveAiSettings({ personality: value })}
                          >
                            <SelectTrigger className="mt-1 bg-slate-800/50 border-slate-700 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-900 border-slate-700">
                              <SelectItem value="professional">Professional</SelectItem>
                              <SelectItem value="friendly">Friendly</SelectItem>
                              <SelectItem value="casual">Casual</SelectItem>
                              <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                              <SelectItem value="witty">Witty</SelectItem>
                              <SelectItem value="formal">Formal</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-slate-400 text-xs">Character Style</Label>
                          <Select 
                            value={aiSettings.character_style} 
                            onValueChange={(value) => saveAiSettings({ character_style: value })}
                          >
                            <SelectTrigger className="mt-1 bg-slate-800/50 border-slate-700 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-900 border-slate-700">
                              <SelectItem value="helper">Helper</SelectItem>
                              <SelectItem value="mentor">Mentor</SelectItem>
                              <SelectItem value="coach">Coach</SelectItem>
                              <SelectItem value="expert">Expert</SelectItem>
                              <SelectItem value="companion">Companion</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label className="text-slate-400 text-xs">Voice Tone</Label>
                          <Select 
                            value={aiSettings.voice_tone} 
                            onValueChange={(value) => saveAiSettings({ voice_tone: value })}
                          >
                            <SelectTrigger className="mt-1 bg-slate-800/50 border-slate-700 text-white">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-900 border-slate-700">
                              <SelectItem value="warm">Warm</SelectItem>
                              <SelectItem value="neutral">Neutral</SelectItem>
                              <SelectItem value="energetic">Energetic</SelectItem>
                              <SelectItem value="calm">Calm</SelectItem>
                              <SelectItem value="authoritative">Authoritative</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <Label className="text-slate-400 text-xs">Voice Pitch</Label>
                            <span className="text-xs text-slate-500">{aiSettings.voice_pitch?.toFixed(1)}</span>
                          </div>
                          <Slider
                            value={[aiSettings.voice_pitch || 1.0]}
                            onValueChange={([value]) => saveAiSettings({ voice_pitch: value })}
                            min={0.5}
                            max={2.0}
                            step={0.1}
                          />
                        </div>

                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <Label className="text-slate-400 text-xs">Voice Speed</Label>
                            <span className="text-xs text-slate-500">{aiSettings.voice_speed?.toFixed(1)}</span>
                          </div>
                          <Slider
                            value={[aiSettings.voice_speed || 1.1]}
                            onValueChange={([value]) => saveAiSettings({ voice_speed: value })}
                            min={0.5}
                            max={2.0}
                            step={0.1}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </ScrollArea>
        </SheetContent>
      </Sheet>
    </>
  );
}