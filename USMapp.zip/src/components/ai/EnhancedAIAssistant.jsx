import React, { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Mic,
  MicOff,
  Camera,
  Save,
  Sparkles,
  Loader2,
  Volume2,
  VolumeX,
  MessageSquare,
  Eye,
  Zap,
  Settings,
  History,
  Command,
  Brain,
  BarChart3,
  Send,
  Calendar,
  FileText
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';

const quickCommands = [
  { icon: Send, label: 'Create Post', command: 'create_post', prompt: 'Create a new social media post' },
  { icon: Calendar, label: 'Schedule Content', command: 'schedule_content', prompt: 'Help me schedule content for this week' },
  { icon: BarChart3, label: 'Analyze Performance', command: 'analyze_performance', prompt: 'Analyze my recent post performance' },
  { icon: Sparkles, label: 'Generate Strategy', command: 'generate_strategy', prompt: 'Create a marketing strategy for my business' },
  { icon: FileText, label: 'Create Report', command: 'create_report', prompt: 'Generate a performance report' },
  { icon: Brain, label: 'Research Topic', command: 'research_topic', prompt: 'Research trending topics in my industry' },
];

export default function EnhancedAIAssistant({ browserRef }) {
  const [mode, setMode] = useState('chat'); // chat, workflow, commands
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedData, setExtractedData] = useState([]);
  
  const recognitionRef = useRef(null);
  const synthRef = useRef(window.speechSynthesis);
  const queryClient = useQueryClient();

  const { data: aiSettings } = useQuery({
    queryKey: ['aiSettings'],
    queryFn: async () => {
      const settings = await base44.entities.AISettings.list('-created_date', 1);
      return settings[0] || null;
    },
  });

  const { data: commandHistory = [] } = useQuery({
    queryKey: ['commands'],
    queryFn: () => base44.entities.AICommand.list('-created_date', 20),
  });

  const createCommandMutation = useMutation({
    mutationFn: (data) => base44.entities.AICommand.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['commands'] }),
  });

  const updateSettingsMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AISettings.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['aiSettings'] }),
  });

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;

      recognitionRef.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('');
        setInput(transcript);
      };

      recognitionRef.current.onend = () => {
        if (isListening) {
          recognitionRef.current.start();
        }
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      synthRef.current.cancel();
    };
  }, [isListening]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not supported');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
      toast.success('Listening...');
    }
  };

  const speak = (text) => {
    if (!synthRef.current || !aiSettings?.voice_enabled) return;

    synthRef.current.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = aiSettings?.voice_speed || 1.0;
    utterance.pitch = aiSettings?.voice_pitch || 1.0;
    utterance.volume = 1.0;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    
    synthRef.current.speak(utterance);
  };

  const stopSpeaking = () => {
    synthRef.current.cancel();
    setIsSpeaking(false);
  };

  const captureScreenshot = async () => {
    if (!browserRef?.current) {
      toast.error('No browser window available');
      return null;
    }

    try {
      const canvas = await html2canvas(browserRef.current, {
        allowTaint: true,
        useCORS: true,
        logging: false,
      });
      
      return canvas.toDataURL('image/png');
    } catch (error) {
      console.error('Screenshot error:', error);
      toast.error('Could not capture screenshot');
      return null;
    }
  };

  const analyzeScreen = async () => {
    setIsProcessing(true);

    const screenshot = await captureScreenshot();
    if (!screenshot) {
      setIsProcessing(false);
      return;
    }

    const blob = await fetch(screenshot).then(r => r.blob());
    const file = new File([blob], 'screenshot.png', { type: 'image/png' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    const personalityContext = aiSettings ? `
    Personality: ${aiSettings.personality}
    Voice Tone: ${aiSettings.voice_tone}
    Response Style: ${aiSettings.response_style}
    ` : '';

    const prompt = `${personalityContext}

Analyze this screenshot and extract key information:
1. Main content/topic
2. Important data, statistics, or insights
3. Actionable marketing opportunities
4. Key takeaways

Provide structured, actionable information.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      file_urls: [file_url],
      response_json_schema: {
        type: 'object',
        properties: {
          main_topic: { type: 'string' },
          key_data: { type: 'array', items: { type: 'string' } },
          marketing_opportunities: { type: 'array', items: { type: 'string' } },
          summary: { type: 'string' },
          actionable_insights: { type: 'array', items: { type: 'string' } }
        }
      }
    });

    const aiMessage = {
      role: 'assistant',
      content: result.summary,
      data: result,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, aiMessage]);
    speak(result.summary);
    setExtractedData(prev => [...prev, { ...result, screenshot: file_url, timestamp: new Date().toISOString() }]);
    
    // Learn from interaction
    if (aiSettings?.learning_enabled) {
      updateSettingsMutation.mutate({
        id: aiSettings.id,
        data: {
          interaction_count: (aiSettings.interaction_count || 0) + 1
        }
      });
    }

    setIsProcessing(false);
    toast.success('Screen analyzed!');
  };

  const executeCommand = async (commandType, promptText) => {
    setIsProcessing(true);
    const startTime = Date.now();

    const commandStart = {
      role: 'user',
      content: promptText,
      commandType,
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, commandStart]);

    try {
      let result;
      const personalityContext = aiSettings ? `
      You are ${aiSettings.name || 'AI Assistant'} with ${aiSettings.personality} personality and ${aiSettings.voice_tone} tone.
      Response style: ${aiSettings.response_style}.
      ` : '';

      switch (commandType) {
        case 'create_post':
          result = await base44.integrations.Core.InvokeLLM({
            prompt: `${personalityContext}
            
Create a compelling social media post. Include:
- Engaging caption with hooks
- 5-10 relevant hashtags
- Optimal posting time recommendation
- Platform-specific optimizations

Make it ready to publish.`,
            response_json_schema: {
              type: 'object',
              properties: {
                caption: { type: 'string' },
                hashtags: { type: 'array', items: { type: 'string' } },
                best_time: { type: 'string' },
                platform_suggestions: { type: 'object' }
              }
            }
          });
          break;

        case 'analyze_performance':
          const posts = await base44.entities.Post.filter({ status: 'published' }, '-published_time', 10);
          result = await base44.integrations.Core.InvokeLLM({
            prompt: `${personalityContext}
            
Analyze these recent posts and provide insights:
${JSON.stringify(posts.map(p => ({ content: p.content, likes: p.likes, comments: p.comments, platform: p.platforms })))}

Provide:
- Performance summary
- Top performing content types
- Improvement recommendations
- Engagement trends`,
            response_json_schema: {
              type: 'object',
              properties: {
                summary: { type: 'string' },
                top_posts: { type: 'array', items: { type: 'string' } },
                recommendations: { type: 'array', items: { type: 'string' } },
                trends: { type: 'string' }
              }
            }
          });
          break;

        case 'generate_strategy':
          result = await base44.integrations.Core.InvokeLLM({
            prompt: `${personalityContext}
            
Generate a comprehensive marketing strategy with:
- Goal and objectives
- Target audience insights
- Content themes (3-5)
- Posting schedule recommendations
- Expected outcomes

Make it actionable and specific.`,
            add_context_from_internet: true,
            response_json_schema: {
              type: 'object',
              properties: {
                strategy_name: { type: 'string' },
                goal: { type: 'string' },
                themes: { type: 'array', items: { type: 'string' } },
                schedule: { type: 'string' },
                expected_results: { type: 'string' }
              }
            }
          });
          break;

        default:
          result = await base44.integrations.Core.InvokeLLM({
            prompt: `${personalityContext}\n\n${promptText}`,
            add_context_from_internet: true
          });
      }

      const executionTime = Date.now() - startTime;

      // Save command to history
      createCommandMutation.mutate({
        command_text: promptText,
        command_type: commandType,
        parameters: {},
        execution_result: typeof result === 'string' ? result : JSON.stringify(result),
        execution_status: 'success',
        execution_time_ms: executionTime
      });

      const aiMessage = {
        role: 'assistant',
        content: typeof result === 'string' ? result : result.summary || JSON.stringify(result, null, 2),
        data: typeof result === 'object' ? result : null,
        timestamp: new Date().toISOString(),
        executionTime
      };

      setMessages(prev => [...prev, aiMessage]);
      speak(aiMessage.content);

      // Update success count
      if (aiSettings?.learning_enabled) {
        updateSettingsMutation.mutate({
          id: aiSettings.id,
          data: {
            successful_recommendations: (aiSettings.successful_recommendations || 0) + 1,
            interaction_count: (aiSettings.interaction_count || 0) + 1
          }
        });
      }

    } catch (error) {
      toast.error('Command execution failed');
      createCommandMutation.mutate({
        command_text: promptText,
        command_type: commandType,
        execution_status: 'failed',
        execution_result: error.message
      });
    }

    setIsProcessing(false);
  };

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = {
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    const recentData = extractedData.slice(-3);
    const context = recentData.length > 0 
      ? `Recent extracted data:\n${recentData.map(d => d.summary).join('\n')}`
      : '';

    const personalityContext = aiSettings ? `
    You are ${aiSettings.name || 'AI Assistant'} with ${aiSettings.personality} personality.
    ` : '';

    const prompt = `${personalityContext}
    
${context}

User: ${userMessage.content}

Provide a helpful response.`;

    const response = await base44.integrations.Core.InvokeLLM({ 
      prompt,
      add_context_from_internet: mode === 'workflow'
    });

    const aiMessage = {
      role: 'assistant',
      content: response,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, aiMessage]);
    speak(response);
    
    if (aiSettings?.learning_enabled) {
      updateSettingsMutation.mutate({
        id: aiSettings.id,
        data: {
          interaction_count: (aiSettings.interaction_count || 0) + 1
        }
      });
    }

    setIsProcessing(false);
  };

  return (
    <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden flex flex-col h-[700px]">
      {/* Header */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">{aiSettings?.name || 'AI Assistant'}</h3>
              <p className="text-xs text-slate-400">
                {aiSettings?.personality || 'friendly'} • {aiSettings?.voice_tone || 'warm'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-violet-500/10 text-violet-400">
              {aiSettings?.interaction_count || 0} interactions
            </Badge>
            <Button
              size="sm"
              variant="ghost"
              onClick={analyzeScreen}
              disabled={isProcessing}
              className="text-violet-400 hover:text-violet-300"
            >
              <Camera className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Mode Selector */}
        <Tabs value={mode} onValueChange={setMode}>
          <TabsList className="w-full bg-slate-800/50">
            <TabsTrigger value="chat" className="flex-1 data-[state=active]:bg-violet-600">
              <MessageSquare className="w-4 h-4 mr-2" />
              Chat
            </TabsTrigger>
            <TabsTrigger value="workflow" className="flex-1 data-[state=active]:bg-violet-600">
              <Zap className="w-4 h-4 mr-2" />
              Workflow
            </TabsTrigger>
            <TabsTrigger value="commands" className="flex-1 data-[state=active]:bg-violet-600">
              <Command className="w-4 h-4 mr-2" />
              Commands
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Content */}
      <div className="flex-1 min-h-0">
        {mode === 'commands' ? (
          <div className="h-full overflow-auto">
            <div className="p-4 space-y-3">
              <h4 className="text-sm font-semibold text-white mb-3">Quick Actions</h4>
              <div className="grid grid-cols-2 gap-3">
                {quickCommands.map((cmd) => (
                  <button
                    key={cmd.command}
                    onClick={() => executeCommand(cmd.command, cmd.prompt)}
                    disabled={isProcessing}
                    className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500 transition-all text-left"
                  >
                    <cmd.icon className="w-6 h-6 text-violet-400 mb-2" />
                    <p className="text-sm font-medium text-white">{cmd.label}</p>
                  </button>
                ))}
              </div>

              <div className="pt-4 border-t border-slate-800">
                <h4 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
                  <History className="w-4 h-4" />
                  Command History
                </h4>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {commandHistory.map((cmd) => (
                      <div key={cmd.id} className="p-3 rounded-lg bg-slate-800/30 border border-slate-800">
                        <div className="flex items-center justify-between mb-1">
                          <p className="text-xs text-slate-400">{cmd.command_type}</p>
                          <Badge className={cn(
                            "text-xs",
                            cmd.execution_status === 'success' 
                              ? "bg-emerald-500/10 text-emerald-400"
                              : "bg-rose-500/10 text-rose-400"
                          )}>
                            {cmd.execution_status}
                          </Badge>
                        </div>
                        <p className="text-sm text-white line-clamp-2">{cmd.command_text}</p>
                        {cmd.execution_time_ms && (
                          <p className="text-xs text-slate-500 mt-1">{cmd.execution_time_ms}ms</p>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </div>
          </div>
        ) : (
          <ScrollArea className="h-full p-4">
            <div className="space-y-4">
              {messages.length === 0 && (
                <div className="text-center py-8">
                  <Brain className="w-12 h-12 mx-auto text-slate-600 mb-3" />
                  <p className="text-slate-400 text-sm">
                    {mode === 'chat' 
                      ? 'Start a conversation or use voice commands'
                      : 'AI will analyze content and automate workflows'}
                  </p>
                </div>
              )}
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "flex gap-3",
                    msg.role === 'user' ? "justify-end" : "justify-start"
                  )}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                  )}
                  <div className={cn(
                    "max-w-[80%] rounded-2xl px-4 py-2",
                    msg.role === 'user' 
                      ? "bg-violet-600 text-white" 
                      : "bg-slate-800 text-slate-100"
                  )}>
                    <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                    {msg.data && (
                      <div className="mt-2 pt-2 border-t border-slate-700 space-y-1">
                        {msg.data.key_data?.slice(0, 3).map((item, i) => (
                          <p key={i} className="text-xs text-slate-400">• {item}</p>
                        ))}
                      </div>
                    )}
                    {msg.executionTime && (
                      <p className="text-xs text-slate-500 mt-1">{msg.executionTime}ms</p>
                    )}
                  </div>
                </div>
              ))}
              {isProcessing && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                    <Loader2 className="w-4 h-4 text-white animate-spin" />
                  </div>
                  <div className="bg-slate-800 rounded-2xl px-4 py-2">
                    <p className="text-sm text-slate-300">Processing...</p>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
        )}
      </div>

      {/* Input */}
      {mode !== 'commands' && (
        <div className="p-4 border-t border-slate-800">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
              placeholder={mode === 'workflow' ? "Describe what you want to automate..." : "Ask anything..."}
              className="flex-1 min-h-[60px] max-h-[120px] bg-slate-800/50 border-slate-700 text-white resize-none"
            />
            <div className="flex flex-col gap-2">
              <Button
                onClick={toggleListening}
                className={cn(
                  "flex-1",
                  isListening 
                    ? "bg-rose-600 hover:bg-rose-700" 
                    : "bg-violet-600 hover:bg-violet-700"
                )}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </Button>
              <Button
                onClick={isSpeaking ? stopSpeaking : sendMessage}
                disabled={(!input.trim() || isProcessing) && !isSpeaking}
                className="flex-1 bg-fuchsia-600 hover:bg-fuchsia-700"
              >
                {isSpeaking ? <VolumeX className="w-4 h-4" /> : <MessageSquare className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}