import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { formatDistanceToNow } from 'date-fns';
import {
  TrendingUp,
  Hash,
  MessageCircle,
  AlertCircle,
  Sparkles,
  Zap,
  ThumbsUp,
  Eye,
  CheckCircle,
  X,
  Loader2,
  RefreshCw,
  Target,
  BarChart3,
  ArrowUpRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { toast } from 'sonner';

const typeIcons = {
  topic: TrendingUp,
  hashtag: Hash,
  sentiment_shift: MessageCircle,
  content_type: BarChart3,
  engagement_spike: Zap
};

const typeColors = {
  topic: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  hashtag: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
  sentiment_shift: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
  content_type: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  engagement_spike: 'bg-amber-500/10 text-amber-400 border-amber-500/20'
};

const priorityColors = {
  urgent: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
  high: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  medium: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  low: 'bg-slate-500/10 text-slate-400 border-slate-500/20'
};

export default function TrendMonitor({ competitors = [] }) {
  const [isScanning, setIsScanning] = useState(false);
  const queryClient = useQueryClient();

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ['trend-alerts'],
    queryFn: () => base44.entities.TrendAlert.filter({ status: { $ne: 'dismissed' } }, '-created_date'),
  });

  const updateAlertMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.TrendAlert.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['trend-alerts'] })
  });

  const createAlertsMutation = useMutation({
    mutationFn: (alerts) => base44.entities.TrendAlert.bulkCreate(alerts),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trend-alerts'] });
      toast.success('Trend analysis complete!');
    }
  });

  const scanTrends = async () => {
    if (competitors.length === 0) {
      toast.error('Add competitors first to scan trends');
      return;
    }

    setIsScanning(true);

    const competitorData = competitors.map(c => ({
      name: c.name,
      platform: c.platform,
      followers: c.followers_count,
      engagement_rate: c.engagement_rate,
      top_hashtags: c.top_hashtags,
      content_themes: c.content_themes,
      growth_rate: c.growth_rate
    }));

    const prompt = `Analyze these social media competitors and identify emerging trends:

${JSON.stringify(competitorData, null, 2)}

Identify and provide:
1. EMERGING TOPICS - New topics/themes gaining traction (not obvious ones)
2. TRENDING HASHTAGS - Hashtags showing growth across competitors
3. SENTIMENT SHIFTS - Changes in audience sentiment or conversation tone
4. CONTENT TYPE TRENDS - Rising content formats (reels, carousels, etc.)
5. ENGAGEMENT OPPORTUNITIES - Specific tactics driving high engagement

For each trend, provide:
- Clear title and description
- Which competitors are using it
- Growth indicators and volume
- Opportunity score (0-100)
- Priority level (low/medium/high/urgent)
- 3-5 specific recommended actions
- Platforms where it's trending

Focus on actionable, timely trends that represent real opportunities.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          trends: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string' },
                title: { type: 'string' },
                description: { type: 'string' },
                trend_data: {
                  type: 'object',
                  properties: {
                    keyword: { type: 'string' },
                    growth_rate: { type: 'number' },
                    volume: { type: 'number' },
                    sentiment: { type: 'string' }
                  }
                },
                competitors_using: { type: 'array', items: { type: 'string' } },
                opportunity_score: { type: 'number' },
                recommended_actions: { type: 'array', items: { type: 'string' } },
                priority: { type: 'string' },
                platforms: { type: 'array', items: { type: 'string' } }
              }
            }
          }
        }
      }
    });

    const newAlerts = result.trends.map(trend => ({
      ...trend,
      status: 'new',
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
    }));

    await createAlertsMutation.mutateAsync(newAlerts);
    setIsScanning(false);
  };

  const markAsReviewed = (id) => {
    updateAlertMutation.mutate({ id, data: { status: 'reviewed' } });
  };

  const markAsActedOn = (id) => {
    updateAlertMutation.mutate({ id, data: { status: 'acted_on' } });
    toast.success('Great! Marked as acted on');
  };

  const dismissAlert = (id) => {
    updateAlertMutation.mutate({ id, data: { status: 'dismissed' } });
  };

  const newAlerts = alerts.filter(a => a.status === 'new');
  const reviewedAlerts = alerts.filter(a => a.status === 'reviewed');
  const actedAlerts = alerts.filter(a => a.status === 'acted_on');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">AI Trend Monitor</h3>
            <p className="text-sm text-slate-400">Real-time competitor trend analysis</p>
          </div>
        </div>
        <Button
          onClick={scanTrends}
          disabled={isScanning}
          className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
        >
          {isScanning ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Scanning Trends...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Scan Trends
            </>
          )}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-4 h-4 text-rose-400" />
            <span className="text-sm text-slate-400">New Alerts</span>
          </div>
          <p className="text-2xl font-bold text-white">{newAlerts.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <Eye className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-slate-400">Reviewed</span>
          </div>
          <p className="text-2xl font-bold text-white">{reviewedAlerts.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span className="text-sm text-slate-400">Acted On</span>
          </div>
          <p className="text-2xl font-bold text-white">{actedAlerts.length}</p>
        </div>
        <div className="p-4 rounded-xl bg-slate-800/50">
          <div className="flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-violet-400" />
            <span className="text-sm text-slate-400">Avg Opportunity</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {alerts.length > 0 
              ? Math.round(alerts.reduce((a, t) => a + (t.opportunity_score || 0), 0) / alerts.length)
              : 0}%
          </p>
        </div>
      </div>

      {/* Alerts */}
      <Tabs defaultValue="new" className="space-y-4">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="new" className="data-[state=active]:bg-violet-600">
            New ({newAlerts.length})
          </TabsTrigger>
          <TabsTrigger value="reviewed" className="data-[state=active]:bg-violet-600">
            Reviewed ({reviewedAlerts.length})
          </TabsTrigger>
          <TabsTrigger value="acted" className="data-[state=active]:bg-violet-600">
            Acted On ({actedAlerts.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="new">
          <TrendAlertsList 
            alerts={newAlerts}
            onMarkReviewed={markAsReviewed}
            onMarkActed={markAsActedOn}
            onDismiss={dismissAlert}
            isLoading={isLoading}
          />
        </TabsContent>

        <TabsContent value="reviewed">
          <TrendAlertsList 
            alerts={reviewedAlerts}
            onMarkActed={markAsActedOn}
            onDismiss={dismissAlert}
            isLoading={isLoading}
          />
        </TabsContent>

        <TabsContent value="acted">
          <TrendAlertsList 
            alerts={actedAlerts}
            onDismiss={dismissAlert}
            isLoading={isLoading}
            showActedBadge
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function TrendAlertsList({ alerts, onMarkReviewed, onMarkActed, onDismiss, isLoading, showActedBadge }) {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
      </div>
    );
  }

  if (alerts.length === 0) {
    return (
      <div className="text-center py-12 text-slate-500">
        <TrendingUp className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>No trends to display</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[600px] pr-4">
      <div className="space-y-4">
        {alerts.map((alert) => {
          const Icon = typeIcons[alert.type] || TrendingUp;
          
          return (
            <div
              key={alert.id}
              className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/50 hover:border-slate-700 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0",
                  typeColors[alert.type]
                )}>
                  <Icon className="w-6 h-6" />
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-semibold text-white">{alert.title}</h4>
                      <Badge className={cn("text-xs", priorityColors[alert.priority])}>
                        {alert.priority}
                      </Badge>
                      {showActedBadge && (
                        <Badge className="bg-emerald-500/10 text-emerald-400 text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Acted on
                        </Badge>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDismiss(alert.id)}
                      className="text-slate-400 hover:text-rose-400"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>

                  <p className="text-sm text-slate-300 mb-4">{alert.description}</p>

                  {/* Metrics */}
                  <div className="grid grid-cols-3 gap-3 mb-4">
                    {alert.trend_data?.growth_rate && (
                      <div className="p-3 rounded-lg bg-slate-800/50">
                        <p className="text-xs text-slate-400 mb-1">Growth</p>
                        <p className="text-lg font-bold text-emerald-400">
                          +{alert.trend_data.growth_rate}%
                        </p>
                      </div>
                    )}
                    {alert.opportunity_score && (
                      <div className="p-3 rounded-lg bg-slate-800/50">
                        <p className="text-xs text-slate-400 mb-1">Opportunity</p>
                        <div className="flex items-center gap-2">
                          <Progress value={alert.opportunity_score} className="h-1.5 flex-1" />
                          <span className="text-sm font-medium text-white">{alert.opportunity_score}</span>
                        </div>
                      </div>
                    )}
                    {alert.trend_data?.volume && (
                      <div className="p-3 rounded-lg bg-slate-800/50">
                        <p className="text-xs text-slate-400 mb-1">Volume</p>
                        <p className="text-lg font-bold text-white">
                          {alert.trend_data.volume >= 1000 
                            ? `${(alert.trend_data.volume / 1000).toFixed(1)}K` 
                            : alert.trend_data.volume}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Competitors Using */}
                  {alert.competitors_using?.length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs text-slate-400 mb-2">Competitors using this:</p>
                      <div className="flex flex-wrap gap-2">
                        {alert.competitors_using.map((comp, i) => (
                          <Badge key={i} variant="outline" className="border-slate-700 text-slate-300 text-xs">
                            {comp}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recommended Actions */}
                  <div className="p-4 rounded-xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 mb-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Zap className="w-4 h-4 text-violet-400" />
                      <span className="text-sm font-medium text-violet-300">Recommended Actions</span>
                    </div>
                    <ul className="space-y-2">
                      {alert.recommended_actions?.map((action, i) => (
                        <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                          <ArrowUpRight className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {onMarkReviewed && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onMarkReviewed(alert.id)}
                        className="border-slate-700 text-slate-300"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Mark Reviewed
                      </Button>
                    )}
                    {onMarkActed && (
                      <Button
                        size="sm"
                        onClick={() => onMarkActed(alert.id)}
                        className="bg-emerald-600 hover:bg-emerald-700"
                      >
                        <CheckCircle className="w-4 h-4 mr-1" />
                        Mark as Acted On
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </ScrollArea>
  );
}