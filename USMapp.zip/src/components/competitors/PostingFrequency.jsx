import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, Clock } from 'lucide-react';
import { format, startOfWeek, addDays } from 'date-fns';

export default function PostingFrequency({ competitorId, competitorName }) {
  const { data: posts = [] } = useQuery({
    queryKey: ['competitor-posts', competitorId],
    queryFn: () => base44.entities.CompetitorPost.filter({ competitor_id: competitorId })
  });

  // Calculate posts per day of week
  const dayData = posts.reduce((acc, post) => {
    if (!post.posted_date) return acc;
    const day = format(new Date(post.posted_date), 'EEEE');
    acc[day] = (acc[day] || 0) + 1;
    return acc;
  }, {});

  const chartData = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => ({
    day: day.substring(0, 3),
    posts: dayData[day] || 0
  }));

  // Calculate posts per hour
  const hourData = posts.reduce((acc, post) => {
    if (!post.posted_date) return acc;
    const hour = format(new Date(post.posted_date), 'HH:00');
    acc[hour] = (acc[hour] || 0) + 1;
    return acc;
  }, {});

  const hourChartData = Array.from({ length: 24 }, (_, i) => {
    const hour = i.toString().padStart(2, '0') + ':00';
    return {
      hour: i < 12 ? `${i || 12}AM` : `${i === 12 ? 12 : i - 12}PM`,
      posts: hourData[hour] || 0
    };
  });

  const totalPosts = posts.length;
  const avgPerWeek = totalPosts > 0 ? (totalPosts / 4).toFixed(1) : 0; // Assuming ~4 weeks of data

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-white font-semibold text-lg mb-4">Posting Statistics</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-slate-800/50 rounded-lg">
            <Calendar className="w-5 h-5 text-violet-400 mb-2" />
            <p className="text-2xl font-bold text-white">{avgPerWeek}</p>
            <p className="text-xs text-slate-400">Posts per week</p>
          </div>
          <div className="p-4 bg-slate-800/50 rounded-lg">
            <Clock className="w-5 h-5 text-blue-400 mb-2" />
            <p className="text-2xl font-bold text-white">{totalPosts}</p>
            <p className="text-xs text-slate-400">Total tracked</p>
          </div>
        </div>
      </Card>

      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-white font-semibold text-lg mb-4">Posts by Day of Week</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="day" stroke="#94a3b8" />
            <YAxis stroke="#94a3b8" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px',
                color: '#fff'
              }}
            />
            <Bar dataKey="posts" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-white font-semibold text-lg mb-4">Posts by Time of Day</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={hourChartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="hour" stroke="#94a3b8" interval={2} />
            <YAxis stroke="#94a3b8" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px',
                color: '#fff'
              }}
            />
            <Bar dataKey="posts" fill="#ec4899" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}