import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Sparkles,
  TrendingUp,
  Heart,
  Clock,
  Target,
  Lightbulb,
  RefreshCw,
  Loader2,
  ChevronDown,
  ChevronUp,
  ThumbsUp,
  ThumbsDown,
  Minus,
  BarChart3,
  FileText,
  Zap,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const sentimentColors = {
  positive: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', icon: ThumbsUp },
  neutral: { bg: 'bg-slate-500/10', text: 'text-slate-400', icon: Minus },
  negative: { bg: 'bg-rose-500/10', text: 'text-rose-400', icon: ThumbsDown },
};

export default function CompetitorAIInsights({ competitor, onInsightsGenerated }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [insights, setInsights] = useState(null);
  const [expanded, setExpanded] = useState(true);

  const analyzeCompetitor = async () => {
    setIsAnalyzing(true);

    const prompt = `Analyze this social media competitor and provide strategic insights:

Competitor: ${competitor.name}
Platform: ${competitor.platform}
Username: @${competitor.username}
Followers: ${competitor.followers_count?.toLocaleString() || 'Unknown'}
Engagement Rate: ${competitor.engagement_rate || 'Unknown'}%
Average Likes: ${competitor.avg_likes?.toLocaleString() || 'Unknown'}
Average Comments: ${competitor.avg_comments?.toLocaleString() || 'Unknown'}
Posts Count: ${competitor.posts_count || 'Unknown'}
Growth Rate: ${competitor.growth_rate || 'Unknown'}%
Known Hashtags: ${competitor.top_hashtags?.join(', ') || 'None tracked'}
Content Themes: ${competitor.content_themes?.join(', ') || 'None tracked'}
Posting Frequency: ${competitor.posting_frequency || 'Unknown'}

Based on typical successful strategies for ${competitor.platform} accounts in their niche, provide:

1. TOP PERFORMING CONTENT TYPES - What types of content (reels, carousels, stories, static posts) likely perform best for them and why

2. TRENDING TOPICS - What trending topics or themes they might be leveraging based on their profile

3. AUDIENCE SENTIMENT - Estimated audience sentiment breakdown (positive/neutral/negative) with reasoning

4. POSTING STRATEGY - Their likely optimal posting times, frequency, and content mix

5. COMPETITIVE ADVANTAGES - What makes them successful, their unique strengths

6. ADAPTATION STRATEGIES - 5 specific, actionable strategies our brand can implement to compete effectively

Be specific, data-driven where possible, and actionable.`;

    const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          top_content_types: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string' },
                performance_score: { type: 'number' },
                reasoning: { type: 'string' },
                example_ideas: { type: 'array', items: { type: 'string' } }
              }
            }
          },
          trending_topics: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                topic: { type: 'string' },
                relevance_score: { type: 'number' },
                how_they_use_it: { type: 'string' },
                opportunity_for_us: { type: 'string' }
              }
            }
          },
          audience_sentiment: {
            type: 'object',
            properties: {
              positive_percentage: { type: 'number' },
              neutral_percentage: { type: 'number' },
              negative_percentage: { type: 'number' },
              key_positive_drivers: { type: 'array', items: { type: 'string' } },
              key_negative_drivers: { type: 'array', items: { type: 'string' } },
              overall_assessment: { type: 'string' }
            }
          },
          posting_strategy: {
            type: 'object',
            properties: {
              optimal_times: { type: 'array', items: { type: 'string' } },
              recommended_frequency: { type: 'string' },
              content_mix: { type: 'array', items: { type: 'object', properties: { type: { type: 'string' }, percentage: { type: 'number' } } } },
              key_tactics: { type: 'array', items: { type: 'string' } }
            }
          },
          competitive_advantages: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                advantage: { type: 'string' },
                impact: { type: 'string' },
                difficulty_to_replicate: { type: 'string' }
              }
            }
          },
          adaptation_strategies: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                strategy: { type: 'string' },
                description: { type: 'string' },
                implementation_steps: { type: 'array', items: { type: 'string' } },
                expected_impact: { type: 'string' },
                priority: { type: 'string' }
              }
            }
          },
          overall_threat_level: { type: 'string' },
          key_takeaway: { type: 'string' }
        }
      }
    });

    setInsights(result);
    setIsAnalyzing(false);
    toast.success('AI analysis complete!');
    
    if (onInsightsGenerated) {
      onInsightsGenerated(result);
    }
  };

  if (!insights) {
    return (
      <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 p-8 text-center">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-white mb-2">AI Competitor Analysis</h3>
        <p className="text-slate-400 mb-6 max-w-md mx-auto">
          Get deep insights into {competitor.name}'s strategy, content performance, and actionable recommendations
        </p>
        <Button
          onClick={analyzeCompetitor}
          disabled={isAnalyzing}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Generate AI Insights
            </>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-white">AI Analysis for {competitor.name}</h3>
            <p className="text-sm text-slate-400">Strategic insights and recommendations</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={cn(
            "capitalize",
            insights.overall_threat_level === 'high' ? "bg-rose-500/10 text-rose-400" :
            insights.overall_threat_level === 'medium' ? "bg-amber-500/10 text-amber-400" :
            "bg-emerald-500/10 text-emerald-400"
          )}>
            {insights.overall_threat_level} threat
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={analyzeCompetitor}
            disabled={isAnalyzing}
            className="text-slate-400"
          >
            <RefreshCw className={cn("w-4 h-4", isAnalyzing && "animate-spin")} />
          </Button>
        </div>
      </div>

      {/* Key Takeaway */}
      <div className="p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
        <div className="flex items-start gap-3">
          <Zap className="w-5 h-5 text-violet-400 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-violet-300 mb-1">Key Takeaway</p>
            <p className="text-white">{insights.key_takeaway}</p>
          </div>
        </div>
      </div>

      <Accordion type="multiple" defaultValue={['content', 'strategies']} className="space-y-4">
        {/* Top Content Types */}
        <AccordionItem value="content" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-5 h-5 text-cyan-400" />
              <span className="font-medium text-white">Top Performing Content Types</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-4 pt-2">
              {insights.top_content_types?.map((content, index) => (
                <div key={index} className="p-4 rounded-xl bg-slate-800/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-white">{content.type}</span>
                    <div className="flex items-center gap-2">
                      <Progress value={content.performance_score} className="w-20 h-2" />
                      <span className="text-sm text-slate-400">{content.performance_score}%</span>
                    </div>
                  </div>
                  <p className="text-sm text-slate-400 mb-3">{content.reasoning}</p>
                  {content.example_ideas?.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {content.example_ideas.map((idea, i) => (
                        <Badge key={i} variant="outline" className="border-slate-700 text-slate-300">
                          {idea}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Trending Topics */}
        <AccordionItem value="topics" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <span className="font-medium text-white">Trending Topics They Leverage</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {insights.trending_topics?.map((topic, index) => (
                <div key={index} className="p-4 rounded-xl bg-slate-800/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-white">{topic.topic}</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400">
                      {topic.relevance_score}% relevant
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-400 mb-2">{topic.how_they_use_it}</p>
                  <div className="flex items-start gap-2 p-3 rounded-lg bg-violet-500/10 border border-violet-500/20">
                    <Lightbulb className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-violet-300">{topic.opportunity_for_us}</p>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Audience Sentiment */}
        <AccordionItem value="sentiment" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Heart className="w-5 h-5 text-rose-400" />
              <span className="font-medium text-white">Audience Sentiment Analysis</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-4 pt-2">
              {/* Sentiment Bars */}
              <div className="grid grid-cols-3 gap-4">
                {['positive', 'neutral', 'negative'].map((type) => {
                  const config = sentimentColors[type];
                  const Icon = config.icon;
                  const value = insights.audience_sentiment?.[`${type}_percentage`] || 0;
                  return (
                    <div key={type} className={cn("p-4 rounded-xl", config.bg)}>
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className={cn("w-4 h-4", config.text)} />
                        <span className={cn("text-sm capitalize", config.text)}>{type}</span>
                      </div>
                      <p className="text-2xl font-bold text-white">{value}%</p>
                    </div>
                  );
                })}
              </div>

              <p className="text-slate-300">{insights.audience_sentiment?.overall_assessment}</p>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                  <p className="text-sm font-medium text-emerald-400 mb-2">Positive Drivers</p>
                  <ul className="space-y-1">
                    {insights.audience_sentiment?.key_positive_drivers?.map((driver, i) => (
                      <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                        <span className="text-emerald-400">+</span>
                        {driver}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/20">
                  <p className="text-sm font-medium text-rose-400 mb-2">Negative Drivers</p>
                  <ul className="space-y-1">
                    {insights.audience_sentiment?.key_negative_drivers?.map((driver, i) => (
                      <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                        <span className="text-rose-400">-</span>
                        {driver}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Posting Strategy */}
        <AccordionItem value="posting" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-amber-400" />
              <span className="font-medium text-white">Posting Strategy</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-2">Optimal Times</p>
                  <div className="flex flex-wrap gap-2">
                    {insights.posting_strategy?.optimal_times?.map((time, i) => (
                      <Badge key={i} className="bg-amber-500/10 text-amber-400">
                        {time}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-2">Frequency</p>
                  <p className="text-white font-medium">{insights.posting_strategy?.recommended_frequency}</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/50">
                <p className="text-sm text-slate-400 mb-3">Content Mix</p>
                <div className="space-y-2">
                  {insights.posting_strategy?.content_mix?.map((item, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className="text-sm text-white w-24">{item.type}</span>
                      <Progress value={item.percentage} className="flex-1 h-2" />
                      <span className="text-sm text-slate-400 w-12">{item.percentage}%</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/50">
                <p className="text-sm text-slate-400 mb-2">Key Tactics</p>
                <ul className="space-y-2">
                  {insights.posting_strategy?.key_tactics?.map((tactic, i) => (
                    <li key={i} className="text-sm text-slate-300 flex items-start gap-2">
                      <span className="text-violet-400">•</span>
                      {tactic}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Competitive Advantages */}
        <AccordionItem value="advantages" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Target className="w-5 h-5 text-violet-400" />
              <span className="font-medium text-white">Competitive Advantages</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-3 pt-2">
              {insights.competitive_advantages?.map((advantage, index) => (
                <div key={index} className="p-4 rounded-xl bg-slate-800/50">
                  <div className="flex items-start justify-between mb-2">
                    <span className="font-medium text-white">{advantage.advantage}</span>
                    <Badge variant="outline" className={cn(
                      "text-xs",
                      advantage.difficulty_to_replicate === 'easy' ? "border-emerald-500/30 text-emerald-400" :
                      advantage.difficulty_to_replicate === 'medium' ? "border-amber-500/30 text-amber-400" :
                      "border-rose-500/30 text-rose-400"
                    )}>
                      {advantage.difficulty_to_replicate} to replicate
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-400">{advantage.impact}</p>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Adaptation Strategies */}
        <AccordionItem value="strategies" className="border border-slate-800 rounded-xl overflow-hidden">
          <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-800/50 [&[data-state=open]]:bg-slate-800/50">
            <div className="flex items-center gap-3">
              <Lightbulb className="w-5 h-5 text-fuchsia-400" />
              <span className="font-medium text-white">Adaptation Strategies for Your Brand</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="px-5 pb-5">
            <div className="space-y-4 pt-2">
              {insights.adaptation_strategies?.map((strategy, index) => (
                <div key={index} className="p-5 rounded-xl bg-gradient-to-br from-slate-800/50 to-slate-800/30 border border-slate-700/50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center text-white font-bold text-sm">
                        {index + 1}
                      </div>
                      <h4 className="font-semibold text-white">{strategy.strategy}</h4>
                    </div>
                    <Badge className={cn(
                      strategy.priority === 'high' ? "bg-rose-500/10 text-rose-400" :
                      strategy.priority === 'medium' ? "bg-amber-500/10 text-amber-400" :
                      "bg-emerald-500/10 text-emerald-400"
                    )}>
                      {strategy.priority} priority
                    </Badge>
                  </div>
                  
                  <p className="text-slate-300 mb-4">{strategy.description}</p>
                  
                  <div className="space-y-2 mb-4">
                    <p className="text-sm font-medium text-slate-400">Implementation Steps:</p>
                    {strategy.implementation_steps?.map((step, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <ArrowRight className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
                        <span className="text-slate-300">{step}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                    <p className="text-sm text-emerald-300">
                      <strong>Expected Impact:</strong> {strategy.expected_impact}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}