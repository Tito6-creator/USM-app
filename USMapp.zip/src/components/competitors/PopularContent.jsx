import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, MessageSquare, Share2, Eye, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';

export default function PopularContent({ competitorId, competitorName }) {
  const { data: posts = [] } = useQuery({
    queryKey: ['competitor-posts', competitorId],
    queryFn: () => base44.entities.CompetitorPost
      .filter({ competitor_id: competitorId }, '-likes', 10)
  });

  if (posts.length === 0) {
    return (
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <p className="text-slate-500 text-center py-8">No posts tracked yet</p>
      </Card>
    );
  }

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <h3 className="text-white font-semibold text-lg mb-4">Top Performing Content</h3>
      
      <div className="space-y-3">
        {posts.map((post, idx) => (
          <div key={post.id} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-violet-500/20 flex items-center justify-center flex-shrink-0">
                <span className="text-violet-400 font-bold text-sm">#{idx + 1}</span>
              </div>
              
              <div className="flex-1">
                {post.media_url && (
                  <img 
                    src={post.media_url} 
                    alt="" 
                    className="w-full h-32 object-cover rounded-lg mb-3"
                  />
                )}
                
                {post.content && (
                  <p className="text-sm text-slate-300 mb-3 line-clamp-2">{post.content}</p>
                )}
                
                <div className="flex items-center gap-4 text-xs text-slate-400 mb-2">
                  <div className="flex items-center gap-1">
                    <Heart className="w-3 h-3 text-rose-400" />
                    <span>{post.likes?.toLocaleString() || 0}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-3 h-3 text-blue-400" />
                    <span>{post.comments || 0}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Share2 className="w-3 h-3 text-green-400" />
                    <span>{post.shares || 0}</span>
                  </div>
                  {post.views > 0 && (
                    <div className="flex items-center gap-1">
                      <Eye className="w-3 h-3 text-violet-400" />
                      <span>{post.views?.toLocaleString()}</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20 text-xs">
                      {post.media_type}
                    </Badge>
                    {post.engagement_rate && (
                      <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                        {post.engagement_rate}% ER
                      </Badge>
                    )}
                  </div>
                  
                  {post.posted_date && (
                    <span className="text-xs text-slate-500">
                      {format(new Date(post.posted_date), 'MMM d')}
                    </span>
                  )}
                </div>
                
                {post.hashtags && post.hashtags.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1">
                    {post.hashtags.slice(0, 5).map((tag, i) => (
                      <span key={i} className="text-xs text-slate-500">#{tag}</span>
                    ))}
                  </div>
                )}
                
                {post.post_url && (
                  <a 
                    href={post.post_url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs text-violet-400 hover:text-violet-300 flex items-center gap-1 mt-2"
                  >
                    View Post <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}