import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Progress } from '@/components/ui/progress';
import {
  Brain, Loader2, TrendingUp, Target, Lightbulb, Hash,
  Calendar, MessageSquare, Eye, Award, AlertCircle, Sparkles
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function AICompetitorAnalyzer({ competitors }) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState(null);
  const [selectedCompetitorIds, setSelectedCompetitorIds] = useState([]);

  const analyzeCompetitors = async () => {
    if (selectedCompetitorIds.length === 0) {
      toast.error('Select at least one competitor to analyze');
      return;
    }

    setIsAnalyzing(true);
    try {
      const selectedCompetitors = competitors.filter(c => selectedCompetitorIds.includes(c.id));

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze these competitor social media profiles and provide comprehensive strategic insights:

${selectedCompetitors.map((c, idx) => `
Competitor ${idx + 1}: ${c.name}
Platform: ${c.platform}
Followers: ${c.followers_count?.toLocaleString()}
Engagement Rate: ${c.engagement_rate}%
Posts: ${c.posts_count}
Posting Frequency: ${c.posting_frequency}
Top Hashtags: ${c.top_hashtags?.join(', ')}
Content Themes: ${c.content_themes?.join(', ')}
Avg Likes: ${c.avg_likes}
Avg Comments: ${c.avg_comments}
`).join('\n')}

Provide deep analysis on:

1. Content Strategy Patterns
   - What content types get most engagement
   - Common themes and topics
   - Content mix (educational, promotional, entertainment)

2. Engagement Tactics
   - How they drive comments and shares
   - CTA strategies
   - Community building approaches

3. Posting Strategy
   - Optimal posting times they use
   - Frequency patterns
   - Consistency analysis

4. Visual & Brand Identity
   - Visual style and aesthetics
   - Brand voice and tone
   - Color palettes and themes

5. Hashtag Strategy
   - Most effective hashtags
   - Hashtag mixing patterns
   - Niche vs trending balance

6. Growth Tactics
   - Follower acquisition methods
   - Collaboration patterns
   - Paid vs organic indicators

7. Differentiation Opportunities
   - Content gaps competitors miss
   - Underserved audience needs
   - Unique angles to take

8. Actionable Recommendations (10 specific actions)
   - What to do differently
   - What to adopt/adapt
   - Quick wins available

Format as detailed JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            overall_summary: { type: 'string' },
            competitive_score: { type: 'number' },
            content_strategy: {
              type: 'object',
              properties: {
                top_content_types: { type: 'array', items: { type: 'string' } },
                common_themes: { type: 'array', items: { type: 'string' } },
                content_mix: { type: 'string' }
              }
            },
            engagement_tactics: {
              type: 'object',
              properties: {
                top_tactics: { type: 'array', items: { type: 'string' } },
                cta_strategies: { type: 'array', items: { type: 'string' } }
              }
            },
            posting_strategy: {
              type: 'object',
              properties: {
                best_times: { type: 'array', items: { type: 'string' } },
                avg_frequency: { type: 'string' },
                consistency_score: { type: 'number' }
              }
            },
            brand_identity: {
              type: 'object',
              properties: {
                visual_style: { type: 'string' },
                tone: { type: 'string' },
                key_elements: { type: 'array', items: { type: 'string' } }
              }
            },
            hashtag_strategy: {
              type: 'object',
              properties: {
                most_effective: { type: 'array', items: { type: 'string' } },
                mixing_pattern: { type: 'string' }
              }
            },
            growth_tactics: {
              type: 'array',
              items: { type: 'string' }
            },
            differentiation_opportunities: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  opportunity: { type: 'string' },
                  impact: { type: 'string' },
                  effort: { type: 'string' }
                }
              }
            },
            recommendations: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  action: { type: 'string' },
                  priority: { type: 'string' },
                  expected_impact: { type: 'string' }
                }
              }
            }
          }
        }
      });

      setAnalysis(result);
      toast.success('AI analysis complete!');
    } catch (error) {
      toast.error('Failed to analyze competitors');
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toggleCompetitor = (id) => {
    setSelectedCompetitorIds(prev =>
      prev.includes(id) ? prev.filter(cid => cid !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="p-6 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border-violet-500/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Brain className="w-6 h-6 text-violet-400" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">AI Competitor Analyzer</h2>
              <p className="text-sm text-slate-400">
                Select competitors to analyze their strategies and get actionable insights
              </p>
            </div>
          </div>
          <Button
            onClick={analyzeCompetitors}
            disabled={isAnalyzing || selectedCompetitorIds.length === 0}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            {isAnalyzing ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 mr-2" />
            )}
            Analyze ({selectedCompetitorIds.length})
          </Button>
        </div>
      </Card>

      {/* Competitor Selection */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-white font-semibold mb-4">Select Competitors</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {competitors.map(competitor => (
            <div
              key={competitor.id}
              onClick={() => toggleCompetitor(competitor.id)}
              className={cn(
                "p-4 rounded-lg border cursor-pointer transition-all",
                selectedCompetitorIds.includes(competitor.id)
                  ? "bg-violet-500/10 border-violet-500/30"
                  : "bg-slate-800/50 border-slate-700 hover:border-slate-600"
              )}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-slate-700 overflow-hidden">
                  {competitor.profile_image ? (
                    <img src={competitor.profile_image} alt={competitor.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-400 text-xs">
                      {competitor.name.charAt(0)}
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium truncate">{competitor.name}</p>
                  <p className="text-xs text-slate-400">{competitor.platform} • {competitor.followers_count?.toLocaleString()} followers</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Analysis Results */}
      {analysis && (
        <div className="space-y-6">
          {/* Summary */}
          <Card className="p-6 bg-slate-900/50 border-slate-800">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-white font-semibold text-lg mb-2">Analysis Summary</h3>
                <p className="text-slate-300">{analysis.overall_summary}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-slate-400 mb-1">Competitive Score</p>
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">{analysis.competitive_score}</span>
                </div>
              </div>
            </div>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Content Strategy */}
            <Card className="p-6 bg-slate-900/50 border-slate-800">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Target className="w-5 h-5 text-blue-400" />
                Content Strategy
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-slate-400 mb-2">Top Content Types</p>
                  <div className="flex flex-wrap gap-2">
                    {analysis.content_strategy.top_content_types.map((type, idx) => (
                      <Badge key={idx} className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                        {type}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-2">Common Themes</p>
                  <div className="flex flex-wrap gap-2">
                    {analysis.content_strategy.common_themes.map((theme, idx) => (
                      <Badge key={idx} className="bg-slate-700 text-slate-300">
                        {theme}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-sm text-slate-300">{analysis.content_strategy.content_mix}</p>
                </div>
              </div>
            </Card>

            {/* Engagement Tactics */}
            <Card className="p-6 bg-slate-900/50 border-slate-800">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-400" />
                Engagement Tactics
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-slate-400 mb-2">Top Tactics</p>
                  <ul className="space-y-2">
                    {analysis.engagement_tactics.top_tactics.map((tactic, idx) => (
                      <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
                        <span className="text-emerald-400">•</span>
                        <span>{tactic}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-2">CTA Strategies</p>
                  <ul className="space-y-2">
                    {analysis.engagement_tactics.cta_strategies.map((cta, idx) => (
                      <li key={idx} className="text-sm text-slate-300 flex items-start gap-2">
                        <span className="text-emerald-400">→</span>
                        <span>{cta}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Card>

            {/* Posting Strategy */}
            <Card className="p-6 bg-slate-900/50 border-slate-800">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-violet-400" />
                Posting Strategy
              </h3>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-slate-400 mb-2">Best Posting Times</p>
                  <div className="flex flex-wrap gap-2">
                    {analysis.posting_strategy.best_times.map((time, idx) => (
                      <Badge key={idx} className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                        {time}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-sm text-slate-300 mb-2">
                    Average Frequency: {analysis.posting_strategy.avg_frequency}
                  </p>
                  <p className="text-xs text-slate-400 mb-1">Consistency Score</p>
                  <Progress value={analysis.posting_strategy.consistency_score} />
                </div>
              </div>
            </Card>

            {/* Brand Identity */}
            <Card className="p-6 bg-slate-900/50 border-slate-800">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                Brand Identity
              </h3>
              <div className="space-y-3">
                <div className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-xs text-slate-400 mb-1">Visual Style</p>
                  <p className="text-sm text-slate-300">{analysis.brand_identity.visual_style}</p>
                </div>
                <div className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-xs text-slate-400 mb-1">Tone</p>
                  <p className="text-sm text-slate-300">{analysis.brand_identity.tone}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400 mb-2">Key Elements</p>
                  <div className="flex flex-wrap gap-2">
                    {analysis.brand_identity.key_elements.map((element, idx) => (
                      <Badge key={idx} className="bg-amber-500/10 text-amber-400 border-amber-500/20">
                        {element}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Hashtag Strategy */}
          <Card className="p-6 bg-slate-900/50 border-slate-800">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Hash className="w-5 h-5 text-fuchsia-400" />
              Hashtag Strategy
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-slate-400 mb-2">Most Effective Hashtags</p>
                <div className="flex flex-wrap gap-2">
                  {analysis.hashtag_strategy.most_effective.map((tag, idx) => (
                    <Badge key={idx} className="bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/20">
                      #{tag}
                    </Badge>
                  ))}
                </div>
              </div>
              <div className="p-3 bg-slate-800/50 rounded-lg">
                <p className="text-xs text-slate-400 mb-1">Mixing Pattern</p>
                <p className="text-sm text-slate-300">{analysis.hashtag_strategy.mixing_pattern}</p>
              </div>
            </div>
          </Card>

          {/* Growth Tactics */}
          <Card className="p-6 bg-slate-900/50 border-slate-800">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              Growth Tactics
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {analysis.growth_tactics.map((tactic, idx) => (
                <div key={idx} className="p-3 bg-slate-800/50 rounded-lg">
                  <p className="text-sm text-slate-300">{tactic}</p>
                </div>
              ))}
            </div>
          </Card>

          {/* Differentiation Opportunities */}
          <Card className="p-6 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border-emerald-500/20">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-emerald-400" />
              Differentiation Opportunities
            </h3>
            <div className="space-y-3">
              {analysis.differentiation_opportunities.map((opp, idx) => (
                <div key={idx} className="p-4 bg-slate-800/50 rounded-lg border border-emerald-500/20">
                  <div className="flex items-start justify-between mb-2">
                    <p className="text-white font-medium flex-1">{opp.opportunity}</p>
                    <div className="flex gap-2">
                      <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                        {opp.impact} impact
                      </Badge>
                      <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 text-xs">
                        {opp.effort} effort
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recommendations */}
          <Card className="p-6 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border-violet-500/20">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Target className="w-5 h-5 text-violet-400" />
              Actionable Recommendations
            </h3>
            <div className="space-y-3">
              {analysis.recommendations.map((rec, idx) => (
                <div key={idx} className="p-4 bg-slate-800/50 rounded-lg border border-violet-500/20">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-violet-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-violet-400 font-bold">{idx + 1}</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium mb-1">{rec.action}</p>
                      <div className="flex gap-2 mt-2">
                        <Badge className={cn(
                          "text-xs",
                          rec.priority === 'high' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' :
                          rec.priority === 'medium' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                          'bg-blue-500/10 text-blue-400 border-blue-500/20'
                        )}>
                          {rec.priority} priority
                        </Badge>
                        <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                          {rec.expected_impact}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}