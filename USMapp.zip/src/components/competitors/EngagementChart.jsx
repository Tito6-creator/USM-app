import React from 'react';
import { Card } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export default function EngagementChart({ competitors }) {
  const chartData = competitors.map(comp => ({
    name: comp.name,
    'Engagement Rate': comp.engagement_rate || 0,
    'Avg Likes': Math.round((comp.avg_likes || 0) / 100), // Scale down for visualization
    'Avg Comments': comp.avg_comments || 0
  }));

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <h3 className="text-white font-semibold text-lg mb-4">Engagement Comparison</h3>
      
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis dataKey="name" stroke="#94a3b8" />
          <YAxis stroke="#94a3b8" />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#1e293b', 
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#fff'
            }}
          />
          <Legend />
          <Bar dataKey="Engagement Rate" fill="#8b5cf6" />
          <Bar dataKey="Avg Likes" fill="#ec4899" />
          <Bar dataKey="Avg Comments" fill="#3b82f6" />
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
}