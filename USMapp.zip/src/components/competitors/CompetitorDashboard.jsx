import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';
import GrowthChart from './GrowthChart';
import EngagementChart from './EngagementChart';
import PopularContent from './PopularContent';
import PostingFrequency from './PostingFrequency';

export default function CompetitorDashboard({ competitor, onBack, allCompetitors }) {
  const { data: history = [] } = useQuery({
    queryKey: ['competitor-history', competitor.id],
    queryFn: () => base44.entities.CompetitorHistory.filter({ competitor_id: competitor.id }, '-snapshot_date')
  });

  return (
    <div className="space-y-6">
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
      >
        <ChevronLeft className="w-4 h-4" />
        Back to Competitors
      </button>

      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center text-white text-2xl font-bold">
          {competitor.name.charAt(0)}
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">{competitor.name}</h1>
          <p className="text-slate-400">@{competitor.username} • {competitor.platform}</p>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="bg-slate-800/50 w-full justify-start">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="content">Popular Content</TabsTrigger>
          <TabsTrigger value="frequency">Posting Frequency</TabsTrigger>
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-6">
          <GrowthChart competitors={[competitor]} historyData={history} />
          <EngagementChart competitors={[competitor]} />
        </TabsContent>

        <TabsContent value="content" className="mt-6">
          <PopularContent competitorId={competitor.id} competitorName={competitor.name} />
        </TabsContent>

        <TabsContent value="frequency" className="mt-6">
          <PostingFrequency competitorId={competitor.id} competitorName={competitor.name} />
        </TabsContent>

        <TabsContent value="comparison" className="space-y-6 mt-6">
          <GrowthChart 
            competitors={allCompetitors} 
            historyData={history} 
          />
          <EngagementChart competitors={allCompetitors} />
        </TabsContent>
      </Tabs>
    </div>
  );
}