import React from 'react';
import { Card } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { format } from 'date-fns';

const colors = ['#8b5cf6', '#ec4899', '#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

export default function GrowthChart({ competitors, historyData }) {
  if (!historyData || historyData.length === 0) {
    return (
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <p className="text-slate-500 text-center py-8">No historical data available</p>
      </Card>
    );
  }

  // Group data by date and competitor
  const groupedData = historyData.reduce((acc, item) => {
    const date = format(new Date(item.snapshot_date), 'MMM d');
    if (!acc[date]) {
      acc[date] = { date };
    }
    const competitor = competitors.find(c => c.id === item.competitor_id);
    if (competitor) {
      acc[date][competitor.name] = item.followers_count;
    }
    return acc;
  }, {});

  const chartData = Object.values(groupedData);

  // Calculate growth percentage
  const getGrowth = (competitorId) => {
    const competitorHistory = historyData
      .filter(h => h.competitor_id === competitorId)
      .sort((a, b) => new Date(a.snapshot_date) - new Date(b.snapshot_date));
    
    if (competitorHistory.length < 2) return 0;
    
    const oldest = competitorHistory[0].followers_count;
    const newest = competitorHistory[competitorHistory.length - 1].followers_count;
    return ((newest - oldest) / oldest * 100).toFixed(1);
  };

  return (
    <Card className="p-6 bg-slate-900/50 border-slate-800">
      <div className="mb-6">
        <h3 className="text-white font-semibold text-lg mb-4">Follower Growth Comparison</h3>
        <div className="flex flex-wrap gap-4">
          {competitors.map((competitor, idx) => {
            const growth = parseFloat(getGrowth(competitor.id));
            return (
              <div key={competitor.id} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: colors[idx % colors.length] }}
                />
                <span className="text-sm text-slate-300">{competitor.name}</span>
                <div className="flex items-center gap-1">
                  {growth >= 0 ? (
                    <TrendingUp className="w-3 h-3 text-emerald-400" />
                  ) : (
                    <TrendingDown className="w-3 h-3 text-red-400" />
                  )}
                  <span className={`text-xs font-medium ${growth >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {growth >= 0 ? '+' : ''}{growth}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis dataKey="date" stroke="#94a3b8" />
          <YAxis stroke="#94a3b8" />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#1e293b', 
              border: '1px solid #334155',
              borderRadius: '8px',
              color: '#fff'
            }}
          />
          <Legend />
          {competitors.map((competitor, idx) => (
            <Line
              key={competitor.id}
              type="monotone"
              dataKey={competitor.name}
              stroke={colors[idx % colors.length]}
              strokeWidth={2}
              dot={{ fill: colors[idx % colors.length] }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
}