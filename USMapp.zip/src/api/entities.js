import { base44 } from './base44Client';


export const SocialAccount = base44.entities.SocialAccount;

export const Post = base44.entities.Post;

export const Message = base44.entities.Message;

export const Competitor = base44.entities.Competitor;

export const Campaign = base44.entities.Campaign;

export const BrandMention = base44.entities.BrandMention;

export const Hashtag = base44.entities.Hashtag;

export const TeamMember = base44.entities.TeamMember;

export const MediaAsset = base44.entities.MediaAsset;

export const Influencer = base44.entities.Influencer;

export const Goal = base44.entities.Goal;

export const LinkInBio = base44.entities.LinkInBio;

export const Report = base44.entities.Report;

export const ChatbotConfig = base44.entities.ChatbotConfig;

export const Notification = base44.entities.Notification;

export const ActivityLog = base44.entities.ActivityLog;

export const MarketingStrategy = base44.entities.MarketingStrategy;

export const ABTest = base44.entities.ABTest;

export const StoryReelAnalytics = base44.entities.StoryReelAnalytics;

export const ScheduledReport = base44.entities.ScheduledReport;

export const Lead = base44.entities.Lead;

export const TrendAlert = base44.entities.TrendAlert;

export const AISettings = base44.entities.AISettings;

export const AutomationRule = base44.entities.AutomationRule;

export const AICommand = base44.entities.AICommand;

export const EmailCampaign = base44.entities.EmailCampaign;

export const SalesFunnel = base44.entities.SalesFunnel;

export const PostTemplate = base44.entities.PostTemplate;

export const PerformanceForecast = base44.entities.PerformanceForecast;

export const AudienceDemographic = base44.entities.AudienceDemographic;

export const ConversionTracking = base44.entities.ConversionTracking;

export const TwoFactorAuth = base44.entities.TwoFactorAuth;

export const ProductOpportunity = base44.entities.ProductOpportunity;

export const MessageTemplate = base44.entities.MessageTemplate;

export const SupportTicket = base44.entities.SupportTicket;

export const FAQ = base44.entities.FAQ;

export const LandingPage = base44.entities.LandingPage;

export const Task = base44.entities.Task;

export const Comment = base44.entities.Comment;

export const MarketplaceProduct = base44.entities.MarketplaceProduct;

export const Purchase = base44.entities.Purchase;

export const Subscription = base44.entities.Subscription;

export const ContentMonetization = base44.entities.ContentMonetization;

export const CompetitorHistory = base44.entities.CompetitorHistory;

export const CompetitorPost = base44.entities.CompetitorPost;

export const BrandKit = base44.entities.BrandKit;

export const CRMFieldMapping = base44.entities.CRMFieldMapping;

export const Contact = base44.entities.Contact;

export const Deal = base44.entities.Deal;

export const CRMTask = base44.entities.CRMTask;

export const CRMNote = base44.entities.CRMNote;

export const WorkflowTemplate = base44.entities.WorkflowTemplate;

export const PageAnalytics = base44.entities.PageAnalytics;



// auth sdk:
export const User = base44.auth;