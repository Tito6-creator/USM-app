import { base44 } from './base44Client';


export const sendApprovalEmail = base44.functions.sendApprovalEmail;

export const approvePost = base44.functions.approvePost;

export const autoPostScheduled = base44.functions.autoPostScheduled;

export const analyzePerformance = base44.functions.analyzePerformance;

export const syncCRMLeads = base44.functions.syncCRMLeads;

export const handleLeadStatusChange = base44.functions.handleLeadStatusChange;

export const handleDealStageChange = base44.functions.handleDealStageChange;

export const checkInactiveLeads = base44.functions.checkInactiveLeads;

export const handleContactStatusChange = base44.functions.handleContactStatusChange;

export const getNextActionSuggestion = base44.functions.getNextActionSuggestion;

export const calculateLeadScore = base44.functions.calculateLeadScore;

export const calculateHealthScore = base44.functions.calculateHealthScore;

export const createCampaignFromVoice = base44.functions.createCampaignFromVoice;

export const sendCampaignApprovalEmail = base44.functions.sendCampaignApprovalEmail;

export const approveCampaign = base44.functions.approveCampaign;

export const monitorCampaignPerformance = base44.functions.monitorCampaignPerformance;

export const trackPageView = base44.functions.trackPageView;

export const trackConversion = base44.functions.trackConversion;

export const getPageAnalytics = base44.functions.getPageAnalytics;

export const verifyDomain = base44.functions.verifyDomain;

export const deployPage = base44.functions.deployPage;

export const analyzeSEO = base44.functions.analyzeSEO;

export const generatePromoVideo = base44.functions.generatePromoVideo;

