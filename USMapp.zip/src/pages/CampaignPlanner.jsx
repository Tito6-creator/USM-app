import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Sparkles,
  Target,
  Plus,
  TrendingUp,
  Users,
  Calendar,
  Eye,
  Trash2,
  Edit,
  Play,
  Copy,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import CampaignWizard from '@/components/campaigns/CampaignWizard';
import CampaignDetails from '@/components/campaigns/CampaignDetails';

const statusColors = {
  draft: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  paused: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  completed: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
};

export default function CampaignPlanner() {
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [viewDetails, setViewDetails] = useState(null);
  
  const queryClient = useQueryClient();

  const { data: campaigns = [] } = useQuery({
    queryKey: ['campaigns'],
    queryFn: () => base44.entities.Campaign.list('-created_date'),
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors'],
    queryFn: () => base44.entities.Competitor.list(),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Campaign.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      toast.success('Campaign deleted');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Campaign.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['campaigns'] });
      toast.success('Campaign updated');
    },
  });

  const activeCampaigns = campaigns.filter(c => c.status === 'active');
  const totalBudget = campaigns.reduce((sum, c) => sum + (c.budget || 0), 0);
  const totalRevenue = campaigns.reduce((sum, c) => sum + (c.revenue || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Campaign Planner</h1>
          <p className="text-slate-400 mt-1">AI-powered integrated marketing campaigns</p>
        </div>
        <Button
          onClick={() => setIsWizardOpen(true)}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Create Campaign
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Target className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{campaigns.length}</p>
              <p className="text-sm text-slate-400">Total Campaigns</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Play className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{activeCampaigns.length}</p>
              <p className="text-sm text-slate-400">Active Campaigns</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">${totalBudget.toLocaleString()}</p>
              <p className="text-sm text-slate-400">Total Budget</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-rose-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">${totalRevenue.toLocaleString()}</p>
              <p className="text-sm text-slate-400">Total Revenue</p>
            </div>
          </div>
        </div>
      </div>

      {/* Campaigns List */}
      {campaigns.length === 0 ? (
        <div className="rounded-2xl bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 p-12 text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No campaigns yet</h3>
          <p className="text-slate-400 mb-6">
            Let AI help you create your first integrated marketing campaign
          </p>
          <Button
            onClick={() => setIsWizardOpen(true)}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Create Campaign with AI
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {campaigns.map((campaign) => (
            <div
              key={campaign.id}
              className="rounded-2xl bg-slate-900/50 border border-slate-800/50 hover:border-slate-700/50 transition-all cursor-pointer"
              onClick={() => setViewDetails(campaign)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-white mb-1">{campaign.name}</h3>
                    <p className="text-sm text-slate-400 line-clamp-2">{campaign.description}</p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="text-slate-400">
                        <Edit className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        setViewDetails(campaign);
                      }}>
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        deleteMutation.mutate(campaign.id);
                      }} className="text-rose-400">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex items-center gap-2 flex-wrap mb-4">
                  <Badge className={statusColors[campaign.status]}>
                    {campaign.status}
                  </Badge>
                  {campaign.platforms?.map((platform) => (
                    <Badge key={platform} variant="outline" className="border-slate-700 text-slate-400 capitalize text-xs">
                      {platform}
                    </Badge>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="p-3 rounded-lg bg-slate-800/50">
                    <p className="text-xs text-slate-500 mb-1">Budget</p>
                    <p className="text-sm font-semibold text-white">${campaign.budget?.toLocaleString() || 0}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50">
                    <p className="text-xs text-slate-500 mb-1">Revenue</p>
                    <p className="text-sm font-semibold text-white">${campaign.revenue?.toLocaleString() || 0}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50">
                    <p className="text-xs text-slate-500 mb-1">Reach</p>
                    <p className="text-sm font-semibold text-white">{campaign.total_reach?.toLocaleString() || 0}</p>
                  </div>
                  <div className="p-3 rounded-lg bg-slate-800/50">
                    <p className="text-xs text-slate-500 mb-1">ROI</p>
                    <p className="text-sm font-semibold text-white">{campaign.roi || 0}%</p>
                  </div>
                </div>

                {campaign.start_date && (
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <Calendar className="w-3 h-3" />
                    {new Date(campaign.start_date).toLocaleDateString()} - {campaign.end_date ? new Date(campaign.end_date).toLocaleDateString() : 'Ongoing'}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Campaign Wizard */}
      <Dialog open={isWizardOpen} onOpenChange={setIsWizardOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-violet-400" />
              AI Campaign Planner
            </DialogTitle>
          </DialogHeader>
          <CampaignWizard
            competitors={competitors}
            onComplete={() => {
              setIsWizardOpen(false);
              queryClient.invalidateQueries({ queryKey: ['campaigns'] });
            }}
          />
        </DialogContent>
      </Dialog>

      {/* Campaign Details */}
      <Dialog open={!!viewDetails} onOpenChange={() => setViewDetails(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">{viewDetails?.name}</DialogTitle>
          </DialogHeader>
          {viewDetails && (
            <CampaignDetails campaign={viewDetails} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}