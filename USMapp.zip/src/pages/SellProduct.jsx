import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function SellProduct() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [product, setProduct] = useState({
    title: '',
    description: '',
    category: 'template',
    price: '',
    thumbnail_url: '',
    tags: '',
    platforms: ''
  });

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const createProductMutation = useMutation({
    mutationFn: (data) => base44.entities.MarketplaceProduct.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['my-products'] });
      toast.success('Product created!');
      navigate(createPageUrl('MyProducts'));
    }
  });

  const handleSubmit = () => {
    if (!product.title || !product.price || !product.category) {
      toast.error('Please fill required fields');
      return;
    }

    createProductMutation.mutate({
      ...product,
      price: parseFloat(product.price),
      seller_email: user?.email,
      seller_name: user?.full_name,
      tags: product.tags.split(',').map(t => t.trim()).filter(Boolean),
      platforms: product.platforms.split(',').map(t => t.trim()).filter(Boolean),
      status: 'active'
    });
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Sell Your Product</h1>
        <p className="text-slate-400 mt-1">List your templates, services, or courses</p>
      </div>

      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <div className="space-y-6">
          <div>
            <Label className="text-white">Product Title *</Label>
            <Input
              placeholder="e.g., Instagram Story Templates Pack"
              value={product.title}
              onChange={(e) => setProduct({ ...product, title: e.target.value })}
              className="mt-2 bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-white">Description *</Label>
            <Textarea
              placeholder="Describe your product..."
              value={product.description}
              onChange={(e) => setProduct({ ...product, description: e.target.value })}
              className="mt-2 bg-slate-800 border-slate-700 text-white h-32"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Category *</Label>
              <Select value={product.category} onValueChange={(v) => setProduct({ ...product, category: v })}>
                <SelectTrigger className="mt-2 bg-slate-800 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="template">Template</SelectItem>
                  <SelectItem value="service">Service</SelectItem>
                  <SelectItem value="course">Course</SelectItem>
                  <SelectItem value="ebook">E-book</SelectItem>
                  <SelectItem value="toolkit">Toolkit</SelectItem>
                  <SelectItem value="consultation">Consultation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white">Price (USD) *</Label>
              <Input
                type="number"
                placeholder="29.99"
                value={product.price}
                onChange={(e) => setProduct({ ...product, price: e.target.value })}
                className="mt-2 bg-slate-800 border-slate-700 text-white"
              />
            </div>
          </div>

          <div>
            <Label className="text-white">Thumbnail URL</Label>
            <Input
              placeholder="https://example.com/image.jpg"
              value={product.thumbnail_url}
              onChange={(e) => setProduct({ ...product, thumbnail_url: e.target.value })}
              className="mt-2 bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-white">Tags (comma separated)</Label>
            <Input
              placeholder="instagram, social media, templates"
              value={product.tags}
              onChange={(e) => setProduct({ ...product, tags: e.target.value })}
              className="mt-2 bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <div>
            <Label className="text-white">Compatible Platforms (comma separated)</Label>
            <Input
              placeholder="instagram, facebook, twitter"
              value={product.platforms}
              onChange={(e) => setProduct({ ...product, platforms: e.target.value })}
              className="mt-2 bg-slate-800 border-slate-700 text-white"
            />
          </div>

          <Button 
            onClick={handleSubmit}
            disabled={createProductMutation.isPending}
            className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            {createProductMutation.isPending ? 'Creating...' : 'List Product'}
          </Button>
        </div>
      </Card>
    </div>
  );
}