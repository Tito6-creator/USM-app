import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Clock,
  Calendar,
  Zap,
  Globe,
  TrendingUp,
  Send,
  Loader2,
  Sparkles,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { addDays, format } from 'date-fns';

export default function SmartScheduler() {
  const [selectedTimezone, setSelectedTimezone] = useState('America/New_York');
  const [bulkPosts, setBulkPosts] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  
  const queryClient = useQueryClient();

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'draft'],
    queryFn: () => base44.entities.Post.filter({ status: 'draft' }, '-created_date', 50),
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['templates'],
    queryFn: () => base44.entities.PostTemplate.list(),
  });

  const scheduleMutation = useMutation({
    mutationFn: (scheduledPosts) => base44.entities.Post.bulkCreate(scheduledPosts),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast.success('Posts scheduled successfully!');
      setBulkPosts([]);
    },
  });

  const generateOptimalSchedule = async () => {
    if (posts.length === 0) {
      toast.error('No draft posts to schedule');
      return;
    }

    setIsGenerating(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate an optimal posting schedule for ${posts.length} social media posts.

Accounts: ${accounts.map(a => `${a.platform} (${a.followers_count} followers, ${a.engagement_rate}% engagement)`).join(', ')}
Timezone: ${selectedTimezone}

Requirements:
1. Distribute posts across the next 7 days
2. Optimize for engagement based on platform best practices
3. Avoid posting too frequently on the same day
4. Consider timezone for global reach
5. Balance across platforms

For EACH post, provide:
- Optimal date and time (ISO 8601 format)
- Platform recommendation
- Reasoning
- Expected engagement score (0-100)

Return a schedule for all ${posts.length} posts.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          schedule: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                post_index: { type: 'number' },
                scheduled_datetime: { type: 'string' },
                recommended_platform: { type: 'string' },
                reasoning: { type: 'string' },
                engagement_score: { type: 'number' }
              }
            }
          },
          overall_strategy: { type: 'string' }
        }
      }
    });

    const scheduledPosts = result.schedule.map((s, idx) => {
      const post = posts[idx];
      return {
        ...post,
        scheduled_time: s.scheduled_datetime,
        platforms: s.recommended_platform ? [s.recommended_platform] : post.platforms,
        status: 'scheduled',
        ai_generated: true
      };
    });

    setBulkPosts(scheduledPosts);
    setIsGenerating(false);
    toast.success('Optimal schedule generated!');
  };

  const timezones = [
    'America/New_York',
    'America/Los_Angeles',
    'America/Chicago',
    'Europe/London',
    'Europe/Paris',
    'Asia/Tokyo',
    'Asia/Dubai',
    'Australia/Sydney',
    'UTC'
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Smart Scheduler</h1>
        <p className="text-slate-400 mt-1">AI-powered optimal posting schedule with timezone support</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Draft Posts</p>
              <p className="text-3xl font-bold text-white mt-1">{posts.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Scheduled</p>
              <p className="text-3xl font-bold text-white mt-1">{bulkPosts.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Clock className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Connected Accounts</p>
              <p className="text-3xl font-bold text-white mt-1">{accounts.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <Globe className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Templates</p>
              <p className="text-3xl font-bold text-white mt-1">{templates.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-cyan-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Timezone Selector */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Global Timezone</h3>
            <p className="text-sm text-slate-400">Optimize posting times for your target audience</p>
          </div>
          <Select value={selectedTimezone} onValueChange={setSelectedTimezone}>
            <SelectTrigger className="w-64 bg-slate-800 border-slate-700 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              {timezones.map(tz => (
                <SelectItem key={tz} value={tz}>{tz}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="bulk" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="bulk" className="data-[state=active]:bg-violet-600">
            <Zap className="w-4 h-4 mr-2" />
            Bulk Scheduler
          </TabsTrigger>
          <TabsTrigger value="queue" className="data-[state=active]:bg-violet-600">
            <TrendingUp className="w-4 h-4 mr-2" />
            Priority Queue
          </TabsTrigger>
        </TabsList>

        <TabsContent value="bulk" className="space-y-6">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-white">AI-Powered Bulk Scheduling</h3>
                <p className="text-sm text-slate-400 mt-1">Let AI create the optimal posting schedule</p>
              </div>
              <Button
                onClick={generateOptimalSchedule}
                disabled={posts.length === 0 || isGenerating}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Schedule
                  </>
                )}
              </Button>
            </div>

            {bulkPosts.length > 0 ? (
              <>
                <div className="space-y-3 mb-6">
                  {bulkPosts.map((post, idx) => (
                    <div key={idx} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-white line-clamp-1">{post.content}</p>
                          <div className="flex items-center gap-3 mt-2 text-xs text-slate-400">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {format(new Date(post.scheduled_time), 'MMM d, yyyy @ h:mm a')}
                            </span>
                            <span className="capitalize">{post.platforms?.join(', ')}</span>
                          </div>
                        </div>
                        <Badge className="bg-violet-500/10 text-violet-400">
                          <Zap className="w-3 h-3 mr-1" />
                          AI Optimized
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>

                <Button
                  onClick={() => scheduleMutation.mutate(bulkPosts)}
                  disabled={scheduleMutation.isPending}
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600"
                >
                  {scheduleMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Schedule All {bulkPosts.length} Posts
                </Button>
              </>
            ) : (
              <div className="text-center py-12 text-slate-500">
                <Clock className="w-12 h-12 mx-auto mb-3 opacity-20" />
                <p>Generate an optimal schedule to preview</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="queue" className="space-y-6">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Priority Queue Management</h3>
            <div className="space-y-3">
              {posts.slice(0, 10).map((post, idx) => (
                <div key={post.id} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-violet-500 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 rounded-lg bg-violet-500/10 flex items-center justify-center">
                      <span className="text-violet-400 font-semibold">#{idx + 1}</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-white font-medium line-clamp-1">{post.content}</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {post.platforms?.join(', ')} • {post.hashtags?.length || 0} hashtags
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-500" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}