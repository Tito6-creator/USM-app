import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Bot,
  Plus,
  Settings,
  MessageSquare,
  Users,
  Zap,
  Globe,
  Phone,
  Sparkles,
  Save,
  Loader2,
  ToggleLeft,
  ToggleRight,
  Trash2,
  MoreVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import ChatSimulator from '@/components/chatbot/ChatSimulator';
import HandoverQueue from '@/components/chatbot/HandoverQueue';
import LeadManager from '@/components/chatbot/LeadManager';
import ConversationAnalysis from '@/components/chatbot/ConversationAnalysis';

const languages = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'zh', name: 'Chinese' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ar', name: 'Arabic' },
];

const crmProviders = [
  { id: 'salesforce', name: 'Salesforce' },
  { id: 'hubspot', name: 'HubSpot' },
  { id: 'pipedrive', name: 'Pipedrive' },
  { id: 'zoho', name: 'Zoho CRM' },
];

export default function Chatbot() {
  const [activeTab, setActiveTab] = useState('simulator');
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [handovers, setHandovers] = useState([]);
  const [editingConfig, setEditingConfig] = useState(null);

  const queryClient = useQueryClient();

  const { data: configs = [] } = useQuery({
    queryKey: ['chatbot-configs'],
    queryFn: () => base44.entities.ChatbotConfig.list('-created_date'),
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.filter({ source: 'chatbot' }, '-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ChatbotConfig.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatbot-configs'] });
      setIsConfigOpen(false);
      toast.success('Chatbot created!');
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ChatbotConfig.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatbot-configs'] });
      toast.success('Settings saved!');
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ChatbotConfig.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['chatbot-configs'] })
  });

  const createLeadMutation = useMutation({
    mutationFn: (data) => base44.entities.Lead.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['leads'] })
  });

  const activeConfig = configs.find(c => c.is_active) || configs[0];

  const handleLeadCapture = (leadData) => {
    createLeadMutation.mutate({
      ...leadData,
      source: 'chatbot',
      status: 'new'
    });
  };

  const handleHandover = (handoverData) => {
    setHandovers(prev => [...prev, { ...handoverData, timestamp: new Date().toISOString() }]);
    toast.info('Customer requesting human assistance');
  };

  const handleAcceptHandover = (handover) => {
    setHandovers(prev => prev.filter(h => h !== handover));
    toast.success('Handover accepted');
  };

  const defaultConfig = {
    name: 'New Chatbot',
    platform: 'all',
    is_active: false,
    greeting_message: 'Hello! 👋 How can I help you today?',
    away_message: 'Thanks for your message! Our team will get back to you shortly.',
    ai_enabled: true,
    ai_personality: 'friendly',
    ai_context: '',
    supported_languages: ['en'],
    auto_translate: true,
    handover_enabled: true,
    lead_capture_enabled: true,
    crm_integration: { enabled: false, provider: '', auto_sync: true }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Chatbot</h1>
          <p className="text-slate-400 mt-1">Smart conversations with intent recognition</p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={() => {
              setEditingConfig(null);
              setIsConfigOpen(true);
            }}
            className="border-slate-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Chatbot
          </Button>
          {activeConfig && (
            <Button
              onClick={() => {
                setEditingConfig(activeConfig);
                setIsConfigOpen(true);
              }}
              className="bg-violet-600 hover:bg-violet-700"
            >
              <Settings className="w-4 h-4 mr-2" />
              Configure
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-violet-400" />
            </div>
            <span className="text-slate-400">Conversations</span>
          </div>
          <p className="text-3xl font-bold text-white">{activeConfig?.total_conversations || 0}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-emerald-400" />
            </div>
            <span className="text-slate-400">Leads Captured</span>
          </div>
          <p className="text-3xl font-bold text-white">{leads.length}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Phone className="w-5 h-5 text-amber-400" />
            </div>
            <span className="text-slate-400">Handovers</span>
          </div>
          <p className="text-3xl font-bold text-white">{handovers.length}</p>
        </div>
        <div className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center">
              <Globe className="w-5 h-5 text-cyan-400" />
            </div>
            <span className="text-slate-400">Languages</span>
          </div>
          <p className="text-3xl font-bold text-white">{activeConfig?.supported_languages?.length || 1}</p>
        </div>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="simulator" className="data-[state=active]:bg-violet-600">
            <Bot className="w-4 h-4 mr-2" />
            Simulator
          </TabsTrigger>
          <TabsTrigger value="handovers" className="data-[state=active]:bg-violet-600">
            <Phone className="w-4 h-4 mr-2" />
            Handovers
            {handovers.length > 0 && (
              <Badge className="ml-2 bg-amber-500 text-white">{handovers.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="leads" className="data-[state=active]:bg-violet-600">
            <Users className="w-4 h-4 mr-2" />
            Leads
          </TabsTrigger>
          <TabsTrigger value="analysis" className="data-[state=active]:bg-violet-600">
            <Sparkles className="w-4 h-4 mr-2" />
            AI Analysis
          </TabsTrigger>
          <TabsTrigger value="bots" className="data-[state=active]:bg-violet-600">
            <Settings className="w-4 h-4 mr-2" />
            My Bots
          </TabsTrigger>
        </TabsList>

        <TabsContent value="simulator" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ChatSimulator
              config={activeConfig}
              onLeadCapture={handleLeadCapture}
              onHandover={handleHandover}
            />
            
            <div className="space-y-6">
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <div className="flex items-center gap-3 mb-4">
                  <Sparkles className="w-5 h-5 text-violet-400" />
                  <h3 className="font-semibold text-white">AI Features Active</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
                    <span className="text-slate-300">Natural Language Understanding</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
                    <span className="text-slate-300">Intent Recognition</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
                    <span className="text-slate-300">Sentiment Analysis</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
                    <span className="text-slate-300">Lead Extraction</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
                    <span className="text-slate-300">Multi-language Support</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400">
                      {activeConfig?.supported_languages?.length || 1} languages
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800/50">
                    <span className="text-slate-300">Smart Handover</span>
                    <Badge className={activeConfig?.handover_enabled ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-500/10 text-slate-400"}>
                      {activeConfig?.handover_enabled ? 'Enabled' : 'Disabled'}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="handovers" className="mt-6">
          <HandoverQueue
            handovers={handovers}
            onAccept={handleAcceptHandover}
            onViewConversation={(h) => console.log('View:', h)}
          />
        </TabsContent>

        <TabsContent value="leads" className="mt-6">
          <LeadManager
            leads={leads}
            crmConfig={activeConfig?.crm_integration}
            onLeadUpdate={() => queryClient.invalidateQueries({ queryKey: ['leads'] })}
          />
        </TabsContent>

        <TabsContent value="analysis" className="mt-6">
          <ConversationAnalysis leads={leads} />
        </TabsContent>

        <TabsContent value="bots" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {configs.map((config) => (
              <div
                key={config.id}
                className={cn(
                  "p-5 rounded-2xl border transition-all cursor-pointer",
                  config.is_active
                    ? "bg-violet-500/10 border-violet-500/30"
                    : "bg-slate-900/50 border-slate-800/50 hover:border-slate-700"
                )}
                onClick={() => {
                  setEditingConfig(config);
                  setIsConfigOpen(true);
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center",
                      config.is_active ? "bg-violet-500" : "bg-slate-700"
                    )}>
                      <Bot className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{config.name}</h3>
                      <p className="text-sm text-slate-400 capitalize">{config.platform}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="text-slate-400">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          updateMutation.mutate({ id: config.id, data: { is_active: !config.is_active } });
                        }}
                      >
                        {config.is_active ? (
                          <ToggleRight className="w-4 h-4 mr-2" />
                        ) : (
                          <ToggleLeft className="w-4 h-4 mr-2" />
                        )}
                        {config.is_active ? 'Deactivate' : 'Activate'}
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteMutation.mutate(config.id);
                        }}
                        className="text-rose-400"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="flex flex-wrap gap-2">
                  {config.ai_enabled && (
                    <Badge className="bg-violet-500/10 text-violet-400 text-xs">AI</Badge>
                  )}
                  {config.handover_enabled && (
                    <Badge className="bg-amber-500/10 text-amber-400 text-xs">Handover</Badge>
                  )}
                  {config.supported_languages?.length > 1 && (
                    <Badge className="bg-cyan-500/10 text-cyan-400 text-xs">
                      {config.supported_languages.length} langs
                    </Badge>
                  )}
                  {config.crm_integration?.enabled && (
                    <Badge className="bg-emerald-500/10 text-emerald-400 text-xs">CRM</Badge>
                  )}
                </div>
              </div>
            ))}

            <button
              onClick={() => {
                setEditingConfig(null);
                setIsConfigOpen(true);
              }}
              className="p-5 rounded-2xl border-2 border-dashed border-slate-700 hover:border-violet-500/50 transition-colors flex flex-col items-center justify-center min-h-[160px]"
            >
              <Plus className="w-8 h-8 text-slate-500 mb-2" />
              <span className="text-slate-400">Create New Bot</span>
            </button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Config Dialog */}
      <Dialog open={isConfigOpen} onOpenChange={setIsConfigOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingConfig ? 'Edit Chatbot' : 'Create Chatbot'}
            </DialogTitle>
          </DialogHeader>

          <ChatbotConfigForm
            initialData={editingConfig || defaultConfig}
            onSave={(data) => {
              if (editingConfig) {
                updateMutation.mutate({ id: editingConfig.id, data });
              } else {
                createMutation.mutate(data);
              }
              setIsConfigOpen(false);
            }}
            isLoading={createMutation.isPending || updateMutation.isPending}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ChatbotConfigForm({ initialData, onSave, isLoading }) {
  const [config, setConfig] = useState(initialData);

  const handleSubmit = () => {
    onSave(config);
  };

  return (
    <div className="space-y-6 pt-4">
      <Tabs defaultValue="general">
        <TabsList className="bg-slate-800/50 w-full">
          <TabsTrigger value="general" className="flex-1">General</TabsTrigger>
          <TabsTrigger value="ai" className="flex-1">AI Settings</TabsTrigger>
          <TabsTrigger value="languages" className="flex-1">Languages</TabsTrigger>
          <TabsTrigger value="handover" className="flex-1">Handover</TabsTrigger>
          <TabsTrigger value="crm" className="flex-1">CRM</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4 mt-4">
          <div>
            <Label className="text-slate-300">Bot Name</Label>
            <Input
              value={config.name}
              onChange={(e) => setConfig({ ...config, name: e.target.value })}
              className="bg-slate-800/50 border-slate-700 mt-2"
            />
          </div>
          <div>
            <Label className="text-slate-300">Platform</Label>
            <Select value={config.platform} onValueChange={(v) => setConfig({ ...config, platform: v })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="all">All Platforms</SelectItem>
                <SelectItem value="facebook">Facebook</SelectItem>
                <SelectItem value="instagram">Instagram</SelectItem>
                <SelectItem value="whatsapp">WhatsApp</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300">Greeting Message</Label>
            <Textarea
              value={config.greeting_message}
              onChange={(e) => setConfig({ ...config, greeting_message: e.target.value })}
              className="bg-slate-800/50 border-slate-700 mt-2"
              rows={3}
            />
          </div>
          <div>
            <Label className="text-slate-300">Away Message</Label>
            <Textarea
              value={config.away_message}
              onChange={(e) => setConfig({ ...config, away_message: e.target.value })}
              className="bg-slate-800/50 border-slate-700 mt-2"
              rows={2}
            />
          </div>
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div>
              <p className="text-white font-medium">Lead Capture</p>
              <p className="text-sm text-slate-400">Automatically extract lead information</p>
            </div>
            <Switch
              checked={config.lead_capture_enabled}
              onCheckedChange={(v) => setConfig({ ...config, lead_capture_enabled: v })}
            />
          </div>
        </TabsContent>

        <TabsContent value="ai" className="space-y-4 mt-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div>
              <p className="text-white font-medium">AI-Powered Responses</p>
              <p className="text-sm text-slate-400">Use advanced AI for natural conversations</p>
            </div>
            <Switch
              checked={config.ai_enabled}
              onCheckedChange={(v) => setConfig({ ...config, ai_enabled: v })}
            />
          </div>
          <div>
            <Label className="text-slate-300">AI Personality</Label>
            <Select value={config.ai_personality} onValueChange={(v) => setConfig({ ...config, ai_personality: v })}>
              <SelectTrigger className="bg-slate-800/50 border-slate-700 mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="friendly">Friendly</SelectItem>
                <SelectItem value="casual">Casual</SelectItem>
                <SelectItem value="formal">Formal</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-300">Business Context</Label>
            <Textarea
              value={config.ai_context}
              onChange={(e) => setConfig({ ...config, ai_context: e.target.value })}
              placeholder="Describe your business, products, services..."
              className="bg-slate-800/50 border-slate-700 mt-2"
              rows={4}
            />
            <p className="text-xs text-slate-500 mt-1">This helps the AI understand your business better</p>
          </div>
        </TabsContent>

        <TabsContent value="languages" className="space-y-4 mt-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div>
              <p className="text-white font-medium">Auto-Translate</p>
              <p className="text-sm text-slate-400">Automatically respond in customer's language</p>
            </div>
            <Switch
              checked={config.auto_translate}
              onCheckedChange={(v) => setConfig({ ...config, auto_translate: v })}
            />
          </div>
          <div>
            <Label className="text-slate-300 mb-3 block">Supported Languages</Label>
            <div className="grid grid-cols-2 gap-2">
              {languages.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    const current = config.supported_languages || [];
                    const updated = current.includes(lang.code)
                      ? current.filter(l => l !== lang.code)
                      : [...current, lang.code];
                    setConfig({ ...config, supported_languages: updated });
                  }}
                  className={cn(
                    "p-3 rounded-lg border text-left transition-all",
                    config.supported_languages?.includes(lang.code)
                      ? "border-violet-500 bg-violet-500/10"
                      : "border-slate-700 hover:border-slate-600"
                  )}
                >
                  <span className="text-white">{lang.name}</span>
                </button>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="handover" className="space-y-4 mt-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div>
              <p className="text-white font-medium">Smart Handover</p>
              <p className="text-sm text-slate-400">Transfer to human agents when needed</p>
            </div>
            <Switch
              checked={config.handover_enabled}
              onCheckedChange={(v) => setConfig({ ...config, handover_enabled: v })}
            />
          </div>
          
          <div className="p-4 rounded-lg bg-slate-800/50">
            <p className="text-white font-medium mb-3">Automatic Handover Triggers</p>
            <div className="space-y-2 text-sm text-slate-400">
              <p>• Customer explicitly requests human assistance</p>
              <p>• Negative sentiment detected (frustrated customer)</p>
              <p>• Complex issues AI cannot resolve</p>
              <p>• High-value lead identified</p>
              <p>• Complaint or escalation detected</p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="crm" className="space-y-4 mt-4">
          <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
            <div>
              <p className="text-white font-medium">CRM Integration</p>
              <p className="text-sm text-slate-400">Sync leads with your CRM</p>
            </div>
            <Switch
              checked={config.crm_integration?.enabled}
              onCheckedChange={(v) => setConfig({
                ...config,
                crm_integration: { ...config.crm_integration, enabled: v }
              })}
            />
          </div>

          {config.crm_integration?.enabled && (
            <>
              <div>
                <Label className="text-slate-300">CRM Provider</Label>
                <Select
                  value={config.crm_integration?.provider}
                  onValueChange={(v) => setConfig({
                    ...config,
                    crm_integration: { ...config.crm_integration, provider: v }
                  })}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700 mt-2">
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    {crmProviders.map((crm) => (
                      <SelectItem key={crm.id} value={crm.id}>{crm.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
                <div>
                  <p className="text-white font-medium">Auto-Sync</p>
                  <p className="text-sm text-slate-400">Automatically sync new leads</p>
                </div>
                <Switch
                  checked={config.crm_integration?.auto_sync}
                  onCheckedChange={(v) => setConfig({
                    ...config,
                    crm_integration: { ...config.crm_integration, auto_sync: v }
                  })}
                />
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>

      <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
        <Button
          onClick={handleSubmit}
          disabled={isLoading}
          className="bg-violet-600 hover:bg-violet-700"
        >
          {isLoading ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Save Configuration
        </Button>
      </div>
    </div>
  );
}