import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, Package, TrendingUp, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function MyProducts() {
  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: myProducts = [] } = useQuery({
    queryKey: ['my-products', user?.email],
    queryFn: () => base44.entities.MarketplaceProduct.filter({ seller_email: user?.email }),
    enabled: !!user
  });

  const { data: mySales = [] } = useQuery({
    queryKey: ['my-sales', user?.email],
    queryFn: () => base44.entities.Purchase.filter({ seller_email: user?.email }),
    enabled: !!user
  });

  const totalRevenue = myProducts.reduce((sum, p) => sum + (p.total_revenue || 0), 0);
  const totalSales = myProducts.reduce((sum, p) => sum + (p.sales_count || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">My Products</h1>
          <p className="text-slate-400 mt-1">Manage your marketplace listings</p>
        </div>
        <Link to={createPageUrl('SellProduct')}>
          <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
            <Package className="w-4 h-4 mr-2" />
            Add New Product
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">${totalRevenue}</p>
              <p className="text-xs text-slate-400">Total Revenue</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-violet-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalSales}</p>
              <p className="text-xs text-slate-400">Total Sales</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <Package className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{myProducts.length}</p>
              <p className="text-xs text-slate-400">Products</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-4">Your Products</h3>
        <div className="space-y-3">
          {myProducts.map(product => (
            <div key={product.id} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg">
              <div className="flex items-center gap-4">
                {product.thumbnail_url && (
                  <img 
                    src={product.thumbnail_url} 
                    alt={product.title}
                    className="w-16 h-16 rounded-lg object-cover"
                  />
                )}
                <div>
                  <h4 className="text-white font-medium">{product.title}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className="text-xs">{product.status}</Badge>
                    <Badge variant="outline" className="text-xs border-slate-700">
                      {product.category}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-white">${product.price}</p>
                <p className="text-xs text-slate-400">{product.sales_count || 0} sales</p>
              </div>
            </div>
          ))}
          {myProducts.length === 0 && (
            <p className="text-center text-slate-500 py-8">No products yet</p>
          )}
        </div>
      </Card>
    </div>
  );
}