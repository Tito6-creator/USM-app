import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Sparkles, Zap, Crown, Building2, Rocket } from "lucide-react";
import PricingComparison from "@/components/pricing/PricingComparison";
import { cn } from "@/lib/utils";

export default function Pricing() {
    const [billingCycle, setBillingCycle] = useState('monthly');

    const calculateYearlyPrice = (monthlyPrice) => {
        const yearly = (monthlyPrice * 12 * 0.84).toFixed(2);
        return yearly;
    };

    const plans = [
        {
            name: "Starter",
            monthlyPrice: 29.99,
            period: "/month",
            description: "1 Brand/Account with 3 platforms",
            icon: Sparkles,
            color: "from-blue-500 to-cyan-500",
            features: [
                { category: "Creation & Publishing", items: [
                    "Manual post creation with AI content generation",
                    "AI video storyboard generation",
                    "Platform-specific content variations",
                    "Recurring post scheduling (daily/weekly/monthly)",
                    "Drag & drop calendar scheduling",
                    "Post templates library",
                    "Media library for assets"
                ]},
                { category: "AI & Automation", items: [
                    "AI content assistant (captions, hashtags, image descriptions, content optimization)"
                ]},
                { category: "Analytics & Reporting", items: [
                    "Dashboard with stats & metrics",
                    "Post performance breakdown",
                    "Trend analysis charts"
                ]},
                { category: "Social Media Management", items: [
                    "Multi-account management across platforms",
                    "Unified inbox with AI response suggestions"
                ]}
            ]
        },
        {
            name: "Entrepreneur",
            monthlyPrice: 59.99,
            period: "/month",
            description: "2 Brand/Accounts with 3 platforms",
            icon: Rocket,
            color: "from-purple-500 to-pink-500",
            popular: false,
            features: [
                { category: "Everything in Starter, plus:", items: []},
                { category: "Creation & Publishing", items: [
                    "Publishing queue management",
                    "Automated content workflows"
                ]},
                { category: "AI & Automation", items: [
                    "AI strategy generator",
                    "AI settings & personality customization",
                    "Auto-response manager for messages"
                ]},
                { category: "Analytics & Reporting", items: [
                    "Advanced analytics (engagement, reach, impressions, clicks, saves)",
                    "Stories/Reels analytics",
                    "Competitor analytics & content gap analysis",
                    "Competitor comparison charts"
                ]},
                { category: "Brand Management", items: [
                    "Brand kit creation (logos, colors, fonts)",
                    "Apply brand assets across content"
                ]},
                { category: "Marketing & Sales", items: [
                    "Campaign planner & wizard",
                    "Link in bio pages",
                    "Landing page builder"
                ]},
                { category: "Team & Support", items: [
                    "Team member management & permissions"
                ]}
            ]
        },
        {
            name: "Pro",
            monthlyPrice: 99.99,
            period: "/month",
            description: "3 Brands/Accounts with 5 platforms",
            icon: Zap,
            color: "from-orange-500 to-red-500",
            popular: true,
            features: [
                { category: "Everything in Entrepreneur, plus:", items: []},
                { category: "AI & Automation", items: [
                    "Automated workflows & rules (trigger-based actions)",
                    "AI chatbot with lead capture & handover",
                    "Performance predictions",
                    "Trend alerts & monitoring"
                ]},
                { category: "Analytics & Reporting", items: [
                    "A/B testing panel",
                    "Multi-metric trend analysis",
                    "Custom report builder with automated insights",
                    "Audience demographics analysis",
                    "Performance forecasting"
                ]},
                { category: "Brand Management", items: [
                    "Multiple brand kits",
                    "Brand voice settings",
                    "Brand hashtag libraries"
                ]},
                { category: "Social Media Management", items: [
                    "Brand mention monitoring",
                    "Sentiment tracking & crisis detection",
                    "Hashtag research & trending hashtags",
                    "Influencer discovery & management"
                ]},
                { category: "CRM & Client Management", items: [
                    "Basic contact management (up to 100 contacts)",
                    "CRM notes & activity history",
                    "Simple pipeline tracking",
                    "Basic automation: Auto-create tasks on deal stage changes (Demo/Trial)"
                ]},
                { category: "Marketing & Sales", items: [
                    "Email campaign manager",
                    "Sales funnel builder",
                    "Lead management with CRM sync",
                    "Conversion tracking with UTM parameters",
                    "Product opportunity identification"
                ]},
                { category: "Team & Support", items: [
                    "Support ticket system",
                    "FAQ management",
                    "Customer support interface",
                    "Activity logs"
                ]}
            ]
        },
        {
            name: "Agency",
            monthlyPrice: 199.99,
            period: "/month",
            description: "6 Brands/Accounts with 10 platforms",
            icon: Crown,
            color: "from-emerald-500 to-teal-500",
            features: [
                { category: "Everything in Pro, plus:", items: []},
                { category: "CRM & Client Management", items: [
                    "Full CRM suite (unlimited contacts)",
                    "Contact management with tags & status",
                    "Sales pipeline with drag-and-drop Kanban",
                    "CRM tasks & follow-ups (calendar + list views)",
                    "Deal management with value tracking",
                    "Activity history & chronological notes",
                    "CRM dashboard with metrics & charts",
                    "AI Next Action Suggestions",
                    "Deal Scoring - Auto-score leads",
                    "Client Health Scores - Predictive churn signals",
                    "Workflow Templates - Pre-built workflows",
                    "Advanced automation: Auto-create demo & trial tasks",
                    "Automated follow-ups for inactive leads (7+ days)",
                    "Churn risk alerts with urgent tasks",
                    "Client onboarding automation",
                    "Daily automated lead nurturing emails",
                    "HubSpot & Salesforce integration",
                    "Bidirectional CRM sync",
                    "Custom field mapping",
                    "Automated CRM actions on status changes"
                ]},
                { category: "Team Collaboration", items: [
                    "Team Workspaces – Organized team environments",
                    "Role-Based Permissions – Granular access control",
                    "Team Invitations – Email-based onboarding",
                    "Collaboration Tools – Real-time team features",
                    "Activity Tracking – Team member activity logs",
                    "Performance Monitoring – Team performance analytics"
                ]},
                { category: "Multi-User Features", items: [
                    "Unlimited User Access – Full team collaboration",
                    "Shared Content Library – Team-wide asset management",
                    "Collaborative Scheduling – Team-based content planning",
                    "Approval Workflows – Multi-level content approval",
                    "Team Analytics – Performance by team"
                ]},
                { category: "Goals & Planning", items: [
                    "Goal setting & tracking",
                    "Content repurposing tool",
                    "Competitor content monitoring",
                    "Enhanced Social Platform Integration",
                    "Advanced Reporting"
                ]}
            ]
        },
        {
            name: "Enterprise",
            monthlyPrice: 399.99,
            startsAt: true,
            period: "/month",
            description: "Higher brand & platform limits",
            icon: Building2,
            color: "from-violet-500 to-fuchsia-500",
            features: [
                { category: "Everything in Agency, plus:", items: [
                    "Dedicated account manager & onboarding",
                    "Custom integrations & API access",
                    "Advanced security & compliance",
                    "Tailored solutions for large teams & enterprises",
                    "Unlimited brands & accounts",
                    "Unlimited team members",
                    "Custom AI model training",
                    "White-label branding",
                    "SLA guarantees",
                    "24/7 priority support"
                ]}
            ]
        }
    ];

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
            {/* Header */}
            <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-20">
                <div className="max-w-7xl mx-auto px-6 text-center">
                    <h1 className="text-5xl font-bold mb-4">
                        Choose Your Plan
                    </h1>
                    <p className="text-xl text-slate-300 mb-6">
                        All plans include 7-day free trial, AI-powered content creation & scheduling, and basic support. Save 16% with annual billing.
                    </p>
                    <div className="flex items-center justify-center gap-3 text-sm flex-wrap">
                        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                            <Check className="w-4 h-4 text-green-400" />
                            <span>7-Day Free Trial</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                            <Check className="w-4 h-4 text-green-400" />
                            <span>AI-Powered Content</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
                            <Check className="w-4 h-4 text-green-400" />
                            <span>Basic Support</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Pricing Cards */}
            <div className="max-w-7xl mx-auto px-6 py-16">
                {/* Billing Toggle */}
                <div className="flex items-center justify-center gap-4 mb-12">
                    <span className={cn("text-sm font-medium", billingCycle === 'monthly' ? 'text-slate-900' : 'text-slate-600')}>
                        Monthly
                    </span>
                    <button
                        onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
                        className="relative w-14 h-7 bg-slate-300 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500"
                    >
                        <span
                            className={cn(
                                "absolute top-1 left-1 w-5 h-5 bg-slate-900 rounded-full transition-transform",
                                billingCycle === 'yearly' && "translate-x-7"
                            )}
                        />
                    </button>
                    <span className={cn("text-sm font-medium", billingCycle === 'yearly' ? 'text-slate-900' : 'text-slate-600')}>
                        Yearly
                    </span>
                    {billingCycle === 'yearly' && (
                        <Badge className="bg-emerald-500 text-white">
                            Save 16%
                        </Badge>
                    )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                    {plans.map((plan) => {
                        const Icon = plan.icon;
                        return (
                            <div
                                key={plan.name}
                                className={`relative bg-white rounded-2xl shadow-xl border-2 transition-all hover:shadow-2xl hover:-translate-y-2 ${
                                    plan.popular ? 'border-purple-500' : 'border-slate-200'
                                }`}
                            >
                                {plan.popular && (
                                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                                        <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-1">
                                            Most Popular
                                        </Badge>
                                    </div>
                                )}
                                
                                <div className="p-6">
                                    {/* Icon & Name */}
                                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}>
                                        <Icon className="w-7 h-7 text-white" />
                                    </div>
                                    
                                    <h3 className="text-2xl font-bold text-slate-900 mb-2">{plan.name}</h3>
                                    <p className="text-slate-600 text-sm mb-4">{plan.description}</p>
                                    
                                    {/* Price */}
                                    <div className="mb-6">
                                        <span className="text-4xl font-bold text-slate-900">
                                            {plan.startsAt && '+'}${billingCycle === 'monthly' ? plan.monthlyPrice : calculateYearlyPrice(plan.monthlyPrice)}
                                        </span>
                                        <span className="text-slate-600">/{billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
                                        {billingCycle === 'yearly' && (
                                            <p className="text-xs text-slate-500 mt-1">${plan.monthlyPrice}/mo billed annually</p>
                                        )}
                                    </div>
                                    
                                    <Button 
                                        className={`w-full bg-gradient-to-r ${plan.color} hover:opacity-90 text-white`}
                                    >
                                        Get Started
                                    </Button>
                                    
                                    {/* Features */}
                                    <div className="mt-6 space-y-4">
                                        {plan.features.map((section, idx) => (
                                            <div key={idx}>
                                                <p className="font-semibold text-slate-900 text-sm mb-2">
                                                    {section.category}
                                                </p>
                                                <div className="space-y-2">
                                                    {section.items.map((item, itemIdx) => (
                                                        <div key={itemIdx} className="flex items-start gap-2">
                                                            <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                                                            <span className="text-sm text-slate-600">{item}</span>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>

                {/* Feature Comparison */}
                <div className="mt-16 bg-white rounded-2xl shadow-xl p-8">
                    <h2 className="text-3xl font-bold text-slate-900 text-center mb-8">
                        Compare All Features
                    </h2>
                    <PricingComparison />
                </div>
            </div>
        </div>
    );
}