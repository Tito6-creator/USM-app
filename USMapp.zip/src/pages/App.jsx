import React, { useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Users, Eye, Heart, TrendingUp, MessageSquare, Share2, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import StatsCard from '@/components/dashboard/StatsCard';
import QuickActions from '@/components/dashboard/QuickActions';
import RecentActivity from '@/components/dashboard/RecentActivity';
import AccountsList from '@/components/dashboard/AccountsList';
import UpcomingPosts from '@/components/dashboard/UpcomingPosts';
import PiPBrowser from '@/components/dashboard/PiPBrowser';
import EnhancedAIAssistant from '@/components/ai/EnhancedAIAssistant';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

export default function App() {
  return (
    <ProtectedRoute>
      <AppContent />
    </ProtectedRoute>
  );
}

function AppContent() {
  const [showBrowser, setShowBrowser] = useState(false);
  const [researchUrl, setResearchUrl] = useState('https://www.google.com');
  const browserRef = useRef(null);
  
  const { data: accounts = [], isLoading: accountsLoading } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
    retry: 1,
    staleTime: 60000,
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'scheduled'],
    queryFn: () => base44.entities.Post.filter({ status: 'scheduled' }, 'scheduled_time', 10),
    retry: 1,
    staleTime: 30000,
  });

  const { data: recentPosts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 20),
    retry: 1,
    staleTime: 30000,
  });

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => base44.entities.Notification.list('-created_date', 20),
    retry: 1,
    staleTime: 60000,
  });

  // Calculate stats
  const totalFollowers = accounts.reduce((sum, acc) => sum + (acc.followers_count || 0), 0);
  const totalEngagement = recentPosts.reduce((sum, post) => sum + (post.likes || 0) + (post.comments || 0) + (post.shares || 0), 0);
  const totalReach = recentPosts.reduce((sum, post) => sum + (post.reach || 0), 0);
  const avgEngagementRate = accounts.length > 0 
    ? (accounts.reduce((sum, acc) => sum + (acc.engagement_rate || 0), 0) / accounts.length).toFixed(2)
    : 0;

  // Create activity feed from notifications
  const activities = notifications.map(notif => ({
    type: notif.type === 'follower' ? 'follower' 
        : notif.type === 'mention' ? 'mention'
        : notif.type === 'message' ? 'comment'
        : 'view',
    message: notif.message,
    platform: notif.platform,
    created_date: notif.created_date,
  }));

  if (accountsLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Welcome back!</h1>
          <p className="text-slate-400 mt-1">Here's what's happening across your social accounts</p>
        </div>
        <Button
          onClick={() => {
            setResearchUrl('https://www.google.com');
            setShowBrowser(true);
          }}
          className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
        >
          <Globe className="w-4 h-4 mr-2" />
          Research Browser
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Followers"
          value={totalFollowers.toLocaleString()}
          change={12.5}
          changeLabel="vs last month"
          icon={Users}
          gradient="from-violet-500 to-purple-500"
        />
        <StatsCard
          title="Total Reach"
          value={totalReach.toLocaleString()}
          change={8.2}
          changeLabel="vs last week"
          icon={Eye}
          gradient="from-cyan-500 to-blue-500"
        />
        <StatsCard
          title="Engagement"
          value={totalEngagement.toLocaleString()}
          change={15.3}
          changeLabel="vs last week"
          icon={Heart}
          gradient="from-rose-500 to-pink-500"
        />
        <StatsCard
          title="Engagement Rate"
          value={`${avgEngagementRate}%`}
          change={3.1}
          changeLabel="vs average"
          icon={TrendingUp}
          gradient="from-emerald-500 to-teal-500"
        />
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Quick Actions</h2>
        <QuickActions />
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <UpcomingPosts posts={posts} />
          <RecentActivity activities={activities} />
        </div>
        <div className="space-y-6">
          <AccountsList accounts={accounts} />
          {showBrowser && <EnhancedAIAssistant browserRef={browserRef} />}
        </div>
      </div>

      {/* Picture-in-Picture Browser */}
      {showBrowser && (
        <PiPBrowser 
          onClose={() => setShowBrowser(false)} 
          onBrowserRef={(ref) => { browserRef.current = ref.current; }}
          initialUrl={researchUrl}
        />
      )}
    </div>
  );
}