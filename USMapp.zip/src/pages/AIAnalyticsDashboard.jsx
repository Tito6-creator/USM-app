import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart
} from 'recharts';
import {
  TrendingUp, TrendingDown, Sparkles, Brain, Target, Clock,
  Hash, Image, Calendar, Award, AlertCircle, CheckCircle2,
  Users, Eye, Heart, MessageCircle, Share2, Loader2, RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import PlatformIcon from '@/components/ui/PlatformIcon';

const COLORS = ['#8b5cf6', '#d946ef', '#3b82f6', '#10b981', '#f59e0b', '#ef4444'];

export default function AIAnalyticsDashboard() {
  const [dateRange, setDateRange] = useState('30');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiInsights, setAiInsights] = useState(null);

  const { data: posts = [], isLoading } = useQuery({
    queryKey: ['posts', 'analytics', dateRange],
    queryFn: async () => {
      const allPosts = await base44.entities.Post.filter({ status: 'published' }, '-published_time', 200);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - parseInt(dateRange));
      return allPosts.filter(p => p.published_time && new Date(p.published_time) >= cutoffDate);
    }
  });

  // Calculate metrics
  const metrics = React.useMemo(() => {
    if (!posts.length) return null;

    const totalLikes = posts.reduce((sum, p) => sum + (p.likes || 0), 0);
    const totalComments = posts.reduce((sum, p) => sum + (p.comments || 0), 0);
    const totalShares = posts.reduce((sum, p) => sum + (p.shares || 0), 0);
    const totalReach = posts.reduce((sum, p) => sum + (p.reach || 0), 0);
    const totalEngagement = totalLikes + totalComments + totalShares;
    const avgEngagementRate = posts.reduce((sum, p) => sum + (p.engagement_rate || 0), 0) / posts.length;

    // Engagement over time
    const engagementByDate = posts.reduce((acc, post) => {
      const date = new Date(post.published_time).toLocaleDateString();
      if (!acc[date]) acc[date] = { date, engagement: 0, posts: 0 };
      acc[date].engagement += (post.likes || 0) + (post.comments || 0) + (post.shares || 0);
      acc[date].posts += 1;
      return acc;
    }, {});
    const engagementTimeline = Object.values(engagementByDate).sort((a, b) => 
      new Date(a.date) - new Date(b.date)
    );

    // Platform performance
    const platformStats = posts.reduce((acc, post) => {
      post.platforms?.forEach(platform => {
        if (!acc[platform]) acc[platform] = { platform, posts: 0, engagement: 0 };
        acc[platform].posts += 1;
        acc[platform].engagement += (post.likes || 0) + (post.comments || 0) + (post.shares || 0);
      });
      return acc;
    }, {});

    // Content type performance
    const typeStats = posts.reduce((acc, post) => {
      const type = post.media_type || 'text';
      if (!acc[type]) acc[type] = { name: type, posts: 0, engagement: 0 };
      acc[type].posts += 1;
      acc[type].engagement += (post.likes || 0) + (post.comments || 0) + (post.shares || 0);
      return acc;
    }, {});

    // Best posting times
    const hourStats = posts.reduce((acc, post) => {
      const hour = new Date(post.published_time).getHours();
      if (!acc[hour]) acc[hour] = { hour: `${hour}:00`, count: 0, engagement: 0 };
      acc[hour].count += 1;
      acc[hour].engagement += (post.likes || 0) + (post.comments || 0) + (post.shares || 0);
      return acc;
    }, {});

    // Top posts
    const topPosts = [...posts]
      .sort((a, b) => {
        const engA = (a.likes || 0) + (a.comments || 0) * 2 + (a.shares || 0) * 3;
        const engB = (b.likes || 0) + (b.comments || 0) * 2 + (b.shares || 0) * 3;
        return engB - engA;
      })
      .slice(0, 5);

    return {
      totalPosts: posts.length,
      totalLikes,
      totalComments,
      totalShares,
      totalReach,
      totalEngagement,
      avgEngagementRate,
      engagementTimeline,
      platformStats: Object.values(platformStats),
      typeStats: Object.values(typeStats),
      hourStats: Object.values(hourStats).sort((a, b) => parseInt(a.hour) - parseInt(b.hour)),
      topPosts
    };
  }, [posts]);

  const generateAIInsights = async () => {
    if (!metrics || posts.length === 0) {
      toast.error('Not enough data to analyze');
      return;
    }

    setIsAnalyzing(true);
    toast.info('🤖 AI is analyzing your performance...');
    
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this social media performance data and provide comprehensive insights:

Posts analyzed: ${metrics.totalPosts}
Total engagement: ${metrics.totalEngagement}
Average engagement rate: ${metrics.avgEngagementRate.toFixed(2)}%

Platform performance:
${metrics.platformStats.map(p => `- ${p.platform}: ${p.posts} posts, ${p.engagement} engagement`).join('\n')}

Content type performance:
${metrics.typeStats.map(t => `- ${t.name}: ${t.posts} posts, ${t.engagement} engagement`).join('\n')}

Provide:
1. Overall performance assessment (1-2 sentences)
2. Key strengths (3-4 bullet points)
3. Areas for improvement (3-4 bullet points)
4. Content strategy recommendations (5 specific actions)
5. Predicted trends for next 30 days
6. Optimal posting schedule suggestions
7. Content type priorities

Format as JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            performance_summary: { type: 'string' },
            strengths: { type: 'array', items: { type: 'string' } },
            improvements: { type: 'array', items: { type: 'string' } },
            recommendations: { type: 'array', items: { type: 'string' } },
            predicted_trends: { type: 'string' },
            optimal_schedule: { type: 'string' },
            content_priorities: { type: 'array', items: { type: 'string' } }
          }
        }
      });

      setAiInsights(result);
      toast.success('✅ AI analysis complete!');
    } catch (error) {
      console.error('AI insights error:', error);
      toast.error('❌ Failed to generate insights: ' + error.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (!metrics) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-12 h-12 text-slate-400 mx-auto mb-4" />
        <p className="text-slate-400">No data available. Publish some posts to see analytics.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-violet-400" />
            AI Analytics Dashboard
          </h1>
          <p className="text-slate-400 mt-1">Comprehensive insights powered by AI</p>
        </div>
        <div className="flex gap-2">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
          </select>
          <Button
            onClick={generateAIInsights}
            disabled={isAnalyzing}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            {isAnalyzing ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4 mr-2" />
            )}
            AI Insights
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Posts</p>
              <p className="text-2xl font-bold text-white mt-1">{metrics.totalPosts}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Engagement</p>
              <p className="text-2xl font-bold text-white mt-1">{metrics.totalEngagement.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-blue-400" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Avg Engagement Rate</p>
              <p className="text-2xl font-bold text-white mt-1">{metrics.avgEngagementRate.toFixed(1)}%</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Target className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Reach</p>
              <p className="text-2xl font-bold text-white mt-1">{metrics.totalReach.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <Users className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Engagement Timeline */}
          <Card className="p-6 bg-slate-900/50 border-slate-800">
            <h3 className="text-white font-semibold mb-4">Engagement Over Time</h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={metrics.engagementTimeline}>
                <defs>
                  <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Area type="monotone" dataKey="engagement" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorEngagement)" />
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Platform Performance */}
            <Card className="p-6 bg-slate-900/50 border-slate-800">
              <h3 className="text-white font-semibold mb-4">Platform Performance</h3>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={metrics.platformStats}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="platform" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                    labelStyle={{ color: '#e2e8f0' }}
                  />
                  <Bar dataKey="engagement" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </Card>

            {/* Content Type Distribution */}
            <Card className="p-6 bg-slate-900/50 border-slate-800">
              <h3 className="text-white font-semibold mb-4">Content Type Performance</h3>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={metrics.typeStats}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => `${entry.name}: ${entry.engagement}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="engagement"
                  >
                    {metrics.typeStats.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          {/* Best Posting Times */}
          <Card className="p-6 bg-slate-900/50 border-slate-800">
            <h3 className="text-white font-semibold mb-4">Best Posting Times</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metrics.hourStats}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="hour" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Line type="monotone" dataKey="engagement" stroke="#8b5cf6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          {/* Top Performing Posts */}
          <Card className="p-6 bg-slate-900/50 border-slate-800">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
              <Award className="w-5 h-5 text-yellow-400" />
              Top Performing Posts
            </h3>
            <div className="space-y-4">
              {metrics.topPosts.map((post, idx) => (
                <div key={post.id} className="p-4 bg-slate-800/50 rounded-lg border border-slate-700">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                          #{idx + 1}
                        </Badge>
                        {post.platforms?.map(p => (
                          <PlatformIcon key={p} platform={p} size="xs" />
                        ))}
                      </div>
                      <p className="text-white font-medium mb-1">{post.title}</p>
                      <p className="text-slate-400 text-sm line-clamp-2">{post.content}</p>
                    </div>
                  </div>
                  <div className="flex gap-4 mt-3 text-sm">
                    <span className="flex items-center gap-1 text-rose-400">
                      <Heart className="w-4 h-4" /> {post.likes || 0}
                    </span>
                    <span className="flex items-center gap-1 text-blue-400">
                      <MessageCircle className="w-4 h-4" /> {post.comments || 0}
                    </span>
                    <span className="flex items-center gap-1 text-emerald-400">
                      <Share2 className="w-4 h-4" /> {post.shares || 0}
                    </span>
                    <span className="flex items-center gap-1 text-violet-400">
                      <Eye className="w-4 h-4" /> {post.reach || 0}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          {!aiInsights ? (
            <Card className="p-12 bg-slate-900/50 border-slate-800 text-center">
              <Brain className="w-16 h-16 text-violet-400 mx-auto mb-4" />
              <h3 className="text-white font-semibold text-xl mb-2">Generate AI Insights</h3>
              <p className="text-slate-400 mb-6">
                Let AI analyze your performance and provide actionable recommendations
              </p>
              <Button
                onClick={generateAIInsights}
                disabled={isAnalyzing}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {isAnalyzing ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4 mr-2" />
                )}
                Analyze Now
              </Button>
            </Card>
          ) : (
            <>
              <Card className="p-6 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border-violet-500/20">
                <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-violet-400" />
                  Performance Summary
                </h3>
                <p className="text-slate-300">{aiInsights.performance_summary}</p>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="p-6 bg-slate-900/50 border-slate-800">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    Key Strengths
                  </h3>
                  <ul className="space-y-2">
                    {aiInsights.strengths.map((strength, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
                        <span>{strength}</span>
                      </li>
                    ))}
                  </ul>
                </Card>

                <Card className="p-6 bg-slate-900/50 border-slate-800">
                  <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-amber-400" />
                    Areas for Improvement
                  </h3>
                  <ul className="space-y-2">
                    {aiInsights.improvements.map((improvement, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-slate-300">
                        <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                        <span>{improvement}</span>
                      </li>
                    ))}
                  </ul>
                </Card>
              </div>

              <Card className="p-6 bg-slate-900/50 border-slate-800">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-blue-400" />
                  Recommendations
                </h3>
                <div className="space-y-3">
                  {aiInsights.recommendations.map((rec, idx) => (
                    <div key={idx} className="p-3 bg-slate-800/50 rounded-lg border border-slate-700">
                      <p className="text-slate-300">{rec}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="p-6 bg-slate-900/50 border-slate-800">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-violet-400" />
                    Optimal Schedule
                  </h3>
                  <p className="text-slate-300">{aiInsights.optimal_schedule}</p>
                </Card>

                <Card className="p-6 bg-slate-900/50 border-slate-800">
                  <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-fuchsia-400" />
                    Predicted Trends
                  </h3>
                  <p className="text-slate-300">{aiInsights.predicted_trends}</p>
                </Card>
              </div>

              <Card className="p-6 bg-slate-900/50 border-slate-800">
                <h3 className="text-white font-semibold mb-4 flex items-center gap-2">
                  <Image className="w-5 h-5 text-emerald-400" />
                  Content Priorities
                </h3>
                <div className="flex flex-wrap gap-2">
                  {aiInsights.content_priorities.map((priority, idx) => (
                    <Badge key={idx} className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      {priority}
                    </Badge>
                  ))}
                </div>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}