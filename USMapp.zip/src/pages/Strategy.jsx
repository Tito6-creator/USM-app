import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import {
  Sparkles,
  Plus,
  Target,
  Clock,
  Trash2,
  Eye,
  MoreVertical,
  Zap,
  FileText,
  ChevronRight,
  TrendingUp,
  RefreshCw,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import StrategyWizard from '@/components/strategy/StrategyWizard';
import StrategyResults from '@/components/strategy/StrategyResults';
import CompetitorContentGapAnalysis from '@/components/strategy/CompetitorContentGapAnalysis';
import ContentRepurposingTool from '@/components/strategy/ContentRepurposingTool';
import PerformancePrediction from '@/components/strategy/PerformancePrediction';
import TrendMonitor from '@/components/competitors/TrendMonitor';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

const goalLabels = {
  brand_awareness: 'Brand Awareness',
  engagement: 'Engagement',
  lead_generation: 'Lead Generation',
  sales: 'Sales',
  community_building: 'Community',
  traffic: 'Traffic',
  followers_growth: 'Followers Growth',
};

const statusColors = {
  draft: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  completed: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  archived: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
};

export default function Strategy() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  
  const [showWizard, setShowWizard] = useState(false);
  const [selectedStrategy, setSelectedStrategy] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState('strategies');

  const { data: strategies = [], isLoading } = useQuery({
    queryKey: ['strategies'],
    queryFn: () => base44.entities.MarketingStrategy.list('-created_date'),
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors'],
    queryFn: () => base44.entities.Competitor.list(),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 50),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MarketingStrategy.create(data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['strategies'] });
      setShowWizard(false);
      setSelectedStrategy(data);
      toast.success('Strategy generated successfully!');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MarketingStrategy.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['strategies'] });
      setSelectedStrategy(null);
      toast.success('Strategy deleted');
    },
  });

  const generateStrategy = async (formData) => {
    setIsGenerating(true);
    toast.info('🤖 AI is creating your strategy...');

    // Build context from existing data
    const accountsContext = accounts.length > 0 
      ? `Connected accounts: ${accounts.map(a => `${a.platform} (@${a.username}) with ${a.followers_count} followers`).join(', ')}`
      : '';
    
    const competitorsContext = competitors.length > 0
      ? `Competitors being tracked: ${competitors.map(c => `${c.name} on ${c.platform} with ${c.followers_count} followers and ${c.engagement_rate}% engagement`).join(', ')}`
      : '';

    const recentPostsContext = posts.length > 0
      ? `Recent post performance: Average ${Math.round(posts.reduce((sum, p) => sum + (p.likes || 0), 0) / posts.length)} likes, ${Math.round(posts.reduce((sum, p) => sum + (p.comments || 0), 0) / posts.length)} comments per post`
      : '';

    const prompt = `You are an expert social media marketing strategist. Generate a comprehensive marketing strategy based on the following inputs:

Goal: ${formData.goal}
Target Audience: ${formData.target_audience}
Industry: ${formData.industry}
Brand Voice: ${formData.brand_voice}
Platforms: ${formData.platforms.join(', ')}
Budget: ${formData.budget_range}
Duration: ${formData.duration_weeks} weeks
Additional Context: ${formData.additional_context || 'None'}

${accountsContext}
${competitorsContext}
${recentPostsContext}

Generate a detailed strategy with:
1. Optimal posting times for each platform and day (7 entries minimum)
2. 5 content themes with descriptions and recommended content types
3. 5 caption templates with different styles
4. 20 relevant hashtags grouped by category with estimated reach and competition level
5. 3 creative campaign ideas with content plans
6. KPI targets based on the goal
7. 3-5 trend recommendations to leverage
8. 3-5 competitor insights with actionable advice

Be specific, actionable, and creative. Tailor everything to the target audience and industry.`;

    try {
      const result = await base44.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          optimal_posting_times: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                platform: { type: 'string' },
                day: { type: 'string' },
                time: { type: 'string' },
                engagement_score: { type: 'number' }
              }
            }
          },
          content_themes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                theme: { type: 'string' },
                description: { type: 'string' },
                frequency: { type: 'string' },
                content_types: { type: 'array', items: { type: 'string' } }
              }
            }
          },
          caption_templates: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                type: { type: 'string' },
                template: { type: 'string' },
                use_case: { type: 'string' }
              }
            }
          },
          recommended_hashtags: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                hashtag: { type: 'string' },
                category: { type: 'string' },
                estimated_reach: { type: 'number' },
                competition: { type: 'string' }
              }
            }
          },
          campaign_ideas: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                description: { type: 'string' },
                objective: { type: 'string' },
                duration_days: { type: 'number' },
                content_plan: { type: 'array', items: { type: 'string' } },
                expected_results: { type: 'string' }
              }
            }
          },
          kpi_targets: {
            type: 'object',
            properties: {
              followers_growth: { type: 'number' },
              engagement_rate: { type: 'number' },
              reach_increase: { type: 'number' },
              conversions: { type: 'number' }
            }
          },
          trend_recommendations: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                trend: { type: 'string' },
                relevance: { type: 'string' },
                how_to_leverage: { type: 'string' }
              }
            }
          },
          competitor_insights: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                insight: { type: 'string' },
                action: { type: 'string' }
              }
            }
          },
          ai_confidence_score: { type: 'number' }
        }
      }
    });

    const strategyData = {
      ...formData,
      ...result,
      status: 'draft',
    };

      createMutation.mutate(strategyData);
    } catch (error) {
      console.error('Strategy generation error:', error);
      toast.error('❌ Failed to generate strategy: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCreateCampaign = (strategy) => {
    // Navigate to create campaign with pre-filled data
    navigate(createPageUrl('CreatePost') + `?strategy=${strategy.id}`);
  };

  if (selectedStrategy) {
    return (
      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={() => setSelectedStrategy(null)}
          className="text-slate-400 hover:text-white -ml-2"
        >
          <ChevronRight className="w-4 h-4 mr-1 rotate-180" />
          Back to Strategies
        </Button>
        <StrategyResults 
          strategy={selectedStrategy} 
          onCreateCampaign={handleCreateCampaign}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">AI Content Strategy</h1>
          <p className="text-slate-400 mt-1">Advanced AI-powered strategy tools and insights</p>
        </div>
        <Button 
          onClick={() => setShowWizard(true)}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          Generate New Strategy
        </Button>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="strategies" className="data-[state=active]:bg-violet-600">
            <FileText className="w-4 h-4 mr-2" />
            My Strategies
          </TabsTrigger>
          <TabsTrigger value="gaps" className="data-[state=active]:bg-violet-600">
            <Target className="w-4 h-4 mr-2" />
            Gap Analysis
          </TabsTrigger>
          <TabsTrigger value="trends" className="data-[state=active]:bg-violet-600">
            <TrendingUp className="w-4 h-4 mr-2" />
            Trend Monitor
          </TabsTrigger>
          <TabsTrigger value="repurpose" className="data-[state=active]:bg-violet-600">
            <RefreshCw className="w-4 h-4 mr-2" />
            Repurpose
          </TabsTrigger>
          <TabsTrigger value="predict" className="data-[state=active]:bg-violet-600">
            <BarChart3 className="w-4 h-4 mr-2" />
            Predict
          </TabsTrigger>
        </TabsList>

        <TabsContent value="strategies" className="mt-6">

      {/* Strategy Wizard Dialog */}
      <Dialog open={showWizard} onOpenChange={setShowWizard}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-4xl max-h-[90vh] overflow-y-auto">
          <StrategyWizard 
            onComplete={generateStrategy}
            isGenerating={isGenerating}
          />
        </DialogContent>
      </Dialog>

      {/* Strategies List */}
      {strategies.length === 0 && !isLoading ? (
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-12 text-center">
          <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 flex items-center justify-center mb-6">
            <Sparkles className="w-10 h-10 text-violet-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">No strategies yet</h3>
          <p className="text-slate-400 mb-6 max-w-md mx-auto">
            Let AI analyze trends, competitors, and your performance to create a personalized marketing strategy
          </p>
          <Button 
            onClick={() => setShowWizard(true)}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Generate Your First Strategy
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {strategies.map((strategy) => (
            <div
              key={strategy.id}
              className={cn(
                "rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden",
                "hover:border-slate-700/50 transition-all cursor-pointer group"
              )}
              onClick={() => setSelectedStrategy(strategy)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center">
                    <Target className="w-6 h-6 text-white" />
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="text-slate-400 opacity-0 group-hover:opacity-100">
                        <MoreVertical className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem onClick={(e) => {
                        e.stopPropagation();
                        setSelectedStrategy(strategy);
                      }}>
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteMutation.mutate(strategy.id);
                        }}
                        className="text-rose-400"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <h3 className="font-semibold text-white text-lg mb-2">{strategy.title}</h3>
                
                <div className="flex items-center gap-2 flex-wrap mb-4">
                  <Badge className={statusColors[strategy.status]}>
                    {strategy.status}
                  </Badge>
                  <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                    {goalLabels[strategy.goal]}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-slate-400">
                    <Clock className="w-4 h-4" />
                    <span>{strategy.duration_weeks} weeks</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400">
                    <FileText className="w-4 h-4" />
                    <span>{strategy.content_themes?.length || 0} content themes</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-400">
                    <Zap className="w-4 h-4 text-amber-400" />
                    <span>{strategy.ai_confidence_score}% AI confidence</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-800">
                  <p className="text-xs text-slate-500">
                    Created {format(new Date(strategy.created_date), 'MMM d, yyyy')}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
        </TabsContent>

        <TabsContent value="gaps" className="mt-6">
          <CompetitorContentGapAnalysis />
        </TabsContent>

        <TabsContent value="trends" className="mt-6">
          <TrendMonitor competitors={competitors} />
        </TabsContent>

        <TabsContent value="repurpose" className="mt-6">
          <ContentRepurposingTool />
        </TabsContent>

        <TabsContent value="predict" className="mt-6">
          <PerformancePrediction />
        </TabsContent>
      </Tabs>
    </div>
  );
}