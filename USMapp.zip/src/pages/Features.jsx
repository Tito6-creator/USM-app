import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import {
  Sparkles,
  Calendar,
  MessageSquare,
  BarChart3,
  Users,
  Shield,
  Zap,
  Brain,
  Globe,
  Clock,
  Target,
  TrendingUp,
  CheckCircle2,
  Search,
  Smartphone,
  Code,
  Monitor,
  Headphones,
  DollarSign
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';

const featureCategories = [
  {
    category: 'AI & Automation',
    icon: Brain,
    color: 'from-violet-500 to-purple-500',
    features: [
      { name: 'AI-Powered Content Generation', description: 'Automated content creation with advanced AI models' },
      { name: 'Enhanced AI Assistant', description: 'Multi-modal interactions with voice input and screen analysis' },
      { name: 'AI Autopilot with Voice Control', description: 'Hands-free automation with voice commands and navigation' },
      { name: 'Autopilot Auto Content Generation', description: 'Automated post creation on demand' },
      { name: 'Autopilot Smart Scheduling', description: 'AI-optimized posting time selection' },
      { name: 'Autopilot Auto Responses', description: 'Intelligent message reply automation' },
      { name: 'Autopilot Performance Optimization', description: 'Continuous content improvement suggestions' },
      { name: 'Autopilot Calendar Auto-Fill', description: 'AI-powered calendar population' },
      { name: 'Autopilot Goal Achievement', description: 'Automated goal-driven actions' },
      { name: 'Voice-Controlled Navigation', description: 'Navigate app with voice commands' },
      { name: 'Voice Content Creation', description: 'Generate posts using voice prompts' },
      { name: 'One-Click Voice Conversation', description: 'Toggle voice dialog mode with single button' },
      { name: 'Custom AI Assistant Name', description: 'Personalize your AI with custom name' },
      { name: 'Voice Gender Selection', description: 'Choose male, female, or neutral voice' },
      { name: 'Personality Customization', description: 'Professional, friendly, casual, enthusiastic, witty, or formal' },
      { name: 'Character Style Selection', description: 'Helper, mentor, coach, expert, or companion roles' },
      { name: 'Voice Tone Control', description: 'Warm, neutral, energetic, calm, or authoritative tones' },
      { name: 'Voice Pitch Adjustment', description: 'Fine-tune voice pitch from 0.5x to 2.0x' },
      { name: 'Voice Speed Control', description: 'Adjust speaking speed from 0.5x to 2.0x' },
      { name: 'Automation Rules Engine', description: 'Trigger-based automated workflows' },
      { name: 'Sentiment Analysis', description: 'Automated sentiment tracking across platforms' },
      { name: 'AI Content Suggestions', description: 'Intelligent content ideas and recommendations' },
      { name: 'Performance Predictions', description: 'AI forecasting with 7-day predictions' },
      { name: 'Trend Detection', description: 'AI-powered trend identification' },
      { name: 'Product Opportunity Detection', description: 'AI-powered market gap identification' },
    ]
  },
  {
    category: 'Content Management',
    icon: Calendar,
    color: 'from-cyan-500 to-blue-500',
    features: [
      { name: 'Visual Calendar Interface', description: 'Drag-and-drop scheduling with color-coding' },
      { name: 'Multiple Calendar Views', description: 'Monthly, weekly, and daily perspectives' },
      { name: 'Content Categories', description: 'Color-coded content organization' },
      { name: 'Campaign Management', description: 'Organize content by campaigns' },
      { name: 'Bulk Operations', description: 'Mass edit and schedule operations' },
      { name: 'Rich Text Editor', description: '2000 character limit posts' },
      { name: 'Media Library', description: 'Image and video management' },
      { name: 'Content Templates', description: 'Reusable post formats' },
      { name: 'Draft System', description: 'Save and edit before publishing' },
      { name: 'Approval Workflows', description: 'Multi-level content approval' },
      { name: 'Recurring Posts', description: 'Automated repetitive content' },
      { name: 'Queue Management', description: 'Priority-based posting queues' },
    ]
  },
  {
    category: 'Analytics & Reporting',
    icon: BarChart3,
    color: 'from-emerald-500 to-teal-500',
    features: [
      { name: 'Real-time Dashboard', description: 'Live metrics and trend analysis' },
      { name: 'Advanced Analytics', description: 'Charts, competitor analysis, visualizations' },
      { name: 'Trend Analysis', description: 'Multi-metric performance trends with growth tracking' },
      { name: 'Post Performance Breakdown', description: 'Detailed post-level metrics and insights' },
      { name: 'Content Format Analysis', description: 'Performance comparison by media type and platform' },
      { name: 'Competitor Comparison', description: 'Multi-dimensional competitive analysis with radar charts' },
      { name: 'ROI Tracking', description: 'Conversion analytics and funnel analysis' },
      { name: 'Audience Demographics', description: 'Age, gender, location, interest insights' },
      { name: 'Performance Forecasting', description: 'Trend direction and seasonal analysis' },
      { name: 'Custom Reports', description: 'Personalized reporting with multiple exports' },
      { name: 'Stories & Reels Analytics', description: 'Detailed ephemeral content metrics' },
      { name: 'Engagement Analytics', description: 'Detailed engagement patterns' },
      { name: 'Interactive Charts', description: 'Real-time data visualization' },
      { name: 'Comparative Analytics', description: 'Cross-platform performance' },
      { name: 'Custom Metrics', description: 'User-defined KPI tracking' },
    ]
  },
  {
    category: 'CRM & Client Management',
    icon: Users,
    color: 'from-blue-500 to-indigo-500',
    features: [
      { name: 'Contact Management', description: 'Complete client database with tags and status tracking' },
      { name: 'Sales Pipeline', description: 'Drag-and-drop Kanban pipeline with deal stages' },
      { name: 'CRM Tasks & Follow-Ups', description: 'Task management with calendar and list views' },
      { name: 'Activity History & Notes', description: 'Chronological notes and interaction tracking' },
      { name: 'CRM Dashboard', description: 'Metrics, charts, and pipeline visualization' },
      { name: 'Deal Management', description: 'Track value, next actions, and close dates' },
      { name: 'Contact Status Tracking', description: 'Lead → Demo → Trial → Client → Churn Risk flow' },
      { name: 'Social Account Linking', description: 'Connect client social accounts to contacts' },
      { name: 'CRM Automation', description: 'Auto-create tasks when deals change stages' },
      { name: 'Auto Demo Tasks', description: 'Automatically create demo tasks when deal moves to Demo stage' },
      { name: 'Auto Trial Tasks', description: 'Create setup, check-in, and renewal tasks for Trial stage' },
      { name: 'Inactive Lead Follow-ups', description: 'Auto-send emails to leads with no interaction in 7+ days' },
      { name: 'Churn Risk Alerts', description: 'Auto-create urgent tasks and send alerts for churn risk contacts' },
      { name: 'Client Onboarding Automation', description: 'Auto-create onboarding tasks when contact becomes client' },
      { name: 'AI Next Action Suggestions', description: 'AI-powered recommendations for next steps based on contact history' },
      { name: 'Deal Scoring', description: 'Automatic lead scoring based on interaction, demo views, and engagement' },
      { name: 'Client Health Scores', description: 'Predictive churn detection based on login, posting, and engagement' },
      { name: 'Workflow Templates', description: 'Pre-built workflows for onboarding, demos, renewals, and outbound' },
      { name: 'HubSpot Integration', description: 'Bidirectional sync with field mapping' },
      { name: 'Salesforce Integration', description: 'Bidirectional sync with field mapping' },
      { name: 'CRM Field Mapping', description: 'Custom field mapping between app and CRM' },
      { name: 'Automated CRM Actions', description: 'Trigger CRM actions based on lead status changes' },
    ]
  },
  {
    category: 'Communication & Support',
    icon: MessageSquare,
    color: 'from-fuchsia-500 to-pink-500',
    features: [
      { name: 'Unified Inbox', description: 'All platforms in one inbox' },
      { name: 'Multi-language Support', description: 'English, Spanish, French, Portuguese' },
      { name: 'Message Templates', description: 'Standardized response templates' },
      { name: 'Support Ticket System', description: 'Integrated help desk' },
      { name: 'FAQ Management', description: 'Self-service knowledge base' },
      { name: 'Priority Management', description: 'Important message prioritization' },
      { name: 'Team Collaboration', description: 'Shared inbox management' },
      { name: 'Escalation Management', description: 'Support ticket routing' },
      { name: 'AI Chatbot', description: 'Automated customer interactions' },
      { name: 'Lead Generation', description: 'Automated lead capture' },
      { name: 'Email Campaigns', description: 'Bulk email management with AI' },
    ]
  },
  {
    category: 'Security & Access',
    icon: Shield,
    color: 'from-orange-500 to-red-500',
    features: [
      { name: 'OAuth 2.0 Integration', description: 'Secure platform connections' },
      { name: 'Role-Based Access Control', description: 'Owner, Admin, Editor, Viewer roles' },
      { name: 'Team Invitations', description: 'Email-based team onboarding' },
      { name: 'Two-Factor Authentication', description: 'Enhanced security layer' },
      { name: 'Session Management', description: 'Secure session handling' },
      { name: 'Activity Logging', description: 'Complete audit trail' },
      { name: 'GDPR Compliance', description: 'Data protection and consent management' },
    ]
  },
  {
    category: 'Campaign Management',
    icon: Target,
    color: 'from-amber-500 to-yellow-500',
    features: [
      { name: 'Campaign Creation', description: 'Comprehensive campaign setup and management' },
      { name: 'ROI Tracking', description: 'Campaign return on investment monitoring' },
      { name: 'Budget Management', description: 'Campaign spending tracking and control' },
      { name: 'Multi-Platform Campaigns', description: 'Cross-platform coordination and execution' },
      { name: 'Goal Tracking', description: 'Campaign objective monitoring and progress' },
      { name: 'Performance Analytics', description: 'Campaign-specific insights and metrics' },
      { name: 'Conversion Tracking', description: 'Goal-based conversion monitoring' },
      { name: 'A/B Testing', description: 'Content performance testing and optimization' },
      { name: 'Landing Page Builder', description: 'Create custom landing pages with templates' },
      { name: 'Landing Page Integration', description: 'Direct linking capabilities to campaigns' },
      { name: 'Lead Generation', description: 'Automated lead capture systems' },
      { name: 'Email Marketing Integration', description: 'Integrated email campaigns' },
    ]
  },
  {
    category: 'Strategy & Planning',
    icon: TrendingUp,
    color: 'from-violet-500 to-indigo-500',
    features: [
      { name: 'AI Strategy Generator', description: 'Comprehensive marketing strategies' },
      { name: 'Campaign Planner', description: 'Multi-platform campaign management' },
      { name: 'Content Strategy Engine', description: 'AI-driven strategy recommendations' },
      { name: 'Brand Kit Management', description: 'Create and manage brand assets (logos, colors, fonts)' },
      { name: 'Brand Asset Application', description: 'Apply brand kits across content and templates' },
      { name: 'Competitor Monitoring', description: 'Track and analyze competitors' },
      { name: 'Hashtag Research', description: 'Optimal hashtag recommendations' },
      { name: 'Influencer Management', description: 'Partnership tracking and ROI' },
      { name: 'Brand Monitoring', description: 'Track brand mentions and sentiment' },
      { name: 'Goals & KPIs', description: 'Set and track performance goals' },
    ]
  },
  {
    category: 'Cross-Platform Publishing',
    icon: Globe,
    color: 'from-indigo-500 to-purple-500',
    features: [
      { name: 'Multi-Platform Support', description: 'Facebook, Instagram, YouTube, TikTok, LinkedIn, Pinterest, Threads' },
      { name: 'Simultaneous Publishing', description: 'Post to multiple platforms at once' },
      { name: 'Platform-Specific Optimization', description: 'Tailor content per platform' },
      { name: 'Timezone Support', description: 'Global posting capabilities' },
      { name: 'Account Management', description: 'Connect and manage multiple accounts' },
      { name: 'Bulk Scheduling', description: 'Mass content scheduling' },
      { name: 'Cross-Platform Analytics', description: 'Unified performance metrics' },
    ]
  },
  {
    category: 'Advanced Features',
    icon: Zap,
    color: 'from-rose-500 to-pink-500',
    features: [
      { name: 'Sales Funnel Builder', description: 'Automated conversion workflows' },
      { name: 'Link in Bio', description: 'Customizable landing pages' },
      { name: 'QR Code Generator', description: 'Create trackable QR codes' },
      { name: 'Crisis Detection', description: 'Real-time brand reputation monitoring' },
      { name: 'Content Repurposing', description: 'Adapt content for different platforms' },
      { name: 'Performance Prediction', description: 'AI-powered engagement forecasting' },
      { name: 'Gap Analysis', description: 'Competitor content gap identification' },
      { name: 'Workflow Automation', description: 'Custom automation rules' },
    ]
  },
  {
    category: 'Support & Help',
    icon: Headphones,
    color: 'from-teal-500 to-cyan-500',
    features: [
      { name: 'Customer Support System', description: 'Ticket management and tracking' },
      { name: 'Knowledge Base', description: 'Searchable FAQ system' },
      { name: 'Multi-Language Support', description: 'English, Spanish, French, Portuguese' },
      { name: 'Auto-Response Templates', description: 'Pre-built message templates' },
      { name: 'Help Documentation', description: 'Comprehensive guides and tutorials' },
    ]
  },
  {
    category: 'Mobile & Responsive',
    icon: Smartphone,
    color: 'from-purple-500 to-pink-500',
    features: [
      { name: 'Mobile-First Design', description: 'Optimized for mobile devices' },
      { name: 'Progressive Web App', description: 'App-like mobile experience' },
      { name: 'Responsive Interface', description: 'Adapts to all screen sizes' },
      { name: 'Touch Optimization', description: 'Mobile-friendly interactions' },
      { name: 'Offline Capabilities', description: 'Limited offline functionality' },
    ]
  },
  {
    category: 'User Experience',
    icon: Monitor,
    color: 'from-indigo-500 to-blue-500',
    features: [
      { name: 'Modern Dashboard', description: 'Clean, intuitive design' },
      { name: 'Dark Mode Ready', description: 'Eye-friendly interface' },
      { name: 'Keyboard Shortcuts', description: 'Power user features' },
      { name: 'Real-Time Updates', description: 'Live data synchronization' },
      { name: 'Theme Controls', description: 'Interface customization' },
      { name: 'Layout Options', description: 'Flexible interface layouts' },
      { name: 'Notification Preferences', description: 'Customizable alerts' },
      { name: 'Dashboard Widgets', description: 'Personalized dashboard' },
      { name: 'Export Options', description: 'Multiple export formats (PDF, CSV, Excel)' },
    ]
  },
  {
    category: 'Growth & Optimization',
    icon: TrendingUp,
    color: 'from-emerald-500 to-green-500',
    features: [
      { name: 'Follower Analytics', description: 'Growth tracking and insights' },
      { name: 'Engagement Optimization', description: 'Engagement rate improvement' },
      { name: 'Content Strategy', description: 'AI-driven content planning' },
      { name: 'Competitor Benchmarking', description: 'Competitive analysis' },
      { name: 'Trend Identification', description: 'Market trend detection' },
      { name: 'Fast Loading Times', description: 'Optimized for speed' },
      { name: 'Mobile Optimized', description: 'Perfect performance on mobile' },
    ]
  }
];

export default function Features() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredFeatures = featureCategories.map(cat => ({
    ...cat,
    features: cat.features.filter(f => 
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(cat => 
    (selectedCategory === 'all' || cat.category === selectedCategory) &&
    cat.features.length > 0
  );

  const totalFeatures = featureCategories.reduce((sum, cat) => sum + cat.features.length, 0);
  const implementedFeatures = totalFeatures;

  return (
    <div className="max-w-[1800px] mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Platform Features</h1>
          <p className="text-slate-400 mt-1">Comprehensive social media marketing suite with AI-powered automation</p>
        </div>
        <Link to={createPageUrl('Pricing')}>
          <Button className="bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:opacity-90">
            <DollarSign className="w-4 h-4 mr-2" />
            View Pricing
          </Button>
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Features</p>
              <p className="text-3xl font-bold text-white mt-1">{totalFeatures}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Implemented</p>
              <p className="text-3xl font-bold text-white mt-1">{implementedFeatures}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Categories</p>
              <p className="text-3xl font-bold text-white mt-1">{featureCategories.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <Target className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Platforms</p>
              <p className="text-3xl font-bold text-white mt-1">8+</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center">
              <Globe className="w-6 h-6 text-cyan-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search features..."
              className="pl-10 bg-slate-800/50 border-slate-700 text-white"
            />
          </div>
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full md:w-auto">
            <TabsList className="bg-slate-800/50 grid grid-cols-3 md:grid-cols-9 w-full md:w-auto">
              <TabsTrigger value="all">All</TabsTrigger>
              {featureCategories.map((cat, idx) => (
                <TabsTrigger key={idx} value={cat.category} className="hidden md:block">
                  {cat.category.split(' ')[0]}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 gap-6">
        {filteredFeatures.map((category, idx) => {
          const Icon = category.icon;
          return (
            <div key={idx} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
              <div className={cn(
                "px-6 py-4 bg-gradient-to-r",
                category.color
              )}>
                <div className="flex items-center gap-3">
                  <Icon className="w-6 h-6 text-white" />
                  <h2 className="text-xl font-bold text-white">{category.category}</h2>
                  <Badge className="bg-white/20 text-white">
                    {category.features.length} features
                  </Badge>
                </div>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {category.features.map((feature, fIdx) => (
                    <div
                      key={fIdx}
                      className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        <div className={cn(
                          "w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center flex-shrink-0",
                          category.color
                        )}>
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-white text-sm mb-1">{feature.name}</h4>
                          <p className="text-xs text-slate-400 line-clamp-2">{feature.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredFeatures.length === 0 && (
        <div className="text-center py-12 text-slate-500">
          <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p>No features found matching your search</p>
        </div>
      )}
    </div>
  );
}