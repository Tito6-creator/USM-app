import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  User, 
  Bell, 
  Shield, 
  Globe, 
  Palette,
  Save,
  Loader2,
  CheckCircle2,
  Cable
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import CRMIntegrationSettings from '@/components/crm/CRMIntegrationSettings';
import FacebookConnect from '@/components/social/FacebookConnect';
import InstagramConnect from '@/components/social/InstagramConnect';
import ThreadsConnect from '@/components/social/ThreadsConnect';
import TikTokConnect from '@/components/social/TikTokConnect';
import PinterestConnect from '@/components/social/PinterestConnect';
import YouTubeConnect from '@/components/social/YouTubeConnect';

export default function Settings() {
  const [user, setUser] = useState(null);
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      push: true,
      mentions: true,
      comments: true,
    },
    privacy: {
      public_profile: true,
      show_analytics: false,
    },
    appearance: {
      theme: 'dark',
      language: 'en',
    }
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const updateProfile = async (data) => {
    try {
      await base44.auth.updateMe(data);
      toast.success('Profile updated');
    } catch (error) {
      toast.error('Failed to update profile');
    }
  };

  const updateSettings = (section, key, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value
      }
    }));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 mt-1">Manage your account and preferences</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="profile" className="data-[state=active]:bg-violet-600">
            <User className="w-4 h-4 mr-2" />
            Profile
          </TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-violet-600">
            <Bell className="w-4 h-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="privacy" className="data-[state=active]:bg-violet-600">
            <Shield className="w-4 h-4 mr-2" />
            Privacy
          </TabsTrigger>
          <TabsTrigger value="appearance" className="data-[state=active]:bg-violet-600">
            <Palette className="w-4 h-4 mr-2" />
            Appearance
          </TabsTrigger>
          <TabsTrigger value="crm" className="data-[state=active]:bg-violet-600">
            <Cable className="w-4 h-4 mr-2" />
            CRM Integration
          </TabsTrigger>
          <TabsTrigger value="social" className="data-[state=active]:bg-violet-600">
            <Globe className="w-4 h-4 mr-2" />
            Social Accounts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 space-y-6">
            <div>
              <Label className="text-white mb-2 block">Full Name</Label>
              <Input
                defaultValue={user?.full_name}
                onBlur={(e) => updateProfile({ full_name: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">Email</Label>
              <Input
                value={user?.email}
                disabled
                className="bg-slate-800/30 border-slate-700 text-slate-500"
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">Role</Label>
              <Input
                value={user?.role}
                disabled
                className="bg-slate-800/30 border-slate-700 text-slate-500 capitalize"
              />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="notifications">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 space-y-4">
            {[
              { key: 'email', label: 'Email Notifications', description: 'Receive notifications via email' },
              { key: 'push', label: 'Push Notifications', description: 'Receive push notifications' },
              { key: 'mentions', label: 'Mentions', description: 'Get notified when someone mentions you' },
              { key: 'comments', label: 'Comments', description: 'Get notified of new comments' },
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
                <div>
                  <p className="text-white font-medium">{item.label}</p>
                  <p className="text-sm text-slate-400">{item.description}</p>
                </div>
                <Switch
                  checked={settings.notifications[item.key]}
                  onCheckedChange={(checked) => updateSettings('notifications', item.key, checked)}
                />
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="privacy">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 space-y-4">
            {[
              { key: 'public_profile', label: 'Public Profile', description: 'Make your profile visible to everyone' },
              { key: 'show_analytics', label: 'Show Analytics', description: 'Display analytics publicly' },
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
                <div>
                  <p className="text-white font-medium">{item.label}</p>
                  <p className="text-sm text-slate-400">{item.description}</p>
                </div>
                <Switch
                  checked={settings.privacy[item.key]}
                  onCheckedChange={(checked) => updateSettings('privacy', item.key, checked)}
                />
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="appearance">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 space-y-4">
            <div className="p-4 rounded-lg bg-slate-800/50">
              <p className="text-white font-medium mb-2">Theme</p>
              <p className="text-sm text-slate-400 mb-3">Choose your preferred theme</p>
              <div className="flex gap-3">
                <Button 
                  variant={settings.appearance.theme === 'dark' ? 'default' : 'outline'}
                  onClick={() => updateSettings('appearance', 'theme', 'dark')}
                  className="flex-1"
                >
                  Dark
                </Button>
                <Button 
                  variant={settings.appearance.theme === 'light' ? 'default' : 'outline'}
                  onClick={() => updateSettings('appearance', 'theme', 'light')}
                  className="flex-1"
                >
                  Light
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="crm">
          <div className="space-y-6">
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-xl font-semibold text-white mb-2">HubSpot</h3>
              <p className="text-slate-400 text-sm mb-4">
                Sync leads and contacts with HubSpot CRM
              </p>
              <CRMIntegrationSettings platform="hubspot" />
            </div>

            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-xl font-semibold text-white mb-2">Salesforce</h3>
              <p className="text-slate-400 text-sm mb-4">
                Sync leads and contacts with Salesforce CRM
              </p>
              <CRMIntegrationSettings platform="salesforce" />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="social">
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-white mb-2">Social Media Accounts</h2>
              <p className="text-slate-400">Connect your social media accounts to manage posts and analytics</p>
            </div>
            <FacebookConnect />
            <InstagramConnect />
            <ThreadsConnect />
            <TikTokConnect />
            <YouTubeConnect />
            <PinterestConnect />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}