import React, { useState } from 'react';
import {
  Code,
  Database,
  Shield,
  Settings,
  Zap,
  CheckCircle2,
  Search,
  Terminal,
  Globe,
  Key,
  FileCode,
  GitBranch
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const technicalCategories = [
  {
    category: 'Backend & Infrastructure',
    icon: Database,
    color: 'from-slate-500 to-gray-500',
    features: [
      { name: 'REST API', description: 'Complete API access for custom integrations' },
      { name: 'Webhook Support', description: 'Real-time event notifications' },
      { name: 'Rate Limiting', description: 'API usage management and throttling' },
      { name: 'Database Optimization', description: 'Efficient data management and indexing' },
      { name: 'Environment Variables', description: 'Secure configuration management' },
      { name: 'Database Management', description: 'PostgreSQL with Drizzle ORM' },
      { name: 'Migration System', description: 'Database version control and migrations' },
      { name: 'OAuth Configuration', description: 'Platform-specific OAuth setup' },
      { name: 'CDN Integration', description: 'Global content delivery network' },
      { name: 'Caching Strategy', description: 'Redis-based caching for improved performance' },
    ]
  },
  {
    category: 'Development & Testing',
    icon: Terminal,
    color: 'from-violet-500 to-purple-500',
    features: [
      { name: 'Testing Framework', description: 'Comprehensive testing suite (Jest, React Testing Library)' },
      { name: 'Error Tracking', description: 'Comprehensive error monitoring and logging' },
      { name: 'Performance Monitoring', description: 'System performance tracking and profiling' },
      { name: 'Error Boundaries', description: 'React error boundaries for graceful error handling' },
      { name: 'Loading States', description: 'Optimized loading indicators and skeleton screens' },
      { name: 'TypeScript Support', description: 'Full TypeScript integration for type safety' },
      { name: 'Hot Module Replacement', description: 'Fast development with instant updates' },
      { name: 'Source Maps', description: 'Debug production builds easily' },
    ]
  },
  {
    category: 'Security & Authentication',
    icon: Shield,
    color: 'from-orange-500 to-red-500',
    features: [
      { name: 'OAuth 2.0 Integration', description: 'Secure third-party authentication' },
      { name: 'JWT Token Management', description: 'Secure session handling with JSON Web Tokens' },
      { name: 'CSRF Protection', description: 'Cross-Site Request Forgery prevention' },
      { name: 'XSS Prevention', description: 'Cross-Site Scripting security measures' },
      { name: 'Rate Limiting', description: 'Brute force attack prevention' },
      { name: 'Encryption at Rest', description: 'Database encryption for sensitive data' },
      { name: 'HTTPS Enforcement', description: 'Secure communication protocols' },
      { name: 'API Key Management', description: 'Secure API credential storage' },
    ]
  },
  {
    category: 'Build & Deployment',
    icon: GitBranch,
    color: 'from-emerald-500 to-teal-500',
    features: [
      { name: 'Continuous Integration', description: 'Automated build and test pipelines' },
      { name: 'Environment Management', description: 'Development, staging, production environments' },
      { name: 'Build Optimization', description: 'Code splitting and tree shaking' },
      { name: 'Asset Optimization', description: 'Image and resource compression' },
      { name: 'Bundle Analysis', description: 'Analyze and optimize bundle sizes' },
      { name: 'Docker Support', description: 'Containerized deployments' },
      { name: 'Health Checks', description: 'Application health monitoring endpoints' },
      { name: 'Rollback Capability', description: 'Quick rollback to previous versions' },
    ]
  },
  {
    category: 'Code Quality',
    icon: FileCode,
    color: 'from-cyan-500 to-blue-500',
    features: [
      { name: 'ESLint Configuration', description: 'Automated code quality checks' },
      { name: 'Prettier Integration', description: 'Consistent code formatting' },
      { name: 'Pre-commit Hooks', description: 'Quality checks before commits' },
      { name: 'Component Architecture', description: 'Modular and reusable components' },
      { name: 'State Management', description: 'React Query for server state management' },
      { name: 'Custom Hooks', description: 'Reusable React hooks for common logic' },
      { name: 'Prop Types', description: 'Runtime type checking for components' },
      { name: 'Documentation', description: 'JSDoc comments for component documentation' },
    ]
  },
  {
    category: 'Performance',
    icon: Zap,
    color: 'from-fuchsia-500 to-pink-500',
    features: [
      { name: 'Code Splitting', description: 'Dynamic imports for faster initial load' },
      { name: 'Lazy Loading', description: 'Load components and routes on demand' },
      { name: 'Image Optimization', description: 'Automatic image compression and lazy loading' },
      { name: 'Service Workers', description: 'PWA capabilities and offline support' },
      { name: 'Request Batching', description: 'Optimize API calls with batching' },
      { name: 'Debouncing', description: 'Optimize search and input handling' },
      { name: 'Virtual Scrolling', description: 'Efficient rendering of large lists' },
      { name: 'Memoization', description: 'React.memo and useMemo for optimization' },
    ]
  },
  {
    category: 'API & Integration',
    icon: Globe,
    color: 'from-indigo-500 to-purple-500',
    features: [
      { name: 'GraphQL Support', description: 'Flexible data querying capabilities' },
      { name: 'Webhook Endpoints', description: 'Receive real-time updates from platforms' },
      { name: 'Rate Limit Handling', description: 'Automatic retry and backoff strategies' },
      { name: 'Request Interceptors', description: 'Centralized request/response handling' },
      { name: 'Error Handling', description: 'Graceful API error management' },
      { name: 'Request Caching', description: 'Reduce redundant API calls' },
      { name: 'API Versioning', description: 'Backward compatible API versions' },
      { name: 'Swagger Documentation', description: 'Auto-generated API documentation' },
    ]
  },
];

export default function DevTools() {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCategories = technicalCategories.map(cat => ({
    ...cat,
    features: cat.features.filter(f => 
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.description.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(cat => cat.features.length > 0);

  const totalFeatures = technicalCategories.reduce((sum, cat) => sum + cat.features.length, 0);

  return (
    <div className="max-w-[1800px] mx-auto space-y-6">
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-700 p-8">
        <div className="flex items-center gap-3 mb-2">
          <Code className="w-8 h-8 text-violet-400" />
          <h1 className="text-3xl font-bold text-white">Developer Tools & Technical Details</h1>
        </div>
        <p className="text-slate-400">Backend infrastructure, security, and development features</p>
        <Badge className="mt-4 bg-amber-500/10 text-amber-400 border-amber-500/20">
          For Developers Only - Not visible to app users
        </Badge>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Technical Features</p>
              <p className="text-3xl font-bold text-white mt-1">{totalFeatures}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Code className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Categories</p>
              <p className="text-3xl font-bold text-white mt-1">{technicalCategories.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Settings className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Status</p>
              <p className="text-3xl font-bold text-white mt-1">Active</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search technical features..."
            className="pl-10 bg-slate-800/50 border-slate-700 text-white"
          />
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 gap-6">
        {filteredCategories.map((category, idx) => {
          const Icon = category.icon;
          return (
            <div key={idx} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
              <div className={cn(
                "px-6 py-4 bg-gradient-to-r",
                category.color
              )}>
                <div className="flex items-center gap-3">
                  <Icon className="w-6 h-6 text-white" />
                  <h2 className="text-xl font-bold text-white">{category.category}</h2>
                  <Badge className="bg-white/20 text-white">
                    {category.features.length} features
                  </Badge>
                </div>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {category.features.map((feature, fIdx) => (
                    <div
                      key={fIdx}
                      className="p-4 rounded-xl bg-slate-800/50 border border-slate-700 hover:border-slate-600 transition-all"
                    >
                      <div className="flex items-start gap-3">
                        <div className={cn(
                          "w-8 h-8 rounded-lg bg-gradient-to-br flex items-center justify-center flex-shrink-0",
                          category.color
                        )}>
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-white text-sm mb-1">{feature.name}</h4>
                          <p className="text-xs text-slate-400 line-clamp-2">{feature.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredCategories.length === 0 && (
        <div className="text-center py-12 text-slate-500">
          <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
          <p>No features found matching your search</p>
        </div>
      )}
    </div>
  );
}