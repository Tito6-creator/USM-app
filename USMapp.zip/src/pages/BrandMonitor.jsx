import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import {
  Eye,
  TrendingUp,
  TrendingDown,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Minus,
  ExternalLink,
  Filter,
  Search,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import StatsCard from '@/components/dashboard/StatsCard';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

const sentimentConfig = {
  positive: { icon: ThumbsUp, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
  neutral: { icon: Minus, color: 'text-slate-400', bg: 'bg-slate-500/10' },
  negative: { icon: ThumbsDown, color: 'text-rose-400', bg: 'bg-rose-500/10' },
};

const priorityColors = {
  low: 'border-slate-500/20 text-slate-400',
  medium: 'border-amber-500/20 text-amber-400',
  high: 'border-orange-500/20 text-orange-400',
  urgent: 'border-rose-500/20 text-rose-400',
};

export default function BrandMonitor() {
  const [searchQuery, setSearchQuery] = useState('');
  const [sentimentFilter, setSentimentFilter] = useState('all');
  const [platformFilter, setPlatformFilter] = useState('all');
  
  const queryClient = useQueryClient();

  const { data: mentions = [], isLoading } = useQuery({
    queryKey: ['brand-mentions'],
    queryFn: () => base44.entities.BrandMention.list('-created_date'),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BrandMention.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['brand-mentions'] }),
  });

  const filteredMentions = mentions.filter(mention => {
    const matchesSearch = mention.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         mention.author_name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSentiment = sentimentFilter === 'all' || mention.sentiment === sentimentFilter;
    const matchesPlatform = platformFilter === 'all' || mention.platform === platformFilter;
    return matchesSearch && matchesSentiment && matchesPlatform;
  });

  // Calculate stats
  const totalMentions = mentions.length;
  const positiveMentions = mentions.filter(m => m.sentiment === 'positive').length;
  const negativeMentions = mentions.filter(m => m.sentiment === 'negative').length;
  const sentimentScore = totalMentions > 0 
    ? Math.round(((positiveMentions - negativeMentions) / totalMentions + 1) * 50)
    : 50;
  const totalReach = mentions.reduce((sum, m) => sum + (m.reach || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Brand Monitor</h1>
          <p className="text-slate-400 mt-1">Track mentions, sentiment, and reputation</p>
        </div>
        <Button 
          variant="outline" 
          className="border-slate-700 text-slate-300"
          onClick={() => queryClient.invalidateQueries({ queryKey: ['brand-mentions'] })}
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Mentions"
          value={totalMentions.toLocaleString()}
          change={12}
          icon={Eye}
          gradient="from-violet-500 to-purple-500"
        />
        <StatsCard
          title="Sentiment Score"
          value={`${sentimentScore}%`}
          change={sentimentScore > 50 ? 5 : -5}
          icon={sentimentScore >= 50 ? TrendingUp : TrendingDown}
          gradient={sentimentScore >= 50 ? "from-emerald-500 to-teal-500" : "from-rose-500 to-pink-500"}
        />
        <StatsCard
          title="Positive Mentions"
          value={positiveMentions.toLocaleString()}
          icon={ThumbsUp}
          gradient="from-emerald-500 to-teal-500"
        />
        <StatsCard
          title="Total Reach"
          value={totalReach.toLocaleString()}
          change={8}
          icon={MessageSquare}
          gradient="from-cyan-500 to-blue-500"
        />
      </div>

      {/* Filters */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-4">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search mentions..."
              className="pl-10 bg-slate-800/50 border-slate-700"
            />
          </div>
          
          <div className="flex gap-3">
            <Select value={sentimentFilter} onValueChange={setSentimentFilter}>
              <SelectTrigger className="w-40 bg-slate-800/50 border-slate-700">
                <SelectValue placeholder="Sentiment" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="all">All Sentiments</SelectItem>
                <SelectItem value="positive">Positive</SelectItem>
                <SelectItem value="neutral">Neutral</SelectItem>
                <SelectItem value="negative">Negative</SelectItem>
              </SelectContent>
            </Select>

            <Select value={platformFilter} onValueChange={setPlatformFilter}>
              <SelectTrigger className="w-40 bg-slate-800/50 border-slate-700">
                <SelectValue placeholder="Platform" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="all">All Platforms</SelectItem>
                <SelectItem value="facebook">Facebook</SelectItem>
                <SelectItem value="instagram">Instagram</SelectItem>
                <SelectItem value="twitter">Twitter</SelectItem>
                <SelectItem value="youtube">YouTube</SelectItem>
                <SelectItem value="tiktok">TikTok</SelectItem>
                <SelectItem value="linkedin">LinkedIn</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Mentions List */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800">
          <h3 className="font-semibold text-white">Recent Mentions</h3>
        </div>
        
        <ScrollArea className="h-[600px]">
          <div className="divide-y divide-slate-800">
            {filteredMentions.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                No mentions found
              </div>
            ) : (
              filteredMentions.map((mention) => {
                const SentimentIcon = sentimentConfig[mention.sentiment]?.icon || Minus;
                const sentimentStyle = sentimentConfig[mention.sentiment] || sentimentConfig.neutral;
                
                return (
                  <div key={mention.id} className="p-6 hover:bg-slate-800/30 transition-colors">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={mention.author_avatar} />
                        <AvatarFallback className="bg-slate-700 text-white">
                          {mention.author_name?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="font-medium text-white">{mention.author_name}</span>
                          <span className="text-slate-500">@{mention.author_username}</span>
                          <PlatformIcon platform={mention.platform} size="xs" />
                          <span className="text-xs text-slate-500">
                            {format(new Date(mention.created_date), 'MMM d, h:mm a')}
                          </span>
                        </div>
                        
                        <p className="text-slate-300 mb-3">{mention.content}</p>
                        
                        <div className="flex items-center gap-3 flex-wrap">
                          <div className={cn(
                            "flex items-center gap-1.5 px-2 py-1 rounded-lg",
                            sentimentStyle.bg
                          )}>
                            <SentimentIcon className={cn("w-4 h-4", sentimentStyle.color)} />
                            <span className={cn("text-xs capitalize", sentimentStyle.color)}>
                              {mention.sentiment}
                            </span>
                          </div>
                          
                          <Badge variant="outline" className={priorityColors[mention.priority]}>
                            {mention.priority} priority
                          </Badge>
                          
                          {mention.reach > 0 && (
                            <span className="text-xs text-slate-500">
                              {mention.reach.toLocaleString()} reach
                            </span>
                          )}
                          
                          {mention.source_url && (
                            <a 
                              href={mention.source_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-violet-400 hover:text-violet-300 text-xs flex items-center gap-1"
                            >
                              View original <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                        
                        {!mention.is_responded && mention.sentiment === 'negative' && (
                          <div className="mt-3 pt-3 border-t border-slate-800">
                            <Button 
                              size="sm" 
                              className="bg-violet-600 hover:bg-violet-700"
                              onClick={() => updateMutation.mutate({ 
                                id: mention.id, 
                                data: { is_responded: true } 
                              })}
                            >
                              Mark as Responded
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}