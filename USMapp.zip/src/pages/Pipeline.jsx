import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, DollarSign } from 'lucide-react';
import { toast } from 'sonner';
import DealModal from '@/components/crm/DealModal';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';

const stages = [
  { id: 'lead', label: 'Lead', color: 'bg-blue-500' },
  { id: 'demo', label: 'Demo', color: 'bg-purple-500' },
  { id: 'trial', label: 'Trial', color: 'bg-amber-500' },
  { id: 'client', label: 'Client', color: 'bg-green-500' },
  { id: 'churn_risk', label: 'Churn Risk', color: 'bg-red-500' }
];

export default function Pipeline() {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editingDeal, setEditingDeal] = useState(null);

  const { data: deals = [], isLoading } = useQuery({
    queryKey: ['deals'],
    queryFn: () => base44.entities.Deal.list('-created_date'),
  });

  const updateDealMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Deal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['deals']);
    },
  });

  const handleDragEnd = async (result) => {
    if (!result.destination) return;

    const dealId = result.draggableId;
    const newStage = result.destination.droppableId;
    
    const deal = deals.find(d => d.id === dealId);
    if (deal && deal.stage !== newStage) {
      const oldStage = deal.stage;
      
      await updateDealMutation.mutateAsync({
        id: dealId,
        data: { stage: newStage }
      });
      
      toast.success(`Deal moved to ${stages.find(s => s.id === newStage)?.label}`);
      
      // Trigger automation
      try {
        await base44.functions.invoke('handleDealStageChange', {
          deal_id: dealId,
          new_stage: newStage,
          old_stage: oldStage
        });
      } catch (error) {
        console.error('Automation trigger failed:', error);
      }
    }
  };

  const dealsByStage = stages.map(stage => ({
    ...stage,
    deals: deals.filter(d => d.stage === stage.id),
    value: deals.filter(d => d.stage === stage.id).reduce((sum, d) => sum + (d.value || 0), 0)
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Sales Pipeline</h1>
          <p className="text-slate-400 mt-1">Track deals through your sales process</p>
        </div>
        <Button 
          onClick={() => {
            setEditingDeal(null);
            setShowModal(true);
          }}
          className="bg-violet-600 hover:bg-violet-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Deal
        </Button>
      </div>

      {/* Pipeline Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {dealsByStage.map(stage => (
          <Card key={stage.id} className="bg-slate-900/50 border-slate-800 p-4">
            <div className="flex items-center gap-2 mb-2">
              <div className={`w-3 h-3 rounded-full ${stage.color}`} />
              <span className="text-sm text-slate-400">{stage.label}</span>
            </div>
            <div className="text-2xl font-bold text-white">{stage.deals.length}</div>
            <div className="text-sm text-slate-400 mt-1">
              ${stage.value.toLocaleString()}
            </div>
          </Card>
        ))}
      </div>

      {/* Kanban Board */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 overflow-x-auto pb-4">
          {dealsByStage.map(stage => (
            <div key={stage.id} className="min-w-[280px]">
              <div className="mb-3">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-medium flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${stage.color}`} />
                    {stage.label}
                  </h3>
                  <Badge variant="secondary">{stage.deals.length}</Badge>
                </div>
                <div className="text-xs text-slate-400">
                  ${stage.value.toLocaleString()}
                </div>
              </div>

              <Droppable droppableId={stage.id}>
                {(provided, snapshot) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`space-y-3 min-h-[200px] p-2 rounded-lg transition-colors ${
                      snapshot.isDraggingOver ? 'bg-slate-800/50' : ''
                    }`}
                  >
                    {stage.deals.map((deal, index) => (
                      <Draggable key={deal.id} draggableId={deal.id} index={index}>
                        {(provided, snapshot) => (
                          <Card
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            onClick={() => {
                              setEditingDeal(deal);
                              setShowModal(true);
                            }}
                            className={`bg-slate-900 border-slate-800 p-4 cursor-pointer hover:bg-slate-800 transition-colors ${
                              snapshot.isDragging ? 'shadow-lg' : ''
                            }`}
                          >
                            <h4 className="text-white font-medium mb-2">{deal.title}</h4>
                            <p className="text-sm text-slate-400 mb-3">{deal.contact_name}</p>
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1 text-green-400 font-semibold">
                                <DollarSign className="w-4 h-4" />
                                {deal.value?.toLocaleString() || 0}
                              </div>
                              {deal.next_action_date && (
                                <span className="text-xs text-slate-400">
                                  {new Date(deal.next_action_date).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                          </Card>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </div>
          ))}
        </div>
      </DragDropContext>

      <DealModal
        open={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingDeal(null);
        }}
        deal={editingDeal}
      />
    </div>
  );
}