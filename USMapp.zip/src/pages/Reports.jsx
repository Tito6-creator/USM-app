import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format, subDays, subMonths } from 'date-fns';
import {
  FileText,
  Plus,
  Calendar as CalendarIcon,
  Clock,
  Mail,
  Download,
  Trash2,
  MoreVertical,
  Eye,
  Pause,
  Play,
  Send,
  Loader2,
  Check,
  BarChart3,
  Users,
  MessageSquare,
  Target,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import ReportBuilder from '@/components/analytics/ReportBuilder';
import AutomatedInsights from '@/components/reports/AutomatedInsights';
import MetricsSummary from '@/components/reports/MetricsSummary';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const frequencyLabels = {
  daily: 'Daily',
  weekly: 'Weekly',
  biweekly: 'Bi-weekly',
  monthly: 'Monthly',
  quarterly: 'Quarterly',
};

const formatIcons = {
  pdf: '📄',
  csv: '📊',
  excel: '📈',
};

export default function Reports() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);
  const [isSending, setIsSending] = useState(false);
  const [period, setPeriod] = useState('week');

  const queryClient = useQueryClient();

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ['scheduled-reports'],
    queryFn: () => base44.entities.ScheduledReport.list('-created_date'),
  });

  // Fetch all data for dashboard
  const { data: posts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.list('-created_date'),
  });

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors'],
    queryFn: () => base44.entities.Competitor.list(),
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list('-created_date'),
  });

  const { data: chatbotConfigs = [] } = useQuery({
    queryKey: ['chatbot-configs'],
    queryFn: () => base44.entities.ChatbotConfig.list(),
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: alerts = [] } = useQuery({
    queryKey: ['trend-alerts'],
    queryFn: () => base44.entities.TrendAlert.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ScheduledReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduled-reports'] });
      setIsCreateOpen(false);
      toast.success('Report created successfully!');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ScheduledReport.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduled-reports'] });
      toast.success('Report updated');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ScheduledReport.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['scheduled-reports'] });
      toast.success('Report deleted');
    },
  });

  const handleSendNow = async (report) => {
    setIsSending(true);
    
    // Generate report content using AI
    const reportContent = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate a social media performance report summary for the following configuration:
      Report Name: ${report.name}
      Type: ${report.report_type}
      Platforms: ${report.platforms?.join(', ')}
      Date Range: ${report.date_range}
      Metrics: ${report.metrics?.join(', ')}
      
      Create a professional summary with key insights and recommendations.`,
      response_json_schema: {
        type: 'object',
        properties: {
          summary: { type: 'string' },
          key_metrics: { type: 'array', items: { type: 'object', properties: { metric: { type: 'string' }, value: { type: 'string' }, change: { type: 'string' } } } },
          insights: { type: 'array', items: { type: 'string' } },
          recommendations: { type: 'array', items: { type: 'string' } }
        }
      }
    });

    // Send email to each recipient
    for (const recipient of report.recipients) {
      if (recipient) {
        await base44.integrations.Core.SendEmail({
          to: recipient,
          subject: `${report.white_label?.company_name || 'SocialPulse'} - ${report.name}`,
          body: `
${report.white_label?.company_name || 'SocialPulse'} Report

${reportContent.summary}

Key Metrics:
${reportContent.key_metrics?.map(m => `• ${m.metric}: ${m.value} (${m.change})`).join('\n')}

Insights:
${reportContent.insights?.map(i => `• ${i}`).join('\n')}

Recommendations:
${reportContent.recommendations?.map(r => `• ${r}`).join('\n')}

${report.white_label?.footer_text || 'Generated by SocialPulse'}
          `
        });
      }
    }

    // Update last sent
    updateMutation.mutate({
      id: report.id,
      data: { 
        last_sent: new Date().toISOString(),
        send_count: (report.send_count || 0) + 1
      }
    });

    setIsSending(false);
    toast.success('Report sent to all recipients!');
  };

  const activeReports = reports.filter(r => r.is_active);
  const inactiveReports = reports.filter(r => !r.is_active);

  // Calculate metrics
  const periodStart = period === 'week' ? subDays(new Date(), 7) : subMonths(new Date(), 1);
  const previousPeriodStart = period === 'week' ? subDays(new Date(), 14) : subMonths(new Date(), 2);
  
  const currentPosts = posts.filter(p => new Date(p.created_date) > periodStart);
  const previousPosts = posts.filter(p => 
    new Date(p.created_date) > previousPeriodStart && new Date(p.created_date) <= periodStart
  );

  const currentLeads = leads.filter(l => new Date(l.created_date) > periodStart);
  const previousLeads = leads.filter(l => 
    new Date(l.created_date) > previousPeriodStart && new Date(l.created_date) <= periodStart
  );

  const currentEngagement = currentPosts.length > 0
    ? currentPosts.reduce((a, p) => a + (p.engagement_rate || 0), 0) / currentPosts.length
    : 0;
  const previousEngagement = previousPosts.length > 0
    ? previousPosts.reduce((a, p) => a + (p.engagement_rate || 0), 0) / previousPosts.length
    : 0;

  const currentReach = currentPosts.reduce((a, p) => a + (p.reach || 0), 0);
  const previousReach = previousPosts.reduce((a, p) => a + (p.reach || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Performance Dashboard</h1>
          <p className="text-slate-400 mt-1">Automated insights and custom reports</p>
        </div>
        <div className="flex items-center gap-3">
          <Tabs value={period} onValueChange={setPeriod}>
            <TabsList className="bg-slate-800/50">
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="month">Month</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button 
            onClick={() => setIsCreateOpen(true)}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Report
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="dashboard" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <MetricsSummary
              current={currentPosts.length}
              previous={previousPosts.length}
              label="Posts Published"
              icon={BarChart3}
            />
            <MetricsSummary
              current={currentEngagement}
              previous={previousEngagement}
              label="Avg Engagement"
              icon={TrendingUp}
              format="percentage"
            />
            <MetricsSummary
              current={currentReach}
              previous={previousReach}
              label="Total Reach"
              icon={Users}
              format="large"
            />
            <MetricsSummary
              current={currentLeads.length}
              previous={previousLeads.length}
              label="Leads Generated"
              icon={Target}
            />
          </div>

          {/* AI Insights */}
          <AutomatedInsights
            period={period}
            data={{
              posts,
              competitors,
              leads,
              chatbotConfigs,
              accounts,
              alerts
            }}
          />
        </TabsContent>

        <TabsContent value="scheduled" className="space-y-6">
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-violet-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{reports.length}</p>
                  <p className="text-sm text-slate-400">Total Reports</p>
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                  <Play className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{activeReports.length}</p>
                  <p className="text-sm text-slate-400">Active Schedules</p>
                </div>
              </div>
            </div>
            <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
                  <Send className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">
                    {reports.reduce((sum, r) => sum + (r.send_count || 0), 0)}
                  </p>
                  <p className="text-sm text-slate-400">Reports Sent</p>
                </div>
              </div>
            </div>
          </div>

      {/* Reports List */}
      {reports.length === 0 && !isLoading ? (
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-12 text-center">
          <FileText className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No reports yet</h3>
          <p className="text-slate-400 mb-6">Create your first scheduled report</p>
          <Button onClick={() => setIsCreateOpen(true)} className="bg-violet-600 hover:bg-violet-700">
            <Plus className="w-4 h-4 mr-2" />
            Create Report
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reports.map((report) => (
            <div
              key={report.id}
              className={cn(
                "rounded-2xl bg-slate-900/50 border overflow-hidden",
                "hover:border-slate-700/50 transition-all",
                report.is_active ? "border-slate-800/50" : "border-slate-800/30 opacity-60"
              )}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center text-2xl",
                      report.white_label?.enabled 
                        ? "bg-gradient-to-br from-violet-500 to-fuchsia-500"
                        : "bg-slate-800"
                    )}>
                      {formatIcons[report.format]}
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{report.name}</h3>
                      <p className="text-sm text-slate-400 capitalize">{report.report_type} Report</p>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-slate-400">
                        <MoreVertical className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem onClick={() => setSelectedReport(report)}>
                        <Eye className="w-4 h-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleSendNow(report)}
                        disabled={isSending}
                      >
                        <Send className="w-4 h-4 mr-2" />
                        Send Now
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => updateMutation.mutate({
                          id: report.id,
                          data: { is_active: !report.is_active }
                        })}
                      >
                        {report.is_active ? (
                          <>
                            <Pause className="w-4 h-4 mr-2" />
                            Pause Schedule
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Activate Schedule
                          </>
                        )}
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => deleteMutation.mutate(report.id)}
                        className="text-rose-400"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="space-y-3 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <CalendarIcon className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-400">{frequencyLabels[report.frequency]}</span>
                    {report.day_of_week && (
                      <span className="text-slate-500 capitalize">• {report.day_of_week}s</span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-400">{report.time_of_day}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Mail className="w-4 h-4 text-slate-500" />
                    <span className="text-slate-400">{report.recipients?.filter(r => r).length} recipients</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className={cn(
                    report.is_active 
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : "bg-slate-500/10 text-slate-400 border-slate-500/20"
                  )}>
                    {report.is_active ? 'Active' : 'Paused'}
                  </Badge>
                  {report.white_label?.enabled && (
                    <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                      White-label
                    </Badge>
                  )}
                  <Badge variant="outline" className="border-slate-700 text-slate-400 uppercase text-xs">
                    {report.format}
                  </Badge>
                </div>

                {report.last_sent && (
                  <div className="mt-4 pt-4 border-t border-slate-800 text-xs text-slate-500">
                    Last sent: {format(new Date(report.last_sent), 'MMM d, yyyy h:mm a')}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
        </TabsContent>
      </Tabs>

      {/* Create Report Dialog */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">Create Scheduled Report</DialogTitle>
          </DialogHeader>
          <ReportBuilder 
            onSave={(data) => createMutation.mutate(data)}
            isLoading={createMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      {/* Report Detail Dialog */}
      <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">{selectedReport?.name}</DialogTitle>
          </DialogHeader>
          
          {selectedReport && (
            <div className="space-y-6 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-1">Frequency</p>
                  <p className="font-medium text-white">{frequencyLabels[selectedReport.frequency]}</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-1">Format</p>
                  <p className="font-medium text-white uppercase">{selectedReport.format}</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-1">Date Range</p>
                  <p className="font-medium text-white">{selectedReport.date_range?.replace(/_/g, ' ')}</p>
                </div>
                <div className="p-4 rounded-xl bg-slate-800/50">
                  <p className="text-sm text-slate-400 mb-1">Times Sent</p>
                  <p className="font-medium text-white">{selectedReport.send_count || 0}</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-slate-400 mb-2">Recipients</p>
                <div className="flex flex-wrap gap-2">
                  {selectedReport.recipients?.filter(r => r).map((recipient, i) => (
                    <Badge key={i} className="bg-slate-800 text-slate-300">
                      <Mail className="w-3 h-3 mr-1" />
                      {recipient}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm text-slate-400 mb-2">Included Sections</p>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(selectedReport.include_sections || {})
                    .filter(([_, enabled]) => enabled)
                    .map(([section]) => (
                      <Badge key={section} variant="outline" className="border-slate-700 text-slate-300 capitalize">
                        <Check className="w-3 h-3 mr-1" />
                        {section.replace(/_/g, ' ')}
                      </Badge>
                    ))
                  }
                </div>
              </div>

              {selectedReport.white_label?.enabled && (
                <div className="p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
                  <p className="text-sm text-violet-400 mb-2">White-label Branding</p>
                  <p className="text-white font-medium">{selectedReport.white_label.company_name}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <div 
                      className="w-6 h-6 rounded" 
                      style={{ backgroundColor: selectedReport.white_label.primary_color }}
                    />
                    <div 
                      className="w-6 h-6 rounded" 
                      style={{ backgroundColor: selectedReport.white_label.secondary_color }}
                    />
                  </div>
                </div>
              )}

              <div className="flex gap-3">
                <Button 
                  onClick={() => handleSendNow(selectedReport)}
                  disabled={isSending}
                  className="flex-1 bg-violet-600 hover:bg-violet-700"
                >
                  {isSending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Send Now
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}