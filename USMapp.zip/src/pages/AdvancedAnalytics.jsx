import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  TrendingUp,
  Users,
  Target,
  DollarSign,
  BarChart3,
  LineChart,
  PieChart,
  Map,
  Clock,
  Smartphone,
  Globe,
  Zap
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import {
  AreaChart,
  Area,
  BarChart as RechartsBarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';

const COLORS = ['#8b5cf6', '#ec4899', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

export default function AdvancedAnalytics() {
  const [timeRange, setTimeRange] = useState('7d');

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time', 100),
  });

  const { data: demographics = [] } = useQuery({
    queryKey: ['demographics'],
    queryFn: () => base44.entities.AudienceDemographic.list(),
  });

  const { data: conversions = [] } = useQuery({
    queryKey: ['conversions'],
    queryFn: () => base44.entities.ConversionTracking.list('-created_date', 50),
  });

  const { data: forecasts = [] } = useQuery({
    queryKey: ['forecasts'],
    queryFn: () => base44.entities.PerformanceForecast.list('-forecast_date', 7),
  });

  // Calculate engagement over time
  const engagementData = posts.slice(0, 30).reverse().map((post, idx) => ({
    name: `Post ${idx + 1}`,
    engagement: (post.likes || 0) + (post.comments || 0) + (post.shares || 0),
    reach: post.reach || 0,
    clicks: post.views || 0
  }));

  // Calculate ROI metrics
  const totalRevenue = conversions.reduce((sum, c) => sum + (c.conversion_value || 0), 0);
  const totalConversions = conversions.length;
  const avgConversionValue = totalConversions > 0 ? totalRevenue / totalConversions : 0;
  const conversionRate = posts.length > 0 ? ((totalConversions / posts.length) * 100).toFixed(2) : 0;

  // Demographic data
  const demo = demographics[0];
  const ageData = demo?.age_distribution ? [
    { name: '13-17', value: demo.age_distribution['13_17'] || 0 },
    { name: '18-24', value: demo.age_distribution['18_24'] || 0 },
    { name: '25-34', value: demo.age_distribution['25_34'] || 0 },
    { name: '35-44', value: demo.age_distribution['35_44'] || 0 },
    { name: '45-54', value: demo.age_distribution['45_54'] || 0 },
    { name: '55-64', value: demo.age_distribution['55_64'] || 0 },
    { name: '65+', value: demo.age_distribution['65_plus'] || 0 },
  ].filter(d => d.value > 0) : [];

  const genderData = demo?.gender_distribution ? [
    { name: 'Male', value: demo.gender_distribution.male || 0 },
    { name: 'Female', value: demo.gender_distribution.female || 0 },
    { name: 'Other', value: demo.gender_distribution.other || 0 },
  ].filter(d => d.value > 0) : [];

  // Forecast data
  const forecastData = forecasts.map(f => ({
    date: new Date(f.forecast_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    followers: f.predicted_metrics?.followers || 0,
    engagement: f.predicted_metrics?.engagement_rate || 0,
    reach: f.predicted_metrics?.reach || 0,
    trend: f.trend_direction
  }));

  return (
    <div className="max-w-[1800px] mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Advanced Analytics</h1>
        <p className="text-slate-400 mt-1">Comprehensive performance insights and forecasting</p>
      </div>

      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Revenue</p>
              <p className="text-3xl font-bold text-white mt-1">${totalRevenue.toLocaleString()}</p>
              <p className="text-xs text-emerald-400 mt-1">+{avgConversionValue.toFixed(0)} avg value</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Conversions</p>
              <p className="text-3xl font-bold text-white mt-1">{totalConversions}</p>
              <p className="text-xs text-violet-400 mt-1">{conversionRate}% rate</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Target className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Active Audience</p>
              <p className="text-3xl font-bold text-white mt-1">{ageData.reduce((sum, d) => sum + d.value, 0).toLocaleString()}</p>
              <p className="text-xs text-fuchsia-400 mt-1">{genderData.length} segments</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <Users className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Forecast Trend</p>
              <p className="text-3xl font-bold text-white mt-1 capitalize">{forecasts[0]?.trend_direction || 'Stable'}</p>
              <p className="text-xs text-cyan-400 mt-1">{forecasts[0]?.confidence_score || 0}% confidence</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-cyan-400" />
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="performance" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="performance" className="data-[state=active]:bg-violet-600">
            <BarChart3 className="w-4 h-4 mr-2" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="demographics" className="data-[state=active]:bg-violet-600">
            <Users className="w-4 h-4 mr-2" />
            Demographics
          </TabsTrigger>
          <TabsTrigger value="conversions" className="data-[state=active]:bg-violet-600">
            <Target className="w-4 h-4 mr-2" />
            Conversions & ROI
          </TabsTrigger>
          <TabsTrigger value="forecast" className="data-[state=active]:bg-violet-600">
            <Zap className="w-4 h-4 mr-2" />
            AI Forecast
          </TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-6">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Engagement Trends</h3>
            <ResponsiveContainer width="100%" height={400}>
              <AreaChart data={engagementData}>
                <defs>
                  <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorReach" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                <Area type="monotone" dataKey="engagement" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorEngagement)" />
                <Area type="monotone" dataKey="reach" stroke="#06b6d4" fillOpacity={1} fill="url(#colorReach)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </TabsContent>

        <TabsContent value="demographics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Age Distribution</h3>
              {ageData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsBarChart data={ageData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="name" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                    <Bar dataKey="value" fill="#8b5cf6" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-12 text-slate-500">No demographic data available</div>
              )}
            </div>

            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Gender Distribution</h3>
              {genderData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={genderData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {genderData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                  </RechartsPieChart>
                </ResponsiveContainer>
              ) : (
                <div className="text-center py-12 text-slate-500">No demographic data available</div>
              )}
            </div>
          </div>

          {demo?.top_locations && demo.top_locations.length > 0 && (
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Map className="w-5 h-5 text-violet-400" />
                Top Locations
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {demo.top_locations.slice(0, 6).map((loc, idx) => (
                  <div key={idx} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-white">{loc.city || loc.country}</p>
                        <p className="text-xs text-slate-400 mt-1">{loc.country}</p>
                      </div>
                      <Badge className="bg-violet-500/10 text-violet-400">
                        {loc.percentage}%
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="conversions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Conversion Funnel</h3>
              <div className="space-y-3">
                {[
                  { label: 'Impressions', value: posts.reduce((sum, p) => sum + (p.reach || 0), 0), color: 'bg-violet-500' },
                  { label: 'Clicks', value: posts.reduce((sum, p) => sum + (p.views || 0), 0), color: 'bg-fuchsia-500' },
                  { label: 'Engagements', value: posts.reduce((sum, p) => sum + (p.likes || 0) + (p.comments || 0), 0), color: 'bg-cyan-500' },
                  { label: 'Conversions', value: totalConversions, color: 'bg-emerald-500' },
                ].map((stage, idx) => {
                  const maxValue = posts.reduce((sum, p) => sum + (p.reach || 0), 0);
                  const width = maxValue > 0 ? (stage.value / maxValue) * 100 : 0;
                  return (
                    <div key={idx}>
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-slate-300">{stage.label}</span>
                        <span className="text-white font-semibold">{stage.value.toLocaleString()}</span>
                      </div>
                      <div className="h-8 rounded-lg bg-slate-800 overflow-hidden">
                        <div className={cn("h-full transition-all", stage.color)} style={{ width: `${width}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="text-lg font-semibold text-white mb-4">Conversion Types</h3>
              <div className="space-y-3">
                {['click', 'signup', 'purchase', 'download'].map((type) => {
                  const count = conversions.filter(c => c.conversion_type === type).length;
                  const value = conversions.filter(c => c.conversion_type === type).reduce((sum, c) => sum + (c.conversion_value || 0), 0);
                  return (
                    <div key={type} className="p-4 rounded-xl bg-slate-800/50 border border-slate-700">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-white capitalize">{type}</p>
                          <p className="text-xs text-slate-400 mt-1">{count} conversions</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-emerald-400">${value.toLocaleString()}</p>
                          <p className="text-xs text-slate-500">revenue</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="forecast" className="space-y-6">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-white">7-Day Performance Forecast</h3>
              {forecasts[0] && (
                <Badge className={cn(
                  "capitalize",
                  forecasts[0].trend_direction === 'increasing' && "bg-emerald-500/10 text-emerald-400",
                  forecasts[0].trend_direction === 'decreasing' && "bg-rose-500/10 text-rose-400",
                  forecasts[0].trend_direction === 'stable' && "bg-slate-500/10 text-slate-400",
                  forecasts[0].trend_direction === 'volatile' && "bg-amber-500/10 text-amber-400"
                )}>
                  {forecasts[0].trend_direction}
                </Badge>
              )}
            </div>
            {forecastData.length > 0 ? (
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={forecastData}>
                  <defs>
                    <linearGradient id="colorForecast" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ec4899" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                  <Legend />
                  <Area type="monotone" dataKey="followers" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorForecast)" />
                  <Area type="monotone" dataKey="reach" stroke="#06b6d4" fillOpacity={0.6} fill="#06b6d4" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center py-12 text-slate-500">No forecast data available</div>
            )}
          </div>

          {forecasts.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {forecasts.slice(0, 3).map((forecast, idx) => (
                <div key={idx} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-white">{forecast.platform}</h4>
                    <Badge className={cn(
                      forecast.trend_direction === 'increasing' && "bg-emerald-500/10 text-emerald-400",
                      forecast.trend_direction === 'decreasing' && "bg-rose-500/10 text-rose-400",
                      forecast.trend_direction === 'stable' && "bg-slate-500/10 text-slate-400"
                    )}>
                      {forecast.seasonal_pattern}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    {forecast.recommendations?.slice(0, 3).map((rec, i) => (
                      <p key={i} className="text-xs text-slate-400">• {rec}</p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}