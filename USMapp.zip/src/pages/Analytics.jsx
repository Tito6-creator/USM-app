import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format, subDays, eachDayOfInterval } from 'date-fns';
import StoriesReelsAnalytics from '@/components/analytics/StoriesReelsAnalytics';
import ABTestingPanel from '@/components/analytics/ABTestingPanel';
import PostPerformanceBreakdown from '@/components/analytics/PostPerformanceBreakdown';
import AIContentOptimizer from '@/components/analytics/AIContentOptimizer';
import TrendAnalysis from '@/components/analytics/TrendAnalysis';
import ContentFormatAnalysis from '@/components/analytics/ContentFormatAnalysis';
import CompetitorComparison from '@/components/analytics/CompetitorComparison';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';
import {
  Users,
  Eye,
  Heart,
  TrendingUp,
  Clock,
  Calendar,
  BarChart3,
  Play,
  FlaskConical,
  FileText,
  Sparkles,
  Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import StatsCard from '@/components/dashboard/StatsCard';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const COLORS = ['#8B5CF6', '#EC4899', '#06B6D4', '#10B981', '#F59E0B', '#EF4444'];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 rounded-lg p-3 shadow-xl">
        <p className="text-slate-400 text-sm mb-1">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm font-medium" style={{ color: entry.color }}>
            {entry.name}: {entry.value.toLocaleString()}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function Analytics() {
  const [dateRange, setDateRange] = useState('7d');
  const [selectedPlatform, setSelectedPlatform] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');

  const queryClient = useQueryClient();

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['posts', 'published'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time'),
  });

  const { data: storiesReels = [] } = useQuery({
    queryKey: ['stories-reels'],
    queryFn: () => base44.entities.StoryReelAnalytics.list('-posted_at'),
  });

  const { data: abTests = [] } = useQuery({
    queryKey: ['ab-tests'],
    queryFn: () => base44.entities.ABTest.list('-created_date'),
  });

  const createTestMutation = useMutation({
    mutationFn: (data) => base44.entities.ABTest.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ab-tests'] }),
  });

  const updateTestMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ABTest.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ab-tests'] }),
  });

  const deleteTestMutation = useMutation({
    mutationFn: (id) => base44.entities.ABTest.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ab-tests'] }),
  });

  // Generate mock data for charts
  const days = dateRange === '7d' ? 7 : dateRange === '30d' ? 30 : 90;
  const engagementData = eachDayOfInterval({
    start: subDays(new Date(), days - 1),
    end: new Date()
  }).map(date => ({
    date: format(date, 'MMM d'),
    followers: Math.floor(Math.random() * 500) + 100,
    engagement: Math.floor(Math.random() * 2000) + 500,
    reach: Math.floor(Math.random() * 10000) + 2000,
  }));

  const platformData = [
    { name: 'Instagram', value: 45, color: '#E4405F' },
    { name: 'Facebook', value: 25, color: '#1877F2' },
    { name: 'TikTok', value: 15, color: '#000000' },
    { name: 'LinkedIn', value: 10, color: '#0A66C2' },
    { name: 'YouTube', value: 5, color: '#FF0000' },
  ];

  const bestTimesData = [
    { hour: '6AM', engagement: 320 },
    { hour: '9AM', engagement: 890 },
    { hour: '12PM', engagement: 1200 },
    { hour: '3PM', engagement: 980 },
    { hour: '6PM', engagement: 1450 },
    { hour: '9PM', engagement: 1680 },
    { hour: '12AM', engagement: 450 },
  ];

  const contentPerformance = [
    { type: 'Reels', engagement: 4500, posts: 12 },
    { type: 'Images', engagement: 2800, posts: 25 },
    { type: 'Carousels', engagement: 3200, posts: 8 },
    { type: 'Stories', engagement: 1800, posts: 45 },
    { type: 'Videos', engagement: 2100, posts: 6 },
  ];

  // Calculate totals
  const totalFollowers = accounts.reduce((sum, acc) => sum + (acc.followers_count || 0), 0);
  const totalEngagement = posts.reduce((sum, post) => sum + (post.likes || 0) + (post.comments || 0), 0);
  const totalReach = posts.reduce((sum, post) => sum + (post.reach || 0), 0);
  const avgEngagementRate = accounts.length > 0 
    ? (accounts.reduce((sum, acc) => sum + (acc.engagement_rate || 0), 0) / accounts.length).toFixed(2)
    : 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Analytics</h1>
          <p className="text-slate-400 mt-1">Track performance across all platforms</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
            <SelectTrigger className="w-40 bg-slate-900/50 border-slate-700">
              <SelectValue placeholder="Platform" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-slate-800">
              <SelectItem value="all">All Platforms</SelectItem>
              <SelectItem value="instagram">Instagram</SelectItem>
              <SelectItem value="facebook">Facebook</SelectItem>
              <SelectItem value="tiktok">TikTok</SelectItem>
              <SelectItem value="youtube">YouTube</SelectItem>
              <SelectItem value="linkedin">LinkedIn</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="flex bg-slate-800/50 rounded-lg p-1">
            {['7d', '30d', '90d'].map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={cn(
                  "px-3 py-1.5 text-sm font-medium rounded-md transition-colors",
                  dateRange === range
                    ? "bg-violet-600 text-white"
                    : "text-slate-400 hover:text-white"
                )}
              >
                {range}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-2 border-b border-slate-800 pb-4 overflow-x-auto">
        {[
          { id: 'overview', label: 'Overview', icon: BarChart3 },
          { id: 'trends', label: 'Trends', icon: TrendingUp },
          { id: 'post-performance', label: 'Posts', icon: FileText },
          { id: 'content-format', label: 'Formats', icon: Play },
          { id: 'competitors', label: 'Competitors', icon: Target },
          { id: 'ai-optimizer', label: 'AI Optimizer', icon: Sparkles },
          { id: 'stories-reels', label: 'Stories & Reels', icon: Play },
          { id: 'ab-testing', label: 'A/B Testing', icon: FlaskConical },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all",
              activeTab === tab.id
                ? "bg-violet-600 text-white"
                : "text-slate-400 hover:text-white hover:bg-slate-800/50"
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Trends Tab */}
      {activeTab === 'trends' && (
        <TrendAnalysis />
      )}

      {/* Post Performance Tab */}
      {activeTab === 'post-performance' && (
        <PostPerformanceBreakdown posts={posts} />
      )}

      {/* Content Format Tab */}
      {activeTab === 'content-format' && (
        <ContentFormatAnalysis />
      )}

      {/* Competitors Tab */}
      {activeTab === 'competitors' && (
        <CompetitorComparison />
      )}

      {/* AI Optimizer Tab */}
      {activeTab === 'ai-optimizer' && (
        <AIContentOptimizer posts={posts} />
      )}

      {/* Stories & Reels Tab */}
      {activeTab === 'stories-reels' && (
        <StoriesReelsAnalytics data={storiesReels} />
      )}

      {/* A/B Testing Tab */}
      {activeTab === 'ab-testing' && (
        <ABTestingPanel
          tests={abTests}
          onCreate={(data) => createTestMutation.mutate(data)}
          onUpdate={(id, data) => updateTestMutation.mutate({ id, data })}
          onDelete={(id) => deleteTestMutation.mutate(id)}
        />
      )}

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Total Followers"
              value={totalFollowers.toLocaleString()}
              change={8.5}
              icon={Users}
              gradient="from-violet-500 to-purple-500"
            />
            <StatsCard
              title="Total Reach"
              value={totalReach.toLocaleString()}
              change={12.3}
              icon={Eye}
              gradient="from-cyan-500 to-blue-500"
            />
            <StatsCard
              title="Total Engagement"
              value={totalEngagement.toLocaleString()}
              change={15.7}
              icon={Heart}
              gradient="from-rose-500 to-pink-500"
            />
            <StatsCard
              title="Avg Engagement Rate"
              value={`${avgEngagementRate}%`}
              change={2.1}
              icon={TrendingUp}
              gradient="from-emerald-500 to-teal-500"
            />
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Engagement Over Time */}
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="font-semibold text-white mb-6">Engagement Over Time</h3>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={engagementData}>
                  <defs>
                    <linearGradient id="colorEngagement" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#64748B" fontSize={12} />
                  <YAxis stroke="#64748B" fontSize={12} />
                  <Tooltip content={<CustomTooltip />} />
                  <Area 
                    type="monotone" 
                    dataKey="engagement" 
                    stroke="#8B5CF6" 
                    fillOpacity={1} 
                    fill="url(#colorEngagement)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            {/* Platform Distribution */}
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <h3 className="font-semibold text-white mb-6">Audience by Platform</h3>
              <div className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={platformData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {platformData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-wrap justify-center gap-4 mt-4">
                {platformData.map((entry, index) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: COLORS[index % COLORS.length] }}
                    />
                    <span className="text-sm text-slate-400">{entry.name}</span>
                    <span className="text-sm text-white font-medium">{entry.value}%</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Best Times to Post */}
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <div className="flex items-center gap-2 mb-6">
                <Clock className="w-5 h-5 text-violet-400" />
                <h3 className="font-semibold text-white">Best Times to Post</h3>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={bestTimesData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="hour" stroke="#64748B" fontSize={12} />
                  <YAxis stroke="#64748B" fontSize={12} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="engagement" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Content Performance */}
            <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
              <div className="flex items-center gap-2 mb-6">
                <BarChart3 className="w-5 h-5 text-violet-400" />
                <h3 className="font-semibold text-white">Content Performance</h3>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={contentPerformance} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis type="number" stroke="#64748B" fontSize={12} />
                  <YAxis dataKey="type" type="category" stroke="#64748B" fontSize={12} width={80} />
                  <Tooltip content={<CustomTooltip />} />
                  <Bar dataKey="engagement" fill="#EC4899" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Follower Growth */}
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="font-semibold text-white mb-6">Follower Growth</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#64748B" fontSize={12} />
                <YAxis stroke="#64748B" fontSize={12} />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="followers" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="reach" 
                  stroke="#06B6D4" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </>
      )}
    </div>
  );
}