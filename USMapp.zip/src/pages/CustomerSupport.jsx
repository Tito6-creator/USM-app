import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Headphones,
  Plus,
  Search,
  Filter,
  Clock,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Star,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';

export default function CustomerSupport() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [newTicket, setNewTicket] = useState({
    customer_name: '',
    customer_email: '',
    subject: '',
    description: '',
    category: 'general',
    priority: 'medium'
  });
  const [replyMessage, setReplyMessage] = useState('');

  const queryClient = useQueryClient();

  const { data: tickets = [] } = useQuery({
    queryKey: ['tickets'],
    queryFn: () => base44.entities.SupportTicket.list('-created_date', 100),
  });

  const { data: faqs = [] } = useQuery({
    queryKey: ['faqs'],
    queryFn: () => base44.entities.FAQ.filter({ is_published: true }, 'order', 50),
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['templates', 'support'],
    queryFn: () => base44.entities.MessageTemplate.filter({ category: 'support' }, '-usage_count', 20),
  });

  const createTicketMutation = useMutation({
    mutationFn: (data) => base44.entities.SupportTicket.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      toast.success('Ticket created!');
      setNewTicket({
        customer_name: '',
        customer_email: '',
        subject: '',
        description: '',
        category: 'general',
        priority: 'medium'
      });
    },
  });

  const updateTicketMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SupportTicket.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tickets'] });
      toast.success('Ticket updated!');
    },
  });

  const addReply = () => {
    if (!selectedTicket || !replyMessage) return;

    const messages = selectedTicket.messages || [];
    messages.push({
      sender: 'Support Team',
      message: replyMessage,
      timestamp: new Date().toISOString(),
      is_internal: false
    });

    updateTicketMutation.mutate({
      id: selectedTicket.id,
      data: { messages, status: 'in_progress' }
    });

    setReplyMessage('');
  };

  const priorityColors = {
    low: 'bg-slate-500/10 text-slate-400',
    medium: 'bg-blue-500/10 text-blue-400',
    high: 'bg-orange-500/10 text-orange-400',
    urgent: 'bg-red-500/10 text-red-400'
  };

  const statusIcons = {
    open: <AlertCircle className="w-4 h-4" />,
    in_progress: <Clock className="w-4 h-4" />,
    waiting_response: <MessageSquare className="w-4 h-4" />,
    resolved: <CheckCircle2 className="w-4 h-4" />,
    closed: <CheckCircle2 className="w-4 h-4" />
  };

  const openTickets = tickets.filter(t => ['open', 'in_progress'].includes(t.status));
  const resolvedTickets = tickets.filter(t => ['resolved', 'closed'].includes(t.status));

  return (
    <div className="max-w-[1600px] mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Customer Support</h1>
          <p className="text-slate-400 mt-1">Manage tickets, FAQs, and customer communications</p>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
              <Plus className="w-4 h-4 mr-2" />
              New Ticket
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">Create Support Ticket</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Customer Name</Label>
                  <Input
                    value={newTicket.customer_name}
                    onChange={(e) => setNewTicket({ ...newTicket, customer_name: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Customer Email</Label>
                  <Input
                    type="email"
                    value={newTicket.customer_email}
                    onChange={(e) => setNewTicket({ ...newTicket, customer_email: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
              </div>
              <div>
                <Label className="text-white">Subject</Label>
                <Input
                  value={newTicket.subject}
                  onChange={(e) => setNewTicket({ ...newTicket, subject: e.target.value })}
                  className="bg-slate-800 border-slate-700 text-white mt-2"
                />
              </div>
              <div>
                <Label className="text-white">Description</Label>
                <Textarea
                  value={newTicket.description}
                  onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                  className="bg-slate-800 border-slate-700 text-white mt-2 min-h-[120px]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-white">Category</Label>
                  <Select value={newTicket.category} onValueChange={(v) => setNewTicket({ ...newTicket, category: v })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      <SelectItem value="technical">Technical</SelectItem>
                      <SelectItem value="billing">Billing</SelectItem>
                      <SelectItem value="general">General</SelectItem>
                      <SelectItem value="feature_request">Feature Request</SelectItem>
                      <SelectItem value="bug_report">Bug Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-white">Priority</Label>
                  <Select value={newTicket.priority} onValueChange={(v) => setNewTicket({ ...newTicket, priority: v })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={() => createTicketMutation.mutate(newTicket)}
                disabled={!newTicket.customer_email || !newTicket.subject || createTicketMutation.isPending}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                Create Ticket
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Open Tickets</p>
              <p className="text-3xl font-bold text-white mt-1">{openTickets.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-orange-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Resolved</p>
              <p className="text-3xl font-bold text-white mt-1">{resolvedTickets.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Avg Response</p>
              <p className="text-3xl font-bold text-white mt-1">2.5h</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Clock className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Satisfaction</p>
              <p className="text-3xl font-bold text-white mt-1">4.8</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <Star className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="tickets" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="tickets" className="data-[state=active]:bg-violet-600">
            <Headphones className="w-4 h-4 mr-2" />
            Tickets
          </TabsTrigger>
          <TabsTrigger value="faqs" className="data-[state=active]:bg-violet-600">
            <MessageSquare className="w-4 h-4 mr-2" />
            FAQs
          </TabsTrigger>
          <TabsTrigger value="templates" className="data-[state=active]:bg-violet-600">
            <Star className="w-4 h-4 mr-2" />
            Templates
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tickets" className="space-y-4">
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tickets..."
                className="pl-10 bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <Button variant="outline" className="border-slate-700">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-3">
              {tickets.map(ticket => (
                <button
                  key={ticket.id}
                  onClick={() => setSelectedTicket(ticket)}
                  className={cn(
                    "w-full p-4 rounded-xl border text-left transition-all",
                    selectedTicket?.id === ticket.id
                      ? "bg-violet-500/10 border-violet-500"
                      : "bg-slate-800/50 border-slate-700 hover:border-slate-600"
                  )}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {statusIcons[ticket.status]}
                      <h4 className="font-semibold text-white text-sm">{ticket.subject}</h4>
                    </div>
                    <Badge className={priorityColors[ticket.priority]}>
                      {ticket.priority}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-400 mb-2 line-clamp-2">{ticket.description}</p>
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>{ticket.customer_name || ticket.customer_email}</span>
                    <span>{formatDistanceToNow(new Date(ticket.created_date), { addSuffix: true })}</span>
                  </div>
                </button>
              ))}
            </div>

            <div className="lg:col-span-2">
              {selectedTicket ? (
                <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
                  <div className="p-6 border-b border-slate-800">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl font-bold text-white">{selectedTicket.subject}</h3>
                        <p className="text-sm text-slate-400 mt-1">
                          <User className="w-3 h-3 inline mr-1" />
                          {selectedTicket.customer_name} • {selectedTicket.customer_email}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={priorityColors[selectedTicket.priority]}>
                          {selectedTicket.priority}
                        </Badge>
                        <Select
                          value={selectedTicket.status}
                          onValueChange={(v) => updateTicketMutation.mutate({ id: selectedTicket.id, data: { status: v } })}
                        >
                          <SelectTrigger className="w-40 bg-slate-800 border-slate-700 text-white">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-900 border-slate-800">
                            <SelectItem value="open">Open</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="waiting_response">Waiting Response</SelectItem>
                            <SelectItem value="resolved">Resolved</SelectItem>
                            <SelectItem value="closed">Closed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 max-h-96 overflow-y-auto">
                    <div className="space-y-4">
                      <div className="p-4 rounded-xl bg-slate-800/50">
                        <p className="text-sm text-slate-300">{selectedTicket.description}</p>
                      </div>
                      {selectedTicket.messages?.map((msg, idx) => (
                        <div key={idx} className={cn(
                          "p-4 rounded-xl",
                          msg.is_internal ? "bg-violet-500/10" : "bg-slate-800/50"
                        )}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-semibold text-white">{msg.sender}</span>
                            <span className="text-xs text-slate-500">
                              {formatDistanceToNow(new Date(msg.timestamp), { addSuffix: true })}
                            </span>
                          </div>
                          <p className="text-sm text-slate-300">{msg.message}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 border-t border-slate-800">
                    <Textarea
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                      placeholder="Type your reply..."
                      className="bg-slate-800 border-slate-700 text-white mb-3"
                    />
                    <Button onClick={addReply} disabled={!replyMessage} className="bg-violet-600">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Send Reply
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-500">
                  Select a ticket to view details
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="faqs">
          <div className="grid grid-cols-1 gap-4">
            {faqs.map(faq => (
              <div key={faq.id} className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-6">
                <h4 className="font-semibold text-white mb-2">{faq.question}</h4>
                <p className="text-sm text-slate-400">{faq.answer}</p>
                <div className="flex items-center gap-4 mt-3 text-xs text-slate-500">
                  <span>{faq.view_count} views</span>
                  <span>{faq.helpful_count} helpful</span>
                  <Badge variant="outline" className="border-slate-700">{faq.category}</Badge>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="templates">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map(template => (
              <div key={template.id} className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-6">
                <h4 className="font-semibold text-white mb-2">{template.name}</h4>
                <p className="text-sm text-slate-400 mb-3">{template.template_text}</p>
                <div className="flex items-center justify-between">
                  <Badge className="bg-violet-500/10 text-violet-400">
                    Used {template.usage_count} times
                  </Badge>
                  <Button size="sm" variant="outline" className="border-slate-700">
                    Use Template
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}