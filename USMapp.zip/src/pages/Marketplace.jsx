import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ShoppingBag, Search, Star, TrendingUp, DollarSign, Package } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { cn } from '@/lib/utils';

const categoryIcons = {
  template: Package,
  service: TrendingUp,
  course: Star,
  ebook: ShoppingBag,
  toolkit: Package,
  consultation: Star
};

export default function Marketplace() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState(null);

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: products = [] } = useQuery({
    queryKey: ['marketplace-products'],
    queryFn: () => base44.entities.MarketplaceProduct.filter({ status: 'active' }, '-created_date')
  });

  const { data: myPurchases = [] } = useQuery({
    queryKey: ['purchases', user?.email],
    queryFn: () => base44.entities.Purchase.filter({ buyer_email: user?.email }),
    enabled: !!user
  });

  const filteredProducts = products.filter(product => {
    if (searchQuery && !product.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !product.description?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    if (selectedCategory !== 'all' && product.category !== selectedCategory) {
      return false;
    }
    return true;
  });

  const hasPurchased = (productId) => {
    return myPurchases.some(p => p.product_id === productId && p.payment_status === 'completed');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Marketplace</h1>
          <p className="text-slate-400 mt-1">Templates, services, and tools for social media success</p>
        </div>
        <div className="flex items-center gap-3">
          <Link to={createPageUrl('MyProducts')}>
            <Button variant="outline" className="border-slate-700">
              <ShoppingBag className="w-4 h-4 mr-2" />
              My Products
            </Button>
          </Link>
          <Link to={createPageUrl('SellProduct')}>
            <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
              <DollarSign className="w-4 h-4 mr-2" />
              Start Selling
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card className="p-4 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-violet-500/20 flex items-center justify-center">
              <Package className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{products.length}</p>
              <p className="text-xs text-slate-400">Products</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <Star className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{products.filter(p => p.is_featured).length}</p>
              <p className="text-xs text-slate-400">Featured</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{myPurchases.length}</p>
              <p className="text-xs text-slate-400">My Purchases</p>
            </div>
          </div>
        </Card>
        <Card className="p-4 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{products.reduce((sum, p) => sum + (p.sales_count || 0), 0)}</p>
              <p className="text-xs text-slate-400">Total Sales</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input
            placeholder="Search products..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-slate-800 border-slate-700 text-white"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-full sm:w-48 bg-slate-800 border-slate-700 text-white">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent className="bg-slate-900 border-slate-800">
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="template">Templates</SelectItem>
            <SelectItem value="service">Services</SelectItem>
            <SelectItem value="course">Courses</SelectItem>
            <SelectItem value="ebook">E-books</SelectItem>
            <SelectItem value="toolkit">Toolkits</SelectItem>
            <SelectItem value="consultation">Consultation</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map(product => {
          const CategoryIcon = categoryIcons[product.category];
          const isPurchased = hasPurchased(product.id);
          
          return (
            <Card 
              key={product.id} 
              className="overflow-hidden bg-slate-900/50 border-slate-800 hover:border-violet-500/50 transition-all cursor-pointer group"
              onClick={() => setSelectedProduct(product)}
            >
              {product.thumbnail_url && (
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={product.thumbnail_url} 
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  {product.is_featured && (
                    <Badge className="absolute top-3 right-3 bg-yellow-500/90 text-yellow-950">
                      Featured
                    </Badge>
                  )}
                  {isPurchased && (
                    <Badge className="absolute top-3 left-3 bg-emerald-500/90 text-white">
                      Purchased
                    </Badge>
                  )}
                </div>
              )}
              
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-white font-semibold line-clamp-1">{product.title}</h3>
                    <p className="text-xs text-slate-400 mt-1">{product.seller_name}</p>
                  </div>
                  <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
                    <CategoryIcon className="w-4 h-4 text-violet-400" />
                  </div>
                </div>
                
                <p className="text-sm text-slate-400 line-clamp-2 mb-3">{product.description}</p>
                
                <div className="flex items-center gap-2 mb-3">
                  {product.platforms?.slice(0, 3).map(platform => (
                    <PlatformIcon key={platform} platform={platform} size="xs" />
                  ))}
                  {product.platforms?.length > 3 && (
                    <span className="text-xs text-slate-500">+{product.platforms.length - 3}</span>
                  )}
                </div>
                
                <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-white">
                      ${product.discount_price || product.price}
                    </span>
                    {product.discount_price && (
                      <span className="text-sm text-slate-500 line-through">${product.price}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1 text-xs text-slate-400">
                    <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
                    <span>{product.rating || 0}</span>
                    <span>({product.reviews_count || 0})</span>
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <Package className="w-12 h-12 mx-auto text-slate-600 mb-3" />
          <p className="text-slate-500">No products found</p>
        </div>
      )}

      {/* Product Detail Dialog */}
      <Dialog open={!!selectedProduct} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">{selectedProduct?.title}</DialogTitle>
          </DialogHeader>
          
          {selectedProduct && (
            <div className="space-y-4">
              {selectedProduct.thumbnail_url && (
                <img 
                  src={selectedProduct.thumbnail_url} 
                  alt={selectedProduct.title}
                  className="w-full h-64 object-cover rounded-lg"
                />
              )}
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-white">
                    ${selectedProduct.discount_price || selectedProduct.price}
                  </p>
                  <p className="text-sm text-slate-400">By {selectedProduct.seller_name}</p>
                </div>
                <Badge className="bg-violet-500/20 text-violet-400">
                  {selectedProduct.category}
                </Badge>
              </div>
              
              <p className="text-slate-300">{selectedProduct.description}</p>
              
              <div className="flex items-center gap-2 flex-wrap">
                {selectedProduct.tags?.map(tag => (
                  <Badge key={tag} variant="outline" className="border-slate-700">
                    {tag}
                  </Badge>
                ))}
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-400">Compatible with:</span>
                {selectedProduct.platforms?.map(platform => (
                  <PlatformIcon key={platform} platform={platform} size="sm" />
                ))}
              </div>
              
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                <span>{selectedProduct.rating || 0} rating</span>
                <span>•</span>
                <span>{selectedProduct.sales_count || 0} sales</span>
              </div>
              
              <Button 
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
                disabled={hasPurchased(selectedProduct.id)}
              >
                {hasPurchased(selectedProduct.id) ? 'Already Purchased' : `Buy Now - $${selectedProduct.discount_price || selectedProduct.price}`}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}