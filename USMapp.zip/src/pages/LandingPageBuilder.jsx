import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Plus,
  Eye,
  Edit,
  Trash2,
  Copy,
  ExternalLink,
  Layout,
  Palette,
  Type,
  Image as ImageIcon,
  Code,
  BarChart3,
  Sparkles,
  Wand2
} from 'lucide-react';
import VisualEditor from '@/components/landing/VisualEditor';
import AIContentGenerator from '@/components/landing/AIContentGenerator';
import AnalyticsDashboard from '@/components/landing/AnalyticsDashboard';
import DomainManager from '@/components/landing/DomainManager';
import SEOOptimizer from '@/components/landing/SEOOptimizer';
import PublishingWorkflow from '@/components/landing/PublishingWorkflow';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function LandingPageBuilder() {
  const [isOpen, setIsOpen] = useState(false);
  const [editingPage, setEditingPage] = useState(null);
  const [visualEditorOpen, setVisualEditorOpen] = useState(false);
  const [aiGeneratorOpen, setAIGeneratorOpen] = useState(false);
  const [analyticsOpen, setAnalyticsOpen] = useState(false);
  const [publishingOpen, setPublishingOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    template: 'minimal',
    content: {
      headline: '',
      subheadline: '',
      body: '',
      cta_text: '',
      cta_url: ''
    },
    design: {
      primary_color: '#8b5cf6',
      secondary_color: '#ec4899',
      background_image: '',
      logo_url: ''
    },
    seo: {
      title: '',
      description: '',
      keywords: []
    }
  });

  const queryClient = useQueryClient();

  const { data: pages = [] } = useQuery({
    queryKey: ['landingPages'],
    queryFn: () => base44.entities.LandingPage.list('-created_date', 50),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.LandingPage.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Landing page created!');
      setIsOpen(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LandingPage.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Landing page updated!');
      setIsOpen(false);
      resetForm();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.LandingPage.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['landingPages'] });
      toast.success('Landing page deleted!');
    },
  });

  const resetForm = () => {
    setFormData({
      name: '',
      slug: '',
      template: 'minimal',
      content: { headline: '', subheadline: '', body: '', cta_text: '', cta_url: '' },
      design: { primary_color: '#8b5cf6', secondary_color: '#ec4899', background_image: '', logo_url: '' },
      seo: { title: '', description: '', keywords: [] }
    });
    setEditingPage(null);
  };

  const handleEdit = (page) => {
    setEditingPage(page);
    setFormData({
      name: page.name,
      slug: page.slug,
      template: page.template || 'minimal',
      content: page.content || {},
      design: page.design || {},
      seo: page.seo || {}
    });
    setIsOpen(true);
  };

  const handleSave = () => {
    if (editingPage) {
      updateMutation.mutate({ id: editingPage.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const openVisualEditor = (page) => {
    setCurrentPage(page);
    setVisualEditorOpen(true);
  };

  const handleVisualEditorSave = async (updatedPage) => {
    await updateMutation.mutateAsync({ id: updatedPage.id, data: updatedPage });
    setVisualEditorOpen(false);
  };

  const handleAIContentApply = (content) => {
    setFormData({
      ...formData,
      content: {
        headline: content.headline,
        subheadline: content.subheadline,
        body: content.hero_body,
        cta_text: content.cta_text,
        cta_url: '#'
      },
      seo: {
        title: content.seo_title,
        description: content.seo_description,
        keywords: []
      }
    });
    setAIGeneratorOpen(false);
    toast.success('AI content applied!');
  };

  const templates = [
    { value: 'minimal', label: 'Minimal', description: 'Clean and simple design' },
    { value: 'product', label: 'Product', description: 'Showcase products' },
    { value: 'service', label: 'Service', description: 'Service offerings' },
    { value: 'event', label: 'Event', description: 'Event registration' },
    { value: 'lead_capture', label: 'Lead Capture', description: 'Form-focused design' },
    { value: 'saas', label: 'SaaS', description: 'Software as a Service' },
    { value: 'agency', label: 'Agency', description: 'Creative agency' },
    { value: 'ecommerce', label: 'E-commerce', description: 'Online store' },
    { value: 'custom', label: 'Custom', description: 'Start from scratch' },
  ];

  if (visualEditorOpen && currentPage) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Visual Editor</h1>
            <p className="text-slate-400 mt-1">Editing: {currentPage.name}</p>
          </div>
          <Button
            variant="outline"
            onClick={() => setVisualEditorOpen(false)}
            className="border-slate-700"
          >
            Back to List
          </Button>
        </div>
        <VisualEditor page={currentPage} onSave={handleVisualEditorSave} />
      </div>
    );
  }

  if (analyticsOpen && currentPage) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Analytics</h1>
            <p className="text-slate-400 mt-1">{currentPage.name}</p>
          </div>
          <Button
            variant="outline"
            onClick={() => setAnalyticsOpen(false)}
            className="border-slate-700"
          >
            Back to List
          </Button>
        </div>
        <AnalyticsDashboard pageId={currentPage.id} />
      </div>
    );
  }

  if (publishingOpen && currentPage) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Publish Landing Page</h1>
            <p className="text-slate-400 mt-1">{currentPage.name}</p>
          </div>
          <Button
            variant="outline"
            onClick={() => setPublishingOpen(false)}
            className="border-slate-700"
          >
            Back to List
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-6">
            <PublishingWorkflow page={currentPage} />
            <DomainManager page={currentPage} />
          </div>
          <SEOOptimizer page={currentPage} />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1600px] mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Landing Page Builder</h1>
          <p className="text-slate-400 mt-1">Create custom landing pages for your campaigns</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={aiGeneratorOpen} onOpenChange={setAIGeneratorOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="border-slate-700">
                <Sparkles className="w-4 h-4 mr-2 text-violet-400" />
                AI Generator
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-800 max-w-4xl max-h-[90vh] overflow-y-auto">
              <AIContentGenerator onApply={handleAIContentApply} />
            </DialogContent>
          </Dialog>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
                <Plus className="w-4 h-4 mr-2" />
                New Landing Page
              </Button>
            </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">
                {editingPage ? 'Edit Landing Page' : 'Create Landing Page'}
              </DialogTitle>
            </DialogHeader>

            <Tabs defaultValue="basic" className="space-y-4">
              <TabsList className="bg-slate-800">
                <TabsTrigger value="basic">
                  <Layout className="w-4 h-4 mr-2" />
                  Basic
                </TabsTrigger>
                <TabsTrigger value="content">
                  <Type className="w-4 h-4 mr-2" />
                  Content
                </TabsTrigger>
                <TabsTrigger value="design">
                  <Palette className="w-4 h-4 mr-2" />
                  Design
                </TabsTrigger>
                <TabsTrigger value="seo">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  SEO
                </TabsTrigger>
              </TabsList>

              <TabsContent value="basic" className="space-y-4">
                <div>
                  <Label className="text-white">Page Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">URL Slug</Label>
                  <Input
                    value={formData.slug}
                    onChange={(e) => setFormData({ ...formData, slug: e.target.value.toLowerCase().replace(/\s/g, '-') })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                    placeholder="my-landing-page"
                  />
                </div>
                <div>
                  <Label className="text-white">Template</Label>
                  <Select value={formData.template} onValueChange={(v) => setFormData({ ...formData, template: v })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      {templates.map(t => (
                        <SelectItem key={t.value} value={t.value}>
                          <div>
                            <p className="font-semibold">{t.label}</p>
                            <p className="text-xs text-slate-400">{t.description}</p>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </TabsContent>

              <TabsContent value="content" className="space-y-4">
                <div>
                  <Label className="text-white">Headline</Label>
                  <Input
                    value={formData.content.headline}
                    onChange={(e) => setFormData({ ...formData, content: { ...formData.content, headline: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Subheadline</Label>
                  <Input
                    value={formData.content.subheadline}
                    onChange={(e) => setFormData({ ...formData, content: { ...formData.content, subheadline: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Body Content</Label>
                  <Textarea
                    value={formData.content.body}
                    onChange={(e) => setFormData({ ...formData, content: { ...formData.content, body: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2 min-h-[120px]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">CTA Button Text</Label>
                    <Input
                      value={formData.content.cta_text}
                      onChange={(e) => setFormData({ ...formData, content: { ...formData.content, cta_text: e.target.value } })}
                      className="bg-slate-800 border-slate-700 text-white mt-2"
                      placeholder="Get Started"
                    />
                  </div>
                  <div>
                    <Label className="text-white">CTA URL</Label>
                    <Input
                      value={formData.content.cta_url}
                      onChange={(e) => setFormData({ ...formData, content: { ...formData.content, cta_url: e.target.value } })}
                      className="bg-slate-800 border-slate-700 text-white mt-2"
                      placeholder="https://..."
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="design" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Primary Color</Label>
                    <Input
                      type="color"
                      value={formData.design.primary_color}
                      onChange={(e) => setFormData({ ...formData, design: { ...formData.design, primary_color: e.target.value } })}
                      className="bg-slate-800 border-slate-700 h-12 mt-2"
                    />
                  </div>
                  <div>
                    <Label className="text-white">Secondary Color</Label>
                    <Input
                      type="color"
                      value={formData.design.secondary_color}
                      onChange={(e) => setFormData({ ...formData, design: { ...formData.design, secondary_color: e.target.value } })}
                      className="bg-slate-800 border-slate-700 h-12 mt-2"
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-white">Background Image URL</Label>
                  <Input
                    value={formData.design.background_image}
                    onChange={(e) => setFormData({ ...formData, design: { ...formData.design, background_image: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Logo URL</Label>
                  <Input
                    value={formData.design.logo_url}
                    onChange={(e) => setFormData({ ...formData, design: { ...formData.design, logo_url: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
              </TabsContent>

              <TabsContent value="seo" className="space-y-4">
                <div>
                  <Label className="text-white">SEO Title</Label>
                  <Input
                    value={formData.seo.title}
                    onChange={(e) => setFormData({ ...formData, seo: { ...formData.seo, title: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div>
                  <Label className="text-white">Meta Description</Label>
                  <Textarea
                    value={formData.seo.description}
                    onChange={(e) => setFormData({ ...formData, seo: { ...formData.seo, description: e.target.value } })}
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex gap-3 pt-4">
              <Button onClick={() => { setIsOpen(false); resetForm(); }} variant="outline" className="flex-1 border-slate-700">
                Cancel
              </Button>
              <Button onClick={handleSave} disabled={!formData.name || !formData.slug} className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600">
                {editingPage ? 'Update' : 'Create'} Page
              </Button>
            </div>
          </DialogContent>
        </Dialog>
        </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {pages.map((page) => (
          <div key={page.id} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
            <div className="aspect-video bg-slate-800 flex items-center justify-center">
              <Layout className="w-12 h-12 text-slate-600" />
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-white">{page.name}</h3>
                  <p className="text-xs text-slate-500">/{page.slug}</p>
                </div>
                <Badge className={cn(
                  page.is_published ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-500/10 text-slate-400'
                )}>
                  {page.is_published ? 'Published' : 'Draft'}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 mb-3">
                <div>
                  <Eye className="w-3 h-3 inline mr-1" />
                  {page.views || 0} views
                </div>
                <div>
                  <BarChart3 className="w-3 h-3 inline mr-1" />
                  {page.conversion_rate || 0}% CVR
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-2">
                <Button size="sm" variant="outline" onClick={() => openVisualEditor(page)} className="border-slate-700">
                  <Wand2 className="w-3 h-3 mr-1" />
                  Design
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleEdit(page)} className="border-slate-700">
                  <Edit className="w-3 h-3 mr-1" />
                  Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => { setCurrentPage(page); setAnalyticsOpen(true); }} className="border-slate-700">
                  <BarChart3 className="w-3 h-3 mr-1" />
                  Analytics
                </Button>
                <Button size="sm" className="bg-violet-600 hover:bg-violet-700" onClick={() => { setCurrentPage(page); setPublishingOpen(true); }}>
                  <Eye className="w-3 h-3 mr-1" />
                  Publish
                </Button>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1 border-slate-700">
                  <ExternalLink className="w-3 h-3" />
                </Button>
                <Button size="sm" variant="outline" onClick={() => deleteMutation.mutate(page.id)} className="border-rose-700 text-rose-400">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}