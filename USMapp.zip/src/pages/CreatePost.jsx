import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { format } from 'date-fns';
import {
  Sparkles,
  Image,
  Video,
  Upload,
  Calendar,
  Clock,
  Hash,
  Send,
  Save,
  Loader2,
  X,
  Wand2,
  FileText,
  Eye,
  Globe,
  Zap,
  Edit,
  List
} from 'lucide-react';
import AutomatedWorkflow from '@/components/content/AutomatedWorkflow';
import PublishingQueue from '@/components/content/PublishingQueue';
import PlatformVariations from '@/components/content/PlatformVariations';
import RecurringSchedule from '@/components/content/RecurringSchedule';
import AIContentAssistant from '@/components/content/AIContentAssistant';
import AIVideoGenerator from '@/components/content/AIVideoGenerator';
import AIContentRefinement from '@/components/content/AIContentRefinement';
import PlatformAdapter from '@/components/content/PlatformAdapter';
import AIVideoScriptGenerator from '@/components/content/AIVideoScriptGenerator';
import AudienceSegmentGenerator from '@/components/content/AudienceSegmentGenerator';
import ViralityPredictor from '@/components/content/ViralityPredictor';
import RealTimeScheduleSuggester from '@/components/scheduling/RealTimeScheduleSuggester';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';

const platforms = ['facebook', 'instagram', 'youtube', 'tiktok', 'pinterest', 'linkedin', 'threads'];

export default function CreatePost() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);
  const [activeTab, setActiveTab] = useState('manual');
  
  const [content, setContent] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState([]);
  const [selectedAccounts, setSelectedAccounts] = useState([]);
  const [mediaUrls, setMediaUrls] = useState([]);
  const [mediaType, setMediaType] = useState('image');
  const [hashtags, setHashtags] = useState([]);
  const [hashtagInput, setHashtagInput] = useState('');
  const [scheduledDate, setScheduledDate] = useState(null);
  const [scheduledTime, setScheduledTime] = useState('12:00');
  const [isScheduled, setIsScheduled] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [aiAutoPilot, setAiAutoPilot] = useState(false);
  const [platformVariations, setPlatformVariations] = useState({});
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurrenceData, setRecurrenceData] = useState({
    recurrence_pattern: 'weekly',
    recurrence_interval: 1,
    recurrence_days: [],
    recurrence_end_date: null,
  });

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts'],
    queryFn: () => base44.entities.SocialAccount.list(),
  });

  const { data: suggestedHashtags = [] } = useQuery({
    queryKey: ['hashtags', 'trending'],
    queryFn: () => base44.entities.Hashtag.filter({ trend_status: 'rising' }, '-avg_engagement', 10),
  });

  const createMutation = useMutation({
    mutationFn: (postData) => base44.entities.Post.create(postData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['posts'] });
      toast.success('✅ Post created successfully!');
      navigate(createPageUrl('Calendar'));
    },
    onError: (error) => {
      console.error('Post creation error:', error);
      toast.error('❌ Failed to create post: ' + error.message);
    }
  });

  const togglePlatform = (platform) => {
    setSelectedPlatforms(prev => 
      prev.includes(platform) 
        ? prev.filter(p => p !== platform)
        : [...prev, platform]
    );
  };

  const toggleAccount = (accountId) => {
    setSelectedAccounts(prev => 
      prev.includes(accountId) 
        ? prev.filter(a => a !== accountId)
        : [...prev, accountId]
    );
  };

  const addHashtag = () => {
    if (hashtagInput && !hashtags.includes(hashtagInput.replace('#', ''))) {
      setHashtags([...hashtags, hashtagInput.replace('#', '')]);
      setHashtagInput('');
    }
  };

  const removeHashtag = (tag) => {
    setHashtags(hashtags.filter(t => t !== tag));
  };

  const handleFileUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);

    try {
      const newUrls = [];
      for (let i = 0; i < files.length; i++) {
        const result = await base44.integrations.Core.UploadFile({ file: files[i] });
        newUrls.push(result.file_url);
      }
      setMediaUrls(prev => [...prev, ...newUrls]);
      toast.success(`✅ ${files.length} file(s) uploaded!`);
    } catch (error) {
      console.error('File upload error:', error);
      toast.error('❌ Upload failed: ' + error.message);
    } finally {
      setIsUploading(false);
      if (e.target) e.target.value = '';
    }
  };

  const generateAIContent = async () => {
    if (selectedPlatforms.length === 0) {
      toast.error('Please select at least one platform first');
      return;
    }

    setIsGenerating(true);
    toast.info('🤖 AI is creating your content...');

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Generate an engaging social media post for ${selectedPlatforms.join(', ')} platforms. 
        The content should be catchy, include emojis, and be optimized for engagement.
        Also suggest 5 relevant hashtags.
        Topic: ${content || 'general marketing content'}`,
        response_json_schema: {
          type: 'object',
          properties: {
            post_content: { type: 'string' },
            hashtags: { type: 'array', items: { type: 'string' } },
            best_time_to_post: { type: 'string' }
          }
        }
      });

      if (result && result.post_content) {
        setContent(result.post_content);
        setHashtags(result.hashtags || []);
        toast.success('✅ AI content generated successfully!');
      } else {
        throw new Error('Invalid response from AI');
      }
    } catch (error) {
      console.error('AI generation error:', error);
      toast.error('❌ Failed to generate content: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = (status) => {
    if (!content) {
      toast.error('Please add some content');
      return;
    }
    if (selectedPlatforms.length === 0) {
      toast.error('Please select at least one platform');
      return;
    }

    let scheduledTime_final = null;
    if (isScheduled && scheduledDate) {
      const [hours, minutes] = scheduledTime.split(':');
      const date = new Date(scheduledDate);
      date.setHours(parseInt(hours), parseInt(minutes));
      scheduledTime_final = date.toISOString();
    }

    createMutation.mutate({
      content,
      platform_variations: platformVariations,
      platforms: selectedPlatforms,
      account_ids: selectedAccounts,
      media_urls: mediaUrls,
      media_type: mediaType,
      hashtags,
      status: status,
      scheduled_time: scheduledTime_final,
      ai_generated: isGenerating,
      is_recurring: isRecurring,
      ...(isRecurring && {
        recurrence_pattern: recurrenceData.recurrence_pattern,
        recurrence_interval: recurrenceData.recurrence_interval,
        recurrence_days: recurrenceData.recurrence_days,
        recurrence_end_date: recurrenceData.recurrence_end_date,
      }),
    });
  };

  const filteredAccounts = accounts.filter(acc => selectedPlatforms.includes(acc.platform));

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Content Creation</h1>
          <p className="text-slate-400 mt-1">Create, automate, and manage your content</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="manual" className="data-[state=active]:bg-violet-600">
            <Edit className="w-4 h-4 mr-2" />
            Manual Create
          </TabsTrigger>
          <TabsTrigger value="workflow" className="data-[state=active]:bg-violet-600">
            <Zap className="w-4 h-4 mr-2" />
            Automated Workflow
          </TabsTrigger>
          <TabsTrigger value="queue" className="data-[state=active]:bg-violet-600">
            <List className="w-4 h-4 mr-2" />
            Publishing Queue
          </TabsTrigger>
        </TabsList>

        <TabsContent value="manual" className="mt-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20">
              <Sparkles className="w-4 h-4 text-violet-400" />
              <span className="text-sm text-violet-300">AI Auto-Pilot</span>
              <Switch checked={aiAutoPilot} onCheckedChange={setAiAutoPilot} />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Platform Selection */}
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <Label className="text-white mb-4 block">Select Platforms</Label>
                <div className="flex flex-wrap gap-3">
                  {platforms.map((platform) => (
                    <button
                      key={platform}
                      onClick={() => togglePlatform(platform)}
                      className={cn(
                        "flex items-center gap-2 px-4 py-2 rounded-xl border transition-all",
                        selectedPlatforms.includes(platform)
                          ? "border-violet-500 bg-violet-500/10"
                          : "border-slate-700 hover:border-slate-600"
                      )}
                    >
                      <PlatformIcon platform={platform} size="sm" />
                      <span className="text-sm text-white capitalize">{platform}</span>
                    </button>
                  ))}
                </div>

                {filteredAccounts.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-slate-800">
                    <Label className="text-slate-400 mb-3 block">Select Accounts</Label>
                    <div className="flex flex-wrap gap-2">
                      {filteredAccounts.map((account) => (
                        <button
                          key={account.id}
                          onClick={() => toggleAccount(account.id)}
                          className={cn(
                            "flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm transition-all",
                            selectedAccounts.includes(account.id)
                              ? "border-violet-500 bg-violet-500/10 text-white"
                              : "border-slate-700 text-slate-400 hover:border-slate-600"
                          )}
                        >
                          <PlatformIcon platform={account.platform} size="xs" />
                          @{account.username}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Content Editor */}
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-white">Post Content</Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={generateAIContent}
                    disabled={isGenerating}
                    className="text-violet-400 hover:text-violet-300"
                  >
                    {isGenerating ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Wand2 className="w-4 h-4 mr-2" />
                    )}
                    Generate with AI
                  </Button>
                </div>
                
                <Textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="What would you like to share?"
                  className="min-h-[200px] bg-slate-800/50 border-slate-700 text-white placeholder:text-slate-500 resize-none"
                />
                
                <div className="flex items-center justify-between mt-3 text-sm text-slate-500">
                  <span>{content.length} characters</span>
                  <span>{280 - content.length} remaining (Twitter limit)</span>
                </div>
              </div>

              {/* Media Upload */}
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <Label className="text-white mb-4 block">Media Upload</Label>

                <input 
                  ref={fileInputRef}
                  type="file" 
                  multiple 
                  accept="image/*,video/*"
                  onChange={handleFileUpload}
                  style={{ display: 'none' }}
                />

                <Button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="w-full bg-violet-600 hover:bg-violet-700"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Choose Files to Upload
                    </>
                  )}
                </Button>

                {isUploading && (
                  <div className="mt-4 p-4 bg-yellow-500/20 border border-yellow-500/50 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin text-yellow-400" />
                      <span className="text-yellow-400 font-semibold">UPLOADING FILES...</span>
                    </div>
                  </div>
                )}

                {mediaUrls.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <p className="text-xs text-emerald-400">✓ {mediaUrls.length} file(s) uploaded</p>
                    <div className="flex flex-wrap gap-3">
                      {mediaUrls.map((url, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={url} 
                            alt={`Upload ${index + 1}`}
                            className="w-20 h-20 rounded-lg object-cover border-2 border-emerald-500"
                          />
                          <button
                            onClick={() => setMediaUrls(mediaUrls.filter((_, i) => i !== index))}
                            className="absolute -top-2 -right-2 w-5 h-5 bg-rose-500 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3 text-white" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Hashtags */}
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <Label className="text-white mb-4 block">Hashtags</Label>
                
                <div className="flex gap-2 mb-4">
                  <Input
                    value={hashtagInput}
                    onChange={(e) => setHashtagInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addHashtag()}
                    placeholder="Add hashtag..."
                    className="bg-slate-800/50 border-slate-700 text-white"
                  />
                  <Button onClick={addHashtag} variant="outline" className="border-slate-700">
                    <Hash className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {hashtags.map((tag) => (
                    <Badge 
                      key={tag}
                      className="bg-violet-500/10 text-violet-400 border-violet-500/20 cursor-pointer hover:bg-violet-500/20"
                      onClick={() => removeHashtag(tag)}
                    >
                      #{tag}
                      <X className="w-3 h-3 ml-1" />
                    </Badge>
                  ))}
                </div>

                {suggestedHashtags.length > 0 && (
                  <div>
                    <p className="text-xs text-slate-500 mb-2">Suggested Hashtags</p>
                    <div className="flex flex-wrap gap-2">
                      {suggestedHashtags.map((h) => (
                        <Badge
                          key={h.id}
                          variant="outline"
                          className="border-slate-700 text-slate-400 cursor-pointer hover:border-violet-500 hover:text-violet-400"
                          onClick={() => !hashtags.includes(h.tag) && setHashtags([...hashtags, h.tag])}
                        >
                          #{h.tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* AI Video Generator */}
              <AIVideoGenerator
                onVideoGenerated={(videoUrl) => {
                  setMediaUrls([...mediaUrls, videoUrl]);
                  setMediaType('video');
                }}
              />

              {/* AI Content Assistant */}
              <AIContentAssistant
                onContentSelect={(text) => setContent(text)}
                onHashtagsSelect={(tags) => setHashtags([...new Set([...hashtags, ...tags])])}
                currentContent={content}
                selectedPlatforms={selectedPlatforms}
                mediaUrls={mediaUrls}
              />

              {/* AI Content Refinement */}
              <AIContentRefinement
                content={content}
                onContentUpdate={setContent}
                onHashtagsUpdate={(tags) => setHashtags([...new Set([...hashtags, ...tags])])}
                currentHashtags={hashtags}
              />

              {/* Platform Adapter */}
              {selectedPlatforms.length > 1 && (
                <PlatformAdapter
                  baseContent={content}
                  selectedPlatforms={selectedPlatforms}
                  onVariationsGenerated={(variations) => setPlatformVariations(variations)}
                />
              )}

              {/* Video Script Generator */}
              <AIVideoScriptGenerator 
                productInfo={content}
                onScriptGenerated={(script) => console.log('Script generated:', script)}
              />

              {/* Audience Segment Generator */}
              <AudienceSegmentGenerator
                baseContent={content}
                onVariationsGenerated={(segments) => console.log('Segments generated:', segments)}
              />

              {/* Virality Predictor */}
              <ViralityPredictor
                content={content}
                mediaUrls={mediaUrls}
                platforms={selectedPlatforms}
                hashtags={hashtags}
              />

              {/* Real-Time Schedule Suggester */}
              <RealTimeScheduleSuggester
                platforms={selectedPlatforms}
                onScheduleSelect={(timeSlot) => {
                  if (timeSlot.immediate) {
                    setIsScheduled(false);
                    toast.success('Will publish immediately!');
                  } else {
                    const now = new Date();
                    const [hours, minutes] = timeSlot.time.split(':');
                    const scheduledDate = new Date(now);
                    scheduledDate.setHours(parseInt(hours), parseInt(minutes || 0), 0, 0);
                    setScheduledDate(scheduledDate);
                    setScheduledTime(`${hours}:${minutes || '00'}`);
                    setIsScheduled(true);
                    toast.success(`Scheduled for ${timeSlot.time}`);
                  }
                }}
              />
              
              {/* Schedule */}
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-white">Schedule Post</Label>
                  <Switch checked={isScheduled} onCheckedChange={setIsScheduled} />
                </div>

                {isScheduled && (
                  <div className="space-y-4">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start border-slate-700 text-slate-300">
                          <Calendar className="w-4 h-4 mr-2" />
                          {scheduledDate ? format(scheduledDate, 'PPP') : 'Pick a date'}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 bg-slate-900 border-slate-800">
                        <CalendarComponent
                          mode="single"
                          selected={scheduledDate}
                          onSelect={setScheduledDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>

                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-slate-400" />
                      <Input
                        type="time"
                        value={scheduledTime}
                        onChange={(e) => setScheduledTime(e.target.value)}
                        className="bg-slate-800/50 border-slate-700 text-white"
                      />
                    </div>

                    <RecurringSchedule
                      isRecurring={isRecurring}
                      onRecurringChange={setIsRecurring}
                      recurrenceData={recurrenceData}
                      onRecurrenceChange={setRecurrenceData}
                    />
                  </div>
                )}
              </div>

              {/* Platform-Specific Content */}
              {selectedPlatforms.length > 1 && (
                <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                  <Label className="text-white mb-4 block">Platform-Specific Content</Label>
                  <PlatformVariations
                    selectedPlatforms={selectedPlatforms}
                    variations={platformVariations}
                    onVariationChange={setPlatformVariations}
                    defaultContent={content}
                    defaultHashtags={hashtags}
                  />
                </div>
              )}

              {/* Preview */}
              <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
                <Label className="text-white mb-4 block">Preview</Label>
                
                <div className="rounded-xl bg-slate-800/50 p-4">
                  {mediaUrls[0] && (
                    <img 
                      src={mediaUrls[0]} 
                      alt="" 
                      className="w-full h-40 object-cover rounded-lg mb-3"
                    />
                  )}
                  <p className="text-sm text-slate-300 whitespace-pre-wrap">
                    {content || 'Your post preview will appear here...'}
                  </p>
                  {hashtags.length > 0 && (
                    <p className="text-sm text-violet-400 mt-2">
                      {hashtags.map(t => `#${t}`).join(' ')}
                    </p>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-3">
                <Button 
                  onClick={() => handleSubmit(isScheduled ? 'scheduled' : 'published')}
                  disabled={createMutation.isPending}
                  className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
                >
                  {createMutation.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : isScheduled ? (
                    <Calendar className="w-4 h-4 mr-2" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  {isScheduled ? 'Schedule Post' : 'Publish Now'}
                </Button>
                
                <Button 
                  onClick={() => handleSubmit('draft')}
                  variant="outline"
                  className="w-full border-slate-700 text-slate-300"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Save as Draft
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="workflow" className="mt-6">
          <AutomatedWorkflow />
        </TabsContent>

        <TabsContent value="queue" className="mt-6">
          <PublishingQueue />
        </TabsContent>
      </Tabs>
    </div>
  );
}