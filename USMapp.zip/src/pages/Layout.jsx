
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from './utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { cn } from '@/lib/utils';
import HelpButton from '@/components/HelpButton';
import {
  LayoutDashboard,
  Calendar,
  PenSquare,
  Inbox,
  Search,
  BarChart3,
  Users,
  Hash,
  FolderOpen,
  Crown,
  Bot,
  Link2,
  FileText,
  Target,
  Settings,
  Bell,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Menu,
  X,
  Eye,
  Zap,
  TrendingUp,
  MessageSquare,
  Brain,
  Headphones,
  Sparkles,
  Layout as LayoutIcon,
  DollarSign,
  Video
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import LanguageSelector from '@/components/LanguageSelector';
import FloatingAutopilot from '@/components/autopilot/FloatingAutopilot';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';

const navigation = [
  { name: 'Dashboard', icon: LayoutDashboard, page: 'App', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'CRM Dashboard', icon: Users, page: 'CRMDashboard', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Contacts', icon: Users, page: 'Contacts', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Pipeline', icon: TrendingUp, page: 'Pipeline', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'CRM Tasks', icon: Calendar, page: 'CRMTasks', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'AI Strategy', icon: Zap, page: 'Strategy', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Campaign Planner', icon: Target, page: 'CampaignPlanner', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Content Calendar', icon: Calendar, page: 'Calendar', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Create Post', icon: PenSquare, page: 'CreatePost', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Create Video', icon: Sparkles, page: 'CreateVideo', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Automation', icon: Zap, page: 'Automation', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Email Campaigns', icon: MessageSquare, page: 'EmailCampaigns', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Inbox', icon: Inbox, page: 'Inbox', badge: true, tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Brand Monitor', icon: Eye, page: 'BrandMonitor', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Competitors', icon: TrendingUp, page: 'Competitors', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Analytics', icon: BarChart3, page: 'Analytics', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Advanced Analytics', icon: Brain, page: 'AIAnalyticsDashboard', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Content Monetization', icon: DollarSign, page: 'ContentMonetization', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Hashtags', icon: Hash, page: 'Hashtags', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Media Library', icon: FolderOpen, page: 'MediaLibrary', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Influencers', icon: Crown, page: 'Influencers', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Chatbot', icon: Bot, page: 'Chatbot', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Link in Bio', icon: Link2, page: 'LinkInBio', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Landing Pages', icon: LayoutIcon, page: 'LandingPageBuilder', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Reports', icon: FileText, page: 'Reports', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Goals', icon: Target, page: 'Goals', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Team', icon: Users, page: 'Team', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Support', icon: Headphones, page: 'CustomerSupport', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Features', icon: Sparkles, page: 'Features', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Pricing', icon: DollarSign, page: 'Pricing', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'AI Settings', icon: Brain, page: 'AISettings', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
  { name: 'Settings', icon: Settings, page: 'Settings', tutorial: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' },
];

export default function Layout({ children, currentPageName }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [autopilotOpen, setAutopilotOpen] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', 'unread'],
    queryFn: () => base44.entities.Notification.filter({ is_read: false }, '-created_date', 10),
    refetchInterval: 30000,
    enabled: !!user,
    retry: 1,
    staleTime: 60000,
  });

  const { data: unreadMessages = [] } = useQuery({
    queryKey: ['messages', 'unread'],
    queryFn: () => base44.entities.Message.filter({ is_read: false }, '-created_date', 50),
    enabled: !!user,
    retry: 1,
    staleTime: 60000,
  });

  const unreadCount = unreadMessages.length;

  const NavContent = ({ mobile = false }) => (
    <div className="flex flex-col h-full">
      <div className={cn(
        "flex items-center gap-3 px-4 py-6 border-b border-slate-800",
        collapsed && !mobile && "justify-center px-2"
      )}>
        {(!collapsed || mobile) ? (
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d388fe1d94f0723fc47a6/68c7e3d55_Screenshot_20260106_000036_Drive.jpg" 
            alt="Ultimate Social Media"
            className="w-full h-auto max-h-40 object-contain"
          />
        ) : (
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d388fe1d94f0723fc47a6/68c7e3d55_Screenshot_20260106_000036_Drive.jpg" 
            alt="Ultimate Social Media"
            className="w-16 h-16 object-contain"
          />
        )}
      </div>

      <ScrollArea className="flex-1 py-4">
        <nav className="space-y-1 px-3">
          {navigation.map((item) => {
            const isActive = currentPageName === item.page;
            return (
              <Link
                key={item.name}
                to={createPageUrl(item.page)}
                onClick={() => mobile && setMobileOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-gradient-to-r from-violet-500/20 to-fuchsia-500/20 text-white border border-violet-500/30"
                    : "text-slate-400 hover:text-white hover:bg-slate-800/50",
                  collapsed && !mobile && "justify-center px-2"
                )}
              >
                <item.icon className={cn("w-5 h-5 flex-shrink-0", isActive && "text-violet-400")} />
                {(!collapsed || mobile) && (
                  <>
                    <span className="flex-1">{item.name}</span>
                    <div className="flex items-center gap-1">
                      {item.badge && unreadCount > 0 && (
                        <Badge className="bg-rose-500 text-white text-[10px] px-1.5 py-0 min-w-[18px] h-[18px]">
                          {unreadCount > 99 ? '99+' : unreadCount}
                        </Badge>
                      )}
                      {item.tutorial && (
                        <a href={item.tutorial} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-5 w-5 text-violet-400 hover:text-violet-300"
                          >
                            <Video className="w-3 h-3" />
                          </Button>
                        </a>
                      )}
                      <HelpButton pageName={item.page} />
                    </div>
                  </>
                )}
              </Link>
            );
          })}
        </nav>
      </ScrollArea>

      {!mobile && (
        <div className="p-3 border-t border-slate-800">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCollapsed(!collapsed)}
            className="w-full justify-center text-slate-400 hover:text-white hover:bg-slate-800"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950">
      <style>{`
        :root {
          --background: 222.2 84% 4.9%;
          --foreground: 210 40% 98%;
          --card: 222.2 84% 4.9%;
          --card-foreground: 210 40% 98%;
          --popover: 222.2 84% 4.9%;
          --popover-foreground: 210 40% 98%;
          --primary: 262.1 83.3% 57.8%;
          --primary-foreground: 210 40% 98%;
          --secondary: 217.2 32.6% 17.5%;
          --secondary-foreground: 210 40% 98%;
          --muted: 217.2 32.6% 17.5%;
          --muted-foreground: 215 20.2% 65.1%;
          --accent: 217.2 32.6% 17.5%;
          --accent-foreground: 210 40% 98%;
          --destructive: 0 62.8% 30.6%;
          --destructive-foreground: 210 40% 98%;
          --border: 217.2 32.6% 17.5%;
          --input: 217.2 32.6% 17.5%;
          --ring: 262.1 83.3% 57.8%;
        }
        body {
          font-family: 'Inter', system-ui, sans-serif;
        }
      `}</style>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-slate-400">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-72 p-0 bg-slate-950 border-slate-800">
                <NavContent mobile />
              </SheetContent>
            </Sheet>
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d388fe1d94f0723fc47a6/68c7e3d55_Screenshot_20260106_000036_Drive.jpg" 
              alt="Ultimate Social Media"
              className="h-14 w-auto object-contain"
            />
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" className="text-slate-400 relative">
              <Bell className="w-5 h-5" />
              {notifications.length > 0 && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-rose-500 rounded-full" />
              )}
            </Button>
            <Avatar className="w-8 h-8">
              <AvatarImage src={user?.avatar} />
              <AvatarFallback className="bg-slate-800 text-slate-300 text-xs">
                {user?.full_name?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
      </div>

      {/* Desktop Sidebar */}
      <aside className={cn(
        "hidden lg:flex fixed left-0 top-0 bottom-0 z-40 flex-col bg-slate-950 border-r border-slate-800 transition-all duration-300",
        collapsed ? "w-[72px]" : "w-64"
      )}>
        <NavContent />
      </aside>

      {/* Main Content */}
      <main className={cn(
        "min-h-screen transition-all duration-300 pt-16 lg:pt-0",
        collapsed ? "lg:pl-[72px]" : "lg:pl-64"
      )}>
        {/* Desktop Header */}
        <header className="hidden lg:flex sticky top-0 z-30 h-20 items-center justify-center px-6 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800 relative">
          <img 
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d388fe1d94f0723fc47a6/68c7e3d55_Screenshot_20260106_000036_Drive.jpg" 
            alt="Ultimate Social Media"
            className="h-16 w-auto object-contain"
          />
          <div className="absolute right-6 flex items-center gap-3">
            <Button
              onClick={() => setAutopilotOpen(true)}
              className="bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600"
            >
              <Zap className="w-4 h-4 mr-2" />
              Autopilot
            </Button>
            <LanguageSelector />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="text-slate-400 hover:text-white relative">
                  <Bell className="w-5 h-5" />
                  {notifications.length > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full animate-pulse" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 bg-slate-900 border-slate-800">
                <div className="px-4 py-3 border-b border-slate-800">
                  <h3 className="font-semibold text-white">Notifications</h3>
                </div>
                <ScrollArea className="h-[300px]">
                  {notifications.length === 0 ? (
                    <div className="px-4 py-8 text-center text-slate-500">
                      No new notifications
                    </div>
                  ) : (
                    notifications.map((notif) => (
                      <DropdownMenuItem key={notif.id} className="px-4 py-3 cursor-pointer focus:bg-slate-800">
                        <div>
                          <p className="text-sm font-medium text-white">{notif.title}</p>
                          <p className="text-xs text-slate-400 mt-0.5">{notif.message}</p>
                        </div>
                      </DropdownMenuItem>
                    ))
                  )}
                </ScrollArea>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-3 px-2 hover:bg-slate-800">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user?.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white text-sm">
                      {user?.full_name?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left hidden xl:block">
                    <p className="text-sm font-medium text-white">{user?.full_name || 'User'}</p>
                    <p className="text-xs text-slate-400">{user?.email}</p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-slate-900 border-slate-800">
                <DropdownMenuItem asChild>
                  <Link to={createPageUrl('Settings')} className="cursor-pointer">
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-slate-800" />
                <DropdownMenuItem 
                  onClick={() => base44.auth.logout()}
                  className="text-rose-400 cursor-pointer focus:text-rose-400"
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <div className="p-4 lg:p-6">
          {children}
        </div>

        {/* Footer */}
        <footer className="border-t border-slate-800 bg-slate-950 py-6 px-6">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-slate-400">
              © 2026 Ultimate Social Media. All rights reserved.
            </div>
            <div className="flex gap-6 text-sm text-slate-400">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Contact</a>
            </div>
          </div>
        </footer>
        </main>
        <FloatingAutopilot externalOpen={autopilotOpen} onExternalOpenChange={setAutopilotOpen} />
        </div>
        );
        }
