import Layout from "./Layout.jsx";

import AIAnalyticsDashboard from "./AIAnalyticsDashboard";

import AISettings from "./AISettings";

import AdvancedAnalytics from "./AdvancedAnalytics";

import Analytics from "./Analytics";

import App from "./App";

import Automation from "./Automation";

import BrandManagement from "./BrandManagement";

import BrandMonitor from "./BrandMonitor";

import CRMDashboard from "./CRMDashboard";

import CRMTasks from "./CRMTasks";

import Calendar from "./Calendar";

import CampaignPlanner from "./CampaignPlanner";

import Chatbot from "./Chatbot";

import Competitors from "./Competitors";

import Contacts from "./Contacts";

import ContentMonetization from "./ContentMonetization";

import CreatePost from "./CreatePost";

import CreateVideo from "./CreateVideo";

import CustomerSupport from "./CustomerSupport";

import Dashboard from "./Dashboard";

import DevTools from "./DevTools";

import EmailCampaigns from "./EmailCampaigns";

import Features from "./Features";

import Goals from "./Goals";

import Hashtags from "./Hashtags";

import Home from "./Home";

import Inbox from "./Inbox";

import Index from "./Index";

import Influencers from "./Influencers";

import Landing from "./Landing";

import LandingPageBuilder from "./LandingPageBuilder";

import LinkInBio from "./LinkInBio";

import Marketplace from "./Marketplace";

import MediaLibrary from "./MediaLibrary";

import MyProducts from "./MyProducts";

import Pipeline from "./Pipeline";

import Pricing from "./Pricing";

import Reports from "./Reports";

import SellProduct from "./SellProduct";

import Settings from "./Settings";

import SmartScheduler from "./SmartScheduler";

import Strategy from "./Strategy";

import Subscriptions from "./Subscriptions";

import Support from "./Support";

import Team from "./Team";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    AIAnalyticsDashboard: AIAnalyticsDashboard,
    
    AISettings: AISettings,
    
    AdvancedAnalytics: AdvancedAnalytics,
    
    Analytics: Analytics,
    
    App: App,
    
    Automation: Automation,
    
    BrandManagement: BrandManagement,
    
    BrandMonitor: BrandMonitor,
    
    CRMDashboard: CRMDashboard,
    
    CRMTasks: CRMTasks,
    
    Calendar: Calendar,
    
    CampaignPlanner: CampaignPlanner,
    
    Chatbot: Chatbot,
    
    Competitors: Competitors,
    
    Contacts: Contacts,
    
    ContentMonetization: ContentMonetization,
    
    CreatePost: CreatePost,
    
    CreateVideo: CreateVideo,
    
    CustomerSupport: CustomerSupport,
    
    Dashboard: Dashboard,
    
    DevTools: DevTools,
    
    EmailCampaigns: EmailCampaigns,
    
    Features: Features,
    
    Goals: Goals,
    
    Hashtags: Hashtags,
    
    Home: Home,
    
    Inbox: Inbox,
    
    Index: Index,
    
    Influencers: Influencers,
    
    Landing: Landing,
    
    LandingPageBuilder: LandingPageBuilder,
    
    LinkInBio: LinkInBio,
    
    Marketplace: Marketplace,
    
    MediaLibrary: MediaLibrary,
    
    MyProducts: MyProducts,
    
    Pipeline: Pipeline,
    
    Pricing: Pricing,
    
    Reports: Reports,
    
    SellProduct: SellProduct,
    
    Settings: Settings,
    
    SmartScheduler: SmartScheduler,
    
    Strategy: Strategy,
    
    Subscriptions: Subscriptions,
    
    Support: Support,
    
    Team: Team,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<AIAnalyticsDashboard />} />
                
                
                <Route path="/AIAnalyticsDashboard" element={<AIAnalyticsDashboard />} />
                
                <Route path="/AISettings" element={<AISettings />} />
                
                <Route path="/AdvancedAnalytics" element={<AdvancedAnalytics />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/App" element={<App />} />
                
                <Route path="/Automation" element={<Automation />} />
                
                <Route path="/BrandManagement" element={<BrandManagement />} />
                
                <Route path="/BrandMonitor" element={<BrandMonitor />} />
                
                <Route path="/CRMDashboard" element={<CRMDashboard />} />
                
                <Route path="/CRMTasks" element={<CRMTasks />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/CampaignPlanner" element={<CampaignPlanner />} />
                
                <Route path="/Chatbot" element={<Chatbot />} />
                
                <Route path="/Competitors" element={<Competitors />} />
                
                <Route path="/Contacts" element={<Contacts />} />
                
                <Route path="/ContentMonetization" element={<ContentMonetization />} />
                
                <Route path="/CreatePost" element={<CreatePost />} />
                
                <Route path="/CreateVideo" element={<CreateVideo />} />
                
                <Route path="/CustomerSupport" element={<CustomerSupport />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/DevTools" element={<DevTools />} />
                
                <Route path="/EmailCampaigns" element={<EmailCampaigns />} />
                
                <Route path="/Features" element={<Features />} />
                
                <Route path="/Goals" element={<Goals />} />
                
                <Route path="/Hashtags" element={<Hashtags />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Inbox" element={<Inbox />} />
                
                <Route path="/Index" element={<Index />} />
                
                <Route path="/Influencers" element={<Influencers />} />
                
                <Route path="/Landing" element={<Landing />} />
                
                <Route path="/LandingPageBuilder" element={<LandingPageBuilder />} />
                
                <Route path="/LinkInBio" element={<LinkInBio />} />
                
                <Route path="/Marketplace" element={<Marketplace />} />
                
                <Route path="/MediaLibrary" element={<MediaLibrary />} />
                
                <Route path="/MyProducts" element={<MyProducts />} />
                
                <Route path="/Pipeline" element={<Pipeline />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/SellProduct" element={<SellProduct />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/SmartScheduler" element={<SmartScheduler />} />
                
                <Route path="/Strategy" element={<Strategy />} />
                
                <Route path="/Subscriptions" element={<Subscriptions />} />
                
                <Route path="/Support" element={<Support />} />
                
                <Route path="/Team" element={<Team />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}