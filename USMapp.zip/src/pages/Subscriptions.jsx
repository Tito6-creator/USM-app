import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Crown, Zap, Rocket, Building2 } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const plans = [
  {
    id: 'free',
    name: 'Free',
    icon: Zap,
    price: 0,
    billing: 'Forever free',
    description: 'Perfect for getting started',
    features: {
      max_accounts: 2,
      max_posts_per_month: 30,
      ai_credits: 10,
      analytics_retention_days: 30,
      team_members: 1,
      white_label: false,
      priority_support: false
    },
    highlights: [
      '2 Social Accounts',
      '30 Posts per month',
      '10 AI Credits',
      '30 Days Analytics',
      'Basic Support'
    ]
  },
  {
    id: 'starter',
    name: 'Starter',
    icon: Crown,
    price: 29,
    billing: 'per month',
    description: 'For growing creators',
    popular: true,
    features: {
      max_accounts: 10,
      max_posts_per_month: 200,
      ai_credits: 100,
      analytics_retention_days: 90,
      team_members: 3,
      white_label: false,
      priority_support: false
    },
    highlights: [
      '10 Social Accounts',
      '200 Posts per month',
      '100 AI Credits',
      '90 Days Analytics',
      '3 Team Members',
      'Advanced Scheduling',
      'Competitor Analysis'
    ]
  },
  {
    id: 'professional',
    name: 'Professional',
    icon: Rocket,
    price: 79,
    billing: 'per month',
    description: 'For professional marketers',
    features: {
      max_accounts: 25,
      max_posts_per_month: 1000,
      ai_credits: 500,
      analytics_retention_days: 365,
      team_members: 10,
      white_label: true,
      priority_support: true
    },
    highlights: [
      '25 Social Accounts',
      'Unlimited Posts',
      '500 AI Credits',
      '1 Year Analytics',
      '10 Team Members',
      'White Label Reports',
      'Priority Support',
      'Custom Integrations',
      'Advanced Analytics'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    icon: Building2,
    price: 199,
    billing: 'per month',
    description: 'For agencies and teams',
    features: {
      max_accounts: 100,
      max_posts_per_month: -1,
      ai_credits: 2000,
      analytics_retention_days: -1,
      team_members: -1,
      white_label: true,
      priority_support: true
    },
    highlights: [
      'Unlimited Accounts',
      'Unlimited Posts',
      '2000 AI Credits',
      'Unlimited Analytics',
      'Unlimited Team Members',
      'White Label Everything',
      'Dedicated Support',
      'Custom Development',
      'SLA Guarantee',
      'Training Sessions'
    ]
  }
];

export default function Subscriptions() {
  const queryClient = useQueryClient();
  const [billingCycle, setBillingCycle] = useState('monthly');

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me()
  });

  const { data: subscription } = useQuery({
    queryKey: ['subscription', user?.email],
    queryFn: () => base44.entities.Subscription.filter({ user_email: user?.email }).then(subs => subs[0]),
    enabled: !!user
  });

  const createSubscriptionMutation = useMutation({
    mutationFn: async (plan) => {
      // In real implementation, this would create a Stripe checkout session
      const newSub = await base44.entities.Subscription.create({
        user_email: user.email,
        plan: plan.id,
        status: 'active',
        billing_cycle: billingCycle,
        features: plan.features,
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
      });
      return newSub;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      toast.success('Subscription activated!');
    }
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      return base44.entities.Subscription.update(subscription.id, {
        cancel_at_period_end: true
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subscription'] });
      toast.success('Subscription will be cancelled at period end');
    }
  });

  const currentPlan = subscription?.plan || 'free';

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-white mb-2">Choose Your Plan</h1>
        <p className="text-slate-400">Scale your social media management with the right plan</p>
      </div>

      {/* Billing Toggle */}
      <div className="flex items-center justify-center gap-4">
        <button
          onClick={() => setBillingCycle('monthly')}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
            billingCycle === 'monthly' 
              ? "bg-violet-600 text-white" 
              : "bg-slate-800 text-slate-400 hover:text-white"
          )}
        >
          Monthly
        </button>
        <button
          onClick={() => setBillingCycle('yearly')}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-medium transition-colors relative",
            billingCycle === 'yearly' 
              ? "bg-violet-600 text-white" 
              : "bg-slate-800 text-slate-400 hover:text-white"
          )}
        >
          Yearly
          <Badge className="absolute -top-2 -right-2 bg-emerald-500 text-white text-xs">
            Save 20%
          </Badge>
        </button>
      </div>

      {/* Current Subscription Info */}
      {subscription && (
        <Card className="p-4 bg-gradient-to-r from-violet-500/10 to-fuchsia-500/10 border-violet-500/20">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-semibold">Current Plan: {subscription.plan}</p>
              <p className="text-sm text-slate-400">
                {subscription.cancel_at_period_end 
                  ? 'Cancels at period end' 
                  : `Renews on ${new Date(subscription.current_period_end).toLocaleDateString()}`}
              </p>
            </div>
            {!subscription.cancel_at_period_end && subscription.plan !== 'free' && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => cancelSubscriptionMutation.mutate()}
                className="border-slate-700"
              >
                Cancel Plan
              </Button>
            )}
          </div>
        </Card>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map(plan => {
          const Icon = plan.icon;
          const price = billingCycle === 'yearly' ? Math.floor(plan.price * 0.8) : plan.price;
          const isCurrentPlan = currentPlan === plan.id;
          
          return (
            <Card
              key={plan.id}
              className={cn(
                "relative overflow-hidden bg-slate-900/50 border-slate-800 transition-all",
                plan.popular && "border-violet-500 shadow-lg shadow-violet-500/20",
                isCurrentPlan && "border-emerald-500"
              )}
            >
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs text-center py-1 font-medium">
                  Most Popular
                </div>
              )}
              
              <div className={cn("p-6", plan.popular && "pt-10")}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-violet-500/20 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-violet-400" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{plan.name}</h3>
                    <p className="text-xs text-slate-400">{plan.description}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-white">${price}</span>
                    <span className="text-slate-400 text-sm">/{plan.billing}</span>
                  </div>
                  {billingCycle === 'yearly' && plan.price > 0 && (
                    <p className="text-xs text-emerald-400 mt-1">
                      Save ${(plan.price * 12) - (price * 12)}/year
                    </p>
                  )}
                </div>
                
                <div className="space-y-2 mb-6">
                  {plan.highlights.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-slate-300">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <Button
                  className={cn(
                    "w-full",
                    isCurrentPlan 
                      ? "bg-slate-700 cursor-not-allowed" 
                      : plan.popular 
                        ? "bg-gradient-to-r from-violet-600 to-fuchsia-600"
                        : "bg-slate-800 hover:bg-slate-700"
                  )}
                  disabled={isCurrentPlan || createSubscriptionMutation.isPending}
                  onClick={() => createSubscriptionMutation.mutate(plan)}
                >
                  {isCurrentPlan ? 'Current Plan' : plan.price === 0 ? 'Get Started' : 'Upgrade Now'}
                </Button>
              </div>
            </Card>
          );
        })}
      </div>

      {/* Features Comparison */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-xl font-bold text-white mb-4">Compare Features</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="text-left py-3 text-sm font-medium text-slate-400">Feature</th>
                {plans.map(plan => (
                  <th key={plan.id} className="text-center py-3 text-sm font-medium text-slate-400">
                    {plan.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-800">
                <td className="py-3 text-sm text-slate-300">Social Accounts</td>
                {plans.map(plan => (
                  <td key={plan.id} className="text-center py-3 text-sm text-white">
                    {plan.features.max_accounts === -1 ? '∞' : plan.features.max_accounts}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 text-sm text-slate-300">Posts per Month</td>
                {plans.map(plan => (
                  <td key={plan.id} className="text-center py-3 text-sm text-white">
                    {plan.features.max_posts_per_month === -1 ? '∞' : plan.features.max_posts_per_month}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 text-sm text-slate-300">AI Credits</td>
                {plans.map(plan => (
                  <td key={plan.id} className="text-center py-3 text-sm text-white">
                    {plan.features.ai_credits}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 text-sm text-slate-300">Team Members</td>
                {plans.map(plan => (
                  <td key={plan.id} className="text-center py-3 text-sm text-white">
                    {plan.features.team_members === -1 ? '∞' : plan.features.team_members}
                  </td>
                ))}
              </tr>
              <tr className="border-b border-slate-800">
                <td className="py-3 text-sm text-slate-300">White Label</td>
                {plans.map(plan => (
                  <td key={plan.id} className="text-center py-3">
                    {plan.features.white_label ? (
                      <Check className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-3 text-sm text-slate-300">Priority Support</td>
                {plans.map(plan => (
                  <td key={plan.id} className="text-center py-3">
                    {plan.features.priority_support ? (
                      <Check className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}