import React from 'react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Ticket, MessageSquare, BookOpen } from 'lucide-react';
import SupportTicketSystem from '@/components/support/SupportTicketSystem';
import AutoResponseManager from '@/components/inbox/AutoResponseManager';

export default function Support() {
  return (
    <div className="max-w-[1800px] mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Customer Support</h1>
        <p className="text-slate-400 mt-1">Manage support tickets, templates, and customer communication</p>
      </div>

      <Tabs defaultValue="tickets" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="tickets" className="data-[state=active]:bg-violet-600">
            <Ticket className="w-4 h-4 mr-2" />
            Support Tickets
          </TabsTrigger>
          <TabsTrigger value="templates" className="data-[state=active]:bg-violet-600">
            <MessageSquare className="w-4 h-4 mr-2" />
            Response Templates
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tickets">
          <SupportTicketSystem />
        </TabsContent>

        <TabsContent value="templates">
          <AutoResponseManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}