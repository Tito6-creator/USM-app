import React, { useState } from 'react';
import TaskManager from '@/components/team/TaskManager';
import AuditLog from '@/components/team/AuditLog';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Users, Mail, Shield, UserPlus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';

export default function Team() {
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('user');

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['team'],
    queryFn: () => base44.entities.User.list(),
  });

  const handleInvite = async () => {
    try {
      await base44.users.inviteUser(inviteEmail, inviteRole);
      toast.success('Invitation sent');
      setIsInviteOpen(false);
      setInviteEmail('');
      setInviteRole('user');
    } catch (error) {
      toast.error('Failed to send invitation');
    }
  };

  const roleColors = {
    admin: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
    user: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  };

  return (
    <div className="space-y-6">
      {/* Task Management */}
      <TaskManager />
      
      {/* Audit Log */}
      <AuditLog />
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Team Management</h1>
          <p className="text-slate-400 mt-1">Manage team members and permissions</p>
        </div>
        <Button
          onClick={() => setIsInviteOpen(true)}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          <UserPlus className="w-4 h-4 mr-2" />
          Invite Member
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{teamMembers.length}</p>
              <p className="text-sm text-slate-400">Team Members</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Shield className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">
                {teamMembers.filter(m => m.role === 'admin').length}
              </p>
              <p className="text-sm text-slate-400">Admins</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">
                {teamMembers.filter(m => m.role === 'user').length}
              </p>
              <p className="text-sm text-slate-400">Members</p>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800/50 border-b border-slate-800">
              <tr>
                <th className="text-left p-4 text-sm font-medium text-slate-400">Member</th>
                <th className="text-left p-4 text-sm font-medium text-slate-400">Email</th>
                <th className="text-left p-4 text-sm font-medium text-slate-400">Role</th>
                <th className="text-left p-4 text-sm font-medium text-slate-400">Joined</th>
              </tr>
            </thead>
            <tbody>
              {teamMembers.map((member) => (
                <tr key={member.id} className="border-b border-slate-800 hover:bg-slate-800/30 transition-colors">
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={member.avatar} />
                        <AvatarFallback className="bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white">
                          {member.full_name?.charAt(0) || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-white font-medium">{member.full_name || 'User'}</span>
                    </div>
                  </td>
                  <td className="p-4 text-slate-400">{member.email}</td>
                  <td className="p-4">
                    <Badge className={roleColors[member.role] || roleColors.user}>
                      {member.role}
                    </Badge>
                  </td>
                  <td className="p-4 text-slate-400">
                    {member.created_date && new Date(member.created_date).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {teamMembers.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            <Users className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p>No team members yet</p>
          </div>
        )}
      </div>

      <Dialog open={isInviteOpen} onOpenChange={setIsInviteOpen}>
        <DialogContent className="bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">Invite Team Member</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-white mb-2 block">Email Address</Label>
              <Input
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="colleague@example.com"
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">Role</Label>
              <Select value={inviteRole} onValueChange={setInviteRole}>
                <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="user">Member</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setIsInviteOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleInvite} className="bg-violet-600">
                <Mail className="w-4 h-4 mr-2" />
                Send Invitation
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}