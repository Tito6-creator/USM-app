import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Zap,
  Plus,
  Play,
  Pause,
  Trash2,
  Edit,
  TrendingUp,
  Heart,
  UserPlus,
  MessageCircle,
  Mail,
  Clock,
  Target,
  BarChart3,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const triggerIcons = {
  new_follower: UserPlus,
  new_comment: MessageCircle,
  new_mention: Target,
  new_dm: Mail,
  scheduled_time: Clock,
  engagement_threshold: TrendingUp,
  sentiment_negative: AlertCircle,
  keyword_detected: Target
};

const actionIcons = {
  send_message: MessageCircle,
  like_post: Heart,
  follow_user: UserPlus,
  create_post: Edit,
  send_email: Mail,
  add_to_list: Plus,
  create_lead: Target,
  trigger_workflow: Zap
};

export default function Automation() {
  const [isCreating, setIsCreating] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [newRule, setNewRule] = useState({
    name: '',
    description: '',
    trigger_type: 'new_follower',
    trigger_conditions: {},
    action_type: 'send_message',
    action_config: { ai_personalize: true },
    is_active: true
  });

  const queryClient = useQueryClient();

  const { data: rules = [] } = useQuery({
    queryKey: ['automationRules'],
    queryFn: () => base44.entities.AutomationRule.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.AutomationRule.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automationRules'] });
      setIsCreating(false);
      setNewRule({
        name: '',
        description: '',
        trigger_type: 'new_follower',
        trigger_conditions: {},
        action_type: 'send_message',
        action_config: { ai_personalize: true },
        is_active: true
      });
      toast.success('Automation rule created!');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.AutomationRule.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automationRules'] });
      toast.success('Rule updated');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.AutomationRule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['automationRules'] });
      toast.success('Rule deleted');
    },
  });

  const toggleRule = (rule) => {
    updateMutation.mutate({
      id: rule.id,
      data: { is_active: !rule.is_active }
    });
  };

  const activeRules = rules.filter(r => r.is_active);
  const totalExecutions = rules.reduce((sum, r) => sum + (r.execution_count || 0), 0);
  const avgSuccessRate = rules.length > 0
    ? rules.reduce((sum, r) => sum + (r.success_rate || 0), 0) / rules.length
    : 0;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Automation Suite</h1>
          <p className="text-slate-400 mt-1">Automate your social media workflows</p>
        </div>
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
              <Plus className="w-4 h-4 mr-2" />
              Create Rule
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
            <DialogHeader>
              <DialogTitle className="text-white">Create Automation Rule</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <Label className="text-white">Rule Name</Label>
                <Input
                  value={newRule.name}
                  onChange={(e) => setNewRule({ ...newRule, name: e.target.value })}
                  placeholder="e.g., Auto-respond to new followers"
                  className="bg-slate-800 border-slate-700 text-white mt-2"
                />
              </div>

              <div>
                <Label className="text-white">Description</Label>
                <Textarea
                  value={newRule.description}
                  onChange={(e) => setNewRule({ ...newRule, description: e.target.value })}
                  placeholder="What does this rule do?"
                  className="bg-slate-800 border-slate-700 text-white mt-2"
                />
              </div>

              <div>
                <Label className="text-white">Trigger</Label>
                <Select value={newRule.trigger_type} onValueChange={(value) => setNewRule({ ...newRule, trigger_type: value })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    <SelectItem value="new_follower">New Follower</SelectItem>
                    <SelectItem value="new_comment">New Comment</SelectItem>
                    <SelectItem value="new_mention">New Mention</SelectItem>
                    <SelectItem value="new_dm">New Direct Message</SelectItem>
                    <SelectItem value="scheduled_time">Scheduled Time</SelectItem>
                    <SelectItem value="engagement_threshold">Engagement Threshold</SelectItem>
                    <SelectItem value="sentiment_negative">Negative Sentiment</SelectItem>
                    <SelectItem value="keyword_detected">Keyword Detected</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-white">Action</Label>
                <Select value={newRule.action_type} onValueChange={(value) => setNewRule({ ...newRule, action_type: value })}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    <SelectItem value="send_message">Send Message</SelectItem>
                    <SelectItem value="like_post">Like Post</SelectItem>
                    <SelectItem value="follow_user">Follow User</SelectItem>
                    <SelectItem value="create_post">Create Post</SelectItem>
                    <SelectItem value="send_email">Send Email</SelectItem>
                    <SelectItem value="add_to_list">Add to List</SelectItem>
                    <SelectItem value="create_lead">Create Lead</SelectItem>
                    <SelectItem value="trigger_workflow">Trigger Workflow</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {(newRule.action_type === 'send_message' || newRule.action_type === 'send_email') && (
                <div>
                  <Label className="text-white">Message Template</Label>
                  <Textarea
                    value={newRule.action_config.message_template || ''}
                    onChange={(e) => setNewRule({
                      ...newRule,
                      action_config: { ...newRule.action_config, message_template: e.target.value }
                    })}
                    placeholder="Thank you for following! 🎉"
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
              )}

              <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
                <div>
                  <Label className="text-white">AI Personalization</Label>
                  <p className="text-xs text-slate-400 mt-1">Let AI customize messages for each user</p>
                </div>
                <Switch
                  checked={newRule.action_config.ai_personalize}
                  onCheckedChange={(checked) => setNewRule({
                    ...newRule,
                    action_config: { ...newRule.action_config, ai_personalize: checked }
                  })}
                />
              </div>

              <Button
                onClick={() => createMutation.mutate(newRule)}
                disabled={!newRule.name || createMutation.isPending}
                className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
              >
                {createMutation.isPending ? (
                  <>
                    <Zap className="w-4 h-4 mr-2 animate-pulse" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Create Automation
                  </>
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Active Rules</p>
              <p className="text-3xl font-bold text-white mt-1">{activeRules.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Zap className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Executions</p>
              <p className="text-3xl font-bold text-white mt-1">{totalExecutions}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Success Rate</p>
              <p className="text-3xl font-bold text-white mt-1">{avgSuccessRate.toFixed(1)}%</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Rules List */}
      <div className="space-y-4">
        {rules.length === 0 ? (
          <div className="text-center py-12 rounded-2xl bg-slate-900/50 border border-slate-800/50">
            <Zap className="w-16 h-16 mx-auto text-slate-600 mb-4" />
            <p className="text-slate-400">No automation rules yet</p>
            <p className="text-sm text-slate-500 mt-1">Create your first rule to automate workflows</p>
          </div>
        ) : (
          rules.map((rule) => {
            const TriggerIcon = triggerIcons[rule.trigger_type] || Zap;
            const ActionIcon = actionIcons[rule.action_type] || Zap;

            return (
              <div key={rule.id} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 hover:border-violet-500/50 transition-colors">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center",
                      rule.is_active ? "bg-violet-500/10" : "bg-slate-800"
                    )}>
                      <TriggerIcon className={cn(
                        "w-6 h-6",
                        rule.is_active ? "text-violet-400" : "text-slate-500"
                      )} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="font-semibold text-white">{rule.name}</h3>
                        <Badge className={cn(
                          rule.is_active 
                            ? "bg-emerald-500/10 text-emerald-400"
                            : "bg-slate-500/10 text-slate-400"
                        )}>
                          {rule.is_active ? 'Active' : 'Paused'}
                        </Badge>
                        {rule.action_config?.ai_personalize && (
                          <Badge className="bg-fuchsia-500/10 text-fuchsia-400">
                            AI Powered
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-400 mb-3">{rule.description}</p>
                      <div className="flex items-center gap-4 text-xs text-slate-500">
                        <div className="flex items-center gap-1">
                          <TriggerIcon className="w-3 h-3" />
                          <span className="capitalize">{rule.trigger_type.replace('_', ' ')}</span>
                        </div>
                        <span>→</span>
                        <div className="flex items-center gap-1">
                          <ActionIcon className="w-3 h-3" />
                          <span className="capitalize">{rule.action_type.replace('_', ' ')}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="text-right mr-4">
                      <p className="text-lg font-semibold text-white">{rule.execution_count || 0}</p>
                      <p className="text-xs text-slate-500">executions</p>
                      {rule.success_rate && (
                        <p className="text-xs text-emerald-400 mt-1">{rule.success_rate}% success</p>
                      )}
                    </div>

                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleRule(rule)}
                      className={cn(
                        rule.is_active
                          ? "text-amber-400 hover:text-amber-300"
                          : "text-emerald-400 hover:text-emerald-300"
                      )}
                    >
                      {rule.is_active ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </Button>

                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteMutation.mutate(rule.id)}
                      className="text-rose-400 hover:text-rose-300"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}