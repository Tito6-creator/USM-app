import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DollarSign, TrendingUp, Eye, Users, Plus } from 'lucide-react';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function ContentMonetization() {
  const queryClient = useQueryClient();
  const [showAddRevenue, setShowAddRevenue] = useState(false);
  const [selectedPost, setSelectedPost] = useState(null);
  const [newRevenue, setNewRevenue] = useState({
    monetization_type: 'ad_revenue',
    revenue: '',
    views: '',
    sponsor_name: '',
    sponsor_amount: ''
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.filter({ status: 'published' }, '-published_time')
  });

  const { data: monetization = [] } = useQuery({
    queryKey: ['monetization'],
    queryFn: () => base44.entities.ContentMonetization.list('-created_date')
  });

  const createRevenueMutation = useMutation({
    mutationFn: (data) => base44.entities.ContentMonetization.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monetization'] });
      toast.success('Revenue tracked');
      setShowAddRevenue(false);
      setNewRevenue({
        monetization_type: 'ad_revenue',
        revenue: '',
        views: '',
        sponsor_name: '',
        sponsor_amount: ''
      });
    }
  });

  const totalRevenue = monetization.reduce((sum, m) => sum + (m.revenue || 0), 0);
  const totalViews = monetization.reduce((sum, m) => sum + (m.views || 0), 0);
  const avgCPM = totalViews > 0 ? (totalRevenue / totalViews) * 1000 : 0;

  const revenueByType = monetization.reduce((acc, m) => {
    acc[m.monetization_type] = (acc[m.monetization_type] || 0) + m.revenue;
    return acc;
  }, {});

  const revenueByPlatform = monetization.reduce((acc, m) => {
    acc[m.platform] = (acc[m.platform] || 0) + m.revenue;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Content Monetization</h1>
          <p className="text-slate-400 mt-1">Track and optimize your content revenue</p>
        </div>
        <Button 
          onClick={() => setShowAddRevenue(true)}
          className="bg-gradient-to-r from-emerald-600 to-teal-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Revenue
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">${totalRevenue.toFixed(2)}</p>
              <p className="text-xs text-slate-400">Total Revenue</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <Eye className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalViews.toLocaleString()}</p>
              <p className="text-xs text-slate-400">Total Views</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-violet-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">${avgCPM.toFixed(2)}</p>
              <p className="text-xs text-slate-400">Avg CPM</p>
            </div>
          </div>
        </Card>

        <Card className="p-5 bg-slate-900/50 border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{monetization.length}</p>
              <p className="text-xs text-slate-400">Monetized Posts</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue by Type */}
        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-4">Revenue by Type</h3>
          <div className="space-y-3">
            {Object.entries(revenueByType).map(([type, revenue]) => (
              <div key={type} className="flex items-center justify-between">
                <span className="text-sm text-slate-300 capitalize">{type.replace('_', ' ')}</span>
                <span className="text-sm font-semibold text-white">${revenue.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Revenue by Platform */}
        <Card className="p-6 bg-slate-900/50 border-slate-800">
          <h3 className="text-lg font-semibold text-white mb-4">Revenue by Platform</h3>
          <div className="space-y-3">
            {Object.entries(revenueByPlatform).map(([platform, revenue]) => (
              <div key={platform} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <PlatformIcon platform={platform} size="sm" />
                  <span className="text-sm text-slate-300 capitalize">{platform}</span>
                </div>
                <span className="text-sm font-semibold text-white">${revenue.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recent Monetization */}
      <Card className="p-6 bg-slate-900/50 border-slate-800">
        <h3 className="text-lg font-semibold text-white mb-4">Recent Revenue</h3>
        <div className="space-y-2">
          {monetization.slice(0, 10).map(item => {
            const post = posts.find(p => p.id === item.post_id);
            
            return (
              <div key={item.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                <div className="flex-1">
                  <p className="text-sm text-white font-medium line-clamp-1">
                    {post?.content || 'Post not found'}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <PlatformIcon platform={item.platform} size="xs" />
                    <Badge variant="outline" className="text-xs border-slate-700">
                      {item.monetization_type.replace('_', ' ')}
                    </Badge>
                    {item.sponsor_name && (
                      <span className="text-xs text-slate-400">• {item.sponsor_name}</span>
                    )}
                  </div>
                </div>
                <div className="text-right ml-4">
                  <p className="text-lg font-bold text-emerald-400">${item.revenue}</p>
                  {item.views > 0 && (
                    <p className="text-xs text-slate-500">{item.views.toLocaleString()} views</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Add Revenue Dialog */}
      <Dialog open={showAddRevenue} onOpenChange={setShowAddRevenue}>
        <DialogContent className="bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">Track Revenue</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Select 
              value={selectedPost?.id || ''} 
              onValueChange={(id) => setSelectedPost(posts.find(p => p.id === id))}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue placeholder="Select post" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                {posts.map(post => (
                  <SelectItem key={post.id} value={post.id}>
                    {post.content?.substring(0, 50)}...
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select 
              value={newRevenue.monetization_type} 
              onValueChange={(v) => setNewRevenue({ ...newRevenue, monetization_type: v })}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                <SelectItem value="ad_revenue">Ad Revenue</SelectItem>
                <SelectItem value="sponsorship">Sponsorship</SelectItem>
                <SelectItem value="affiliate">Affiliate</SelectItem>
                <SelectItem value="brand_deal">Brand Deal</SelectItem>
                <SelectItem value="tips">Tips</SelectItem>
              </SelectContent>
            </Select>

            <Input
              type="number"
              placeholder="Revenue amount"
              value={newRevenue.revenue}
              onChange={(e) => setNewRevenue({ ...newRevenue, revenue: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />

            <Input
              type="number"
              placeholder="Views (optional)"
              value={newRevenue.views}
              onChange={(e) => setNewRevenue({ ...newRevenue, views: e.target.value })}
              className="bg-slate-800 border-slate-700 text-white"
            />

            {(newRevenue.monetization_type === 'sponsorship' || newRevenue.monetization_type === 'brand_deal') && (
              <Input
                placeholder="Sponsor name"
                value={newRevenue.sponsor_name}
                onChange={(e) => setNewRevenue({ ...newRevenue, sponsor_name: e.target.value })}
                className="bg-slate-800 border-slate-700 text-white"
              />
            )}

            <Button
              onClick={() => {
                if (!selectedPost || !newRevenue.revenue) {
                  toast.error('Please fill required fields');
                  return;
                }
                
                createRevenueMutation.mutate({
                  post_id: selectedPost.id,
                  platform: selectedPost.platforms[0],
                  monetization_type: newRevenue.monetization_type,
                  revenue: parseFloat(newRevenue.revenue),
                  views: newRevenue.views ? parseInt(newRevenue.views) : 0,
                  sponsor_name: newRevenue.sponsor_name,
                  cpm: newRevenue.views ? (parseFloat(newRevenue.revenue) / parseInt(newRevenue.views)) * 1000 : 0,
                  payment_status: 'paid'
                });
              }}
              className="w-full bg-emerald-600"
            >
              Add Revenue
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}