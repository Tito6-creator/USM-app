import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Brain,
  Save,
  Sparkles,
  Volume2,
  TrendingUp,
  Zap,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';

export default function AISettings() {
  const queryClient = useQueryClient();
  const [settings, setSettings] = useState(null);

  const { data: existingSettings, isLoading } = useQuery({
    queryKey: ['aiSettings'],
    queryFn: async () => {
      const settings = await base44.entities.AISettings.list('-created_date', 1);
      return settings[0] || null;
    },
    retry: 1,
    staleTime: 60000,
  });

  useEffect(() => {
    if (existingSettings) {
      setSettings(existingSettings);
    } else {
      setSettings({
        personality: 'friendly',
        voice_tone: 'warm',
        response_style: 'balanced',
        name: 'AI Assistant',
        expertise_focus: ['social_media', 'marketing', 'content_creation'],
        learning_enabled: true,
        voice_enabled: true,
        voice_speed: 1.0,
        voice_pitch: 1.0,
        auto_actions_enabled: false
      });
    }
  }, [existingSettings]);

  const saveMutation = useMutation({
    mutationFn: (data) => {
      if (existingSettings?.id) {
        return base44.entities.AISettings.update(existingSettings.id, data);
      } else {
        return base44.entities.AISettings.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['aiSettings'] });
      toast.success('AI settings saved!');
    },
  });

  if (isLoading || !settings) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-violet-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-400">Loading AI settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">AI Customization</h1>
        <p className="text-slate-400 mt-1">Personalize your AI assistant's behavior and personality</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Interactions</p>
              <p className="text-3xl font-bold text-white mt-1">{existingSettings?.interaction_count || 0}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Brain className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Successful Tasks</p>
              <p className="text-3xl font-bold text-white mt-1">{existingSettings?.successful_recommendations || 0}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Award className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Learning Status</p>
              <p className="text-3xl font-bold text-white mt-1">{settings.learning_enabled ? 'Active' : 'Paused'}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Settings Form */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-violet-400" />
            Personality & Style
          </h3>

          <div className="space-y-4">
            <div>
              <Label className="text-white">Assistant Name</Label>
              <Input
                value={settings.name}
                onChange={(e) => setSettings({ ...settings, name: e.target.value })}
                placeholder="AI Assistant"
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>

            <div>
              <Label className="text-white">Personality</Label>
              <Select value={settings.personality} onValueChange={(value) => setSettings({ ...settings, personality: value })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="professional">Professional - Business-focused and formal</SelectItem>
                  <SelectItem value="friendly">Friendly - Warm and approachable</SelectItem>
                  <SelectItem value="casual">Casual - Relaxed and conversational</SelectItem>
                  <SelectItem value="enthusiastic">Enthusiastic - Energetic and motivating</SelectItem>
                  <SelectItem value="witty">Witty - Humorous and clever</SelectItem>
                  <SelectItem value="formal">Formal - Strictly professional</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white">Voice Tone</Label>
              <Select value={settings.voice_tone} onValueChange={(value) => setSettings({ ...settings, voice_tone: value })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="warm">Warm - Friendly and welcoming</SelectItem>
                  <SelectItem value="neutral">Neutral - Balanced and objective</SelectItem>
                  <SelectItem value="energetic">Energetic - Dynamic and exciting</SelectItem>
                  <SelectItem value="calm">Calm - Soothing and measured</SelectItem>
                  <SelectItem value="authoritative">Authoritative - Confident and expert</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white">Response Style</Label>
              <Select value={settings.response_style} onValueChange={(value) => setSettings({ ...settings, response_style: value })}>
                <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="concise">Concise - Brief and to the point</SelectItem>
                  <SelectItem value="detailed">Detailed - Comprehensive and thorough</SelectItem>
                  <SelectItem value="balanced">Balanced - Mix of detail and brevity</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-fuchsia-400" />
            Voice Settings
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
              <div>
                <Label className="text-white">Voice Enabled</Label>
                <p className="text-xs text-slate-400 mt-1">Allow AI to speak responses</p>
              </div>
              <Switch
                checked={settings.voice_enabled}
                onCheckedChange={(checked) => setSettings({ ...settings, voice_enabled: checked })}
              />
            </div>

            {settings.voice_enabled && (
              <>
                <div>
                  <Label className="text-white">Speech Speed: {settings.voice_speed}x</Label>
                  <Slider
                    value={[settings.voice_speed]}
                    onValueChange={([value]) => setSettings({ ...settings, voice_speed: value })}
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    className="mt-2"
                  />
                </div>

                <div>
                  <Label className="text-white">Voice Pitch: {settings.voice_pitch}x</Label>
                  <Slider
                    value={[settings.voice_pitch]}
                    onValueChange={([value]) => setSettings({ ...settings, voice_pitch: value })}
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    className="mt-2"
                  />
                </div>
              </>
            )}
          </div>
        </div>

        <div className="border-t border-slate-800 pt-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Brain className="w-5 h-5 text-emerald-400" />
            Learning & Intelligence
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
              <div>
                <Label className="text-white">AI Learning Enabled</Label>
                <p className="text-xs text-slate-400 mt-1">AI learns from your interactions and improves over time</p>
              </div>
              <Switch
                checked={settings.learning_enabled}
                onCheckedChange={(checked) => setSettings({ ...settings, learning_enabled: checked })}
              />
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-slate-800/50">
              <div>
                <Label className="text-white">Auto-Actions</Label>
                <p className="text-xs text-slate-400 mt-1">Allow AI to perform actions automatically when confident</p>
              </div>
              <Switch
                checked={settings.auto_actions_enabled}
                onCheckedChange={(checked) => setSettings({ ...settings, auto_actions_enabled: checked })}
              />
            </div>
          </div>
        </div>

        <Button
          onClick={() => saveMutation.mutate(settings)}
          disabled={saveMutation.isPending}
          className="w-full bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          <Save className="w-4 h-4 mr-2" />
          {saveMutation.isPending ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  );
}