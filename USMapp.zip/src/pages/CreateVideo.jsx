import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Video, Loader2, Sparkles, Wand2, Download } from 'lucide-react';
import { toast } from 'sonner';

export default function CreateVideo() {
  const [platform, setPlatform] = useState('');
  const [goal, setGoal] = useState('');
  const [productName, setProductName] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState('15');
  const [voiceGender, setVoiceGender] = useState('female');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [script, setScript] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoDetails, setVideoDetails] = useState(null);
  const [generationError, setGenerationError] = useState('');

  const generateScript = async () => {
    if (!productName || !goal) {
      toast.error('Please enter product name and goal');
      return;
    }

    setIsGeneratingScript(true);
    setScript(''); // Clear old script
    toast.info('🤖 AI is writing your video script...');
    
    try {
      console.log('[SCRIPT GEN] Starting script generation...');
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a compelling ${duration}-second video script for ${platform || 'social media'}.

Product: ${productName}
Description: ${description || 'N/A'}
Goal: ${goal}

Generate a punchy, engaging script with:
- Hook (first 2 seconds)
- Problem/Solution
- Key benefits
- Call to action
Keep it conversational and platform-appropriate. Maximum ${duration} seconds of narration.`,
        add_context_from_internet: false
      });

      console.log('[SCRIPT GEN] Response:', response);
      
      if (response && typeof response === 'string' && response.trim().length > 0) {
        setScript(response);
        toast.success('✅ Script generated! Now click "Generate Video"');
      } else {
        throw new Error('No valid script received from AI');
      }
    } catch (error) {
      console.error('[SCRIPT GEN] Error:', error);
      toast.error('❌ Failed to generate script: ' + error.message);
      setScript(''); // Reset on error
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleGenerateVideo = async () => {
    if (!script) {
      toast.error('Please generate a script first');
      return;
    }

    setIsGenerating(true);
    setVideoUrl('');
    setVideoDetails(null);
    setGenerationError('');
    
    const loadingToast = toast.loading('🎬 Generating video with AI voiceover... This takes 30-60 seconds', {
      duration: 90000
    });

    try {
      console.log('[VIDEO GEN] Starting video generation...');
      console.log('[VIDEO GEN] Parameters:', {
        script,
        platform: platform || 'instagram',
        goal,
        productName,
        duration: parseInt(duration),
        voiceGender
      });

      const response = await base44.functions.invoke('generatePromoVideo', {
        script,
        platform: platform || 'instagram',
        goal,
        productName,
        duration: parseInt(duration),
        voiceGender
      });
      
      console.log('[VIDEO GEN] Response received:', response);
      
      if (response.data && response.data.success) {
        console.log('[VIDEO GEN] Success! Video URL:', response.data.videoUrl);
        setVideoUrl(response.data.videoUrl);
        setVideoDetails(response.data.details);
        toast.dismiss(loadingToast);
        toast.success('✅ Video generated! Scrolling to preview...', { duration: 5000 });
        
        // Scroll to video preview after a short delay
        setTimeout(() => {
          const videoPreview = document.getElementById('video-preview-section');
          if (videoPreview) {
            videoPreview.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }, 500);
      } else {
        console.error('[VIDEO GEN] Generation failed:', response.data);
        toast.dismiss(loadingToast);
        const errorMsg = response.data?.error || 'Unknown error';
        setGenerationError(errorMsg);
        toast.error('❌ Video generation failed: ' + errorMsg, { duration: 8000 });
      }
    } catch (error) {
      console.error('[VIDEO GEN] Exception caught:', error);
      toast.dismiss(loadingToast);
      const errorMsg = error.response?.data?.error || error.message || 'Something went wrong';
      setGenerationError(errorMsg);
      toast.error('❌ Error: ' + errorMsg, { duration: 8000 });
    } finally {
      console.log('[VIDEO GEN] Process completed, resetting state');
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white flex items-center gap-3">
          <Video className="w-8 h-8 text-violet-400" />
          AI Video Generator
        </h1>
        <p className="text-slate-400 mt-2">Create professional promo videos with AI-generated scripts and voiceovers</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Configuration */}
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-violet-400" />
              Video Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label className="text-white">Product/Service Name</Label>
              <Input
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g., Ultimate CRM Pro"
                className="bg-slate-800 border-slate-700 text-white mt-2"
              />
            </div>

            <div>
              <Label className="text-white">Description (Optional)</Label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Brief description to help AI understand your product..."
                className="bg-slate-800 border-slate-700 text-white mt-2 min-h-[80px]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white">Platform</Label>
                <Select value={platform} onValueChange={setPlatform}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                    <SelectValue placeholder="Select platform" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="youtube">YouTube</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-white">Goal</Label>
                <Select value={goal} onValueChange={setGoal}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                    <SelectValue placeholder="Select goal" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="promo">Product Promo</SelectItem>
                    <SelectItem value="education">Educational</SelectItem>
                    <SelectItem value="testimonial">Testimonial</SelectItem>
                    <SelectItem value="announcement">Announcement</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white">Duration</Label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="15">15 seconds</SelectItem>
                    <SelectItem value="30">30 seconds</SelectItem>
                    <SelectItem value="60">60 seconds</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-white">Voice Gender</Label>
                <Select value={voiceGender} onValueChange={setVoiceGender}>
                  <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700">
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              onClick={generateScript}
              disabled={isGeneratingScript || !productName || !goal}
              className="w-full bg-violet-600 hover:bg-violet-700"
            >
              {isGeneratingScript ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating Script...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4 mr-2" />
                  Generate AI Script
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Script Editor */}
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Video Script</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {script ? (
              <>
                <Textarea
                  value={script}
                  onChange={(e) => setScript(e.target.value)}
                  className="bg-slate-800 border-slate-700 text-white min-h-[250px] font-mono text-sm"
                />
                <div className="flex items-center gap-2">
                  <Badge className="bg-emerald-500/10 text-emerald-400">
                    AI Generated
                  </Badge>
                  <span className="text-xs text-slate-500">Edit script as needed</span>
                </div>
                <Button
                  onClick={handleGenerateVideo}
                  disabled={isGenerating || !script || script.trim().length === 0}
                  className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating Video...
                    </>
                  ) : (
                    <>
                      <Video className="w-4 h-4 mr-2" />
                      Generate Video
                    </>
                  )}
                </Button>
              </>
            ) : (
              <div className="h-[250px] flex items-center justify-center border border-dashed border-slate-700 rounded-lg">
                <div className="text-center">
                  <Sparkles className="w-12 h-12 mx-auto text-slate-600 mb-3" />
                  <p className="text-slate-500">Generate a script to get started</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Loading State */}
      {isGenerating && (
        <Card className="relative bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 border-4 animate-pulse" style={{
          borderImage: 'linear-gradient(45deg, #8b5cf6, #ec4899, #3b82f6, #8b5cf6) 1',
          animation: 'neonFlash 1s infinite'
        }}>
          <style>{`
            @keyframes neonFlash {
              0%, 100% { border-color: #8b5cf6; box-shadow: 0 0 20px #8b5cf6; }
              25% { border-color: #ec4899; box-shadow: 0 0 30px #ec4899; }
              50% { border-color: #3b82f6; box-shadow: 0 0 20px #3b82f6; }
              75% { border-color: #f59e0b; box-shadow: 0 0 30px #f59e0b; }
            }
          `}</style>
          <CardContent className="py-20">
            <div className="flex flex-col items-center justify-center space-y-6">
              <Loader2 className="w-20 h-20 text-violet-400 animate-spin" />
              <div className="text-center">
                <h3 className="text-2xl font-bold text-white mb-2">🎬 Creating Your Video...</h3>
                <p className="text-slate-300 mb-4">This takes 30-60 seconds. Please wait!</p>
                <div className="flex items-center justify-center gap-2">
                  <div className="w-2 h-2 bg-violet-400 rounded-full animate-pulse" />
                  <div className="w-2 h-2 bg-fuchsia-400 rounded-full animate-pulse delay-100" />
                  <div className="w-2 h-2 bg-violet-400 rounded-full animate-pulse delay-200" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Error State */}
      {generationError && !isGenerating && (
        <Card className="bg-red-500/20 border-red-500 border-2">
          <CardContent className="py-10">
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center">
                <span className="text-4xl">❌</span>
              </div>
              <div className="text-center max-w-2xl">
                <h3 className="text-xl font-bold text-white mb-2">Video Generation Failed</h3>
                <p className="text-red-200 mb-4">{generationError}</p>
                <div className="bg-black/30 rounded-lg p-4 text-left">
                  <p className="text-xs text-red-300 font-mono break-all">{generationError}</p>
                </div>
                <Button 
                  onClick={handleGenerateVideo}
                  className="mt-4 bg-red-500 hover:bg-red-600"
                >
                  Try Again
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Video Preview */}
      {videoUrl && (
        <Card id="video-preview-section" className="relative bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 border-4" style={{
          animation: 'neonFlash 1s infinite'
        }}>
          <style>{`
            @keyframes neonFlash {
              0%, 100% { border-color: #8b5cf6; box-shadow: 0 0 20px #8b5cf6; }
              25% { border-color: #ec4899; box-shadow: 0 0 30px #ec4899; }
              50% { border-color: #3b82f6; box-shadow: 0 0 20px #3b82f6; }
              75% { border-color: #f59e0b; box-shadow: 0 0 30px #f59e0b; }
            }
          `}</style>
          <CardHeader>
            <CardTitle className="text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <span className="text-2xl font-bold">🎬 YOUR VIDEO IS READY!</span>
              <Button
                variant="outline"
                className="border-violet-500 text-violet-400 hover:bg-violet-500/10"
                onClick={() => window.open(videoUrl, '_blank')}
              >
                <Download className="w-4 h-4 mr-2" />
                Open Full Screen
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="w-full bg-black rounded-xl overflow-hidden border-4 border-violet-500" style={{ minHeight: '500px', maxHeight: '80vh' }}>
              <video
                src={videoUrl}
                controls
                autoPlay
                playsInline
                preload="auto"
                className="w-full h-full object-contain"
                style={{ minHeight: '500px', maxHeight: '80vh' }}
                onError={(e) => {
                  console.error('[VIDEO] Failed to load:', e);
                  toast.error('❌ Video failed to load. URL: ' + videoUrl);
                }}
                onLoadedData={() => {
                  console.log('[VIDEO] ✅ Video loaded successfully');
                }}
              />
            </div>
            
            <div className="p-4 bg-violet-500/10 border border-violet-500/20 rounded-lg">
              <p className="text-sm text-violet-300 mb-2 font-medium">🎬 Video URL:</p>
              <a 
                href={videoUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-xs text-violet-400 underline break-all hover:text-violet-300"
              >
                {videoUrl}
              </a>
            </div>

            {videoDetails && (
              <div className="p-4 rounded-lg bg-slate-800/50 border border-slate-700">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-xs text-slate-400">Duration</p>
                    <p className="text-lg font-bold text-white">{videoDetails.duration}s</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Resolution</p>
                    <p className="text-lg font-bold text-white">{videoDetails.resolution}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Format</p>
                    <p className="text-lg font-bold text-white">{videoDetails.format}</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Info */}
      <Card className="bg-gradient-to-br from-violet-500/5 to-fuchsia-500/5 border-violet-500/20">
        <CardContent className="p-6">
          <h3 className="text-white font-semibold mb-3">How It Works</h3>
          <ul className="space-y-2 text-sm text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-violet-400">1.</span>
              <span>AI analyzes your product and goal to create a compelling script</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-violet-400">2.</span>
              <span>System selects royalty-free stock footage matching your content</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-violet-400">3.</span>
              <span>AI generates natural voiceover from your script</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-violet-400">4.</span>
              <span>Video is rendered with professional transitions and effects</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}