import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Target, Plus, Edit, Trash2, TrendingUp, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function Goals() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    target_value: 0,
    current_value: 0,
    metric_type: 'followers',
    deadline: '',
  });

  const queryClient = useQueryClient();

  const { data: goals = [] } = useQuery({
    queryKey: ['goals'],
    queryFn: () => base44.entities.Goal.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Goal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      setIsDialogOpen(false);
      resetForm();
      toast.success('Goal created');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Goal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      setIsDialogOpen(false);
      resetForm();
      toast.success('Goal updated');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Goal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['goals'] });
      toast.success('Goal deleted');
    },
  });

  const resetForm = () => {
    setFormData({ title: '', target_value: 0, current_value: 0, metric_type: 'followers', deadline: '' });
    setEditingGoal(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingGoal) {
      updateMutation.mutate({ id: editingGoal.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (goal) => {
    setEditingGoal(goal);
    setFormData({
      title: goal.title,
      target_value: goal.target_value,
      current_value: goal.current_value,
      metric_type: goal.metric_type,
      deadline: goal.deadline?.split('T')[0] || '',
    });
    setIsDialogOpen(true);
  };

  const getProgress = (goal) => {
    return Math.min((goal.current_value / goal.target_value) * 100, 100);
  };

  const activeGoals = goals.filter(g => getProgress(g) < 100);
  const completedGoals = goals.filter(g => getProgress(g) >= 100);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Goals & KPIs</h1>
          <p className="text-slate-400 mt-1">Track your performance targets</p>
        </div>
        <Button
          onClick={() => {
            resetForm();
            setIsDialogOpen(true);
          }}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Goal
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Target className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{goals.length}</p>
              <p className="text-sm text-slate-400">Total Goals</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{activeGoals.length}</p>
              <p className="text-sm text-slate-400">Active Goals</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Target className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{completedGoals.length}</p>
              <p className="text-sm text-slate-400">Completed</p>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {activeGoals.length > 0 && (
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="font-semibold text-white mb-4">Active Goals</h3>
            <div className="space-y-4">
              {activeGoals.map((goal) => {
                const progress = getProgress(goal);
                return (
                  <div key={goal.id} className="p-4 rounded-xl bg-slate-800/50">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h4 className="text-white font-medium mb-1">{goal.title}</h4>
                        <div className="flex items-center gap-3 text-sm text-slate-400">
                          <Badge className="bg-violet-500/10 text-violet-400 border-violet-500/20 capitalize">
                            {goal.metric_type}
                          </Badge>
                          {goal.deadline && (
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {new Date(goal.deadline).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleEdit(goal)}
                          className="text-slate-400 hover:text-violet-400"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(goal.id)}
                          className="text-slate-400 hover:text-rose-400"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">Progress</span>
                        <span className="text-white font-medium">
                          {goal.current_value?.toLocaleString()} / {goal.target_value?.toLocaleString()}
                        </span>
                      </div>
                      <Progress value={progress} className="h-2" />
                      <p className="text-xs text-slate-500 text-right">{progress.toFixed(1)}% complete</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {completedGoals.length > 0 && (
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <h3 className="font-semibold text-white mb-4">Completed Goals</h3>
            <div className="space-y-3">
              {completedGoals.map((goal) => (
                <div key={goal.id} className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-white font-medium">{goal.title}</h4>
                      <p className="text-sm text-slate-400">
                        {goal.current_value?.toLocaleString()} / {goal.target_value?.toLocaleString()} {goal.metric_type}
                      </p>
                    </div>
                    <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      Completed
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {goals.length === 0 && (
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-12 text-center">
            <Target className="w-12 h-12 mx-auto mb-3 text-slate-600" />
            <p className="text-slate-500">No goals set yet</p>
          </div>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingGoal ? 'Edit Goal' : 'Create New Goal'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-white mb-2 block">Goal Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Reach 10K followers"
                required
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">Metric Type</Label>
              <Select value={formData.metric_type} onValueChange={(value) => setFormData({ ...formData, metric_type: value })}>
                <SelectTrigger className="bg-slate-800/50 border-slate-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-slate-800">
                  <SelectItem value="followers">Followers</SelectItem>
                  <SelectItem value="engagement">Engagement</SelectItem>
                  <SelectItem value="reach">Reach</SelectItem>
                  <SelectItem value="posts">Posts</SelectItem>
                  <SelectItem value="revenue">Revenue</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white mb-2 block">Current Value</Label>
                <Input
                  type="number"
                  value={formData.current_value}
                  onChange={(e) => setFormData({ ...formData, current_value: parseInt(e.target.value) })}
                  required
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
              <div>
                <Label className="text-white mb-2 block">Target Value</Label>
                <Input
                  type="number"
                  value={formData.target_value}
                  onChange={(e) => setFormData({ ...formData, target_value: parseInt(e.target.value) })}
                  required
                  className="bg-slate-800/50 border-slate-700 text-white"
                />
              </div>
            </div>
            <div>
              <Label className="text-white mb-2 block">Deadline (optional)</Label>
              <Input
                type="date"
                value={formData.deadline}
                onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-violet-600">
                {editingGoal ? 'Update' : 'Create'} Goal
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}