import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Crown, Plus, Users, TrendingUp, DollarSign, Mail, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';

export default function Influencers() {
  const { data: influencers = [] } = useQuery({
    queryKey: ['influencers'],
    queryFn: () => base44.entities.Influencer.list('-follower_count'),
  });

  const statusColors = {
    contacted: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
    negotiating: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    partnered: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    declined: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Influencer Management</h1>
          <p className="text-slate-400 mt-1">Track partnerships and ROI</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Crown className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{influencers.length}</p>
              <p className="text-sm text-slate-400">Total Influencers</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">
                {influencers.filter(i => i.partnership_status === 'partnered').length}
              </p>
              <p className="text-sm text-slate-400">Active Partners</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">
                {influencers.reduce((sum, i) => sum + (i.follower_count || 0), 0).toLocaleString()}
              </p>
              <p className="text-sm text-slate-400">Total Reach</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">
                {(influencers.reduce((sum, i) => sum + (i.roi || 0), 0) / influencers.length || 0).toFixed(1)}%
              </p>
              <p className="text-sm text-slate-400">Avg ROI</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {influencers.map((influencer) => (
          <div key={influencer.id} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <div className="flex items-start gap-4 mb-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={influencer.profile_image} />
                <AvatarFallback className="bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white">
                  {influencer.name?.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-semibold truncate">{influencer.name}</h3>
                <p className="text-sm text-slate-400 truncate">@{influencer.username}</p>
                <div className="flex items-center gap-2 mt-1">
                  <PlatformIcon platform={influencer.platform} size="xs" />
                  <Badge className={statusColors[influencer.partnership_status] || statusColors.contacted}>
                    {influencer.partnership_status}
                  </Badge>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-slate-500 mb-1">Followers</p>
                <p className="text-sm font-semibold text-white">
                  {(influencer.follower_count || 0).toLocaleString()}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-slate-500 mb-1">Engagement</p>
                <p className="text-sm font-semibold text-white">{influencer.engagement_rate || 0}%</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-slate-500 mb-1">Cost</p>
                <p className="text-sm font-semibold text-white">${influencer.cost_per_post || 0}</p>
              </div>
              <div className="p-3 rounded-lg bg-slate-800/50">
                <p className="text-xs text-slate-500 mb-1">ROI</p>
                <p className="text-sm font-semibold text-white">{influencer.roi || 0}%</p>
              </div>
            </div>

            <div className="flex gap-2">
              {influencer.email && (
                <Button size="sm" variant="outline" className="flex-1 border-slate-700">
                  <Mail className="w-4 h-4 mr-2" />
                  Contact
                </Button>
              )}
              {influencer.profile_url && (
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1 border-slate-700"
                  onClick={() => window.open(influencer.profile_url, '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Profile
                </Button>
              )}
            </div>
          </div>
        ))}

        {influencers.length === 0 && (
          <div className="col-span-full rounded-2xl bg-slate-900/50 border border-slate-800/50 p-12 text-center">
            <Crown className="w-12 h-12 mx-auto mb-3 text-slate-600" />
            <p className="text-slate-500">No influencers tracked yet</p>
          </div>
        )}
      </div>
    </div>
  );
}