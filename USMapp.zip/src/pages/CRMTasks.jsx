import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar, Plus, Phone, Mail, MessageSquare, Video, MoreVertical, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import TaskModal from '@/components/crm/TaskModal';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday } from 'date-fns';

const taskTypeIcons = {
  call: Phone,
  email: Mail,
  dm: MessageSquare,
  demo: Video,
  renewal: CheckCircle2,
  other: Calendar
};

const priorityColors = {
  low: 'bg-slate-500/10 text-slate-400',
  medium: 'bg-amber-500/10 text-amber-400',
  high: 'bg-red-500/10 text-red-400'
};

export default function CRMTasks() {
  const queryClient = useQueryClient();
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [currentDate, setCurrentDate] = useState(new Date());

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ['crm-tasks'],
    queryFn: () => base44.entities.CRMTask.list('-due_date'),
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CRMTask.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['crm-tasks']);
      toast.success('Task updated');
    },
  });

  const toggleTaskStatus = async (task) => {
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    await updateTaskMutation.mutateAsync({
      id: task.id,
      data: {
        status: newStatus,
        completed_date: newStatus === 'completed' ? new Date().toISOString() : null
      }
    });
  };

  const pendingTasks = tasks.filter(t => t.status === 'pending');
  const completedTasks = tasks.filter(t => t.status === 'completed');
  const overdueTasks = pendingTasks.filter(t => new Date(t.due_date) < new Date());

  // Calendar view data
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Tasks & Follow-Ups</h1>
          <p className="text-slate-400 mt-1">Manage your client interactions</p>
        </div>
        <Button 
          onClick={() => {
            setEditingTask(null);
            setShowModal(true);
          }}
          className="bg-violet-600 hover:bg-violet-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Task
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="text-2xl font-bold text-white">{pendingTasks.length}</div>
          <div className="text-sm text-slate-400 mt-1">Pending</div>
        </Card>
        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="text-2xl font-bold text-red-400">{overdueTasks.length}</div>
          <div className="text-sm text-slate-400 mt-1">Overdue</div>
        </Card>
        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="text-2xl font-bold text-green-400">{completedTasks.length}</div>
          <div className="text-sm text-slate-400 mt-1">Completed</div>
        </Card>
        <Card className="bg-slate-900/50 border-slate-800 p-4">
          <div className="text-2xl font-bold text-white">
            {pendingTasks.filter(t => isToday(new Date(t.due_date))).length}
          </div>
          <div className="text-sm text-slate-400 mt-1">Due Today</div>
        </Card>
      </div>

      <Tabs defaultValue="list" className="space-y-6">
        <TabsList className="bg-slate-800/50">
          <TabsTrigger value="list" className="data-[state=active]:bg-violet-600">
            List View
          </TabsTrigger>
          <TabsTrigger value="calendar" className="data-[state=active]:bg-violet-600">
            Calendar View
          </TabsTrigger>
        </TabsList>

        <TabsContent value="list" className="space-y-4">
          {overdueTasks.length > 0 && (
            <div>
              <h3 className="text-red-400 font-semibold mb-3 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-red-400" />
                Overdue ({overdueTasks.length})
              </h3>
              <div className="space-y-2">
                {overdueTasks.map(task => (
                  <TaskCard key={task.id} task={task} onToggle={toggleTaskStatus} onEdit={setEditingTask} />
                ))}
              </div>
            </div>
          )}

          <div>
            <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-violet-400" />
              Pending ({pendingTasks.length})
            </h3>
            <div className="space-y-2">
              {pendingTasks.filter(t => !overdueTasks.includes(t)).map(task => (
                <TaskCard key={task.id} task={task} onToggle={toggleTaskStatus} onEdit={setEditingTask} />
              ))}
            </div>
          </div>

          {completedTasks.length > 0 && (
            <div>
              <h3 className="text-green-400 font-semibold mb-3 flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-400" />
                Completed ({completedTasks.length})
              </h3>
              <div className="space-y-2">
                {completedTasks.slice(0, 10).map(task => (
                  <TaskCard key={task.id} task={task} onToggle={toggleTaskStatus} onEdit={setEditingTask} />
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="calendar">
          <div className="bg-slate-900/50 border border-slate-800 rounded-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">
                {format(currentDate, 'MMMM yyyy')}
              </h3>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() - 1)))}
                >
                  Previous
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setCurrentDate(new Date())}
                >
                  Today
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setCurrentDate(new Date(currentDate.setMonth(currentDate.getMonth() + 1)))}
                >
                  Next
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-center text-sm font-medium text-slate-400 py-2">
                  {day}
                </div>
              ))}

              {daysInMonth.map(day => {
                const dayTasks = tasks.filter(t => 
                  t.due_date && isSameDay(new Date(t.due_date), day)
                );
                
                return (
                  <div 
                    key={day.toString()} 
                    className={`min-h-[100px] border border-slate-800 rounded-lg p-2 ${
                      isToday(day) ? 'bg-violet-600/10 border-violet-600/30' : 'bg-slate-800/20'
                    }`}
                  >
                    <div className={`text-sm mb-2 ${isToday(day) ? 'text-violet-400 font-bold' : 'text-slate-400'}`}>
                      {format(day, 'd')}
                    </div>
                    <div className="space-y-1">
                      {dayTasks.slice(0, 3).map(task => {
                        const Icon = taskTypeIcons[task.task_type];
                        return (
                          <div 
                            key={task.id}
                            onClick={() => setEditingTask(task)}
                            className="text-xs p-1 rounded bg-slate-900/50 hover:bg-slate-900 cursor-pointer truncate flex items-center gap-1"
                          >
                            <Icon className="w-3 h-3 flex-shrink-0" />
                            <span className="truncate">{task.title}</span>
                          </div>
                        );
                      })}
                      {dayTasks.length > 3 && (
                        <div className="text-xs text-slate-400">+{dayTasks.length - 3} more</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <TaskModal
        open={showModal || !!editingTask}
        onClose={() => {
          setShowModal(false);
          setEditingTask(null);
        }}
        task={editingTask}
      />
    </div>
  );
}

function TaskCard({ task, onToggle, onEdit }) {
  const Icon = taskTypeIcons[task.task_type];
  const isOverdue = new Date(task.due_date) < new Date() && task.status === 'pending';

  return (
    <Card 
      className="bg-slate-900/50 border-slate-800 p-4 hover:bg-slate-900/70 transition-colors cursor-pointer"
      onClick={() => onEdit(task)}
    >
      <div className="flex items-start gap-3">
        <Checkbox 
          checked={task.status === 'completed'}
          onCheckedChange={(e) => {
            e.stopPropagation();
            onToggle(task);
          }}
          onClick={(e) => e.stopPropagation()}
        />

        <div className="flex-1">
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center gap-2">
              <Icon className="w-4 h-4 text-slate-400" />
              <h4 className={`text-white font-medium ${task.status === 'completed' ? 'line-through opacity-50' : ''}`}>
                {task.title}
              </h4>
            </div>
            <Badge className={priorityColors[task.priority]}>
              {task.priority}
            </Badge>
          </div>

          <p className="text-sm text-slate-400 mb-2">{task.contact_name}</p>

          <div className="flex items-center gap-3 text-sm">
            <span className={`${isOverdue ? 'text-red-400' : 'text-slate-400'}`}>
              {task.due_date ? format(new Date(task.due_date), 'MMM d, h:mm a') : 'No due date'}
            </span>
            <Badge variant="outline" className="text-xs">
              {task.task_type}
            </Badge>
          </div>
        </div>
      </div>
    </Card>
  );
}