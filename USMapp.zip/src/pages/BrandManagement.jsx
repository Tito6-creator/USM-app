import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Palette, Type, Image, Check, Edit, Trash2, Star } from 'lucide-react';
import BrandKitEditor from '@/components/brand/BrandKitEditor';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function BrandManagement() {
  const [editingKit, setEditingKit] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const queryClient = useQueryClient();

  const { data: brandKits = [] } = useQuery({
    queryKey: ['brand-kits'],
    queryFn: () => base44.entities.BrandKit.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.BrandKit.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['brand-kits'] });
      setShowEditor(false);
      setEditingKit(null);
      toast.success('Brand kit created successfully');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.BrandKit.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['brand-kits'] });
      setShowEditor(false);
      setEditingKit(null);
      toast.success('Brand kit updated successfully');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.BrandKit.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['brand-kits'] });
      toast.success('Brand kit deleted');
    },
  });

  const setActiveMutation = useMutation({
    mutationFn: async (id) => {
      // Deactivate all first
      await Promise.all(
        brandKits.map(kit => 
          base44.entities.BrandKit.update(kit.id, { is_active: false })
        )
      );
      // Activate the selected one
      return base44.entities.BrandKit.update(id, { is_active: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['brand-kits'] });
      toast.success('Active brand kit updated');
    },
  });

  const handleSave = (data) => {
    if (editingKit) {
      updateMutation.mutate({ id: editingKit.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const activeKit = brandKits.find(kit => kit.is_active);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Brand Management</h1>
          <p className="text-slate-400 mt-1">Create and manage your brand kits for consistent content</p>
        </div>
        <Button
          onClick={() => {
            setEditingKit(null);
            setShowEditor(true);
          }}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Brand Kit
        </Button>
      </div>

      {/* Editor */}
      {showEditor && (
        <BrandKitEditor
          brandKit={editingKit}
          onSave={handleSave}
          onCancel={() => {
            setShowEditor(false);
            setEditingKit(null);
          }}
          isSaving={createMutation.isPending || updateMutation.isPending}
        />
      )}

      {/* Active Brand Kit */}
      {activeKit && !showEditor && (
        <Card className="p-6 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border-violet-500/20">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center">
                <Star className="w-6 h-6 text-violet-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  {activeKit.name}
                  <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30">
                    Active
                  </Badge>
                </h3>
                <p className="text-sm text-slate-400">Currently applied to your content</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setEditingKit(activeKit);
                setShowEditor(true);
              }}
              className="border-violet-500/30 text-violet-300 hover:bg-violet-500/10"
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Logo */}
            {activeKit.logo_url && (
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-700">
                <div className="flex items-center gap-2 mb-3">
                  <Image className="w-4 h-4 text-violet-400" />
                  <span className="text-sm font-medium text-white">Logo</span>
                </div>
                <img 
                  src={activeKit.logo_url} 
                  alt="Brand logo" 
                  className="w-full h-20 object-contain bg-white rounded-lg"
                />
              </div>
            )}

            {/* Colors */}
            {activeKit.colors && (
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-700">
                <div className="flex items-center gap-2 mb-3">
                  <Palette className="w-4 h-4 text-violet-400" />
                  <span className="text-sm font-medium text-white">Colors</span>
                </div>
                <div className="flex gap-2">
                  {Object.entries(activeKit.colors).slice(0, 5).map(([name, color]) => (
                    <div key={name} className="flex-1">
                      <div 
                        className="w-full h-12 rounded-lg border border-slate-600" 
                        style={{ backgroundColor: color }}
                      />
                      <p className="text-xs text-slate-500 mt-1 capitalize">{name}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Fonts */}
            {activeKit.fonts && (
              <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-700">
                <div className="flex items-center gap-2 mb-3">
                  <Type className="w-4 h-4 text-violet-400" />
                  <span className="text-sm font-medium text-white">Typography</span>
                </div>
                <div className="space-y-2">
                  {activeKit.fonts.heading && (
                    <div>
                      <p className="text-xs text-slate-400">Heading</p>
                      <p className="text-sm text-white font-semibold">{activeKit.fonts.heading}</p>
                    </div>
                  )}
                  {activeKit.fonts.body && (
                    <div>
                      <p className="text-xs text-slate-400">Body</p>
                      <p className="text-sm text-white">{activeKit.fonts.body}</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Brand Kits List */}
      {!showEditor && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {brandKits.map((kit) => (
            <Card 
              key={kit.id} 
              className={cn(
                "p-6 bg-slate-900/50 border-slate-800 transition-all",
                kit.is_active && "border-violet-500/30 bg-violet-500/5"
              )}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white mb-1">{kit.name}</h3>
                  {kit.tagline && (
                    <p className="text-sm text-slate-400">{kit.tagline}</p>
                  )}
                </div>
                {kit.is_active && (
                  <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                    <Check className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                )}
              </div>

              {/* Preview */}
              <div className="space-y-3 mb-4">
                {kit.logo_url && (
                  <div className="h-16 flex items-center justify-center bg-white rounded-lg">
                    <img 
                      src={kit.logo_url} 
                      alt={kit.name} 
                      className="h-12 object-contain"
                    />
                  </div>
                )}

                {kit.colors && (
                  <div className="flex gap-1">
                    {Object.values(kit.colors).slice(0, 5).map((color, idx) => (
                      <div 
                        key={idx}
                        className="flex-1 h-8 rounded border border-slate-700"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                )}

                {kit.brand_voice && (
                  <Badge variant="outline" className="border-slate-700 text-slate-400 capitalize">
                    {kit.brand_voice}
                  </Badge>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                {!kit.is_active && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveMutation.mutate(kit.id)}
                    disabled={setActiveMutation.isPending}
                    className="flex-1 border-slate-700"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Set Active
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setEditingKit(kit);
                    setShowEditor(true);
                  }}
                  className="text-slate-400 hover:text-white"
                >
                  <Edit className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    if (confirm('Delete this brand kit?')) {
                      deleteMutation.mutate(kit.id);
                    }
                  }}
                  disabled={deleteMutation.isPending}
                  className="text-slate-400 hover:text-rose-400"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {brandKits.length === 0 && !showEditor && (
        <Card className="p-12 bg-slate-900/50 border-slate-800 text-center">
          <Palette className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No brand kits yet</h3>
          <p className="text-slate-400 mb-6">Create your first brand kit to maintain consistency</p>
          <Button
            onClick={() => setShowEditor(true)}
            className="bg-violet-600 hover:bg-violet-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Brand Kit
          </Button>
        </Card>
      )}
    </div>
  );
}