import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths, parseISO, startOfWeek, endOfWeek } from 'date-fns';
import { ChevronLeft, ChevronRight, Plus, Clock, MoreVertical, Edit, Trash2, Eye, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import AICalendarGenerator from '@/components/calendar/AICalendarGenerator';
import AIScheduleOptimizer from '@/components/calendar/AIScheduleOptimizer';
import ContentRepurposingTool from '@/components/strategy/ContentRepurposingTool';
import PostComments from '@/components/team/PostComments';

const statusColors = {
  draft: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  scheduled: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  pending_approval: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  published: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  failed: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
};

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedPost, setSelectedPost] = useState(null);
  const [showAIGenerator, setShowAIGenerator] = useState(false);
  const [showAITools, setShowAITools] = useState(false);
  
  const queryClient = useQueryClient();

  const { data: posts = [] } = useQuery({
    queryKey: ['posts'],
    queryFn: () => base44.entities.Post.list('-scheduled_time'),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Post.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['posts'] }),
  });

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const getPostsForDate = (date) => {
    return posts.filter(post => {
      if (!post.scheduled_time) return false;
      return isSameDay(parseISO(post.scheduled_time), date);
    });
  };

  const selectedDatePosts = selectedDate ? getPostsForDate(selectedDate) : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Content Calendar</h1>
          <p className="text-slate-400 mt-1">Plan and schedule your posts</p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            onClick={() => setShowAITools(true)}
            className="bg-gradient-to-r from-emerald-600 to-teal-600"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            AI Tools
          </Button>
          <Button
            onClick={() => setShowAIGenerator(true)}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            AI Calendar
          </Button>
          <Link to={createPageUrl('CreatePost')}>
            <Button variant="outline" className="border-slate-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Post
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
        {/* Calendar */}
        <div className="xl:col-span-3 rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
          {/* Calendar Header */}
          <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
            <h2 className="text-xl font-semibold text-white">
              {format(currentDate, 'MMMM yyyy')}
            </h2>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setCurrentDate(subMonths(currentDate, 1))}
                className="text-slate-400 hover:text-white"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setCurrentDate(new Date())}
                className="text-slate-400 hover:text-white"
              >
                Today
              </Button>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setCurrentDate(addMonths(currentDate, 1))}
                className="text-slate-400 hover:text-white"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Days of week */}
          <div className="grid grid-cols-7 border-b border-slate-800">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="px-2 py-3 text-center text-sm font-medium text-slate-400">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7">
            {calendarDays.map((day, index) => {
              const dayPosts = getPostsForDate(day);
              const isCurrentMonth = format(day, 'M') === format(currentDate, 'M');
              const isSelected = selectedDate && isSameDay(day, selectedDate);

              return (
                <div
                  key={index}
                  onClick={() => setSelectedDate(day)}
                  className={cn(
                    "min-h-[100px] p-2 border-b border-r border-slate-800 cursor-pointer transition-colors",
                    !isCurrentMonth && "bg-slate-900/50",
                    isSelected && "bg-violet-500/10",
                    "hover:bg-slate-800/50"
                  )}
                >
                  <div className={cn(
                    "w-7 h-7 rounded-full flex items-center justify-center text-sm mb-1",
                    isToday(day) && "bg-violet-600 text-white",
                    !isToday(day) && isCurrentMonth && "text-white",
                    !isToday(day) && !isCurrentMonth && "text-slate-600"
                  )}>
                    {format(day, 'd')}
                  </div>
                  
                  <div className="space-y-1">
                    {dayPosts.slice(0, 3).map((post) => (
                      <div
                        key={post.id}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPost(post);
                        }}
                        className={cn(
                          "text-xs px-1.5 py-0.5 rounded truncate cursor-pointer",
                          statusColors[post.status]
                        )}
                      >
                        {post.content?.substring(0, 20)}...
                      </div>
                    ))}
                    {dayPosts.length > 3 && (
                      <div className="text-xs text-slate-500 px-1.5">
                        +{dayPosts.length - 3} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar - Selected Date */}
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden">
          <div className="px-4 py-4 border-b border-slate-800">
            <h3 className="font-semibold text-white">
              {selectedDate ? format(selectedDate, 'EEEE, MMM d') : 'Select a date'}
            </h3>
          </div>
          
          <ScrollArea className="h-[600px]">
            <div className="p-4 space-y-3">
              {selectedDatePosts.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <p>No posts scheduled</p>
                  <Link to={createPageUrl('CreatePost')}>
                    <Button size="sm" variant="outline" className="mt-4">
                      <Plus className="w-4 h-4 mr-1" />
                      Create Post
                    </Button>
                  </Link>
                </div>
              ) : (
                selectedDatePosts.map((post) => (
                  <div 
                    key={post.id}
                    className="p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-1 text-xs text-slate-400">
                        <Clock className="w-3 h-3" />
                        {post.scheduled_time && format(parseISO(post.scheduled_time), 'h:mm a')}
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="w-6 h-6 text-slate-400">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                          <DropdownMenuItem onClick={() => setSelectedPost(post)}>
                            <Eye className="w-4 h-4 mr-2" />
                            View
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => deleteMutation.mutate(post.id)}
                            className="text-rose-400"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    <p className="text-sm text-white line-clamp-2 mb-2">{post.content}</p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex -space-x-1">
                        {post.platforms?.map((platform) => (
                          <PlatformIcon key={platform} platform={platform} size="xs" />
                        ))}
                      </div>
                      <Badge className={statusColors[post.status]}>
                        {post.status?.replace('_', ' ')}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </div>

      {/* Post Detail Dialog */}
      <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white">Post Details</DialogTitle>
          </DialogHeader>
          
          {selectedPost && (
            <div className="space-y-4">
              {selectedPost.media_urls?.[0] && (
                <div className="rounded-xl overflow-hidden">
                  <img 
                    src={selectedPost.media_urls[0]} 
                    alt="" 
                    className="w-full h-48 object-cover"
                  />
                </div>
              )}
              
              <p className="text-white">{selectedPost.content}</p>
              
              <div className="flex items-center gap-2 flex-wrap">
                {selectedPost.hashtags?.map((tag) => (
                  <Badge key={tag} variant="outline" className="border-slate-700 text-slate-400">
                    #{tag}
                  </Badge>
                ))}
              </div>
              
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <div className="flex -space-x-1">
                  {selectedPost.platforms?.map((platform) => (
                    <PlatformIcon key={platform} platform={platform} size="sm" />
                  ))}
                </div>
                <Badge className={statusColors[selectedPost.status]}>
                  {selectedPost.status?.replace('_', ' ')}
                </Badge>
              </div>

              {/* Comments Section */}
              <div className="mt-6 pt-6 border-t border-slate-800">
                <PostComments postId={selectedPost.id} />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* AI Tools Dialog */}
      <Dialog open={showAITools} onOpenChange={setShowAITools}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white">AI Scheduling Tools</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
            <AIScheduleOptimizer
              platforms={['instagram', 'facebook', 'twitter', 'linkedin']}
              onScheduleApply={(schedule) => {
                toast.success(`Applied schedule for ${schedule.time}`);
                setShowAITools(false);
              }}
            />
            <ContentRepurposingTool
              onContentCreated={() => {
                queryClient.invalidateQueries({ queryKey: ['posts'] });
                toast.success('Content created!');
              }}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* AI Calendar Generator */}
      {showAIGenerator && (
        <AICalendarGenerator
          onClose={() => setShowAIGenerator(false)}
          onGenerated={() => queryClient.invalidateQueries({ queryKey: ['posts'] })}
        />
      )}
    </div>
  );
}