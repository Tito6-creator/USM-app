import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Image, Video, Upload, Trash2, Download, Search, Filter, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function MediaLibrary() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [isUploading, setIsUploading] = useState(false);
  const queryClient = useQueryClient();

  const { data: media = [] } = useQuery({
    queryKey: ['media'],
    queryFn: () => base44.entities.MediaAsset.list('-created_date'),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.MediaAsset.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['media'] });
      toast.success('Media deleted');
    },
  });

  const handleFileUpload = async (e) => {
    const files = e.target.files;
    if (!files.length) return;

    setIsUploading(true);
    try {
      for (const file of files) {
        const result = await base44.integrations.Core.UploadFile({ file });
        await base44.entities.MediaAsset.create({
          name: file.name,
          file_url: result.file_url,
          file_type: file.type.startsWith('image') ? 'image' : 'video',
          file_size: file.size,
        });
      }
      queryClient.invalidateQueries({ queryKey: ['media'] });
      toast.success('Media uploaded');
    } catch (error) {
      toast.error('Upload failed');
    } finally {
      setIsUploading(false);
    }
  };

  const filteredMedia = media.filter(m => {
    const matchesSearch = m.name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterType === 'all' || m.file_type === filterType;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Media Library</h1>
          <p className="text-slate-400 mt-1">Manage your images and videos</p>
        </div>
        <div>
          <input
            type="file"
            multiple
            accept="image/*,video/*"
            onChange={handleFileUpload}
            className="hidden"
            id="media-upload"
          />
          <label htmlFor="media-upload">
            <Button asChild disabled={isUploading} className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
              <span>
                {isUploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                Upload Media
              </span>
            </Button>
          </label>
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search media..."
              className="pl-10 bg-slate-800/50 border-slate-700 text-white"
            />
          </div>
          <div className="flex gap-2">
            {['all', 'image', 'video'].map((type) => (
              <Button
                key={type}
                variant={filterType === type ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterType(type)}
                className={cn(
                  filterType === type && "bg-violet-600"
                )}
              >
                {type === 'all' && <Filter className="w-4 h-4 mr-2" />}
                {type === 'image' && <Image className="w-4 h-4 mr-2" />}
                {type === 'video' && <Video className="w-4 h-4 mr-2" />}
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {filteredMedia.map((item) => (
            <div key={item.id} className="group relative rounded-xl overflow-hidden bg-slate-800/50">
              {item.file_type === 'image' ? (
                <img src={item.file_url} alt={item.file_name} className="w-full h-40 object-cover" />
              ) : (
                <div className="w-full h-40 bg-slate-900 flex items-center justify-center">
                  <Video className="w-10 h-10 text-slate-600" />
                </div>
              )}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:text-cyan-400"
                  onClick={() => window.open(item.file_url, '_blank')}
                >
                  <Download className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-white hover:text-rose-400"
                  onClick={() => deleteMutation.mutate(item.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              <div className="p-2">
                <p className="text-xs text-slate-400 truncate">{item.name}</p>
              </div>
            </div>
          ))}
        </div>

        {filteredMedia.length === 0 && (
          <div className="text-center py-12 text-slate-500">
            <Image className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p>No media found</p>
          </div>
        )}
      </div>
    </div>
  );
}