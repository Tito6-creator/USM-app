import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import {
  Mail,
  Plus,
  Send,
  Calendar,
  Users,
  TrendingUp,
  Eye,
  MousePointerClick,
  Trash2,
  Sparkles,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function EmailCampaigns() {
  const [isCreating, setIsCreating] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [newCampaign, setNewCampaign] = useState({
    name: '',
    subject_line: '',
    email_content: '',
    from_name: '',
    segment: 'all_leads',
    status: 'draft'
  });

  const queryClient = useQueryClient();

  const { data: campaigns = [] } = useQuery({
    queryKey: ['emailCampaigns'],
    queryFn: () => base44.entities.EmailCampaign.list('-created_date'),
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.EmailCampaign.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailCampaigns'] });
      setIsCreating(false);
      setNewCampaign({
        name: '',
        subject_line: '',
        email_content: '',
        from_name: '',
        segment: 'all_leads',
        status: 'draft'
      });
      toast.success('Campaign created!');
    },
  });

  const sendCampaignMutation = useMutation({
    mutationFn: async ({ id, campaign }) => {
      // Get recipient emails based on segment
      let recipients = [];
      if (campaign.segment === 'all_leads') {
        recipients = leads.map(l => l.email).filter(Boolean);
      } else if (campaign.segment === 'engaged') {
        recipients = leads.filter(l => l.status === 'contacted' || l.status === 'qualified').map(l => l.email).filter(Boolean);
      }

      // Send emails
      for (const email of recipients) {
        await base44.integrations.Core.SendEmail({
          from_name: campaign.from_name || 'SocialPulse',
          to: email,
          subject: campaign.subject_line,
          body: campaign.email_content
        });
      }

      // Update campaign
      return base44.entities.EmailCampaign.update(id, {
        status: 'sent',
        sent_count: recipients.length,
        recipient_list: recipients
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailCampaigns'] });
      toast.success('Campaign sent successfully!');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EmailCampaign.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['emailCampaigns'] });
      toast.success('Campaign deleted');
    },
  });

  const generateAIContent = async () => {
    if (!newCampaign.name) {
      toast.error('Enter campaign name first');
      return;
    }

    setIsGeneratingAI(true);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Create a professional email campaign for: ${newCampaign.name}

Generate:
1. Compelling subject line (under 50 characters)
2. Professional email body with:
   - Engaging opening
   - Clear value proposition
   - Call-to-action
   - Professional closing

Make it persuasive but not pushy.`,
      response_json_schema: {
        type: 'object',
        properties: {
          subject_line: { type: 'string' },
          email_content: { type: 'string' }
        }
      }
    });

    setNewCampaign({
      ...newCampaign,
      subject_line: result.subject_line,
      email_content: result.email_content,
      ai_optimized: true
    });

    setIsGeneratingAI(false);
    toast.success('AI content generated!');
  };

  const totalSent = campaigns.reduce((sum, c) => sum + (c.sent_count || 0), 0);
  const totalOpened = campaigns.reduce((sum, c) => sum + (c.opened_count || 0), 0);
  const totalClicked = campaigns.reduce((sum, c) => sum + (c.clicked_count || 0), 0);
  const avgOpenRate = totalSent > 0 ? ((totalOpened / totalSent) * 100).toFixed(1) : 0;
  const avgClickRate = totalSent > 0 ? ((totalClicked / totalSent) * 100).toFixed(1) : 0;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Email Campaigns</h1>
          <p className="text-slate-400 mt-1">Create and manage bulk email campaigns</p>
        </div>
        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600">
              <Plus className="w-4 h-4 mr-2" />
              New Campaign
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-slate-900 border-slate-800 max-w-3xl">
            <DialogHeader>
              <DialogTitle className="text-white">Create Email Campaign</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <Label className="text-white">Campaign Name</Label>
                <Input
                  value={newCampaign.name}
                  onChange={(e) => setNewCampaign({ ...newCampaign, name: e.target.value })}
                  placeholder="e.g., New Product Launch"
                  className="bg-slate-800 border-slate-700 text-white mt-2"
                />
              </div>

              <div className="flex gap-3">
                <div className="flex-1">
                  <Label className="text-white">From Name</Label>
                  <Input
                    value={newCampaign.from_name}
                    onChange={(e) => setNewCampaign({ ...newCampaign, from_name: e.target.value })}
                    placeholder="Your Company"
                    className="bg-slate-800 border-slate-700 text-white mt-2"
                  />
                </div>
                <div className="flex-1">
                  <Label className="text-white">Segment</Label>
                  <Select value={newCampaign.segment} onValueChange={(value) => setNewCampaign({ ...newCampaign, segment: value })}>
                    <SelectTrigger className="bg-slate-800 border-slate-700 text-white mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-900 border-slate-800">
                      <SelectItem value="all_leads">All Leads ({leads.length})</SelectItem>
                      <SelectItem value="engaged">Engaged Only</SelectItem>
                      <SelectItem value="cold">Cold Leads</SelectItem>
                      <SelectItem value="customers">Customers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <Label className="text-white">Subject Line</Label>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={generateAIContent}
                    disabled={isGeneratingAI}
                    className="text-violet-400 hover:text-violet-300"
                  >
                    {isGeneratingAI ? (
                      <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                    ) : (
                      <Sparkles className="w-3 h-3 mr-1" />
                    )}
                    AI Generate
                  </Button>
                </div>
                <Input
                  value={newCampaign.subject_line}
                  onChange={(e) => setNewCampaign({ ...newCampaign, subject_line: e.target.value })}
                  placeholder="Your compelling subject line"
                  className="bg-slate-800 border-slate-700 text-white"
                />
                <p className="text-xs text-slate-500 mt-1">{newCampaign.subject_line.length}/50 characters</p>
              </div>

              <div>
                <Label className="text-white">Email Content</Label>
                <Textarea
                  value={newCampaign.email_content}
                  onChange={(e) => setNewCampaign({ ...newCampaign, email_content: e.target.value })}
                  placeholder="Write your email content here..."
                  className="bg-slate-800 border-slate-700 text-white mt-2 min-h-[300px]"
                />
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={() => createMutation.mutate({ ...newCampaign, status: 'draft' })}
                  disabled={!newCampaign.name || !newCampaign.subject_line || !newCampaign.email_content}
                  variant="outline"
                  className="flex-1 border-slate-700"
                >
                  Save as Draft
                </Button>
                <Button
                  onClick={() => createMutation.mutate(newCampaign)}
                  disabled={!newCampaign.name || !newCampaign.subject_line || !newCampaign.email_content}
                  className="flex-1 bg-gradient-to-r from-violet-600 to-fuchsia-600"
                >
                  Create & Send Later
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Sent</p>
              <p className="text-3xl font-bold text-white mt-1">{totalSent}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Send className="w-6 h-6 text-violet-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Open Rate</p>
              <p className="text-3xl font-bold text-white mt-1">{avgOpenRate}%</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Eye className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Click Rate</p>
              <p className="text-3xl font-bold text-white mt-1">{avgClickRate}%</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-fuchsia-500/10 flex items-center justify-center">
              <MousePointerClick className="w-6 h-6 text-fuchsia-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-400 text-sm">Total Leads</p>
              <p className="text-3xl font-bold text-white mt-1">{leads.length}</p>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Users className="w-6 h-6 text-amber-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Campaigns List */}
      <div className="space-y-4">
        {campaigns.length === 0 ? (
          <div className="text-center py-12 rounded-2xl bg-slate-900/50 border border-slate-800/50">
            <Mail className="w-16 h-16 mx-auto text-slate-600 mb-4" />
            <p className="text-slate-400">No email campaigns yet</p>
            <p className="text-sm text-slate-500 mt-1">Create your first campaign to reach your leads</p>
          </div>
        ) : (
          campaigns.map((campaign) => (
            <div key={campaign.id} className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6 hover:border-violet-500/50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold text-white">{campaign.name}</h3>
                    <Badge className={cn(
                      campaign.status === 'sent' && "bg-emerald-500/10 text-emerald-400",
                      campaign.status === 'sending' && "bg-amber-500/10 text-amber-400",
                      campaign.status === 'draft' && "bg-slate-500/10 text-slate-400"
                    )}>
                      {campaign.status}
                    </Badge>
                    {campaign.ai_optimized && (
                      <Badge className="bg-fuchsia-500/10 text-fuchsia-400">
                        <Sparkles className="w-3 h-3 mr-1" />
                        AI Optimized
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-400 mb-3">{campaign.subject_line}</p>
                  
                  {campaign.status === 'sent' && (
                    <div className="flex items-center gap-6 text-sm">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Send className="w-4 h-4" />
                        {campaign.sent_count} sent
                      </div>
                      <div className="flex items-center gap-2 text-emerald-400">
                        <Eye className="w-4 h-4" />
                        {campaign.open_rate || 0}% opened
                      </div>
                      <div className="flex items-center gap-2 text-fuchsia-400">
                        <MousePointerClick className="w-4 h-4" />
                        {campaign.click_rate || 0}% clicked
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {campaign.status === 'draft' && (
                    <Button
                      size="sm"
                      onClick={() => sendCampaignMutation.mutate({ id: campaign.id, campaign })}
                      disabled={sendCampaignMutation.isPending}
                      className="bg-violet-600 hover:bg-violet-700"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Send Now
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => deleteMutation.mutate(campaign.id)}
                    className="text-rose-400 hover:text-rose-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}