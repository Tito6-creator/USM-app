import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Link2, Plus, Edit, Trash2, Eye, BarChart3, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

export default function LinkInBio() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingLink, setEditingLink] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    url: '',
    description: '',
    is_active: true,
  });

  const queryClient = useQueryClient();

  const { data: links = [] } = useQuery({
    queryKey: ['linkinbio'],
    queryFn: () => base44.entities.LinkInBio.list('-order'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.LinkInBio.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['linkinbio'] });
      setIsDialogOpen(false);
      resetForm();
      toast.success('Link added');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LinkInBio.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['linkinbio'] });
      setIsDialogOpen(false);
      resetForm();
      toast.success('Link updated');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.LinkInBio.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['linkinbio'] });
      toast.success('Link deleted');
    },
  });

  const resetForm = () => {
    setFormData({ title: '', url: '', description: '', is_active: true });
    setEditingLink(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingLink) {
      updateMutation.mutate({ id: editingLink.id, data: formData });
    } else {
      createMutation.mutate({ ...formData, order: links.length });
    }
  };

  const handleEdit = (link) => {
    setEditingLink(link);
    setFormData({
      title: link.title,
      url: link.url,
      description: link.description || '',
      is_active: link.is_active,
    });
    setIsDialogOpen(true);
  };

  const totalClicks = links.reduce((sum, link) => sum + (link.click_count || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Link in Bio</h1>
          <p className="text-slate-400 mt-1">Manage your bio links and track clicks</p>
        </div>
        <Button
          onClick={() => {
            resetForm();
            setIsDialogOpen(true);
          }}
          className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Link
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Link2 className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{links.length}</p>
              <p className="text-sm text-slate-400">Total Links</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Eye className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{links.filter(l => l.is_active).length}</p>
              <p className="text-sm text-slate-400">Active Links</p>
            </div>
          </div>
        </div>
        <div className="rounded-xl bg-slate-900/50 border border-slate-800/50 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{totalClicks}</p>
              <p className="text-sm text-slate-400">Total Clicks</p>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
        <div className="space-y-3">
          {links.map((link) => (
            <div
              key={link.id}
              className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-white font-medium truncate">{link.title}</h3>
                    <Badge className={link.is_active 
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : "bg-slate-500/10 text-slate-400 border-slate-500/20"
                    }>
                      {link.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-400 truncate mb-2">{link.url}</p>
                  {link.description && (
                    <p className="text-sm text-slate-500">{link.description}</p>
                  )}
                  <div className="flex items-center gap-4 mt-2 text-sm text-slate-400">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {link.click_count || 0} clicks
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => window.open(link.url, '_blank')}
                    className="text-slate-400 hover:text-cyan-400"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => handleEdit(link)}
                    className="text-slate-400 hover:text-violet-400"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={() => deleteMutation.mutate(link.id)}
                    className="text-slate-400 hover:text-rose-400"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}

          {links.length === 0 && (
            <div className="text-center py-12 text-slate-500">
              <Link2 className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p>No links added yet</p>
            </div>
          )}
        </div>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="text-white">
              {editingLink ? 'Edit Link' : 'Add New Link'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label className="text-white mb-2 block">Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="My Website"
                required
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">URL</Label>
              <Input
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                placeholder="https://example.com"
                required
                type="url"
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div>
              <Label className="text-white mb-2 block">Description (optional)</Label>
              <Input
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Check out my website"
                className="bg-slate-800/50 border-slate-700 text-white"
              />
            </div>
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-violet-600">
                {editingLink ? 'Update' : 'Add'} Link
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}