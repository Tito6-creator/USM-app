import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Sparkles, Clock, TrendingUp, Users, Target, Zap,
  CheckCircle2, Calendar, BarChart3, MessageSquare,
  Brain, Globe, Shield, ArrowRight, Star
} from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import PricingComparison from '@/components/pricing/PricingComparison';

export default function Dashboard() {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(auth => {
      setIsAuthenticated(auth);
      if (auth) {
        // Redirect to App page if authenticated
        window.location.href = createPageUrl('App');
      }
    });
  }, []);

  const handleWaitlist = async (e) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    try {
      await base44.entities.Lead.create({
        name: 'Waitlist Signup',
        email,
        source: 'website',
        status: 'new',
        tags: ['waitlist']
      });
      toast.success('Successfully joined the waitlist!');
      setEmail('');
    } catch (error) {
      toast.error('Failed to join waitlist');
    } finally {
      setIsSubmitting(false);
    }
  };

  const problems = [
    {
      icon: Clock,
      title: "Drowning in Manual Work",
      description: "Spending hours scheduling posts, managing multiple platforms, and tracking analytics manually"
    },
    {
      icon: TrendingUp,
      title: "Inconsistent Results",
      description: "Posting randomly without strategy, struggling to understand what content performs best"
    },
    {
      icon: Users,
      title: "Lost Opportunities",
      description: "Missing customer messages, losing leads, and failing to engage your audience effectively"
    },
    {
      icon: Target,
      title: "No Clear ROI",
      description: "Can't prove social media value or track which efforts drive actual business results"
    }
  ];

  const solutions = [
    {
      icon: Zap,
      title: "AI-Powered Automation",
      description: "Let AI generate content, schedule posts, and respond to messages automatically"
    },
    {
      icon: Brain,
      title: "Smart Analytics",
      description: "Get actionable insights and predictions to optimize your social media strategy"
    },
    {
      icon: Calendar,
      title: "Unified Management",
      description: "Manage all your social accounts, CRM, and campaigns from one powerful dashboard"
    },
    {
      icon: MessageSquare,
      title: "Never Miss a Lead",
      description: "Automated inbox management with AI responses and seamless CRM integration"
    }
  ];

  const outcomes = [
    "Save 20+ hours per week on social media management",
    "Increase engagement rates by 3-5x with AI-optimized content",
    "Never miss a customer inquiry or sales opportunity",
    "Grow your audience 10x faster with data-driven strategies",
    "Automate 80% of repetitive tasks while maintaining quality",
    "Get real-time insights to make smarter marketing decisions"
  ];

  const targetAudience = [
    {
      title: "Social Media Managers",
      description: "Manage multiple clients and accounts effortlessly with AI automation"
    },
    {
      title: "Small Business Owners",
      description: "Focus on your business while AI handles your social media presence"
    },
    {
      title: "Marketing Agencies",
      description: "Scale your services and deliver better results for more clients"
    },
    {
      title: "Content Creators",
      description: "Spend more time creating, less time managing and scheduling"
    }
  ];

  const [billingCycle, setBillingCycle] = useState('monthly');

  const calculateYearlyPrice = (monthlyPrice) => {
    const yearly = (monthlyPrice * 12 * 0.84).toFixed(2);
    return yearly;
  };

  const pricingPlans = [
    {
      name: "Starter",
      monthlyPrice: 29.99,
      description: "Perfect for individuals getting started",
      features: [
        "1 Brand/Account with 3 platforms",
        "Unlimited post scheduling",
        "AI content generation",
        "Post templates library",
        "Drag & drop scheduling",
        "Basic analytics"
      ],
      cta: "Start Free Trial",
      popular: false
    },
    {
      name: "Entrepreneur",
      monthlyPrice: 59.99,
      description: "For solopreneurs and small teams",
      features: [
        "2 Brand/Accounts with 3 platforms",
        "Unlimited post scheduling",
        "AI strategy generator",
        "Publishing queue",
        "Advanced analytics",
        "Campaign planner"
      ],
      cta: "Start Free Trial",
      popular: false
    },
    {
      name: "Pro",
      monthlyPrice: 99.99,
      description: "Ideal for growing businesses",
      features: [
        "3 Brands/Accounts with 5 platforms",
        "Unlimited post scheduling",
        "AI chatbot & automation",
        "A/B testing",
        "CRM integration",
        "Priority support"
      ],
      cta: "Start Free Trial",
      popular: true
    },
    {
      name: "Agency",
      monthlyPrice: 199.99,
      description: "For agencies managing clients",
      features: [
        "6 Brands/Accounts with 10 platforms",
        "Unlimited post scheduling",
        "Full CRM suite",
        "Team collaboration",
        "White-label option",
        "Approval workflows"
      ],
      cta: "Start Free Trial",
      popular: false
    },
    {
      name: "Enterprise",
      monthlyPrice: 399.99,
      startsAt: true,
      description: "For large organizations",
      features: [
        "Higher brand & platform limits",
        "Unlimited post scheduling",
        "Dedicated account manager",
        "Custom integrations",
        "Advanced security",
        "24/7 support"
      ],
      cta: "Contact Sales",
      popular: false
    }
  ];

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-950">
        <div className="w-12 h-12 border-4 border-violet-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-xl border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d388fe1d94f0723fc47a6/68c7e3d55_Screenshot_20260106_000036_Drive.jpg" 
                alt="Ultimate Social Media"
                className="h-12 w-auto object-contain"
              />
            </div>
            <div className="flex items-center gap-4">
              <Link to={createPageUrl('Pricing')}>
                <Button variant="ghost" className="text-slate-300 hover:text-white">
                  Pricing
                </Button>
              </Link>
              <Link to={createPageUrl('App')}>
                <Button variant="outline" className="border-slate-700 text-slate-300 hover:text-white">
                  Log In
                </Button>
              </Link>
              <Button className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-6 bg-violet-500/10 text-violet-400 border-violet-500/20 px-4 py-1">
            <Sparkles className="w-3 h-3 mr-1" />
            AI-Powered Social Media Management
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Manage All Your Social Media
            <br />
            <span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">
              10x Faster with AI
            </span>
          </h1>
          <p className="text-xl text-slate-400 max-w-3xl mx-auto mb-10">
            The only platform that combines social media management, CRM, and AI automation 
            to help you grow your audience, engage customers, and drive real business results.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to={createPageUrl('App')}>
              <Button size="lg" className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700 text-lg px-8">
                Start Free Trial
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <form onSubmit={handleWaitlist} className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-64 bg-slate-900 border-slate-700 text-white"
              />
              <Button 
                type="submit" 
                variant="outline" 
                size="lg"
                disabled={isSubmitting}
                className="border-slate-700 text-slate-300 hover:text-white"
              >
                Join Waitlist
              </Button>
            </form>
          </div>
          <div className="flex items-center justify-center gap-6 mt-8 text-slate-400 text-sm">
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span className="ml-2">Rated 5/5 by users</span>
            </div>
          </div>
        </div>
      </section>

      {/* Problems Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Tired of These Social Media Struggles?
            </h2>
            <p className="text-xl text-slate-400">
              You're not alone. Here's what's holding you back.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {problems.map((problem, idx) => (
              <Card key={idx} className="p-6 bg-slate-900/50 border-slate-800 hover:border-violet-500/30 transition-all">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center flex-shrink-0">
                    <problem.icon className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg mb-2">{problem.title}</h3>
                    <p className="text-slate-400">{problem.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Your Complete Social Media Solution
            </h2>
            <p className="text-xl text-slate-400">
              Everything you need to dominate social media, powered by AI.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {solutions.map((solution, idx) => (
              <Card key={idx} className="p-6 bg-gradient-to-br from-violet-500/5 to-fuchsia-500/5 border-violet-500/20 hover:border-violet-500/40 transition-all">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-violet-500/10 flex items-center justify-center flex-shrink-0">
                    <solution.icon className="w-6 h-6 text-violet-400" />
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-lg mb-2">{solution.title}</h3>
                    <p className="text-slate-400">{solution.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Who It's For Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Built For Professionals Like You
            </h2>
            <p className="text-xl text-slate-400">
              Whether you're managing one account or a hundred, we've got you covered.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {targetAudience.map((audience, idx) => (
              <Card key={idx} className="p-6 bg-slate-900/50 border-slate-800 text-center hover:border-violet-500/30 transition-all">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500/20 to-fuchsia-500/20 flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-violet-400" />
                </div>
                <h3 className="text-white font-semibold text-lg mb-2">{audience.title}</h3>
                <p className="text-slate-400 text-sm">{audience.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Outcomes Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Real Results You Can Measure
            </h2>
            <p className="text-xl text-slate-400">
              Join thousands of users who've transformed their social media game.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {outcomes.map((outcome, idx) => (
              <div key={idx} className="flex items-start gap-3 p-4 bg-slate-900/30 rounded-xl border border-slate-800">
                <CheckCircle2 className="w-6 h-6 text-emerald-400 flex-shrink-0 mt-0.5" />
                <p className="text-slate-300">{outcome}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-900/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-slate-400">
              Choose the plan that fits your needs. Upgrade or downgrade anytime.
            </p>
          </div>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-12">
            <span className={cn("text-sm font-medium", billingCycle === 'monthly' ? 'text-white' : 'text-slate-400')}>
              Monthly
            </span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'yearly' : 'monthly')}
              className="relative w-14 h-7 bg-slate-700 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500"
            >
              <span
                className={cn(
                  "absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform",
                  billingCycle === 'yearly' && "translate-x-7"
                )}
              />
            </button>
            <span className={cn("text-sm font-medium", billingCycle === 'yearly' ? 'text-white' : 'text-slate-400')}>
              Yearly
            </span>
            {billingCycle === 'yearly' && (
              <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                Save 16%
              </Badge>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-12">
            {pricingPlans.map((plan, idx) => (
              <Card 
                key={idx} 
                className={`p-6 ${plan.popular 
                  ? 'bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border-violet-500/30 relative' 
                  : 'bg-slate-900/50 border-slate-800'}`}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-violet-600 text-white">
                    Most Popular
                  </Badge>
                )}
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                  <div className="mb-2">
                    <span className="text-4xl font-bold text-white">
                      {plan.startsAt && '+'}${billingCycle === 'monthly' ? plan.monthlyPrice : calculateYearlyPrice(plan.monthlyPrice)}
                    </span>
                    <span className="text-slate-400 ml-2">/{billingCycle === 'monthly' ? 'mo' : 'yr'}</span>
                  </div>
                  {billingCycle === 'yearly' && (
                    <p className="text-xs text-slate-500 mb-2">${plan.monthlyPrice}/mo billed annually</p>
                  )}
                  <p className="text-slate-400 text-sm">{plan.description}</p>
                </div>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2 text-slate-300 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-violet-400 flex-shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full ${plan.popular 
                    ? 'bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700' 
                    : 'bg-slate-800 hover:bg-slate-700 text-white'}`}
                >
                  {plan.cta}
                </Button>
              </Card>
            ))}
          </div>

          {/* Feature Comparison Chart */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold text-white text-center mb-8">
              Compare All Features
            </h3>
            <PricingComparison />
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-500/20 rounded-3xl p-12">
            <h2 className="text-4xl font-bold text-white mb-4">
              Ready to Transform Your Social Media?
            </h2>
            <p className="text-xl text-slate-400 mb-8">
              Join thousands of professionals who've already made the switch.
              Start your free trial today—no credit card required.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl('App')}>
                <Button size="lg" className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-700 hover:to-fuchsia-700 text-lg px-8">
                  Start Free Trial
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Button 
                size="lg" 
                variant="outline"
                className="border-slate-700 text-slate-300 hover:text-white"
              >
                Schedule a Demo
              </Button>
            </div>
            <p className="text-slate-500 text-sm mt-6">
              14-day free trial • Cancel anytime
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/692d388fe1d94f0723fc47a6/68c7e3d55_Screenshot_20260106_000036_Drive.jpg" 
                alt="Ultimate Social Media"
                className="h-12 w-auto object-contain mb-4"
              />
              <p className="text-slate-400 text-sm">
                The ultimate AI-powered social media management platform.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white">Features</a></li>
                <li><Link to={createPageUrl('Pricing')} className="hover:text-white">Pricing</Link></li>
                <li><a href="#" className="hover:text-white">Integrations</a></li>
                <li><a href="#" className="hover:text-white">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Cookie Policy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-slate-400">
              © 2026 Ultimate Social Media. All rights reserved.
            </div>
            <div className="flex gap-4">
              <Shield className="w-5 h-5 text-slate-400" />
              <Globe className="w-5 h-5 text-slate-400" />
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}