import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  TrendingUp, 
  Calendar, 
  AlertCircle,
  DollarSign,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe', '#ede9fe'];

export default function CRMDashboard() {
  const { data: contacts = [] } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list(),
  });

  const { data: deals = [] } = useQuery({
    queryKey: ['deals'],
    queryFn: () => base44.entities.Deal.list(),
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['crm-tasks'],
    queryFn: () => base44.entities.CRMTask.list(),
  });

  // Calculate metrics
  const totalLeads = contacts.filter(c => c.status === 'lead').length;
  const dealsInPipeline = deals.filter(d => !['client', 'churn_risk'].includes(d.stage)).length;
  const demosBooked = deals.filter(d => d.stage === 'demo').length;
  const churnRisk = contacts.filter(c => c.status === 'churn_risk').length;
  const upcomingTasks = tasks.filter(t => t.status === 'pending' && new Date(t.due_date) >= new Date()).length;
  const totalPipelineValue = deals.reduce((sum, d) => sum + (d.value || 0), 0);

  // Pipeline by stage
  const pipelineData = [
    { name: 'Lead', value: deals.filter(d => d.stage === 'lead').length },
    { name: 'Demo', value: deals.filter(d => d.stage === 'demo').length },
    { name: 'Trial', value: deals.filter(d => d.stage === 'trial').length },
    { name: 'Client', value: deals.filter(d => d.stage === 'client').length },
    { name: 'Churn Risk', value: deals.filter(d => d.stage === 'churn_risk').length },
  ];

  const statusDistribution = [
    { name: 'Leads', value: contacts.filter(c => c.status === 'lead').length },
    { name: 'Demos', value: contacts.filter(c => c.status === 'demo').length },
    { name: 'Trials', value: contacts.filter(c => c.status === 'trial').length },
    { name: 'Clients', value: contacts.filter(c => c.status === 'client').length },
    { name: 'Churn Risk', value: contacts.filter(c => c.status === 'churn_risk').length },
  ];

  const recentTasks = tasks.filter(t => t.status === 'pending').slice(0, 5);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">CRM Dashboard</h1>
        <p className="text-slate-400 mt-1">Overview of your sales pipeline and activities</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Total Leads</CardTitle>
            <Users className="w-4 h-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{totalLeads}</div>
            <Link to={createPageUrl('Contacts')} className="text-xs text-violet-400 hover:text-violet-300">
              View all contacts →
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Deals in Pipeline</CardTitle>
            <TrendingUp className="w-4 h-4 text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{dealsInPipeline}</div>
            <p className="text-xs text-slate-400 mt-1">
              ${totalPipelineValue.toLocaleString()} total value
            </p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Demos Booked</CardTitle>
            <Calendar className="w-4 h-4 text-amber-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{demosBooked}</div>
            <Link to={createPageUrl('Pipeline')} className="text-xs text-violet-400 hover:text-violet-300">
              View pipeline →
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Churn Risk</CardTitle>
            <AlertCircle className="w-4 h-4 text-red-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">{churnRisk}</div>
            <p className="text-xs text-slate-400 mt-1">Requires immediate attention</p>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Upcoming Tasks</CardTitle>
            <Clock className="w-4 h-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{upcomingTasks}</div>
            <Link to={createPageUrl('CRMTasks')} className="text-xs text-violet-400 hover:text-violet-300">
              View all tasks →
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-slate-400">Pipeline Value</CardTitle>
            <DollarSign className="w-4 h-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              ${totalPipelineValue.toLocaleString()}
            </div>
            <p className="text-xs text-slate-400 mt-1">Total opportunity value</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Pipeline by Stage</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={pipelineData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  labelStyle={{ color: '#f1f5f9' }}
                />
                <Bar dataKey="value" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-slate-900/50 border-slate-800">
          <CardHeader>
            <CardTitle className="text-white">Contact Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Tasks */}
      <Card className="bg-slate-900/50 border-slate-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">Upcoming Tasks</CardTitle>
            <Link to={createPageUrl('CRMTasks')}>
              <Badge variant="outline" className="cursor-pointer hover:bg-violet-600/10">
                View All
              </Badge>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          {recentTasks.length === 0 ? (
            <p className="text-slate-400 text-center py-8">No upcoming tasks</p>
          ) : (
            <div className="space-y-3">
              {recentTasks.map(task => (
                <div key={task.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                  <div className="flex-1">
                    <h4 className="text-white font-medium">{task.title}</h4>
                    <p className="text-sm text-slate-400">{task.contact_name}</p>
                  </div>
                  <div className="text-right">
                    <Badge className={task.priority === 'high' ? 'bg-red-500/10 text-red-400' : 'bg-slate-700'}>
                      {task.task_type}
                    </Badge>
                    <p className="text-xs text-slate-400 mt-1">
                      {task.due_date ? new Date(task.due_date).toLocaleDateString() : 'No date'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}