import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Hash, TrendingUp, Plus, Search, Trash2, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function Hashtags() {
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  const { data: hashtags = [] } = useQuery({
    queryKey: ['hashtags'],
    queryFn: () => base44.entities.Hashtag.list('-avg_engagement'),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Hashtag.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hashtags'] });
      toast.success('Hashtag removed');
    },
  });

  const filteredHashtags = hashtags.filter(h => 
    h.tag?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const trendingHashtags = hashtags.filter(h => h.trend_status === 'rising').slice(0, 10);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Hashtag Research</h1>
          <p className="text-slate-400 mt-1">Discover and track trending hashtags</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <div className="relative mb-6">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search hashtags..."
                className="pl-10 bg-slate-800/50 border-slate-700 text-white"
              />
            </div>

            <div className="space-y-3">
              {filteredHashtags.map((hashtag) => (
                <div
                  key={hashtag.id}
                  className="p-4 rounded-xl bg-slate-800/50 hover:bg-slate-800 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-violet-500/10 flex items-center justify-center">
                        <Hash className="w-5 h-5 text-violet-400" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium">#{hashtag.tag}</h3>
                        <p className="text-sm text-slate-400">{hashtag.category || 'General'}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteMutation.mutate(hashtag.id)}
                      className="text-slate-400 hover:text-rose-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-2 rounded-lg bg-slate-900/50">
                      <p className="text-xs text-slate-500">Posts</p>
                      <p className="text-sm font-semibold text-white">{hashtag.post_count || 0}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-900/50">
                      <p className="text-xs text-slate-500">Engagement</p>
                      <p className="text-sm font-semibold text-white">{hashtag.avg_engagement || 0}%</p>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-900/50">
                      <p className="text-xs text-slate-500">Trend</p>
                      <Badge className={cn(
                        "text-xs",
                        hashtag.trend_status === 'rising' && "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
                        hashtag.trend_status === 'stable' && "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
                        hashtag.trend_status === 'declining' && "bg-slate-500/10 text-slate-400 border-slate-500/20"
                      )}>
                        {hashtag.trend_status || 'stable'}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}

              {filteredHashtags.length === 0 && (
                <div className="text-center py-12 text-slate-500">
                  <Hash className="w-12 h-12 mx-auto mb-3 opacity-20" />
                  <p>No hashtags found</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-white">Trending Now</h3>
            </div>
            <div className="space-y-2">
              {trendingHashtags.map((hashtag) => (
                <div
                  key={hashtag.id}
                  className="p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-white font-medium">#{hashtag.tag}</span>
                    <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-xs">
                      {hashtag.avg_engagement || 0}%
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}