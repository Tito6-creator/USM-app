import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Plus,
  TrendingUp,
  TrendingDown,
  Users,
  Heart,
  MessageSquare,
  MoreVertical,
  Trash2,
  ExternalLink,
  BarChart3,
  Clock,
  Hash,
  Target,
  Sparkles,
  ChevronLeft
} from 'lucide-react';
import CompetitorAIInsights from '@/components/competitors/CompetitorAIInsights';
import TrendMonitor from '@/components/competitors/TrendMonitor';
import AICompetitorAnalyzer from '@/components/competitors/AICompetitorAnalyzer';
import CompetitorDashboard from '@/components/competitors/CompetitorDashboard';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';

function formatNumber(num) {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num?.toString() || '0';
}

export default function Competitors() {
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedCompetitor, setSelectedCompetitor] = useState(null);
  const [analyzeCompetitor, setAnalyzeCompetitor] = useState(null);
  const [showTrendMonitor, setShowTrendMonitor] = useState(false);
  const [showAIAnalyzer, setShowAIAnalyzer] = useState(false);
  const [viewDashboard, setViewDashboard] = useState(null);
  const [newCompetitor, setNewCompetitor] = useState({
    name: '',
    platform: 'instagram',
    username: '',
    profile_url: ''
  });
  
  const queryClient = useQueryClient();

  const { data: competitors = [] } = useQuery({
    queryKey: ['competitors'],
    queryFn: () => base44.entities.Competitor.list('-followers_count'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Competitor.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competitors'] });
      setIsAddOpen(false);
      setNewCompetitor({ name: '', platform: 'instagram', username: '', profile_url: '' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Competitor.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['competitors'] });
      setSelectedCompetitor(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Competitor.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['competitors'] }),
  });

  // Dashboard View
  if (viewDashboard) {
    return (
      <CompetitorDashboard 
        competitor={viewDashboard} 
        onBack={() => setViewDashboard(null)}
        allCompetitors={competitors}
      />
    );
  }

  // AI Analyzer View
  if (showAIAnalyzer) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setShowAIAnalyzer(false)}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Competitors
        </button>
        
        <AICompetitorAnalyzer competitors={competitors} />
      </div>
    );
  }

  // Trend Monitor View
  if (showTrendMonitor) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setShowTrendMonitor(false)}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Competitors
        </button>
        
        <TrendMonitor competitors={competitors} />
      </div>
    );
  }

  // AI Analysis View
  if (analyzeCompetitor) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setAnalyzeCompetitor(null)}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to Competitors
        </button>
        
        <CompetitorAIInsights 
          competitor={analyzeCompetitor}
          onInsightsGenerated={(insights) => {
            // Save insights to competitor
            updateMutation.mutate({
              id: analyzeCompetitor.id,
              data: {
                content_themes: insights.trending_topics?.map(t => t.topic) || [],
                notes: insights.key_takeaway
              }
            });
          }}
        />
      </div>
    );
  }

  const handleSubmit = () => {
    if (!newCompetitor.name || !newCompetitor.username) return;
    createMutation.mutate(newCompetitor);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Competitor Analysis</h1>
          <p className="text-slate-400 mt-1">Monitor and analyze your competition</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button
            onClick={() => setShowAIAnalyzer(true)}
            disabled={competitors.length === 0}
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            AI Analyzer
          </Button>
          <Button
            onClick={() => setShowTrendMonitor(true)}
            className="bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700"
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            Trend Monitor
          </Button>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="border-slate-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Competitor
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-slate-900 border-slate-800">
            <DialogHeader>
              <DialogTitle className="text-white">Add Competitor</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <Label className="text-slate-300">Name</Label>
                <Input
                  value={newCompetitor.name}
                  onChange={(e) => setNewCompetitor({ ...newCompetitor, name: e.target.value })}
                  placeholder="Competitor name"
                  className="bg-slate-800/50 border-slate-700 mt-2"
                />
              </div>
              <div>
                <Label className="text-slate-300">Platform</Label>
                <Select 
                  value={newCompetitor.platform} 
                  onValueChange={(v) => setNewCompetitor({ ...newCompetitor, platform: v })}
                >
                  <SelectTrigger className="bg-slate-800/50 border-slate-700 mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-900 border-slate-800">
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="tiktok">TikTok</SelectItem>
                    <SelectItem value="youtube">YouTube</SelectItem>
                    <SelectItem value="linkedin">LinkedIn</SelectItem>
                    <SelectItem value="twitter">Twitter</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-slate-300">Username</Label>
                <Input
                  value={newCompetitor.username}
                  onChange={(e) => setNewCompetitor({ ...newCompetitor, username: e.target.value })}
                  placeholder="@username"
                  className="bg-slate-800/50 border-slate-700 mt-2"
                />
              </div>
              <div>
                <Label className="text-slate-300">Profile URL (optional)</Label>
                <Input
                  value={newCompetitor.profile_url}
                  onChange={(e) => setNewCompetitor({ ...newCompetitor, profile_url: e.target.value })}
                  placeholder="https://..."
                  className="bg-slate-800/50 border-slate-700 mt-2"
                />
              </div>
              <Button 
                onClick={handleSubmit}
                disabled={createMutation.isPending}
                className="w-full bg-violet-600 hover:bg-violet-700"
              >
                Add Competitor
              </Button>
            </div>
          </DialogContent>
          </Dialog>
        </div>
      </div>

      {competitors.length === 0 ? (
        <div className="rounded-2xl bg-slate-900/50 border border-slate-800/50 p-12 text-center">
          <Target className="w-16 h-16 mx-auto text-slate-600 mb-4" />
          <h3 className="text-lg font-semibold text-white mb-2">No competitors added</h3>
          <p className="text-slate-400 mb-6">Start tracking your competition to gain insights</p>
          <Button onClick={() => setIsAddOpen(true)} className="bg-violet-600 hover:bg-violet-700">
            <Plus className="w-4 h-4 mr-2" />
            Add Your First Competitor
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {competitors.map((competitor) => (
            <div
              key={competitor.id}
              className={cn(
                "rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden",
                "hover:border-slate-700/50 transition-all cursor-pointer"
              )}
              onClick={() => setSelectedCompetitor(competitor)}
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-14 h-14">
                      <AvatarImage src={competitor.profile_image} />
                      <AvatarFallback className="bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white text-lg">
                        {competitor.name?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-white">{competitor.name}</h3>
                      <div className="flex items-center gap-2 text-sm text-slate-400">
                        <span>@{competitor.username}</span>
                        <PlatformIcon platform={competitor.platform} size="xs" />
                      </div>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="text-slate-400">
                        <MoreVertical className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem 
                        onClick={(e) => {
                          e.stopPropagation();
                          setViewDashboard(competitor);
                        }}
                      >
                        <BarChart3 className="w-4 h-4 mr-2" />
                        View Dashboard
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={(e) => {
                          e.stopPropagation();
                          setAnalyzeCompetitor(competitor);
                        }}
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        AI Analysis
                      </DropdownMenuItem>
                      {competitor.profile_url && (
                        <DropdownMenuItem asChild>
                          <a href={competitor.profile_url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="w-4 h-4 mr-2" />
                            View Profile
                          </a>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem 
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteMutation.mutate(competitor.id);
                        }}
                        className="text-rose-400"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Remove
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center p-3 rounded-xl bg-slate-800/50">
                    <Users className="w-5 h-5 mx-auto text-violet-400 mb-1" />
                    <p className="text-lg font-bold text-white">{formatNumber(competitor.followers_count)}</p>
                    <p className="text-xs text-slate-500">Followers</p>
                  </div>
                  <div className="text-center p-3 rounded-xl bg-slate-800/50">
                    <Heart className="w-5 h-5 mx-auto text-rose-400 mb-1" />
                    <p className="text-lg font-bold text-white">{formatNumber(competitor.avg_likes)}</p>
                    <p className="text-xs text-slate-500">Avg Likes</p>
                  </div>
                  <div className="text-center p-3 rounded-xl bg-slate-800/50">
                    <BarChart3 className="w-5 h-5 mx-auto text-emerald-400 mb-1" />
                    <p className="text-lg font-bold text-white">{competitor.engagement_rate || 0}%</p>
                    <p className="text-xs text-slate-500">Eng. Rate</p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                  <div className="flex items-center gap-1">
                    {competitor.growth_rate >= 0 ? (
                      <TrendingUp className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-rose-400" />
                    )}
                    <span className={cn(
                      "text-sm font-medium",
                      competitor.growth_rate >= 0 ? "text-emerald-400" : "text-rose-400"
                    )}>
                      {competitor.growth_rate || 0}% growth
                    </span>
                  </div>
                  <span className="text-xs text-slate-500">{competitor.posts_count || 0} posts</span>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setViewDashboard(competitor);
                    }}
                    className="text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
                  >
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setAnalyzeCompetitor(competitor);
                    }}
                    className="text-violet-400 hover:text-violet-300 hover:bg-violet-500/10"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    AI Analysis
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Competitor Detail Dialog */}
      <Dialog open={!!selectedCompetitor} onOpenChange={() => setSelectedCompetitor(null)}>
        <DialogContent className="bg-slate-900 border-slate-800 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-3">
              {selectedCompetitor && (
                <>
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={selectedCompetitor.profile_image} />
                    <AvatarFallback className="bg-violet-600 text-white">
                      {selectedCompetitor.name?.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  {selectedCompetitor.name}
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          
          {selectedCompetitor && (
            <Tabs defaultValue="overview" className="mt-4">
              <TabsList className="bg-slate-800/50 w-full">
                <TabsTrigger value="overview" className="flex-1">Overview</TabsTrigger>
                <TabsTrigger value="content" className="flex-1">Content</TabsTrigger>
                <TabsTrigger value="hashtags" className="flex-1">Hashtags</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <p className="text-sm text-slate-400 mb-1">Followers</p>
                    <p className="text-2xl font-bold text-white">{formatNumber(selectedCompetitor.followers_count)}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <p className="text-sm text-slate-400 mb-1">Following</p>
                    <p className="text-2xl font-bold text-white">{formatNumber(selectedCompetitor.following_count)}</p>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <p className="text-sm text-slate-400 mb-1">Avg Engagement</p>
                    <p className="text-2xl font-bold text-white">{selectedCompetitor.engagement_rate || 0}%</p>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <p className="text-sm text-slate-400 mb-1">Total Posts</p>
                    <p className="text-2xl font-bold text-white">{selectedCompetitor.posts_count || 0}</p>
                  </div>
                </div>
                
                {selectedCompetitor.posting_frequency && (
                  <div className="p-4 rounded-xl bg-slate-800/50">
                    <div className="flex items-center gap-2 mb-2">
                      <Clock className="w-4 h-4 text-violet-400" />
                      <span className="text-sm text-slate-400">Posting Frequency</span>
                    </div>
                    <p className="text-white">{selectedCompetitor.posting_frequency}</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="content" className="mt-4">
                <div className="space-y-4">
                  {selectedCompetitor.content_themes?.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {selectedCompetitor.content_themes.map((theme, i) => (
                        <Badge key={i} className="bg-violet-500/10 text-violet-400 border-violet-500/20">
                          {theme}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 text-center py-8">No content themes tracked yet</p>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="hashtags" className="mt-4">
                <div className="space-y-4">
                  {selectedCompetitor.top_hashtags?.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {selectedCompetitor.top_hashtags.map((tag, i) => (
                        <Badge key={i} variant="outline" className="border-slate-700 text-slate-300">
                          <Hash className="w-3 h-3 mr-1" />
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 text-center py-8">No hashtags tracked yet</p>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}