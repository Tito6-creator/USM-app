import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Plus, 
  Search, 
  Mail, 
  Phone, 
  Building2,
  Filter,
  MoreVertical,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';
import ContactModal from '@/components/crm/ContactModal';
import ContactDetailModal from '@/components/crm/ContactDetailModal';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const statusColors = {
  lead: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  demo: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  trial: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  client: 'bg-green-500/10 text-green-400 border-green-500/20',
  churn_risk: 'bg-red-500/10 text-red-400 border-red-500/20'
};

const statusLabels = {
  lead: 'Lead',
  demo: 'Demo',
  trial: 'Trial',
  client: 'Client',
  churn_risk: 'Churn Risk'
};

export default function Contacts() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [tagFilter, setTagFilter] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [viewingContact, setViewingContact] = useState(null);

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => base44.entities.Contact.list('-created_date'),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Contact.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['contacts']);
      toast.success('Contact deleted');
    },
  });

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = contact.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         contact.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         contact.company?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || contact.status === statusFilter;
    const matchesTag = tagFilter === 'all' || contact.tags?.includes(tagFilter);
    return matchesSearch && matchesStatus && matchesTag;
  });

  const allTags = [...new Set(contacts.flatMap(c => c.tags || []))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Contacts</h1>
          <p className="text-slate-400 mt-1">Manage your clients and leads</p>
        </div>
        <Button 
          onClick={() => {
            setEditingContact(null);
            setShowModal(true);
          }}
          className="bg-violet-600 hover:bg-violet-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Contact
        </Button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[250px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search contacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-slate-800 border-slate-700 text-white"
          />
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[150px] bg-slate-800 border-slate-700 text-white">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-700">
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="lead">Lead</SelectItem>
            <SelectItem value="demo">Demo</SelectItem>
            <SelectItem value="trial">Trial</SelectItem>
            <SelectItem value="client">Client</SelectItem>
            <SelectItem value="churn_risk">Churn Risk</SelectItem>
          </SelectContent>
        </Select>

        <Select value={tagFilter} onValueChange={setTagFilter}>
          <SelectTrigger className="w-[150px] bg-slate-800 border-slate-700 text-white">
            <SelectValue placeholder="Tags" />
          </SelectTrigger>
          <SelectContent className="bg-slate-800 border-slate-700">
            <SelectItem value="all">All Tags</SelectItem>
            {allTags.map(tag => (
              <SelectItem key={tag} value={tag}>{tag}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {['lead', 'demo', 'trial', 'client', 'churn_risk'].map(status => {
          const count = contacts.filter(c => c.status === status).length;
          return (
            <Card key={status} className="bg-slate-900/50 border-slate-800 p-4">
              <div className="text-2xl font-bold text-white">{count}</div>
              <div className={`text-sm mt-1 ${statusColors[status]}`}>
                {statusLabels[status]}
              </div>
            </Card>
          );
        })}
      </div>

      {/* Contacts Grid */}
      {isLoading ? (
        <div className="text-center text-slate-400 py-12">Loading contacts...</div>
      ) : filteredContacts.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-slate-400">No contacts found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredContacts.map(contact => (
            <Card key={contact.id} className="bg-slate-900/50 border-slate-800 p-4 hover:bg-slate-900/70 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={contact.avatar} />
                    <AvatarFallback className="bg-violet-600 text-white">
                      {contact.name?.charAt(0) || '?'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="text-white font-medium">{contact.name}</h3>
                    {contact.company && (
                      <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                        <Building2 className="w-3 h-3" />
                        {contact.company}
                      </p>
                    )}
                  </div>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-slate-800 border-slate-700">
                    <DropdownMenuItem onClick={() => setViewingContact(contact)}>
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => {
                      setEditingContact(contact);
                      setShowModal(true);
                    }}>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => deleteMutation.mutate(contact.id)}
                      className="text-red-400"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="space-y-2 mb-3">
                {contact.email && (
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Mail className="w-3 h-3" />
                    {contact.email}
                  </div>
                )}
                {contact.phone && (
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Phone className="w-3 h-3" />
                    {contact.phone}
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between">
                <Badge className={statusColors[contact.status]}>
                  {statusLabels[contact.status]}
                </Badge>

                <div className="flex gap-1">
                  {contact.tags?.slice(0, 2).map((tag, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {contact.tags?.length > 2 && (
                    <Badge variant="outline" className="text-xs">
                      +{contact.tags.length - 2}
                    </Badge>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <ContactModal
        open={showModal}
        onClose={() => {
          setShowModal(false);
          setEditingContact(null);
        }}
        contact={editingContact}
      />

      <ContactDetailModal
        contact={viewingContact}
        onClose={() => setViewingContact(null)}
      />
    </div>
  );
}