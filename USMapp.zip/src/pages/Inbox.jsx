import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { format } from 'date-fns';
import {
  Search,
  Star,
  StarOff,
  Check,
  CheckCheck,
  Send,
  MoreVertical,
  Trash2,
  Tag,
  Filter,
  MessageCircle,
  AtSign,
  MessageSquare,
  Reply,
  Sparkles,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import AIResponseSuggestions from '@/components/inbox/AIResponseSuggestions';
import SentimentTracker from '@/components/monitoring/SentimentTracker';
import CrisisDetection from '@/components/monitoring/CrisisDetection';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import PlatformIcon from '@/components/ui/PlatformIcon';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from '@/components/ui/tabs';

const sentimentColors = {
  positive: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  neutral: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  negative: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
};

const typeIcons = {
  dm: MessageCircle,
  comment: MessageSquare,
  mention: AtSign,
  reply: Reply,
};

export default function Inbox() {
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterPlatform, setFilterPlatform] = useState('all');
  const [activeTab, setActiveTab] = useState('inbox');
  
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['messages'],
    queryFn: () => base44.entities.Message.list('-created_date'),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Message.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['messages'] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Message.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
      setSelectedMessage(null);
    },
  });

  const filteredMessages = messages.filter(msg => {
    const matchesSearch = msg.content?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         msg.sender_name?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || msg.message_type === filterType;
    const matchesPlatform = filterPlatform === 'all' || msg.platform === filterPlatform;
    return matchesSearch && matchesType && matchesPlatform;
  });

  const unreadCount = messages.filter(m => !m.is_read).length;
  const starredCount = messages.filter(m => m.is_starred).length;

  const handleSelectMessage = (msg) => {
    setSelectedMessage(msg);
    if (!msg.is_read) {
      updateMutation.mutate({ id: msg.id, data: { is_read: true } });
    }
  };

  const toggleStar = (msg, e) => {
    e.stopPropagation();
    updateMutation.mutate({ id: msg.id, data: { is_starred: !msg.is_starred } });
  };

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-white">Unified Inbox</h1>
          <p className="text-slate-400 mt-1">
            {unreadCount} unread • {starredCount} starred
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search messages..."
              className="pl-10 w-64 bg-slate-900/50 border-slate-700"
            />
          </div>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
        <TabsList className="bg-slate-800/50 mb-6">
          <TabsTrigger value="inbox" className="data-[state=active]:bg-violet-600">
            <MessageCircle className="w-4 h-4 mr-2" />
            Messages
          </TabsTrigger>
          <TabsTrigger value="sentiment" className="data-[state=active]:bg-violet-600">
            <TrendingUp className="w-4 h-4 mr-2" />
            Sentiment Tracking
          </TabsTrigger>
          <TabsTrigger value="crisis" className="data-[state=active]:bg-violet-600">
            <AlertTriangle className="w-4 h-4 mr-2" />
            Crisis Detection
          </TabsTrigger>
        </TabsList>

        <TabsContent value="inbox" className="flex-1 min-h-0 mt-0">
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-0">
        {/* Message List */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden flex flex-col">
          <div className="p-4 border-b border-slate-800">
            <Tabs defaultValue="all" onValueChange={setFilterType}>
              <TabsList className="w-full bg-slate-800/50">
                <TabsTrigger value="all" className="flex-1 data-[state=active]:bg-violet-600">All</TabsTrigger>
                <TabsTrigger value="dm" className="flex-1 data-[state=active]:bg-violet-600">DMs</TabsTrigger>
                <TabsTrigger value="comment" className="flex-1 data-[state=active]:bg-violet-600">Comments</TabsTrigger>
                <TabsTrigger value="mention" className="flex-1 data-[state=active]:bg-violet-600">Mentions</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <ScrollArea className="flex-1">
            <div className="divide-y divide-slate-800">
              {filteredMessages.length === 0 ? (
                <div className="p-8 text-center text-slate-500">
                  No messages found
                </div>
              ) : (
                filteredMessages.map((msg) => {
                  const TypeIcon = typeIcons[msg.message_type] || MessageCircle;
                  
                  return (
                    <div
                      key={msg.id}
                      onClick={() => handleSelectMessage(msg)}
                      className={cn(
                        "p-4 cursor-pointer transition-colors",
                        selectedMessage?.id === msg.id ? "bg-violet-500/10" : "hover:bg-slate-800/50",
                        !msg.is_read && "bg-slate-800/30"
                      )}
                    >
                      <div className="flex items-start gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={msg.sender_avatar} />
                          <AvatarFallback className="bg-slate-700 text-white">
                            {msg.sender_name?.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center gap-2">
                              <span className={cn(
                                "font-medium truncate",
                                !msg.is_read ? "text-white" : "text-slate-300"
                              )}>
                                {msg.sender_name}
                              </span>
                              <PlatformIcon platform={msg.platform} size="xs" />
                            </div>
                            <button onClick={(e) => toggleStar(msg, e)}>
                              {msg.is_starred ? (
                                <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                              ) : (
                                <StarOff className="w-4 h-4 text-slate-600 hover:text-slate-400" />
                              )}
                            </button>
                          </div>
                          
                          <p className={cn(
                            "text-sm line-clamp-2",
                            !msg.is_read ? "text-slate-300" : "text-slate-500"
                          )}>
                            {msg.content}
                          </p>
                          
                          <div className="flex items-center gap-2 mt-2">
                            <TypeIcon className="w-3 h-3 text-slate-500" />
                            <span className="text-xs text-slate-500">
                              {format(new Date(msg.created_date), 'MMM d, h:mm a')}
                            </span>
                            {msg.sentiment && (
                              <Badge className={cn("text-xs", sentimentColors[msg.sentiment])}>
                                {msg.sentiment}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </ScrollArea>
        </div>

        {/* Message Detail */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900/50 border border-slate-800/50 overflow-hidden flex flex-col">
          {selectedMessage ? (
            <>
              <div className="p-6 border-b border-slate-800">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={selectedMessage.sender_avatar} />
                      <AvatarFallback className="bg-slate-700 text-white">
                        {selectedMessage.sender_name?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-white">{selectedMessage.sender_name}</h3>
                      <div className="flex items-center gap-2 text-sm text-slate-400">
                        <span>@{selectedMessage.sender_username}</span>
                        <span>•</span>
                        <PlatformIcon platform={selectedMessage.platform} size="xs" showLabel />
                      </div>
                    </div>
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-slate-400">
                        <MoreVertical className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-slate-900 border-slate-800">
                      <DropdownMenuItem onClick={() => toggleStar(selectedMessage, { stopPropagation: () => {} })}>
                        <Star className="w-4 h-4 mr-2" />
                        {selectedMessage.is_starred ? 'Unstar' : 'Star'}
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => deleteMutation.mutate(selectedMessage.id)}
                        className="text-rose-400"
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>

              <ScrollArea className="flex-1 p-6">
                <div className="space-y-4">
                  <div className="rounded-xl bg-slate-800/50 p-4">
                    <p className="text-white whitespace-pre-wrap">{selectedMessage.content}</p>
                    <p className="text-xs text-slate-500 mt-3">
                      {format(new Date(selectedMessage.created_date), 'EEEE, MMMM d, yyyy at h:mm a')}
                    </p>
                  </div>

                  {selectedMessage.sentiment && (
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-slate-400">Sentiment:</span>
                      <Badge className={sentimentColors[selectedMessage.sentiment]}>
                        {selectedMessage.sentiment}
                      </Badge>
                    </div>
                  )}

                  {selectedMessage.tags?.length > 0 && (
                    <div className="flex items-center gap-2 flex-wrap">
                      <Tag className="w-4 h-4 text-slate-400" />
                      {selectedMessage.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="border-slate-700 text-slate-400">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* AI Response Suggestions */}
                  <AIResponseSuggestions
                    message={selectedMessage}
                    onSelectSuggestion={(suggestion) => setReplyText(suggestion)}
                  />
                </div>
              </ScrollArea>

              <div className="p-4 border-t border-slate-800">
                <div className="flex gap-3">
                  <Textarea
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply..."
                    className="flex-1 min-h-[80px] bg-slate-800/50 border-slate-700 text-white resize-none"
                  />
                  <Button 
                    className="bg-violet-600 hover:bg-violet-700 self-end"
                    disabled={!replyText.trim()}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-500">
              <div className="text-center">
                <MessageCircle className="w-16 h-16 mx-auto mb-4 opacity-20" />
                <p>Select a message to view details</p>
              </div>
            </div>
          )}
        </div>
          </div>
        </TabsContent>

        <TabsContent value="sentiment" className="flex-1 min-h-0 mt-0">
          <SentimentTracker />
        </TabsContent>

        <TabsContent value="crisis" className="flex-1 min-h-0 mt-0">
          <CrisisDetection />
        </TabsContent>
      </Tabs>
    </div>
  );
}